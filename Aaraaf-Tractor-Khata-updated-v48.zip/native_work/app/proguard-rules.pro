# ---- Araaf Tractor Khata: R8 নিয়ম (preview/release বিল্ডে minify চালু) ----
-keepattributes *Annotation*, InnerClasses, Signature, RuntimeVisibleAnnotations, EnclosingMethod

# kotlinx.serialization: ব্যাকআপ/সিঙ্ক JSON ও টাইপ-সেফ নেভিগেশন রুট
-keepclassmembers @kotlinx.serialization.Serializable class ** {
    *** Companion;
    *** INSTANCE;
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.example.**$$serializer { *; }
-keepclasseswithmembers class com.example.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep @kotlinx.serialization.Serializable class * { *; }

# Room এনটিটি ও DAO (কলাম-নাম বদলে গেলে ডেটা ভাঙে)
-keep class com.example.data.local.entity.** { *; }
-keep class * extends androidx.room.RoomDatabase { *; }

# WorkManager ওয়ার্কার (নাম ধরে তৈরি হয়)
-keep class com.example.worker.** extends androidx.work.ListenableWorker {
    public <init>(android.content.Context, androidx.work.WorkerParameters);
}

# ব্যাকআপ/ডোমেইন মডেল (JSON-এ ব্যবহৃত)
-keep class com.example.data.backup.** { *; }
-keep class com.example.domain.model.** { *; }

# নেটওয়ার্ক লাইব্রেরির ঐচ্ছিক ডিপেন্ডেন্সি
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-dontwarn javax.annotation.**
-dontwarn okhttp3.internal.platform.**
