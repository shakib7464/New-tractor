package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.AttachmentEntity
import com.example.data.local.entity.AuditLogEntity
import com.example.data.local.entity.BackupHistoryEntity
import com.example.data.local.entity.DeviceInformationEntity
import com.example.data.local.entity.SyncQueueEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AttachmentDao {
  @Query("SELECT * FROM attachments WHERE ownerType = :ownerType AND ownerId = :ownerId AND isDeleted = 0 ORDER BY createdAt DESC")
  fun observeByOwner(ownerType: String, ownerId: String): Flow<List<AttachmentEntity>>

  @Query("SELECT * FROM attachments WHERE isDeleted = 0")
  suspend fun getActiveAttachmentsNow(): List<AttachmentEntity>

  @Query("SELECT * FROM attachments")
  suspend fun getAllIncludingDeleted(): List<AttachmentEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(attachment: AttachmentEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(attachments: List<AttachmentEntity>)

  @Query("UPDATE attachments SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt WHERE id = :id")
  suspend fun softDelete(id: String, deletedAt: Long)

  @Query("DELETE FROM attachments WHERE id = :id")
  suspend fun hardDeleteById(id: String)

  @Query("DELETE FROM attachments")
  suspend fun deleteAll()
}

@Dao
interface AuditLogDao {
  @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 500")
  fun observeRecentLogs(): Flow<List<AuditLogEntity>>

  @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC")
  suspend fun getAllNow(): List<AuditLogEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(log: AuditLogEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(logs: List<AuditLogEntity>)

  @Query("DELETE FROM audit_logs")
  suspend fun deleteAll()
}

@Dao
interface BackupHistoryDao {
  @Query("SELECT * FROM backup_history ORDER BY createdAt DESC")
  fun observeAll(): Flow<List<BackupHistoryEntity>>

  @Query("SELECT * FROM backup_history WHERE backupType = :type AND status = 'VERIFIED' ORDER BY createdAt DESC")
  suspend fun getVerifiedByType(type: String): List<BackupHistoryEntity>

  @Query("SELECT * FROM backup_history ORDER BY createdAt DESC LIMIT 1")
  suspend fun getLatest(): BackupHistoryEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(item: BackupHistoryEntity)

  @Update
  suspend fun update(item: BackupHistoryEntity)

  @Query("DELETE FROM backup_history WHERE id = :id")
  suspend fun deleteById(id: String)
}

@Dao
interface SyncQueueDao {
  @Query("SELECT * FROM sync_queue ORDER BY createdAt DESC")
  fun observeAll(): Flow<List<SyncQueueEntity>>

  @Query("SELECT * FROM sync_queue WHERE status IN ('PENDING_SYNC', 'FAILED') ORDER BY createdAt ASC")
  suspend fun getPendingNow(): List<SyncQueueEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(item: SyncQueueEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(items: List<SyncQueueEntity>)

  @Query("UPDATE sync_queue SET status = :status, updatedAt = :now, lastError = :error WHERE id = :id")
  suspend fun updateStatus(id: String, status: String, now: Long, error: String? = null)

  @Query("DELETE FROM sync_queue")
  suspend fun deleteAll()
}

@Dao
interface DeviceInfoDao {
  @Query("SELECT * FROM device_information LIMIT 1")
  fun observeDeviceInfo(): Flow<DeviceInformationEntity?>

  @Query("SELECT * FROM device_information LIMIT 1")
  suspend fun getDeviceInfoNow(): DeviceInformationEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsert(info: DeviceInformationEntity)
}
