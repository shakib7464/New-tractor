package com.example.domain.billing

import com.example.data.local.entity.AgriculturalJobEntity
import com.example.data.local.entity.JobStatus

/**
 * নতুন কাজ/জমি চাষের ফর্মে "কাজের ধরন" আগের বার যেটা নেওয়া হয়েছিল সেটাই নিজে থেকে বসানোর জন্য।
 * আগে সেই জমির সর্বশেষ কাজ দেখা হয়; না থাকলে সেই কাস্টমারের সর্বশেষ কাজ; কিছুই না থাকলে null।
 * ব্যবহারকারী ফর্মে চাইলে এটা বদলাতে পারেন।
 */
object LastWorkTypeResolver {
  data class Choice(val workType: String, val customWorkName: String)

  private fun latest(list: List<AgriculturalJobEntity>): Choice? =
    list
      .filter { !it.isDeleted && it.status != JobStatus.CANCELLED.code }
      .maxByOrNull { it.createdAt }
      ?.let { Choice(it.workType, it.customWorkName) }

  fun resolve(jobs: List<AgriculturalJobEntity>, customerId: String?, landId: String?): Choice? {
    if (!landId.isNullOrBlank()) {
      latest(jobs.filter { it.landId == landId })?.let { return it }
    }
    if (!customerId.isNullOrBlank()) {
      latest(jobs.filter { it.customerId == customerId })?.let { return it }
    }
    return null
  }
}
