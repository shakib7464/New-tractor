package com.example.data.local.entity

enum class LandUnit(val code: String) {
  DECIMAL("DECIMAL"),
  KATHA("KATHA"),
  BIGHA("BIGHA"),
  ACRE("ACRE"),
}

enum class WorkType(val code: String) {
  ROTAVATOR("ROTAVATOR"),
  LAND_PLOUGHING("LAND_PLOUGHING"),
  HARROWING("HARROWING"),
  LAND_PREPARATION("LAND_PREPARATION"),
  CUSTOM("CUSTOM"),
}

enum class BillingMethod(val code: String) {
  PER_DECIMAL("PER_DECIMAL"),
  PER_KATHA("PER_KATHA"),
  PER_BIGHA("PER_BIGHA"),
  PER_ACRE("PER_ACRE"),
  PER_HOUR("PER_HOUR"),
  FIXED_AMOUNT("FIXED_AMOUNT"),
  CUSTOM_AMOUNT("CUSTOM_AMOUNT"),
}

enum class JobStatus(val code: String) {
  PENDING("PENDING"),
  IN_PROGRESS("IN_PROGRESS"),
  COMPLETED("COMPLETED"),
  CANCELLED("CANCELLED"),
}

enum class TransactionType(val code: String) {
  OPENING_BALANCE("OPENING_BALANCE"),
  WORK_CHARGE("WORK_CHARGE"),
  ADDITIONAL_CHARGE("ADDITIONAL_CHARGE"),
  DISCOUNT("DISCOUNT"),
  PAYMENT("PAYMENT"),
  ADVANCE_RECEIVED("ADVANCE_RECEIVED"),
  ADVANCE_ADJUSTMENT("ADVANCE_ADJUSTMENT"),
  REFUND("REFUND"),
  MANUAL_ADJUSTMENT("MANUAL_ADJUSTMENT"),
}

enum class PaymentMethod(val code: String) {
  CASH("CASH"),
  BANK("BANK"),
  BKASH("BKASH"),
  NAGAD("NAGAD"),
  OTHER("OTHER"),
}

enum class PaymentTargetType(val code: String) {
  LAND("LAND"),
  JOB("JOB"),
  OUTSTANDING_BALANCE("OUTSTANDING_BALANCE"),
  ADVANCE("ADVANCE"),
}

enum class AdvanceEntryType(val code: String) {
  RECEIVED("RECEIVED"),
  ADJUSTED("ADJUSTED"),
  REFUNDED("REFUNDED"),
}

enum class AttachmentOwnerType(val code: String) {
  CUSTOMER("CUSTOMER"),
  LAND("LAND"),
  JOB("JOB"),
  PAYMENT("PAYMENT"),
}

enum class SyncStatus(val code: String) {
  LOCAL_ONLY("LOCAL_ONLY"),
  PENDING_SYNC("PENDING_SYNC"),
  SYNCED("SYNCED"),
  CONFLICT("CONFLICT"),
}

enum class BackupType(val code: String) {
  LOCAL_JSON("LOCAL_JSON"),
  GOOGLE_DRIVE("GOOGLE_DRIVE"),
  SAFETY_PRE_RESTORE("SAFETY_PRE_RESTORE"),
}

enum class BackupStatus(val code: String) {
  PENDING("PENDING"),
  UPLOADING("UPLOADING"),
  VERIFIED("VERIFIED"),
  FAILED("FAILED"),
}
