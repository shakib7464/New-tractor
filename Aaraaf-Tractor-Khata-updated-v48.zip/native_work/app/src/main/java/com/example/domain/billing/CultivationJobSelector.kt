package com.example.domain.billing

import com.example.data.local.entity.AgriculturalJobEntity
import com.example.data.local.entity.BillingMethod
import com.example.data.local.entity.JobStatus
import com.example.data.local.entity.WorkType

/**
 * একটি জমির "প্রথম চাষের বিল" কোনটা তা ঠিক করে। জমি এডিটের সময় রেট/কয়বার চাষ এই কাজেই বসে।
 *
 * আগে শুধু "সবচেয়ে পুরোনো কাঠা-ভিত্তিক কাজ" ধরা হতো, ফলে সেটা অন্য ধরনের কাজ (যেমন মই/হ্যারোইং)
 * হলে ভুল কাজের বিল বদলে যেত। এখন আগে জমি-চাষ (LAND_PLOUGHING) ধরা হয়;
 * না থাকলে আগের নিয়মে সবচেয়ে পুরোনো কাঠা-ভিত্তিক কাজ।
 */
object CultivationJobSelector {
  fun pickPrimary(landJobs: List<AgriculturalJobEntity>): AgriculturalJobEntity? {
    val perKatha = landJobs.filter {
      !it.isDeleted &&
        it.status != JobStatus.CANCELLED.code &&
        it.billingMethod == BillingMethod.PER_KATHA.code
    }
    return perKatha
      .filter { it.workType == WorkType.LAND_PLOUGHING.code }
      .minByOrNull { it.createdAt }
      ?: perKatha.minByOrNull { it.createdAt }
  }
}
