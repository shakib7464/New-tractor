package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

object StaffPaymentCategory {
  /** হেল্পার / ড্রাইভারকে দেওয়া টাকা */
  const val HELPER_DRIVER = "HELPER_DRIVER"

  /** গাড়ির (ট্রাক্টরের) মালিককে দেওয়া টাকা */
  const val TRACTOR_OWNER = "TRACTOR_OWNER"
}

@Serializable
@Entity(tableName = "staff_payments")
data class StaffPaymentEntity(
  @PrimaryKey val id: String,
  val category: String,
  val personName: String,
  val paymentDate: Long,
  val amount: Double,
  val note: String,
  val createdAt: Long,
  val updatedAt: Long,
  val isDeleted: Boolean = false,
)
