package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

object FuelEntryType {
  const val PURCHASE = "PURCHASE"
  const val DEPOSIT = "DEPOSIT"
}

@Serializable
@Entity(tableName = "fuel_dealers")
data class FuelDealerEntity(
  @PrimaryKey val id: String,
  val name: String,
  val mobile: String,
  val createdAt: Long,
  val updatedAt: Long,
  val isDeleted: Boolean = false,
)

@Serializable
@Entity(tableName = "fuel_entries")
data class FuelEntryEntity(
  @PrimaryKey val id: String,
  val dealerId: String,
  val entryType: String,
  val entryDate: Long,
  val liters: Double,
  val ratePerLiter: Double,
  val totalAmount: Double,
  val paidAmount: Double,
  val driverName: String,
  val note: String,
  val createdAt: Long,
  val updatedAt: Long,
  val isDeleted: Boolean = false,
)
