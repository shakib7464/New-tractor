package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.CustomerEntity
import com.example.domain.billing.FormatUtils
import com.example.localization.AppStrings

@Composable
fun CustomerFormDialog(
  existing: CustomerEntity? = null,
  initialName: String = "",
  strings: AppStrings,
  onDismiss: () -> Unit,
  onSave: (
    fullName: String,
    mobileNumber: String,
    address: String,
    village: String,
    unionName: String,
    upazila: String,
    district: String,
    notes: String,
    regDate: Long,
    customRate: Double?,
  ) -> Unit,
) {
  var fullName by remember { mutableStateOf(existing?.fullName ?: initialName) }
  var mobile by remember { mutableStateOf(existing?.mobileNumber ?: "") }
  var address by remember { mutableStateOf(existing?.address ?: "") }
  var village by remember { mutableStateOf(existing?.village ?: "") }
  var unionName by remember { mutableStateOf(existing?.unionName ?: "") }
  var upazila by remember { mutableStateOf(existing?.upazila ?: "") }
  var district by remember { mutableStateOf(existing?.district ?: "") }
  var notes by remember { mutableStateOf(existing?.notes ?: "") }
  var regDateText by remember {
    mutableStateOf(FormatUtils.formatDate(existing?.registrationDate ?: System.currentTimeMillis()))
  }
  var customRateText by remember { mutableStateOf(existing?.customRatePerUnit?.toString() ?: "") }
  var errorMsg by remember { mutableStateOf<String?>(null) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(if (existing == null) strings.addCustomer else "${strings.edit}: ${existing.fullName}") },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedTextField(
          value = fullName,
          onValueChange = { fullName = it; errorMsg = null },
          label = { Text(strings.fullName) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("customer_name_input"),
        )
        OutlinedTextField(
          value = mobile,
          onValueChange = { mobile = it; errorMsg = null },
          label = { Text(strings.mobileNumber.replace("*", "").trim()) },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("customer_mobile_input"),
        )
        OutlinedTextField(
          value = village,
          onValueChange = { village = it },
          label = { Text(strings.village) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("customer_village_input"),
        )
        OutlinedTextField(
          value = regDateText,
          onValueChange = { regDateText = it },
          label = { Text(strings.registrationDate) },
          placeholder = { Text("DD-MM-YYYY") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
          value = address,
          onValueChange = { address = it },
          label = { Text(strings.address) },
          modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text(strings.notes) },
          modifier = Modifier.fillMaxWidth(),
        )
        if (errorMsg != null) {
          Text(errorMsg!!, color = androidx.compose.material3.MaterialTheme.colorScheme.error)
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (fullName.isBlank()) {
            errorMsg = "নাম আবশ্যক"
            return@Button
          }
          val regMs = FormatUtils.parseDmyDate(regDateText) ?: System.currentTimeMillis()
          onSave(
            fullName, mobile, address, village, unionName, upazila, district,
            notes, regMs, customRateText.toDoubleOrNull(),
          )
        },
        modifier = Modifier.height(48.dp).testTag("save_customer_btn"),
      ) {
        Text(strings.save)
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss, modifier = Modifier.height(48.dp)) {
        Text(strings.cancel)
      }
    },
  )
}
