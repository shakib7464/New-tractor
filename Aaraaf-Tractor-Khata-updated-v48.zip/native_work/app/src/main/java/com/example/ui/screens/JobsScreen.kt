package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddTask
import androidx.compose.material.icons.rounded.Agriculture
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.AgriculturalJobEntity
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.JobStatus
import com.example.data.local.entity.LandEntity
import com.example.domain.billing.FormatUtils
import com.example.localization.AppStrings
import com.example.ui.components.EmptyStateCard
import com.example.ui.theme.LocalLedgerColors

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun JobsScreen(
  jobs: List<AgriculturalJobEntity>,
  customers: List<CustomerEntity>,
  lands: List<LandEntity>,
  strings: AppStrings,
  currencySymbol: String,
  onAddJob: () -> Unit,
  onUpdateStatus: (jobId: String, newStatus: String) -> Unit,
  onDeleteJob: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  var statusFilter by remember { mutableStateOf<String?>(null) }
  var searchQuery by remember { mutableStateOf("") }
  val ledgerColors = LocalLedgerColors.current

  val custMap = remember(customers) { customers.associateBy { it.id } }
  val landMap = remember(lands) { lands.associateBy { it.id } }

  val filtered = remember(jobs, statusFilter, searchQuery, custMap, landMap) {
    val q = searchQuery.trim().lowercase()
    jobs
      .filter { statusFilter == null || it.status == statusFilter }
      .filter { j ->
        if (q.isEmpty()) true
        else {
          val cName = custMap[j.customerId]?.fullName?.lowercase().orEmpty()
          val lName = landMap[j.landId]?.landName?.lowercase().orEmpty()
          j.jobCode.lowercase().contains(q) || cName.contains(q) || lName.contains(q)
        }
      }
  }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    floatingActionButton = {
      FloatingActionButton(
        onClick = onAddJob,
        modifier = Modifier.testTag("jobs_add_fab"),
      ) {
        Icon(Icons.Rounded.AddTask, contentDescription = strings.addJob)
      }
    },
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Spacer(Modifier.height(4.dp))
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
        placeholder = { Text("কাজের কোড, কাস্টমার বা জমি খুঁজুন...") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
      )

      FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(
          selected = statusFilter == null,
          onClick = { statusFilter = null },
          label = { Text("${strings.allFilter} (${jobs.size})") },
        )
        JobStatus.entries.forEach { st ->
          FilterChip(
            selected = statusFilter == st.code,
            onClick = { statusFilter = st.code },
            label = { Text(strings.jobStatusLabel(st.code)) },
          )
        }
      }

      if (filtered.isEmpty()) {
        EmptyStateCard(
          icon = Icons.Rounded.Agriculture,
          message = "কোনো কৃষি কাজ পাওয়া যায়নি",
          actionLabel = strings.addJob,
          onAction = onAddJob,
        )
      } else {
        LazyColumn(
          contentPadding = PaddingValues(bottom = 88.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          items(filtered, key = { it.id }) { job ->
            val customer = custMap[job.customerId]
            val land = landMap[job.landId]
            var statusMenuOpen by remember { mutableStateOf(false) }

            Card(
              shape = MaterialTheme.shapes.medium,
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      "${job.jobCode} • ${strings.workTypeLabel(job.workType, job.customWorkName)}",
                      style = MaterialTheme.typography.titleSmall,
                      fontWeight = FontWeight.Bold,
                    )
                    Text(
                      "${customer?.fullName ?: "-"} → ${land?.landName ?: "-"}",
                      style = MaterialTheme.typography.bodyMedium,
                    )
                  }
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                      onClick = { statusMenuOpen = true },
                      shape = MaterialTheme.shapes.small,
                      color = MaterialTheme.colorScheme.primaryContainer,
                    ) {
                      Text(
                        strings.jobStatusLabel(job.status),
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                      )
                    }
                    DropdownMenu(expanded = statusMenuOpen, onDismissRequest = { statusMenuOpen = false }) {
                      JobStatus.entries.forEach { st ->
                        DropdownMenuItem(
                          text = { Text(strings.jobStatusLabel(st.code)) },
                          onClick = {
                            statusMenuOpen = false
                            onUpdateStatus(job.id, st.code)
                          },
                        )
                      }
                    }
                    IconButton(onClick = { onDeleteJob(job.id) }) {
                      Icon(Icons.Rounded.DeleteOutline, contentDescription = strings.delete)
                    }
                  }
                }

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Text(
                    "${FormatUtils.formatDate(job.workDate)} • ${FormatUtils.formatNumber(job.landArea)} ${strings.unitLabel(job.areaUnit)} × ${job.numberOfPasses?.coerceAtLeast(1) ?: 1} বার @ ${FormatUtils.formatTaka(job.rate, currencySymbol)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                }

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Text(
                    "${strings.totalBill}: ${FormatUtils.formatTaka(job.totalBill, currencySymbol)}",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                  )
                  Text(
                    "${strings.remainingDue}: ${FormatUtils.formatTaka(job.remainingDue, currencySymbol)}",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = if (job.remainingDue > 0.01) ledgerColors.dueColor else ledgerColors.paidColor,
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}
