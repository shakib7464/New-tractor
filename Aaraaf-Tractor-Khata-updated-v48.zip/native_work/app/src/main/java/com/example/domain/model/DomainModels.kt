package com.example.domain.model

import com.example.data.local.entity.AdvancePaymentEntity
import com.example.data.local.entity.AgriculturalJobEntity
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.LandEntity
import com.example.data.local.entity.LedgerTransactionEntity
import com.example.data.local.entity.PaymentEntity

data class LandFinancialSummary(
  val land: LandEntity,
  val openingBalance: Double,
  val workCharges: Double,
  val additionalCharges: Double,
  val discounts: Double,
  val payments: Double,
  val advanceAdjustments: Double,
  val refunds: Double,
  val manualAdjustmentsNet: Double,
  val currentBalance: Double,
  val jobs: List<AgriculturalJobEntity>,
  val transactions: List<LedgerTransactionEntity>,
)

data class CustomerFinancialSummary(
  val customer: CustomerEntity,
  val lands: List<LandFinancialSummary>,
  val jobs: List<AgriculturalJobEntity>,
  val payments: List<PaymentEntity>,
  val advanceEntries: List<AdvancePaymentEntity>,
  val allTransactions: List<LedgerTransactionEntity>,
  val openingBalance: Double,
  val totalBilled: Double,
  val totalAdditionalCharges: Double,
  val totalDiscounts: Double,
  val totalPaid: Double,
  val totalAdvanceReceived: Double,
  val totalAdvanceUsed: Double,
  val totalAdvanceRefunded: Double,
  val remainingAdvance: Double,
  val totalOutstandingBalance: Double,
)

data class DashboardSummary(
  val totalCustomers: Int,
  val totalLands: Int,
  val totalJobs: Int,
  val completedJobs: Int,
  val pendingJobs: Int,
  val totalBilledAmount: Double,
  val totalCollectedAmount: Double,
  val totalOutstandingAmount: Double,
  val totalAdvanceReceived: Double,
  val totalRemainingAdvance: Double,
  val todaysJobCount: Int,
  val todaysBilledAmount: Double,
  val todaysCollectionAmount: Double,
  val monthlyBilledAmount: Double,
  val monthlyCollectionAmount: Double,
  val recentActivities: List<ActivityFeedItem>,
)

data class ActivityFeedItem(
  val id: String,
  val title: String,
  val subtitle: String,
  val amount: Double?,
  val timestamp: Long,
  val type: ActivityType,
)

enum class ActivityType {
  JOB,
  PAYMENT,
  ADVANCE,
  CUSTOMER,
  LAND,
  ADJUSTMENT,
}

data class BulkPrintFilter(
  val selectedCustomerIds: Set<String> = emptySet(), // empty = ALL customers
  val selectedLandIds: Set<String> = emptySet(), // empty = ALL lands
  val startDateMillis: Long? = null,
  val endDateMillis: Long? = null,
  val onlyWithOutstandingDues: Boolean = false,
)

data class BulkConsolidatedSummary(
  val totalCustomers: Int,
  val totalLands: Int,
  val totalJobs: Int,
  val totalBilledAmount: Double,
  val totalAdditionalCharges: Double,
  val totalDiscounts: Double,
  val totalPaymentsCollected: Double,
  val totalAdvancesReceived: Double,
  val totalAdvanceAdjustments: Double,
  val totalOutstandingAmount: Double,
)

enum class ReportPeriod {
  DAILY,
  WEEKLY,
  MONTHLY,
  YEARLY,
  ALL_TIME,
  CUSTOM,
}

enum class ReportCategory {
  OVERVIEW,
  CUSTOMER_WISE,
  LAND_WISE,
  WORK_RECORDS,
  PAYMENT_COLLECTION,
  OUTSTANDING_DUES,
  ADVANCE_PAYMENTS,
  COMPLETED_JOBS,
  PENDING_JOBS,
}
