package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import com.example.data.local.entity.FuelDealerEntity
import com.example.data.local.entity.FuelEntryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FuelDao {
  @Query("SELECT * FROM fuel_dealers WHERE isDeleted = 0 ORDER BY name COLLATE NOCASE ASC")
  fun observeDealers(): Flow<List<FuelDealerEntity>>

  @Query("SELECT * FROM fuel_entries WHERE isDeleted = 0 ORDER BY entryDate DESC, createdAt DESC")
  fun observeEntries(): Flow<List<FuelEntryEntity>>

  @Query("SELECT * FROM fuel_dealers")
  suspend fun getAllDealersIncludingDeleted(): List<FuelDealerEntity>

  @Query("SELECT * FROM fuel_entries")
  suspend fun getAllEntriesIncludingDeleted(): List<FuelEntryEntity>

  @Query("SELECT COUNT(*) FROM fuel_entries WHERE dealerId = :dealerId AND isDeleted = 0")
  suspend fun countActiveEntriesForDealer(dealerId: String): Int

  @Upsert
  suspend fun upsertDealer(dealer: FuelDealerEntity)

  @Upsert
  suspend fun upsertEntry(entry: FuelEntryEntity)

  @Upsert
  suspend fun upsertAllDealers(dealers: List<FuelDealerEntity>)

  @Upsert
  suspend fun upsertAllEntries(entries: List<FuelEntryEntity>)

  @Query("DELETE FROM fuel_dealers")
  suspend fun deleteAllDealers()

  @Query("DELETE FROM fuel_entries")
  suspend fun deleteAllEntries()
}
