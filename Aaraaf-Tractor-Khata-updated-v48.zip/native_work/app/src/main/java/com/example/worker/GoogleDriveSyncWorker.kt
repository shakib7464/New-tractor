package com.example.worker

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.data.backup.SyncAccountMismatchException
import com.example.data.backup.SyncRepository
import com.example.data.local.AraafDatabase
import com.example.data.preferences.AppPreferencesManager
import java.util.concurrent.TimeUnit

/** ব্যাকগ্রাউন্ডে Google Drive-এর সাথে খাতার ডেটা মেলায়। নেট না থাকলে নেট আসা পর্যন্ত অপেক্ষা করে। */
class GoogleDriveSyncWorker(
  appContext: Context,
  workerParams: WorkerParameters,
) : CoroutineWorker(appContext, workerParams) {

  override suspend fun doWork(): Result {
    val db = AraafDatabase.getInstance(applicationContext)
    val prefs = AppPreferencesManager(applicationContext)
    val settings = prefs.getSettingsNow()
    if (settings.driveAccountEmail.isNullOrBlank()) return Result.success()

    val result = SyncRepository(applicationContext, db, prefs).syncNow()
    return if (result.isSuccess) {
      Result.success()
    } else if (result.exceptionOrNull() is SyncAccountMismatchException) {
      Result.failure()
    } else if (runAttemptCount < 5) {
      Result.retry()
    } else {
      Result.failure()
    }
  }

  companion object {
    private const val UNIQUE_PERIODIC_NAME = "araaf_drive_periodic_sync"
    private const val UNIQUE_PENDING_NAME = "araaf_drive_pending_sync"

    private fun networkConstraints() = Constraints.Builder()
      .setRequiredNetworkType(NetworkType.CONNECTED)
      .build()

    /** প্রতি ১৫ মিনিটে (অ্যান্ড্রয়েডের সর্বনিম্ন) নেট থাকলে সিঙ্ক। */
    fun schedulePeriodic(context: Context, enabled: Boolean) {
      val wm = WorkManager.getInstance(context)
      if (!enabled) {
        wm.cancelUniqueWork(UNIQUE_PERIODIC_NAME)
        wm.cancelUniqueWork(UNIQUE_PENDING_NAME)
        return
      }
      val request = PeriodicWorkRequestBuilder<GoogleDriveSyncWorker>(15, TimeUnit.MINUTES)
        .setConstraints(networkConstraints())
        .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 5, TimeUnit.MINUTES)
        .build()
      wm.enqueueUniquePeriodicWork(UNIQUE_PERIODIC_NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
    }

    /** ডেটা বদলের পরে অল্প দেরিতে সিঙ্ক। পরপর কয়েকটা বদল হলে একসাথে একবারই চলে। */
    fun enqueueSoon(context: Context) {
      val request = OneTimeWorkRequestBuilder<GoogleDriveSyncWorker>()
        .setConstraints(networkConstraints())
        .setInitialDelay(5, TimeUnit.SECONDS)
        .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 1, TimeUnit.MINUTES)
        .build()
      WorkManager.getInstance(context).enqueueUniqueWork(
        UNIQUE_PENDING_NAME,
        ExistingWorkPolicy.REPLACE,
        request,
      )
    }
  }
}
