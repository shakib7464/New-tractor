package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlin.math.hypot

/** প্যাটার্ন (নোডের ক্রম) স্টোর/হ্যাশ করার জন্য স্ট্রিং, যেমন [0,1,4,7] -> "0147" */
fun patternToSecret(nodes: List<Int>): String = nodes.joinToString("")

const val PATTERN_MIN_DOTS = 4

/**
 * ৩×৩ প্যাটার্ন প্যাড। আঙুল তুললে [onPatternComplete] কল হয়।
 * [resetKey] বদলালে বা নতুন করে আঁকা শুরু করলে আগের প্যাটার্ন মুছে যায়।
 */
@Composable
fun PatternLockPad(
  modifier: Modifier = Modifier,
  resetKey: Any? = null,
  isError: Boolean = false,
  onPatternStart: () -> Unit = {},
  onPatternComplete: (List<Int>) -> Unit,
) {
  val selected = remember { mutableStateListOf<Int>() }
  var current by remember { mutableStateOf<Offset?>(null) }
  val latestComplete by rememberUpdatedState(onPatternComplete)
  val latestStart by rememberUpdatedState(onPatternStart)

  LaunchedEffect(resetKey) { selected.clear(); current = null }

  val activeColor = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
  val idle = MaterialTheme.colorScheme.outline

  Canvas(
    modifier = modifier
      .fillMaxWidth()
      .aspectRatio(1f)
      .pointerInput(Unit) {
        val cell = size.width / 3f
        fun center(i: Int) = Offset((i % 3 + 0.5f) * cell, (i / 3 + 0.5f) * cell)
        fun hit(p: Offset) {
          for (i in 0..8) {
            if (i in selected) continue
            val c = center(i)
            if (hypot(p.x - c.x, p.y - c.y) <= cell * 0.3f) {
              if (selected.isNotEmpty()) {
                val l = selected.last()
                val r1 = l / 3; val c1 = l % 3; val r2 = i / 3; val c2 = i % 3
                // মাঝের নোড পেরিয়ে গেলে (যেমন ১→৩) সেটাও যোগ হবে
                if ((r1 + r2) % 2 == 0 && (c1 + c2) % 2 == 0) {
                  val mid = ((r1 + r2) / 2) * 3 + (c1 + c2) / 2
                  if (mid !in selected) selected.add(mid)
                }
              }
              selected.add(i)
              break
            }
          }
        }
        fun finish() {
          current = null
          if (selected.isNotEmpty()) latestComplete(selected.toList())
        }
        detectDragGestures(
          onDragStart = { o -> selected.clear(); latestStart(); current = o; hit(o) },
          onDrag = { change, _ -> current = change.position; hit(change.position) },
          onDragEnd = { finish() },
          onDragCancel = { finish() },
        )
      },
  ) {
    val cell = size.width / 3f
    fun center(i: Int) = Offset((i % 3 + 0.5f) * cell, (i / 3 + 0.5f) * cell)
    val w = 6.dp.toPx()
    for (k in 0 until selected.size - 1) {
      drawLine(activeColor, center(selected[k]), center(selected[k + 1]), strokeWidth = w, cap = StrokeCap.Round)
    }
    val cur = current
    if (cur != null && selected.isNotEmpty()) {
      drawLine(activeColor, center(selected.last()), cur, strokeWidth = w, cap = StrokeCap.Round)
    }
    for (i in 0..8) {
      val on = i in selected
      drawCircle(if (on) activeColor else idle, radius = 8.dp.toPx(), center = center(i))
      if (on) drawCircle(activeColor.copy(alpha = 0.25f), radius = 22.dp.toPx(), center = center(i))
    }
  }
}
