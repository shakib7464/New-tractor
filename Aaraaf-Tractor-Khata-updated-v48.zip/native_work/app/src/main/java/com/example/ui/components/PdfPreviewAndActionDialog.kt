package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.NavigateBefore
import androidx.compose.material.icons.automirrored.rounded.NavigateNext
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.export.PdfPrintHelper
import com.example.localization.AppStrings
import com.example.ui.PdfGenerationUiState
import java.io.File

@Composable
fun PdfStateHostDialog(
  pdfState: PdfGenerationUiState,
  strings: AppStrings,
  onCancel: () -> Unit,
  onDismiss: () -> Unit,
  onSavedLocallyMessage: (String) -> Unit,
) {
  when (pdfState) {
    PdfGenerationUiState.Idle -> Unit
    is PdfGenerationUiState.Generating -> {
      AlertDialog(
        onDismissRequest = {},
        title = { Text(strings.generatingPdfProgress) },
        text = {
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            val fraction = if (pdfState.total > 0) pdfState.processed.toFloat() / pdfState.total else 0f
            LinearProgressIndicator(progress = { fraction.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
            Text("${pdfState.processed} / ${pdfState.total} কাস্টমার প্রক্রিয়াধীন...")
          }
        },
        confirmButton = {
          TextButton(onClick = onCancel, modifier = Modifier.testTag("cancel_pdf_button")) {
            Text(strings.cancel)
          }
        },
      )
    }
    is PdfGenerationUiState.Error -> {
      AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("PDF তৈরি ব্যর্থ") },
        text = { Text(pdfState.message) },
        confirmButton = {
          TextButton(onClick = onDismiss) { Text(strings.close) }
        },
      )
    }
    is PdfGenerationUiState.Ready -> {
      PdfPreviewDialog(
        file = pdfState.file,
        title = pdfState.title,
        strings = strings,
        onDismiss = onDismiss,
        onSavedLocallyMessage = onSavedLocallyMessage,
      )
    }
  }
}

@Composable
fun PdfPreviewDialog(
  file: File,
  title: String,
  strings: AppStrings,
  onDismiss: () -> Unit,
  onSavedLocallyMessage: (String) -> Unit,
) {
  val context = LocalContext.current
  var pageIndex by remember(file) { mutableIntStateOf(0) }
  var pageCount by remember(file) { mutableIntStateOf(1) }
  var renderedBitmap by remember(file) { mutableStateOf<Bitmap?>(null) }

  val saveLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.CreateDocument("application/pdf")
  ) { uri ->
    if (uri != null) {
      PdfPrintHelper.copyFileToUri(context, file, uri)
        .onSuccess { onSavedLocallyMessage("PDF সংরক্ষণ করা হয়েছে") }
        .onFailure { onSavedLocallyMessage("PDF সংরক্ষণ ব্যর্থ: ${it.message}") }
    }
  }

  DisposableEffect(file, pageIndex) {
    var pfd: ParcelFileDescriptor? = null
    var renderer: PdfRenderer? = null
    try {
      pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
      renderer = PdfRenderer(pfd)
      pageCount = renderer.pageCount.coerceAtLeast(1)
      val safeIdx = pageIndex.coerceIn(0, pageCount - 1)
      val page = renderer.openPage(safeIdx)
      val scale = 2
      val bmp = Bitmap.createBitmap(page.width * scale, page.height * scale, Bitmap.Config.ARGB_8888)
      bmp.eraseColor(android.graphics.Color.WHITE)
      page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
      page.close()
      renderedBitmap = bmp
    } catch (_: Throwable) {
      renderedBitmap = null
    }
    onDispose {
      runCatching { renderer?.close() }
      runCatching { pfd?.close() }
    }
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      shape = MaterialTheme.shapes.large,
      tonalElevation = 6.dp,
    ) {
      Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
              "${file.name} (${file.length() / 1024} KB)",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
          IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_pdf_preview")) {
            Icon(Icons.Rounded.Close, contentDescription = strings.close)
          }
        }

        // Page preview canvas
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f, fill = false)
            .verticalScroll(rememberScrollState())
            .background(Color(0xFFE5E7EB), MaterialTheme.shapes.small)
            .padding(8.dp),
          contentAlignment = Alignment.Center,
        ) {
          val bmp = renderedBitmap
          if (bmp != null) {
            Image(
              bitmap = bmp.asImageBitmap(),
              contentDescription = "PDF Page ${pageIndex + 1}",
              modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(595f / 842f),
              contentScale = ContentScale.Fit,
            )
          } else {
            Text("PDF প্রস্তুত (${pageCount} পৃষ্ঠা)", modifier = Modifier.padding(24.dp))
          }
        }

        // Page navigation
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.Center,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          IconButton(
            onClick = { if (pageIndex > 0) pageIndex-- },
            enabled = pageIndex > 0,
          ) {
            Icon(Icons.AutoMirrored.Rounded.NavigateBefore, contentDescription = "Previous page")
          }
          Text(
            "পৃষ্ঠা ${pageIndex + 1} / $pageCount",
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.padding(horizontal = 12.dp),
          )
          IconButton(
            onClick = { if (pageIndex < pageCount - 1) pageIndex++ },
            enabled = pageIndex < pageCount - 1,
          ) {
            Icon(Icons.AutoMirrored.Rounded.NavigateNext, contentDescription = "Next page")
          }
        }

        // Action Buttons: Print, Save Locally, Share
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Button(
            onClick = { PdfPrintHelper.printPdf(context, file, title) },
            modifier = Modifier
              .weight(1f)
              .height(48.dp)
              .testTag("pdf_print_btn"),
          ) {
            Icon(Icons.Rounded.Print, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(4.dp))
            Text(strings.printSystem, maxLines = 1)
          }
          OutlinedButton(
            onClick = { saveLauncher.launch(file.name) },
            modifier = Modifier
              .weight(1f)
              .height(48.dp)
              .testTag("pdf_save_btn"),
          ) {
            Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(4.dp))
            Text(strings.savePdf, maxLines = 1)
          }
          OutlinedButton(
            onClick = { PdfPrintHelper.shareFile(context, file, "application/pdf", title) },
            modifier = Modifier
              .weight(1f)
              .height(48.dp)
              .testTag("pdf_share_btn"),
          ) {
            Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(4.dp))
            Text("শেয়ার", maxLines = 1)
          }
        }
      }
    }
  }
}
