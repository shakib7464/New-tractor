package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import com.example.data.local.entity.StaffPaymentEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface StaffPaymentDao {
  @Query("SELECT * FROM staff_payments WHERE isDeleted = 0 ORDER BY paymentDate DESC, createdAt DESC")
  fun observeAll(): Flow<List<StaffPaymentEntity>>

  @Query("SELECT * FROM staff_payments")
  suspend fun getAllIncludingDeleted(): List<StaffPaymentEntity>

  @Upsert
  suspend fun upsert(payment: StaffPaymentEntity)

  @Upsert
  suspend fun upsertAll(payments: List<StaffPaymentEntity>)

  @Query("DELETE FROM staff_payments")
  suspend fun deleteAll()
}
