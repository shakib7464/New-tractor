package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.LandEntity
import com.example.domain.billing.FormatUtils
import com.example.domain.model.BulkPrintFilter
import com.example.localization.AppStrings

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun BulkPrintFilterSheet(
  customers: List<CustomerEntity>,
  lands: List<LandEntity>,
  initialFilter: BulkPrintFilter,
  strings: AppStrings,
  onDismiss: () -> Unit,
  onGeneratePdf: (BulkPrintFilter) -> Unit,
) {
  var selectedCustomerIds by remember { mutableStateOf(initialFilter.selectedCustomerIds) }
  var selectedLandIds by remember { mutableStateOf(initialFilter.selectedLandIds) }
  var onlyOutstanding by remember { mutableStateOf(initialFilter.onlyWithOutstandingDues) }
  var startDateText by remember {
    mutableStateOf(initialFilter.startDateMillis?.let { FormatUtils.formatDate(it) } ?: "")
  }
  var endDateText by remember {
    mutableStateOf(initialFilter.endDateMillis?.let { FormatUtils.formatDate(it) } ?: "")
  }

  val filteredAvailableLands = remember(selectedCustomerIds, lands) {
    if (selectedCustomerIds.isEmpty()) lands else lands.filter { it.customerId in selectedCustomerIds }
  }

  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 20.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Text(
        text = strings.bulkPrintDialogTitle,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
      )

      // Customer Selection
      Text(strings.selectCustomers, style = MaterialTheme.typography.labelLarge)
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(
          selected = selectedCustomerIds.isEmpty(),
          onClick = {
            selectedCustomerIds = emptySet()
            selectedLandIds = emptySet()
          },
          label = { Text(strings.allCustomers) },
        )
        customers.forEach { customer ->
          val checked = customer.id in selectedCustomerIds
          FilterChip(
            selected = checked,
            onClick = {
              selectedCustomerIds = if (checked) {
                selectedCustomerIds - customer.id
              } else {
                selectedCustomerIds + customer.id
              }
            },
            label = { Text(customer.fullName) },
          )
        }
      }

      // Land Selection
      if (filteredAvailableLands.isNotEmpty()) {
        Text(strings.selectLands, style = MaterialTheme.typography.labelLarge)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          FilterChip(
            selected = selectedLandIds.isEmpty(),
            onClick = { selectedLandIds = emptySet() },
            label = { Text(strings.allLands) },
          )
          filteredAvailableLands.forEach { land ->
            val checked = land.id in selectedLandIds
            FilterChip(
              selected = checked,
              onClick = {
                selectedLandIds = if (checked) selectedLandIds - land.id else selectedLandIds + land.id
              },
              label = { Text(land.landName) },
            )
          }
        }
      }

      HorizontalDivider()

      // Date Range
      Text("${strings.dateRange} (${strings.allDates})", style = MaterialTheme.typography.labelLarge)
      Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
          value = startDateText,
          onValueChange = { startDateText = it },
          label = { Text(strings.startDate) },
          placeholder = { Text("01-01-2026") },
          singleLine = true,
          modifier = Modifier.weight(1f),
        )
        OutlinedTextField(
          value = endDateText,
          onValueChange = { endDateText = it },
          label = { Text(strings.endDate) },
          placeholder = { Text("31-12-2026") },
          singleLine = true,
          modifier = Modifier.weight(1f),
        )
      }

      // Only outstanding toggle
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(strings.onlyOutstandingCustomers, style = MaterialTheme.typography.bodyLarge)
          Text(
            if (onlyOutstanding) strings.onlyOutstandingCustomers else strings.includeZeroBalanceCustomers,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        Switch(
          checked = onlyOutstanding,
          onCheckedChange = { onlyOutstanding = it },
          modifier = Modifier.testTag("bulk_filter_outstanding_switch"),
        )
      }

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedButton(
          onClick = onDismiss,
          modifier = Modifier
            .weight(1f)
            .height(48.dp),
        ) {
          Text(strings.cancel)
        }
        Button(
          onClick = {
            val startMs = FormatUtils.parseDmyDate(startDateText)?.let { FormatUtils.startOfDayMillis(it) }
            val endMs = FormatUtils.parseDmyDate(endDateText)?.let { FormatUtils.endOfDayMillis(it) }
            onGeneratePdf(
              BulkPrintFilter(
                selectedCustomerIds = selectedCustomerIds,
                selectedLandIds = selectedLandIds,
                startDateMillis = startMs,
                endDateMillis = endMs,
                onlyWithOutstandingDues = onlyOutstanding,
              )
            )
          },
          modifier = Modifier
            .weight(1.6f)
            .height(48.dp)
            .testTag("bulk_filter_generate_btn"),
        ) {
          Text(strings.generateCombinedPdf, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}
