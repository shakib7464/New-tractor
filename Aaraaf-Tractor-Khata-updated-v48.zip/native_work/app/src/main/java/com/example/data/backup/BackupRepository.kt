package com.example.data.backup

import android.content.Context
import android.util.Base64
import androidx.room.withTransaction
import com.example.data.local.AraafDatabase
import com.example.data.local.entity.AuditLogEntity
import com.example.data.local.entity.BackupHistoryEntity
import com.example.data.local.entity.BackupStatus
import com.example.data.local.entity.BackupType
import com.example.data.local.entity.SyncStatus
import com.example.data.preferences.AppPreferencesManager
import com.example.data.profile.ProfileManager
import com.example.domain.billing.FormatUtils
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

data class RestoreSummary(
  val customersRestored: Int,
  val landsRestored: Int,
  val jobsRestored: Int,
  val paymentsRestored: Int,
  val conflictsDetected: Int,
  val safetyBackupPath: String,
)

class BackupRepository(
  private val context: Context,
  private val db: AraafDatabase,
  private val prefs: AppPreferencesManager,
  private val driveService: GoogleDriveService = GoogleDriveService(),
) {
  private val json = Json {
    prettyPrint = false
    ignoreUnknownKeys = true
    encodeDefaults = true
  }

  val backupHistoryFlow: Flow<List<BackupHistoryEntity>> = db.backupHistoryDao().observeAll()

  suspend fun createLocalBackupJson(
    backupType: String = BackupType.LOCAL_JSON.code,
    encryptionPassphrase: String? = null,
  ): Result<Pair<File, BackupHistoryEntity>> = withContext(Dispatchers.IO) {
    runCatching {
      val now = System.currentTimeMillis()
      val deviceId = db.deviceInfoDao().getDeviceInfoNow()?.deviceId ?: "android-device"
      val attachments = db.attachmentDao().getAllIncludingDeleted()
      val attachmentBlobs = mutableMapOf<String, String>()
      for (att in attachments) {
        val f = File(att.localPath)
        if (f.exists() && f.length() <= 5 * 1024 * 1024) {
          attachmentBlobs[att.id] = Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
        }
      }

      val payload = BackupPayload(
        appName = "Araaf Tractor Khata",
        schemaVersion = 1,
        backupId = UUID.randomUUID().toString(),
        createdAt = now,
        deviceId = deviceId,
        customers = db.customerDao().getAllCustomersIncludingDeleted(),
        lands = db.landDao().getAllLandsIncludingDeleted(),
        landRateHistory = db.landRateHistoryDao().getAllNow(),
        tractors = db.tractorDao().getAllIncludingDeleted(),
        jobs = db.jobDao().getAllJobsIncludingDeleted(),
        payments = db.paymentDao().getAllIncludingDeleted(),
        advances = db.advancePaymentDao().getAllIncludingDeleted(),
        transactions = db.ledgerTransactionDao().getAllIncludingDeleted(),
        fuelDealers = db.fuelDao().getAllDealersIncludingDeleted(),
        fuelEntries = db.fuelDao().getAllEntriesIncludingDeleted(),
        staffPayments = db.staffPaymentDao().getAllIncludingDeleted(),
        attachments = attachments,
        auditLogs = db.auditLogDao().getAllNow(),
        attachmentBlobsBase64 = attachmentBlobs,
      )

      val payloadJson = json.encodeToString(payload)
      val checksum = sha256(payloadJson.toByteArray(Charsets.UTF_8))

      val envelope = if (!encryptionPassphrase.isNullOrBlank()) {
        BackupEnvelope(
          appName = "Araaf Tractor Khata",
          schemaVersion = 1,
          checksumSha256 = checksum,
          isEncrypted = true,
          encryptedPayloadBase64 = encryptWithPassphrase(payloadJson, encryptionPassphrase),
          payload = null,
        )
      } else {
        BackupEnvelope(
          appName = "Araaf Tractor Khata",
          schemaVersion = 1,
          checksumSha256 = checksum,
          isEncrypted = false,
          payload = payload,
        )
      }

      val serialized = json.encodeToString(envelope)
      val dir = File(context.filesDir, "backups").apply { mkdirs() }
      val prefix = if (backupType == BackupType.SAFETY_PRE_RESTORE.code) {
        "AraafTractorKhata_SafetyBackup"
      } else {
        "AraafTractorKhata_Backup"
      }
      val fileName = "${prefix}${profileTag()}_${FormatUtils.formatTimestampForFile(now)}.json"
      val outFile = File(dir, fileName)
      outFile.writeText(serialized, Charsets.UTF_8)

      val totalRecords = payload.customers.size + payload.lands.size + payload.jobs.size +
        payload.payments.size + payload.advances.size + payload.transactions.size

      val history = BackupHistoryEntity(
        id = payload.backupId,
        fileName = fileName,
        localFilePath = outFile.absolutePath,
        backupType = backupType,
        status = BackupStatus.VERIFIED.code,
        recordCount = totalRecords,
        attachmentCount = attachmentBlobs.size,
        fileSizeBytes = outFile.length(),
        checksumSha256 = checksum,
        isEncrypted = !encryptionPassphrase.isNullOrBlank(),
        createdAt = now,
        verifiedAt = now,
      )
      db.backupHistoryDao().insert(history)
      outFile to history
    }
  }

  suspend fun performGoogleDriveBackup(
    encryptionPassphrase: String? = null,
  ): Result<BackupHistoryEntity> = withContext(Dispatchers.IO) {
    val token = DriveAuth.freshAccessToken(context, prefs)
      ?: return@withContext Result.failure(IllegalStateException("Google Drive account not connected"))

    val localResult = createLocalBackupJson(
      backupType = BackupType.GOOGLE_DRIVE.code,
      encryptionPassphrase = encryptionPassphrase,
    )
    val (file, draftHistory) = localResult.getOrElse { return@withContext Result.failure(it) }

    val uploadingHistory = draftHistory.copy(status = BackupStatus.UPLOADING.code)
    db.backupHistoryDao().update(uploadingHistory)

    val uploadRes = driveService.uploadBackupToAppData(
      accessToken = token,
      fileName = file.name,
      contentBytes = file.readBytes(),
    )

    uploadRes.fold(
      onSuccess = { remote ->
        // Verify size > 0 and valid Drive ID before marking verified or pruning older backups
        if (remote.id.isBlank() || remote.sizeBytes <= 0L) {
          val failed = uploadingHistory.copy(
            status = BackupStatus.FAILED.code,
            errorMessage = "Verification failed: empty Drive file",
          )
          db.backupHistoryDao().update(failed)
          return@withContext Result.failure(IllegalStateException("Verification failed"))
        }

        val now = System.currentTimeMillis()
        val verified = uploadingHistory.copy(
          driveFileId = remote.id,
          status = BackupStatus.VERIFIED.code,
          verifiedAt = now,
        )
        db.backupHistoryDao().update(verified)
        prefs.setLastBackupTimestamp(now)

        // Retain latest 10 verified Google Drive backups, never delete before new backup verified
        val remoteFiles = driveService.listBackups(token).getOrNull().orEmpty().filter { belongsToActiveProfile(it.name) }
        if (remoteFiles.size > 10) {
          remoteFiles.drop(10).forEach { oldRemote ->
            if (oldRemote.id != remote.id) {
              driveService.deleteFile(token, oldRemote.id)
            }
          }
        }
        val localDriveHistories = db.backupHistoryDao().getVerifiedByType(BackupType.GOOGLE_DRIVE.code)
        if (localDriveHistories.size > 10) {
          localDriveHistories.drop(10).forEach { oldHist ->
            oldHist.localFilePath?.let { File(it).delete() }
            db.backupHistoryDao().deleteById(oldHist.id)
          }
        }
        Result.success(verified)
      },
      onFailure = { err ->
        val failed = uploadingHistory.copy(
          status = BackupStatus.FAILED.code,
          errorMessage = err.message ?: "Upload failed",
        )
        db.backupHistoryDao().update(failed)
        Result.failure(err)
      },
    )
  }

  /** প্রথম প্রোফাইলের ব্যাকআপ নামে কোনো ট্যাগ থাকে না; অন্যদের নামে _P<id> থাকে */
  private fun profileTag(): String {
    val id = ProfileManager.activeId(context)
    return if (id == ProfileManager.DEFAULT_ID) "" else "_P$id"
  }

  private fun belongsToActiveProfile(name: String): Boolean {
    val id = ProfileManager.activeId(context)
    return if (id == ProfileManager.DEFAULT_ID) {
      !Regex("_P[0-9a-f]{8}_").containsMatchIn(name)
    } else {
      name.contains("_P${id}_")
    }
  }

  suspend fun listDriveBackups(): Result<List<DriveBackupRemoteFile>> {
    val token = DriveAuth.freshAccessToken(context, prefs)
      ?: return Result.failure(IllegalStateException("Google Drive account not connected"))
    return driveService.listBackups(token).map { files -> files.filter { belongsToActiveProfile(it.name) } }
  }

  suspend fun restoreFromGoogleDrive(
    fileId: String,
    passphrase: String? = null,
    mergeOnly: Boolean = false,
  ): Result<RestoreSummary> = withContext(Dispatchers.IO) {
    val token = DriveAuth.freshAccessToken(context, prefs)
      ?: return@withContext Result.failure(IllegalStateException("Google Drive account not connected"))
    val bytes = driveService.downloadBackup(token, fileId).getOrElse {
      return@withContext Result.failure(it)
    }
    restoreFromJsonString(String(bytes, Charsets.UTF_8), passphrase, mergeOnly)
  }

  suspend fun validateAndDecodeBackup(
    jsonText: String,
    passphrase: String? = null,
  ): Result<BackupPayload> = withContext(Dispatchers.IO) {
    runCatching {
      val envelope = json.decodeFromString<BackupEnvelope>(jsonText)
      require(envelope.appName == "Araaf Tractor Khata") {
        "অবৈধ ব্যাকআপ ফাইল: এটি Araaf Tractor Khata ব্যাকআপ নয়"
      }
      val payload = if (envelope.isEncrypted) {
        val pass = passphrase?.takeIf { it.isNotBlank() }
          ?: throw IllegalArgumentException("এই ব্যাকআপ এনক্রিপ্টেড। পাসওয়ার্ড দিন।")
        val cipherB64 = envelope.encryptedPayloadBase64
          ?: throw IllegalArgumentException("Missing encrypted payload")
        val decrypted = decryptWithPassphrase(cipherB64, pass)
        val computedHash = sha256(decrypted.toByteArray(Charsets.UTF_8))
        require(computedHash == envelope.checksumSha256) {
          "ব্যাকআপ ফাইল যাচাই ব্যর্থ হয়েছে (Checksum mismatch)"
        }
        json.decodeFromString<BackupPayload>(decrypted)
      } else {
        val rawPayload = envelope.payload ?: throw IllegalArgumentException("Missing backup payload")
        val computedHash = sha256(json.encodeToString(rawPayload).toByteArray(Charsets.UTF_8))
        require(computedHash == envelope.checksumSha256 || envelope.checksumSha256.isBlank()) {
          "ব্যাকআপ ফাইল ক্ষতিগ্রস্ত হয়েছে (Integrity check failed)"
        }
        rawPayload
      }
      payload
    }
  }

  suspend fun restoreFromJsonString(
    jsonText: String,
    passphrase: String? = null,
    mergePreventDuplicates: Boolean = false,
  ): Result<RestoreSummary> = withContext(Dispatchers.IO) {
    val payload = validateAndDecodeBackup(jsonText, passphrase).getOrElse {
      return@withContext Result.failure(it)
    }

    // Step 1: Always create a safety backup before restoration
    val safetyResult = createLocalBackupJson(BackupType.SAFETY_PRE_RESTORE.code)
    val safetyPath = safetyResult.getOrNull()?.first?.absolutePath.orEmpty()

    runCatching {
      var conflicts = 0
      val attachDir = File(context.filesDir, "attachments").apply { mkdirs() }
      val restoredAttachments = payload.attachments.map { att ->
        val b64 = payload.attachmentBlobsBase64[att.id]
        if (!b64.isNullOrBlank()) {
          val target = File(attachDir, "${att.id}_${att.fileName}")
          target.writeBytes(Base64.decode(b64, Base64.NO_WRAP))
          att.copy(localPath = target.absolutePath)
        } else {
          att
        }
      }

      db.withTransaction {
        if (!mergePreventDuplicates) {
          db.ledgerTransactionDao().deleteAll()
          db.paymentDao().deleteAll()
          db.advancePaymentDao().deleteAll()
          db.jobDao().deleteAll()
          db.landRateHistoryDao().deleteAll()
          db.landDao().deleteAll()
          db.customerDao().deleteAll()
          db.tractorDao().deleteAll()
          db.attachmentDao().deleteAll()
          db.fuelDao().deleteAllEntries()
          db.fuelDao().deleteAllDealers()
          db.staffPaymentDao().deleteAll()

          db.customerDao().insertAll(payload.customers)
          db.tractorDao().insertAll(payload.tractors)
          db.landDao().insertAll(payload.lands)
          db.landRateHistoryDao().insertAll(payload.landRateHistory)
          db.jobDao().insertAll(payload.jobs)
          db.paymentDao().insertAll(payload.payments)
          db.advancePaymentDao().insertAll(payload.advances)
          db.ledgerTransactionDao().insertAll(payload.transactions)
          db.attachmentDao().insertAll(restoredAttachments)
          db.fuelDao().upsertAllDealers(payload.fuelDealers)
          db.fuelDao().upsertAllEntries(payload.fuelEntries)
          db.staffPaymentDao().upsertAll(payload.staffPayments)
        } else {
          val existingCustMap = db.customerDao().getAllCustomersIncludingDeleted().associateBy { it.id }
          val mergedCustomers = payload.customers.map { incoming ->
            val local = existingCustMap[incoming.id]
            when {
              local == null -> incoming
              local.deviceId != incoming.deviceId && local.updatedAt != incoming.updatedAt -> {
                conflicts++
                if (incoming.updatedAt > local.updatedAt) {
                  incoming.copy(syncStatus = SyncStatus.CONFLICT.code)
                } else {
                  local.copy(syncStatus = SyncStatus.CONFLICT.code)
                }
              }
              incoming.version >= local.version -> incoming
              else -> local
            }
          }
          db.customerDao().upsertAll(mergedCustomers)

          val existingTractorIds = db.tractorDao().getAllIncludingDeleted().map { it.id }.toSet()
          db.tractorDao().insertAll(payload.tractors.filter { it.id !in existingTractorIds })

          val existingLandIds = db.landDao().getAllLandsIncludingDeleted().map { it.id }.toSet()
          db.landDao().insertAll(payload.lands.filter { it.id !in existingLandIds })
          db.landRateHistoryDao().insertAll(payload.landRateHistory)

          val existingJobIds = db.jobDao().getAllJobsIncludingDeleted().map { it.id }.toSet()
          db.jobDao().insertAll(payload.jobs.filter { it.id !in existingJobIds })

          val existingPayIds = db.paymentDao().getAllIncludingDeleted().map { it.id }.toSet()
          db.paymentDao().insertAll(payload.payments.filter { it.id !in existingPayIds })

          val existingAdvIds = db.advancePaymentDao().getAllIncludingDeleted().map { it.id }.toSet()
          db.advancePaymentDao().insertAll(payload.advances.filter { it.id !in existingAdvIds })

          val existingTxnIds = db.ledgerTransactionDao().getAllIncludingDeleted().map { it.id }.toSet()
          db.ledgerTransactionDao().insertAll(payload.transactions.filter { it.id !in existingTxnIds })

          val existingDealerIds = db.fuelDao().getAllDealersIncludingDeleted().map { it.id }.toSet()
          db.fuelDao().upsertAllDealers(payload.fuelDealers.filter { it.id !in existingDealerIds })
          val existingFuelEntryIds = db.fuelDao().getAllEntriesIncludingDeleted().map { it.id }.toSet()
          db.fuelDao().upsertAllEntries(payload.fuelEntries.filter { it.id !in existingFuelEntryIds })
          val existingStaffPayIds = db.staffPaymentDao().getAllIncludingDeleted().map { it.id }.toSet()
          db.staffPaymentDao().upsertAll(payload.staffPayments.filter { it.id !in existingStaffPayIds })

          val existingAttIds = db.attachmentDao().getAllIncludingDeleted().map { it.id }.toSet()
          db.attachmentDao().insertAll(restoredAttachments.filter { it.id !in existingAttIds })
        }

        val devId = db.deviceInfoDao().getDeviceInfoNow()?.deviceId ?: "android-device"
        db.auditLogDao().insert(
          AuditLogEntity(
            id = UUID.randomUUID().toString(),
            entityType = "BACKUP",
            entityId = payload.backupId,
            action = "BACKUP_RESTORE",
            summary = "Restored ${payload.customers.size} customers, ${payload.lands.size} lands, ${payload.jobs.size} jobs",
            timestamp = System.currentTimeMillis(),
            deviceId = devId,
          )
        )
      }

      AraafDatabase.seedInitialTractorAndDevice(db)

      RestoreSummary(
        customersRestored = payload.customers.size,
        landsRestored = payload.lands.size,
        jobsRestored = payload.jobs.size,
        paymentsRestored = payload.payments.size,
        conflictsDetected = conflicts,
        safetyBackupPath = safetyPath,
      )
    }
  }

  private fun sha256(bytes: ByteArray): String {
    val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
    return digest.joinToString("") { "%02x".format(it) }
  }

  private fun encryptWithPassphrase(plainText: String, passphrase: String): String {
    val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
    val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
    val spec = PBEKeySpec(passphrase.toCharArray(), salt, 65536, 256)
    val key = SecretKeySpec(factory.generateSecret(spec).encoded, "AES")
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, key)
    val iv = cipher.iv
    val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
    val combined = ByteArray(1 + salt.size + 1 + iv.size + encrypted.size)
    var pos = 0
    combined[pos++] = salt.size.toByte()
    System.arraycopy(salt, 0, combined, pos, salt.size)
    pos += salt.size
    combined[pos++] = iv.size.toByte()
    System.arraycopy(iv, 0, combined, pos, iv.size)
    pos += iv.size
    System.arraycopy(encrypted, 0, combined, pos, encrypted.size)
    return Base64.encodeToString(combined, Base64.NO_WRAP)
  }

  private fun decryptWithPassphrase(encoded: String, passphrase: String): String {
    val combined = Base64.decode(encoded, Base64.NO_WRAP)
    var pos = 0
    val saltLen = combined[pos++].toInt() and 0xFF
    val salt = combined.copyOfRange(pos, pos + saltLen)
    pos += saltLen
    val ivLen = combined[pos++].toInt() and 0xFF
    val iv = combined.copyOfRange(pos, pos + ivLen)
    pos += ivLen
    val ciphertext = combined.copyOfRange(pos, combined.size)

    val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
    val spec = PBEKeySpec(passphrase.toCharArray(), salt, 65536, 256)
    val key = SecretKeySpec(factory.generateSecret(spec).encoded, "AES")
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
    return String(cipher.doFinal(ciphertext), Charsets.UTF_8)
  }
}
