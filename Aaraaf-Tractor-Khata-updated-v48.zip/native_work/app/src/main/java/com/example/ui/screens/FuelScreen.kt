@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.Scaffold
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.FuelDealerEntity
import com.example.data.local.entity.FuelEntryEntity
import com.example.data.local.entity.FuelEntryType
import com.example.domain.billing.FormatUtils

private data class FuelDealerSummary(
  val dealer: FuelDealerEntity,
  val liters: Double,
  val total: Double,
  val paid: Double,
) {
  val balance: Double get() = total - paid
}

private fun numText(v: Double): String = if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FuelScreen(
  dealers: List<FuelDealerEntity>,
  entries: List<FuelEntryEntity>,
  currencySymbol: String,
  onBack: () -> Unit,
  onSaveDealer: (String, String) -> Unit,
  onUpdateDealer: (FuelDealerEntity, String, String) -> Unit,
  onDeleteDealer: (FuelDealerEntity) -> Unit,
  onSaveEntry: (String, Boolean, Long, Double, Double, Double, String, String) -> Unit,
  onUpdateEntry: (FuelEntryEntity, String, Boolean, Long, Double, Double, Double, String, String) -> Unit,
  onDeleteEntry: (FuelEntryEntity) -> Unit,
) {
  var tab by remember { mutableIntStateOf(0) }
  var showDealerDialog by remember { mutableStateOf(false) }
  var showEntryDialog by remember { mutableStateOf(false) }
  var detailDealer by remember { mutableStateOf<FuelDealerEntity?>(null) }
  var editDealer by remember { mutableStateOf<FuelDealerEntity?>(null) }
  var editEntry by remember { mutableStateOf<FuelEntryEntity?>(null) }
  var pendingDeleteDealer by remember { mutableStateOf<FuelDealerEntity?>(null) }
  var pendingDeleteEntry by remember { mutableStateOf<FuelEntryEntity?>(null) }

  val dealerNames = dealers.associate { it.id to it.name }
  val summaries = dealers.map { d ->
    val list = entries.filter { it.dealerId == d.id }
    FuelDealerSummary(
      dealer = d,
      liters = list.filter { it.entryType == FuelEntryType.PURCHASE }.sumOf { it.liters },
      total = list.sumOf { it.totalAmount },
      paid = list.sumOf { it.paidAmount },
    )
  }
  val totalDue = summaries.sumOf { it.balance }
  val totalJoma = entries.sumOf { it.paidAmount }
  val jomaEntries = entries.filter { it.paidAmount > 0.0 }

  Scaffold(
    floatingActionButton = {
      if (dealers.isEmpty()) {
        ExtendedFloatingActionButton(
          onClick = { showDealerDialog = true },
          icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
          text = { Text("দোকান যোগ করুন") },
        )
      } else {
        FloatingActionButton(onClick = { showEntryDialog = true }) {
          Icon(Icons.Rounded.Add, contentDescription = "তেল / জমা যোগ")
        }
      }
    },
  ) { innerPadding ->
  Column(
    modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
      IconButton(onClick = onBack) {
        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "ফিরে যান")
      }
      Text("তেলের হিসাব", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    }


    TabRow(selectedTabIndex = tab) {
      Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("মোট বকেয়া") })
      Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("মোট জমা") })
    }

    if (tab == 0) {
      LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
          TotalsCard(
            totalLiters = summaries.sumOf { it.liters },
            totalAmount = summaries.sumOf { it.total },
            totalPaid = summaries.sumOf { it.paid },
            totalDue = totalDue,
            currencySymbol = currencySymbol,
          )
        }
        if (summaries.isEmpty()) {
          item { Text("এখনো কোনো দোকান যোগ হয়নি") }
        }
        items(summaries, key = { it.dealer.id }) { s ->
          DealerCard(s = s, currencySymbol = currencySymbol, onOpen = { detailDealer = s.dealer })
        }
        item { TextButton(onClick = { showDealerDialog = true }) { Text("+ নতুন দোকান যোগ করুন") } }
      }
    } else {
      LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
          SummaryCard(
            title = "সব দোকানে মোট জমা",
            value = FormatUtils.formatTaka(totalJoma, currencySymbol),
            highlight = false,
          )
        }
        if (jomaEntries.isEmpty()) {
          item { Text("এখনো কোনো জমা নেই") }
        }
        items(jomaEntries, key = { it.id }) { e ->
          JomaCard(e = e, dealerName = dealerNames[e.dealerId] ?: "-", currencySymbol = currencySymbol)
        }
      }
    }
  }
  }

  if (showDealerDialog) {
    FuelDealerDialog(
      title = "নতুন দোকান",
      initialName = "",
      initialMobile = "",
      onDismiss = { showDealerDialog = false },
      onSave = { name, mobile ->
        onSaveDealer(name, mobile)
        showDealerDialog = false
      },
    )
  }

  if (showEntryDialog) {
    FuelEntryDialog(
      dealers = dealers,
      currencySymbol = currencySymbol,
      initial = null,
      onDismiss = { showEntryDialog = false },
      onSave = { dealerId, isPurchase, date, liters, rate, amount, driver, note ->
        onSaveEntry(dealerId, isPurchase, date, liters, rate, amount, driver, note)
        showEntryDialog = false
      },
    )
  }

  detailDealer?.let { d ->
    FuelDealerDetailDialog(
      dealer = d,
      entries = entries.filter { it.dealerId == d.id },
      currencySymbol = currencySymbol,
      onDismiss = { detailDealer = null },
      onEditDealer = { editDealer = d },
      onDeleteDealer = { pendingDeleteDealer = d },
      onEditEntry = { editEntry = it },
      onDeleteEntry = { pendingDeleteEntry = it },
    )
  }

  editDealer?.let { ed ->
    FuelDealerDialog(
      title = "দোকান সংশোধন",
      initialName = ed.name,
      initialMobile = ed.mobile,
      onDismiss = { editDealer = null },
      onSave = { name, mobile ->
        onUpdateDealer(ed, name, mobile)
        editDealer = null
      },
    )
  }

  editEntry?.let { ee ->
    FuelEntryDialog(
      dealers = dealers,
      currencySymbol = currencySymbol,
      initial = ee,
      onDismiss = { editEntry = null },
      onSave = { dealerId, isPurchase, date, liters, rate, amount, driver, note ->
        onUpdateEntry(ee, dealerId, isPurchase, date, liters, rate, amount, driver, note)
        editEntry = null
      },
    )
  }

  pendingDeleteEntry?.let { pe ->
    ConfirmDeleteDialog(
      text = "এই এন্ট্রিটি মুছে ফেলবেন?",
      onConfirm = {
        onDeleteEntry(pe)
        pendingDeleteEntry = null
      },
      onDismiss = { pendingDeleteEntry = null },
    )
  }

  pendingDeleteDealer?.let { pd ->
    ConfirmDeleteDialog(
      text = "দোকানটি মুছে ফেলবেন? এর কোনো হিসাব থাকলে মোছা যাবে না।",
      onConfirm = {
        onDeleteDealer(pd)
        pendingDeleteDealer = null
        detailDealer = null
      },
      onDismiss = { pendingDeleteDealer = null },
    )
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SummaryCard(title: String, value: String, highlight: Boolean) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
  ) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
      Text(title, style = MaterialTheme.typography.titleSmall)
      Text(
        value,
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.Bold,
        color = if (highlight) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
      )
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DealerCard(s: FuelDealerSummary, currencySymbol: String, onOpen: () -> Unit) {
  Card(onClick = onOpen, modifier = Modifier.fillMaxWidth()) {
    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
      Text(s.dealer.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
      if (s.dealer.mobile.isNotBlank()) {
        Text(s.dealer.mobile, style = MaterialTheme.typography.bodySmall)
      }
      Text(
        "মোট তেল: ${FormatUtils.formatNumber(s.liters)} লিটার • মোট দাম: ${FormatUtils.formatTaka(s.total, currencySymbol)}",
        style = MaterialTheme.typography.bodyMedium,
      )
      Text(
        "মোট জমা: ${FormatUtils.formatTaka(s.paid, currencySymbol)}",
        style = MaterialTheme.typography.bodyMedium,
      )
      val balanceText = when {
        s.balance > 0.0 -> "বাকি: ${FormatUtils.formatTaka(s.balance, currencySymbol)}"
        s.balance < 0.0 -> "অতিরিক্ত জমা: ${FormatUtils.formatTaka(-s.balance, currencySymbol)}"
        else -> "বাকি নেই"
      }
      Text(
        balanceText,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = if (s.balance > 0.0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
      )
      Text("বিবরণ ও সংশোধনের জন্য চাপুন", style = MaterialTheme.typography.bodySmall)
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun JomaCard(e: FuelEntryEntity, dealerName: String, currencySymbol: String) {
  Card(modifier = Modifier.fillMaxWidth()) {
    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(FormatUtils.formatDate(e.entryDate), style = MaterialTheme.typography.bodySmall)
        Text(
          FormatUtils.formatTaka(e.paidAmount, currencySymbol),
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
        )
      }
      Text(dealerName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
      Text(
        if (e.entryType == FuelEntryType.PURCHASE) "তেল কেনার সময় জমা" else "আলাদা জমা",
        style = MaterialTheme.typography.bodySmall,
      )
      val extra = listOf(e.driverName, e.note).filter { it.isNotBlank() }.joinToString(" • ")
      if (extra.isNotBlank()) {
        Text(extra, style = MaterialTheme.typography.bodySmall)
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FuelDealerDetailDialog(
  dealer: FuelDealerEntity,
  entries: List<FuelEntryEntity>,
  currencySymbol: String,
  onDismiss: () -> Unit,
  onEditDealer: () -> Unit,
  onDeleteDealer: () -> Unit,
  onEditEntry: (FuelEntryEntity) -> Unit,
  onDeleteEntry: (FuelEntryEntity) -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(dealer.name) },
    text = {
      Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.verticalScroll(rememberScrollState()),
      ) {
        if (dealer.mobile.isNotBlank()) {
          Text(dealer.mobile, style = MaterialTheme.typography.bodySmall)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          TextButton(onClick = onEditDealer) { Text("দোকান সংশোধন") }
          TextButton(onClick = onDeleteDealer) {
            Text("দোকান মুছুন", color = MaterialTheme.colorScheme.error)
          }
        }
        if (entries.isEmpty()) {
          Text("এই দোকানে এখনো কোনো এন্ট্রি নেই")
        }
        entries.sortedByDescending { it.entryDate }.forEach { e ->
          Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
              Text(
                "${FormatUtils.formatDate(e.entryDate)} • ${if (e.entryType == FuelEntryType.PURCHASE) "তেল কেনা" else "জমা"}",
                style = MaterialTheme.typography.titleSmall,
              )
              if (e.entryType == FuelEntryType.PURCHASE) {
                Text(
                  "${FormatUtils.formatNumber(e.liters)} লিটার × ${FormatUtils.formatNumber(e.ratePerLiter)} = ${FormatUtils.formatTaka(e.totalAmount, currencySymbol)}",
                  style = MaterialTheme.typography.bodySmall,
                )
              }
              Text(
                "জমা: ${FormatUtils.formatTaka(e.paidAmount, currencySymbol)}",
                style = MaterialTheme.typography.bodySmall,
              )
              val extra = listOf(e.driverName, e.note).filter { it.isNotBlank() }.joinToString(" • ")
              if (extra.isNotBlank()) {
                Text(extra, style = MaterialTheme.typography.bodySmall)
              }
              Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { onEditEntry(e) }) { Text("সংশোধন") }
                TextButton(onClick = { onDeleteEntry(e) }) {
                  Text("মুছুন", color = MaterialTheme.colorScheme.error)
                }
              }
            }
          }
        }
      }
    },
    confirmButton = {
      OutlinedButton(onClick = onDismiss) { Text("বন্ধ করুন") }
    },
  )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConfirmDeleteDialog(text: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("নিশ্চিত করুন") },
    text = { Text(text) },
    confirmButton = {
      Button(onClick = onConfirm) { Text("মুছুন") }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss) { Text("বাতিল") }
    },
  )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FuelDealerDialog(
  title: String,
  initialName: String,
  initialMobile: String,
  onDismiss: () -> Unit,
  onSave: (String, String) -> Unit,
) {
  var name by remember { mutableStateOf(initialName) }
  var mobile by remember { mutableStateOf(initialMobile) }
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(title) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("দোকানের নাম") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
          value = mobile,
          onValueChange = { mobile = it },
          label = { Text("মোবাইল (ঐচ্ছিক)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    },
    confirmButton = {
      Button(onClick = { onSave(name, mobile) }, enabled = name.isNotBlank()) {
        Text("সংরক্ষণ করুন")
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss) { Text("বাতিল") }
    },
  )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FuelEntryDialog(
  dealers: List<FuelDealerEntity>,
  currencySymbol: String,
  initial: FuelEntryEntity?,
  onDismiss: () -> Unit,
  onSave: (String, Boolean, Long, Double, Double, Double, String, String) -> Unit,
) {
  val initialIsPurchase = initial == null || initial.entryType == FuelEntryType.PURCHASE
  var isPurchase by remember { mutableStateOf(initialIsPurchase) }
  var dealerId by remember { mutableStateOf(initial?.dealerId ?: dealers.firstOrNull()?.id ?: "") }
  var dealerExpanded by remember { mutableStateOf(false) }
  var dateText by remember {
    mutableStateOf(FormatUtils.formatDate(initial?.entryDate ?: System.currentTimeMillis()))
  }
  var litersText by remember {
    mutableStateOf(if (initial != null && initial.entryType == FuelEntryType.PURCHASE) numText(initial.liters) else "")
  }
  var rateText by remember {
    mutableStateOf(if (initial != null && initial.entryType == FuelEntryType.PURCHASE) numText(initial.ratePerLiter) else "")
  }
  var amountText by remember { mutableStateOf(initial?.let { numText(it.paidAmount) } ?: "") }
  var driver by remember { mutableStateOf(initial?.driverName ?: "") }
  var note by remember { mutableStateOf(initial?.note ?: "") }

  val liters = litersText.toDoubleOrNull() ?: 0.0
  val rate = rateText.toDoubleOrNull() ?: 0.0
  val amount = amountText.toDoubleOrNull() ?: 0.0
  val dealerName = dealers.firstOrNull { it.id == dealerId }?.name ?: "দোকান বেছে নিন"
  val canSave = dealers.isNotEmpty() && dealerId.isNotBlank() &&
    (if (isPurchase) liters > 0.0 && rate > 0.0 else amount > 0.0)

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text((if (isPurchase) "তেল কেনা" else "দোকানে জমা") + if (initial != null) " (সংশোধন)" else "") },
    text = {
      Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.verticalScroll(rememberScrollState()),
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          FilterChip(selected = isPurchase, onClick = { isPurchase = true }, label = { Text("তেল কেনা") })
          FilterChip(selected = !isPurchase, onClick = { isPurchase = false }, label = { Text("দোকানে জমা") })
        }
        if (dealers.isEmpty()) {
          Text("আগে একটি দোকান যোগ করুন", color = MaterialTheme.colorScheme.error)
        } else {
          ExposedDropdownMenuBox(
            expanded = dealerExpanded,
            onExpandedChange = { dealerExpanded = it },
          ) {
            OutlinedTextField(
              value = dealerName,
              onValueChange = {},
              readOnly = true,
              label = { Text("দোকান") },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dealerExpanded) },
              modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
            )
            ExposedDropdownMenu(
              expanded = dealerExpanded,
              onDismissRequest = { dealerExpanded = false },
            ) {
              dealers.forEach { d ->
                DropdownMenuItem(
                  text = { Text(d.name) },
                  onClick = {
                    dealerId = d.id
                    dealerExpanded = false
                  },
                )
              }
            }
          }
        }
        OutlinedTextField(
          value = dateText,
          onValueChange = { dateText = it },
          label = { Text("তারিখ") },
          placeholder = { Text("DD-MM-YYYY") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        if (isPurchase) {
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = litersText,
              onValueChange = { litersText = it },
              label = { Text("লিটার") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              singleLine = true,
              modifier = Modifier.weight(1f),
            )
            OutlinedTextField(
              value = rateText,
              onValueChange = { rateText = it },
              label = { Text("প্রতি লিটার দর") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              singleLine = true,
              modifier = Modifier.weight(1f),
            )
          }
          Text(
            "মোট দাম: ${FormatUtils.formatTaka(liters * rate, currencySymbol)}",
            style = MaterialTheme.typography.bodyMedium,
          )
          OutlinedTextField(
            value = amountText,
            onValueChange = { amountText = it },
            label = { Text("দোকানে এখনই জমা (ঐচ্ছিক)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
          OutlinedTextField(
            value = driver,
            onValueChange = { driver = it },
            label = { Text("ড্রাইভারের নাম") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
        } else {
          OutlinedTextField(
            value = amountText,
            onValueChange = { amountText = it },
            label = { Text("জমার পরিমাণ") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
        }
        OutlinedTextField(
          value = note,
          onValueChange = { note = it },
          label = { Text("নোট / মন্তব্য") },
          modifier = Modifier.fillMaxWidth(),
        )
      }
    },
    confirmButton = {
      Button(
        enabled = canSave,
        onClick = {
          val date = FormatUtils.parseDmyDate(dateText) ?: System.currentTimeMillis()
          onSave(
            dealerId,
            isPurchase,
            date,
            if (isPurchase) liters else 0.0,
            if (isPurchase) rate else 0.0,
            amount,
            if (isPurchase) driver else "",
            note,
          )
        },
      ) {
        Text("সংরক্ষণ করুন")
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss) { Text("বাতিল") }
    },
  )
}


@Composable
private fun TotalsCard(
  totalLiters: Double,
  totalAmount: Double,
  totalPaid: Double,
  totalDue: Double,
  currencySymbol: String,
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
  ) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
      Text("সব দোকানের হিসাব", style = MaterialTheme.typography.titleSmall)
      Text("মোট তেল: ${FormatUtils.formatNumber(totalLiters)} লিটার", style = MaterialTheme.typography.bodyMedium)
      Text("মোট দাম: ${FormatUtils.formatTaka(totalAmount, currencySymbol)}", style = MaterialTheme.typography.bodyMedium)
      Text("মোট জমা: ${FormatUtils.formatTaka(totalPaid, currencySymbol)}", style = MaterialTheme.typography.bodyMedium)
      Text(
        "মোট বকেয়া: ${FormatUtils.formatTaka(totalDue, currencySymbol)}",
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.Bold,
        color = if (totalDue > 0.0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
      )
    }
  }
}