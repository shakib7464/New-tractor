package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(
  tableName = "customers",
  indices = [
    Index(value = ["mobileNumber"]),
    Index(value = ["fullName"]),
    Index(value = ["village"]),
    Index(value = ["isDeleted"]),
  ],
)
data class CustomerEntity(
  @PrimaryKey val id: String,
  val customerCode: String,
  val fullName: String,
  val mobileNumber: String,
  val address: String = "",
  val village: String = "",
  val unionName: String = "",
  val upazila: String = "",
  val district: String = "",
  val notes: String = "",
  val registrationDate: Long,
  val customRatePerUnit: Double? = null,
  val customRateMethod: String? = null,
  val isDeleted: Boolean = false,
  val deletedAt: Long? = null,
  val createdAt: Long,
  val updatedAt: Long,
  val deviceId: String,
  val syncStatus: String = SyncStatus.LOCAL_ONLY.code,
  val version: Long = 1L,
)

@Serializable
@Entity(
  tableName = "lands",
  foreignKeys = [
    ForeignKey(
      entity = CustomerEntity::class,
      parentColumns = ["id"],
      childColumns = ["customerId"],
      onDelete = ForeignKey.RESTRICT,
    )
  ],
  indices = [
    Index(value = ["customerId"]),
    Index(value = ["id", "customerId"], unique = true),
    Index(value = ["isDeleted"]),
  ],
)
data class LandEntity(
  @PrimaryKey val id: String,
  val landCode: String,
  val customerId: String,
  val landName: String,
  val village: String = "",
  val locationDetails: String = "",
  val sizeValue: Double,
  val unit: String = LandUnit.DECIMAL.code,
  val cropInfo: String = "",
  val cultivationSeason: String = "",
  val openingBalance: Double = 0.0,
  val notes: String = "",
  val isDeleted: Boolean = false,
  val deletedAt: Long? = null,
  val createdAt: Long,
  val updatedAt: Long,
  val deviceId: String,
  val syncStatus: String = SyncStatus.LOCAL_ONLY.code,
  val version: Long = 1L,
)

@Serializable
@Entity(
  tableName = "land_rate_history",
  foreignKeys = [
    ForeignKey(
      entity = LandEntity::class,
      parentColumns = ["id"],
      childColumns = ["landId"],
      onDelete = ForeignKey.CASCADE,
    )
  ],
  indices = [Index(value = ["landId"])],
)
data class LandRateHistoryEntity(
  @PrimaryKey val id: String,
  val landId: String,
  val workType: String,
  val billingMethod: String,
  val rate: Double,
  val effectiveDate: Long,
  val notes: String = "",
)

@Serializable
@Entity(
  tableName = "tractors",
  indices = [Index(value = ["isActive"]), Index(value = ["isDeleted"])],
)
data class TractorEntity(
  @PrimaryKey val id: String,
  val tractorCode: String,
  val name: String,
  val brand: String = "",
  val model: String = "",
  val registrationInfo: String = "",
  val notes: String = "",
  val isActive: Boolean = true,
  val isDeleted: Boolean = false,
  val deletedAt: Long? = null,
  val createdAt: Long,
  val updatedAt: Long,
  val deviceId: String,
  val syncStatus: String = SyncStatus.LOCAL_ONLY.code,
  val version: Long = 1L,
)
