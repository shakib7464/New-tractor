package com.example

import android.app.Application
import com.example.data.backup.BackupRepository
import com.example.data.backup.SyncRepository
import com.example.data.local.AraafDatabase
import com.example.data.preferences.AppPreferencesManager
import com.example.data.repository.KhataRepository
import com.example.export.PdfGenerator
import com.example.worker.GoogleDriveSyncWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AraafApplication : Application() {
  private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

  val database: AraafDatabase by lazy { AraafDatabase.getInstance(this) }
  val preferencesManager: AppPreferencesManager by lazy { AppPreferencesManager(this) }
  val khataRepository: KhataRepository by lazy { KhataRepository(this, database) }
  val backupRepository: BackupRepository by lazy {
    BackupRepository(this, database, preferencesManager)
  }
  val syncRepository: SyncRepository by lazy {
    SyncRepository(this, database, preferencesManager)
  }
  val pdfGenerator: PdfGenerator by lazy { PdfGenerator(this) }

  override fun onCreate() {
    super.onCreate()
    // রিস্টার্টের জন্য ব্যবহৃত আলাদা প্রসেসে ডাটাবেস খোলার দরকার নেই
    if (isRestartHelperProcess()) return
    appScope.launch {
      AraafDatabase.seedInitialTractorAndDevice(database)
      khataRepository.purgeExpiredRecycleBin()
      val settings = preferencesManager.getSettingsNow()
      GoogleDriveSyncWorker.schedulePeriodic(
        this@AraafApplication,
        !settings.driveAccountEmail.isNullOrBlank(),
      )
    }
  }

  private fun isRestartHelperProcess(): Boolean = runCatching {
    java.io.File("/proc/self/cmdline").readText().trim { it == '\u0000' || it.isWhitespace() }.endsWith(":restart")
  }.getOrDefault(false)
}
