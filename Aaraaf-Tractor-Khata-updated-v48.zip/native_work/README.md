# Araaf Tractor Khata — Update 2.1

This source package includes the Katha-based land and job billing updates, a dedicated payment-history screen, payment date/time capture, and updated PDF statement details. See `UPDATE_STATUS_BN.txt` for the exact change list and build limitations. The Room database schema was intentionally left unchanged to protect existing customer and ledger data.

# Araaf Tractor Khata

Offline-first Android application built with Kotlin, Jetpack Compose (Material 3), and Room/SQLite for agricultural tractor service accounting, independent land-wise ledgers, billing, payment receipts, Google Drive backup/restore, and one-click bulk A4 PDF statements in Bengali (`বাংলা`).

---

## 1. Database Structure (Room / SQLite — Offline-First Source of Truth)

All tables use UUID primary keys (`id`), foreign keys with referential integrity, database indexes, soft-delete flags (`isDeleted`, `deletedAt`) for 30-day Recycle Bin recovery, and multi-device sync metadata (`deviceId`, `createdAt`, `updatedAt`, `syncStatus`, `version`).

| Entity / Table | Purpose | Key Relations & Fields |
|---|---|---|
| `customers` | Customer profiles & custom rates | `id`, `customerCode`, `fullName`, `mobileNumber`, `village`, `unionName`, `upazila`, `district`, `registrationDate`, `customRatePerUnit` |
| `lands` | Agricultural lands owned by customers | `id`, `landCode`, `customerId` (FK), `landName`, `sizeValue`, `unit` (`DECIMAL`/`BIGHA`/`ACRE`), `cropInfo`, `cultivationSeason`, `openingBalance` |
| `land_rate_history` | Historical rates per land & work type | `id`, `landId` (FK), `workType`, `billingMethod`, `rate`, `effectiveDate` |
| `tractors` | Multi-tractor registry (seeded with 1 active tractor) | `id`, `tractorCode`, `name`, `brand`, `model`, `registrationInfo`, `isActive` |
| `agricultural_jobs` | Individual work records per land & tractor | `id`, `jobCode`, `customerId`, `landId`, `tractorId`, `workDate`, `workType`, `billingMethod`, `landArea`, `rate`, `workingHours`, `baseBill`, `additionalCharges`, `discount`, `totalBill`, `advanceAdjustment`, `amountPaid`, `remainingDue`, `status`, optional rotavator/operator specs |
| `ledger_transactions` | **Independent per-land ledger** (balances always recalculated from these original rows) | `id`, `transactionCode`, `customerId`, `landId`, `jobId`, `paymentId`, `advanceId`, `transactionDate`, `transactionType`, `debitAmount`, `creditAmount`, `description` |
| `payments` | Payment records & receipt snapshots | `id`, `receiptNumber`, `customerId`, `landId`, `jobId`, `targetType`, `paymentDate`, `amount`, `paymentMethod` (`CASH`/`BANK`/`BKASH`/`NAGAD`/`OTHER`) |
| `advance_payments` | Separate advance ledger (`RECEIVED`, `ADJUSTED`, `REFUNDED`) | `id`, `receiptNumber`, `customerId`, `landId`, `jobId`, `entryType`, `amount`, `paymentMethod`, `transactionDate` |
| `attachments` | Local photos & documents linked to Customer/Land/Job/Payment | `id`, `ownerType`, `ownerId`, `fileName`, `localPath`, `mimeType` |
| `audit_logs` | Immutable audit trail of create/edit/delete/restore/financial changes | `id`, `entityType`, `entityId`, `action`, `summary`, `previousValueJson`, `newValueJson`, `timestamp` |
| `backup_history` | Local & Google Drive backup verification metadata | `id`, `fileName`, `driveFileId`, `backupType`, `status`, `checksumSha256`, `isEncrypted`, `verifiedAt` |
| `sync_queue` & `device_information` | Multi-device conflict detection & device identity | `deviceId`, `operation`, `status`, `retryCount` |

### Financial Ledger Isolation Guarantee
- Every `LedgerTransactionEntity` is strictly scoped to a single `landId`.
- `LandDue(L) = SUM(debitAmount) - SUM(creditAmount)` across non-deleted transactions for `landId == L`.
- `CustomerDue(C) = SUM(LandDue(L))` across all active lands of `C`.
- Advance payments are tracked separately in `advance_payments` and are **never** deducted from a land's outstanding due until an explicit `ADVANCE_ADJUSTMENT` transaction is recorded.

---

## 2. Google Drive OAuth & Backup Configuration

The app uses Play Services Identity `AuthorizationClient` (`com.google.android.gms:play-services-auth`) with scopes `drive.appdata` and `drive.file`, plus `GoogleDriveBackupWorker` (Android `WorkManager`) for automatic background upload and exponential retry when internet reconnects.

To enable Google Drive sign-in on your own signing key / release APK:
1. Open [Google Cloud Console](https://console.cloud.google.com/) and select or create a project.
2. Enable the **Google Drive API**.
3. Configure the **OAuth Consent Screen** (External or Internal) and add scopes `.../auth/drive.appdata` and `.../auth/drive.file`.
4. Create an **Android OAuth 2.0 Client ID** with:
   - **Package name:** `com.aistudio.tractorkhata.arafbd`
   - **SHA-1 certificate fingerprint:** run `keytool -list -v -keystore <your-keystore> -alias <alias>` and paste the SHA-1.
5. No private client secret is embedded in the APK; Android Play Services verifies your app via package name + SHA-1.

---

## 3. Build & Installation Instructions

```bash
# Build Debug APK
gradle :app:assembleDebug

# Run All Unit & Robolectric Tests
gradle :app:testDebugUnitTest
```

Output APK location: `app/build/outputs/apk/debug/app-debug.apk`.

---

## 4. Backup & Restore Instructions

- **Google Drive Backup:** Open **আরও (More) → Google Drive ব্যাকআপ ও রিস্টোর**. Connect your Google account, enable **Auto backup when online** (and optionally **Wi-Fi only**), or tap **এখনই ব্যাকআপ নিন**. The app verifies each upload before keeping the latest 10 verified snapshots.
- **Offline JSON Export / Import (with optional AES-256-GCM encryption):** Export a complete JSON snapshot (including attachments) to device storage or restore/merge from any `.json` backup. Before any restore runs, a local **Safety Backup** is automatically created.
- **Google Drive Backup vs. Real-Time Multi-Device Sync:** Google Drive backup stores point-in-time snapshots of the full SQLite database and attachments. Real-time multi-device synchronization across multiple phones simultaneously requires a dedicated cloud backend (e.g., Firestore/REST sync server); the database schema already stores UUIDs, `deviceId`, timestamps, `version`, and `CONFLICT` detection flags for future backend integration.

---

## 5. PDF Printing & Export Instructions

- **One-Click Bulk Print ("সব কাস্টমারের হিসাব একসাথে প্রিন্ট"):** Available directly on the **Dashboard** and **Reports** screen. Recalculates every land and customer balance fresh from original ledger records, starts each customer on a new A4 page using embedded **Noto Sans Bengali** typography, and appends a **Final Consolidated Summary** page.
- **Filters:** Tap **ফিল্টার** to choose All vs. Selected Customers, All vs. Selected Lands, All Dates vs. Custom Date Range (`DD-MM-YYYY`), and Only Outstanding Dues vs. All Customers.
- **Actions after generation:** Preview pages offline, print via **Android System Print Service**, save PDF locally via **Storage Access Framework**, or share via **WhatsApp / other apps**.
- **Excel Export:** Tap **Excel (.xlsx) এক্সপোর্ট** in Reports to generate a multi-sheet `.xlsx` workbook offline.
