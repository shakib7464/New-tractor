package com.example

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.preferences.AppThemeMode
import com.example.ui.MainViewModel
import com.example.ui.navigation.AraafAppRoot
import com.example.ui.theme.AraafKhataTheme

class MainActivity : FragmentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    // 120Hz স্ক্রিন থাকলে সেটা ব্যবহারের অনুরোধ (ডিভাইসের সেটিং অনুযায়ী)
    window.attributes = window.attributes.apply { preferredRefreshRate = 120f }
    enableEdgeToEdge()
    setContent {
      val mainViewModel: MainViewModel = viewModel()
      val settings by mainViewModel.settings.collectAsStateWithLifecycle()
      val useDarkTheme = when (settings.themeMode) {
        AppThemeMode.LIGHT -> false
        AppThemeMode.DARK -> true
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
      }
      AraafKhataTheme(darkTheme = useDarkTheme) {
        AraafAppRoot(viewModel = mainViewModel)
      }
    }
  }
}
