package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.LandEntity
import com.example.data.local.entity.PaymentEntity
import com.example.domain.billing.FormatUtils
import com.example.localization.AppStrings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentsScreen(
  payments: List<PaymentEntity>,
  customers: List<CustomerEntity>,
  lands: List<LandEntity>,
  strings: AppStrings,
  currencySymbol: String,
  onBack: () -> Unit,
  onAddPayment: () -> Unit,
) {
  val activePayments = remember(payments) { payments.filter { !it.isDeleted }.sortedByDescending { it.paymentDate } }
  val totalPaid = remember(activePayments) { activePayments.sumOf { it.amount } }
  val receiverGroups = remember(activePayments) {
    activePayments.groupBy { payment ->
      Regex("(?:^|\\|\\s*)গ্রহণকারী:\\s*([^|]+)").find(payment.notes)?.groupValues?.getOrNull(1)?.trim()
        ?.takeIf { it.isNotBlank() } ?: "নাম উল্লেখ নেই"
    }.toList().sortedBy { it.first.lowercase() }
  }
  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("পেমেন্ট হিসাব") },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, contentDescription = "ফিরে যান") } },
        actions = { Button(onClick = onAddPayment, modifier = Modifier.padding(end = 8.dp)) { Icon(Icons.Rounded.Add, contentDescription = null); Text("পেমেন্ট") } },
      )
    },
  ) { padding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(padding),
      contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      item {
        val total = totalPaid
        Card(colors = CardDefaults.cardColors()) {
          Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("মোট জমা", fontWeight = FontWeight.Medium)
            Text(FormatUtils.formatTaka(total, currencySymbol), fontWeight = FontWeight.Bold)
            Text("মোট ${activePayments.size}টি পেমেন্ট", style = androidx.compose.material3.MaterialTheme.typography.bodySmall)
          }
        }
      }
      if (activePayments.isEmpty()) {
        item { Text("এখনো কোনো পেমেন্টের তথ্য নেই।") }
      }
      items(receiverGroups, key = { it.first }) { (receiver, entries) ->
        Card {
          Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Column {
                Text("গ্রহণকারী: $receiver", fontWeight = FontWeight.Bold)
                Text("${entries.size}টি লেনদেন", style = androidx.compose.material3.MaterialTheme.typography.bodySmall)
              }
              Text(FormatUtils.formatTaka(entries.sumOf { it.amount }, currencySymbol), fontWeight = FontWeight.Bold)
            }
            entries.forEach { payment ->
              androidx.compose.material3.HorizontalDivider()
              val customer = customers.firstOrNull { it.id == payment.customerId }
              val land = lands.firstOrNull { it.id == payment.landId }
              Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text(customer?.fullName ?: "অজানা কাস্টমার", fontWeight = FontWeight.SemiBold)
                  Text(FormatUtils.formatTaka(payment.amount, currencySymbol), fontWeight = FontWeight.SemiBold)
                }
                Text("জমি: ${land?.landName ?: "—"}")
                Text("তারিখ ও সময়: ${FormatUtils.formatDateTime(payment.paymentDate)}")
                Text("মাধ্যম: ${strings.paymentMethodLabel(payment.paymentMethod)}")
                Text("রসিদ: ${payment.receiptNumber}", style = androidx.compose.material3.MaterialTheme.typography.bodySmall)
              }
            }
          }
        }
      }
    }
  }
}
