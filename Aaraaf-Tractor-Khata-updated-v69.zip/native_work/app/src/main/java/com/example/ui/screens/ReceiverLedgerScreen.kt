package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Inbox
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.AdvanceEntryType
import com.example.data.local.entity.AdvancePaymentEntity
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.PaymentEntity
import com.example.domain.billing.FormatUtils
import com.example.localization.AppStrings
import com.example.ui.components.EmptyStateCard

private data class ReceiveEntry(
  val id: String,
  val receiver: String,
  val customerName: String,
  val amount: Double,
  val date: Long,
  val methodLabel: String,
  val receipt: String,
  val isAdvance: Boolean,
)

private const val NO_RECEIVER = "গ্রহণকারী উল্লেখ নেই"

/**
 * জমি যোগের সময় "জমা" বা কাজ যোগের সময় "পরিশোধিত জমা" দিলে অ্যাপ নিজে থেকে পেমেন্ট রসিদ বানায়।
 * গ্রহণকারীর হিসাবে শুধু পেমেন্ট পেজ থেকে নেওয়া টাকা দেখানো হবে, তাই এগুলো বাদ।
 * (কাস্টমারের বকেয়া/লেজারে এগুলো আগের মতোই হিসাব হয়, শুধু এই তালিকায় দেখায় না।)
 */
private fun isAutoCreatedPayment(p: PaymentEntity): Boolean =
  p.notes.contains("জমি যোগের সময় জমা") || p.referenceNote.isNotBlank()
private val receiverRegex = Regex("(?:^|\\|\\s*)গ্রহণকারী:\\s*([^|]+)")

/** কে কখন কার কাছ থেকে কত টাকা নিলো — গ্রহণকারী ধরে আলাদা হিসাব */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReceiverLedgerScreen(
  payments: List<PaymentEntity>,
  advances: List<AdvancePaymentEntity>,
  customers: List<CustomerEntity>,
  strings: AppStrings,
  currencySymbol: String,
  onBack: () -> Unit,
  onChangeReceiver: (String, Boolean, String) -> Unit = { _, _, _ -> },
) {
  val entries = remember(payments, advances, customers) {
    val nameOf = customers.associate { it.id to it.fullName }
    val fromPayments = payments.filter { !it.isDeleted && !isAutoCreatedPayment(it) }.map { p ->
      val r = receiverRegex.find(p.notes)?.groupValues?.getOrNull(1)?.trim().orEmpty()
      ReceiveEntry(
        id = p.id,
        receiver = r.ifBlank { NO_RECEIVER },
        customerName = nameOf[p.customerId] ?: "অজানা কাস্টমার",
        amount = p.amount,
        date = p.paymentDate,
        methodLabel = strings.paymentMethodLabel(p.paymentMethod),
        receipt = p.receiptNumber,
        isAdvance = false,
      )
    }
    val fromAdvances = advances
      .filter { !it.isDeleted && it.entryType == AdvanceEntryType.RECEIVED.code }
      .map { a ->
        val r = a.notes.trim().removePrefix("গ্রহণকারী:").trim()
        ReceiveEntry(
          id = a.id,
          receiver = r.ifBlank { NO_RECEIVER },
          customerName = nameOf[a.customerId] ?: "অজানা কাস্টমার",
          amount = a.amount,
          date = a.transactionDate,
          methodLabel = strings.paymentMethodLabel(a.paymentMethod),
          receipt = a.receiptNumber,
          isAdvance = true,
        )
      }
    (fromPayments + fromAdvances)
  }

  val todayStart = FormatUtils.startOfDayMillis()
  val todayEnd = FormatUtils.endOfDayMillis()
  val groups = remember(entries) {
    entries.groupBy { it.receiver.lowercase() }
      .map { (_, list) -> list.first().receiver to list.sortedByDescending { it.date } }
      .sortedByDescending { (_, list) -> list.sumOf { it.amount } }
  }
  var expanded by remember { mutableStateOf<String?>(null) }
  var editingEntry by remember { mutableStateOf<ReceiveEntry?>(null) }
  val knownReceivers = remember(groups) { groups.map { it.first }.filter { it != NO_RECEIVER } }

  editingEntry?.let { e ->
    var nameText by remember(e.id) { mutableStateOf(if (e.receiver == NO_RECEIVER) "" else e.receiver) }
    AlertDialog(
      onDismissRequest = { editingEntry = null },
      title = { Text("গ্রহণকারী ঠিক করুন") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            "${e.customerName} • ${FormatUtils.formatTaka(e.amount, currencySymbol)} • ${e.receipt}",
            style = MaterialTheme.typography.bodySmall,
          )
          OutlinedTextField(
            value = nameText,
            onValueChange = { nameText = it },
            label = { Text("কে টাকা নিয়েছেন") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
          if (knownReceivers.isNotEmpty()) {
            Row(
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            ) {
              knownReceivers.forEach { n ->
                FilterChip(
                  selected = nameText.trim().equals(n, ignoreCase = true),
                  onClick = { nameText = n },
                  label = { Text(n) },
                )
              }
            }
          }
          Text("নাম ফাঁকা রাখলে \"গ্রহণকারী উল্লেখ নেই\" হবে।", style = MaterialTheme.typography.bodySmall)
        }
      },
      confirmButton = {
        Button(onClick = {
          onChangeReceiver(e.id, e.isAdvance, nameText)
          editingEntry = null
        }) { Text("সংরক্ষণ করুন") }
      },
      dismissButton = { OutlinedButton(onClick = { editingEntry = null }) { Text("বাতিল") } },
    )
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("পেমেন্ট গ্রহণকারীর হিসাব") },
        navigationIcon = {
          IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, contentDescription = "ফিরে যান") }
        },
      )
    },
  ) { padding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(padding),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)),
        ) {
          Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("মোট গ্রহণ (সবাই মিলে)", style = MaterialTheme.typography.labelLarge)
            Text(
              FormatUtils.formatTaka(entries.sumOf { it.amount }, currencySymbol),
              style = MaterialTheme.typography.headlineSmall,
              fontWeight = FontWeight.Bold,
            )
            Text(
              "আজ: " + FormatUtils.formatTaka(
                entries.filter { it.date in todayStart..todayEnd }.sumOf { it.amount }, currencySymbol,
              ) + " • ${groups.size} জন গ্রহণকারী",
              style = MaterialTheme.typography.bodySmall,
            )
            Text(
              "কোনো এন্ট্রিতে চাপ দিয়ে গ্রহণকারীর নাম ঠিক করতে পারবেন",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }
      if (groups.isEmpty()) {
        item { EmptyStateCard(icon = Icons.Rounded.Inbox, message = "এখনো কোনো পেমেন্ট গ্রহণ হয়নি") }
      }
      items(groups, key = { it.first.lowercase() }) { (receiver, list) ->
        val isOpen = expanded == receiver
        val todaySum = list.filter { it.date in todayStart..todayEnd }.sumOf { it.amount }
        Card(
          onClick = { expanded = if (isOpen) null else receiver },
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        ) {
          Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Column(Modifier.weight(1f)) {
                Text(receiver, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                  "${list.size} বার টাকা নিয়েছেন • আজ ${FormatUtils.formatTaka(todaySum, currencySymbol)}",
                  style = MaterialTheme.typography.bodySmall,
                )
              }
              Text(
                FormatUtils.formatTaka(list.sumOf { it.amount }, currencySymbol),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.End,
              )
            }
            if (isOpen) {
              HorizontalDivider(color = Color.Gray.copy(alpha = 0.25f))
              list.forEach { e ->
                Row(
                  Modifier.fillMaxWidth().clickable { editingEntry = e },
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Column(Modifier.weight(1f)) {
                    Text(
                      e.customerName + if (e.isAdvance) " (অগ্রিম)" else "",
                      style = MaterialTheme.typography.bodyMedium,
                      fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                      "${FormatUtils.formatDate(e.date)} ${FormatUtils.formatDate(e.date, "hh:mm a")} • ${e.methodLabel} • ${e.receipt}",
                      style = MaterialTheme.typography.bodySmall,
                    )
                  }
                  Text(
                    FormatUtils.formatTaka(e.amount, currencySymbol),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                  )
                  Spacer(Modifier.size(8.dp))
                  Icon(
                    Icons.Rounded.Edit,
                    contentDescription = "গ্রহণকারী ঠিক করুন",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp),
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}
