package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Inbox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.AgriculturalJobEntity
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.JobStatus
import com.example.data.local.entity.LandEntity
import com.example.data.local.entity.PaymentEntity
import com.example.domain.billing.FormatUtils
import com.example.domain.model.CustomerFinancialSummary
import com.example.localization.AppStrings
import com.example.ui.components.EmptyStateCard
import com.example.ui.theme.LocalLedgerColors
import kotlin.math.abs

/** Dashboard কার্ড ট্যাপ করলে কোন লিস্ট খুলবে তার কোড */
object DashListKind {
  const val BILLS = "bills"
  const val COLLECTED = "collected"
  const val DUES = "dues"
  const val TODAY_WORK = "today_work"
  const val TODAY_COLLECTION = "today_collection"
}

private data class DashDetail(val left: String, val right: String)

private data class DashRow(
  val customerId: String,
  val workedKatha: Double = 0.0,
  val name: String,
  val subtitle: String,
  val amount: Double,
  val details: List<DashDetail>,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardListScreen(
  kind: String,
  summaries: List<CustomerFinancialSummary>,
  jobs: List<AgriculturalJobEntity>,
  payments: List<PaymentEntity>,
  customers: List<CustomerEntity>,
  lands: List<LandEntity>,
  strings: AppStrings,
  currencySymbol: String,
  onBack: () -> Unit,
  onSelectCustomer: (String) -> Unit,
) {
  val ledgerColors = LocalLedgerColors.current

  val title = when (kind) {
    DashListKind.BILLS -> strings.totalBilled
    DashListKind.COLLECTED -> strings.totalCollected
    DashListKind.DUES -> strings.totalOutstanding
    DashListKind.TODAY_WORK -> strings.todaysWork
    else -> strings.todaysCollection
  }
  val accent = when (kind) {
    DashListKind.BILLS -> MaterialTheme.colorScheme.primary
    DashListKind.COLLECTED, DashListKind.TODAY_COLLECTION -> ledgerColors.paidColor
    DashListKind.DUES -> ledgerColors.dueColor
    else -> MaterialTheme.colorScheme.secondary
  }
  val emptyMessage = when (kind) {
    DashListKind.BILLS -> "এখনো কোনো বিল নেই।"
    DashListKind.COLLECTED -> "এখনো কোনো আদায় হয়নি।"
    DashListKind.DUES -> "কোনো কাস্টমারের বকেয়া নেই 🎉"
    DashListKind.TODAY_WORK -> "আজ এখনো কোনো কাজ করা হয়নি।"
    else -> "আজ এখনো কোনো আদায় হয়নি।"
  }
  val countLabel = when (kind) {
    DashListKind.TODAY_WORK -> "জন কাস্টমারের কাজ"
    else -> "জন কাস্টমার"
  }

  val rows = remember(kind, summaries, jobs, payments, customers, lands) {
    val nameOf = customers.associate { it.id to it.fullName }
    val landNameOf = lands.associate { it.id to it.landName }
    val todayStart = FormatUtils.startOfDayMillis()
    val todayEnd = FormatUtils.endOfDayMillis()

    fun paymentRows(list: List<PaymentEntity>, withDate: Boolean): List<DashRow> =
      list.filter { !it.isDeleted }
        .groupBy { it.customerId }
        .map { (cid, pays) ->
          val sorted = pays.sortedByDescending { it.paymentDate }
          DashRow(
            customerId = cid,
            name = nameOf[cid] ?: "অজানা কাস্টমার",
            subtitle = "${sorted.size} বার দিয়েছেন",
            amount = sorted.sumOf { it.amount },
            details = sorted.map { p ->
              val whenText = if (withDate) FormatUtils.formatDate(p.paymentDate)
              else FormatUtils.formatDate(p.paymentDate, "hh:mm a")
              DashDetail(
                left = "$whenText • ${strings.paymentMethodLabel(p.paymentMethod)}",
                right = FormatUtils.formatTaka(p.amount, currencySymbol),
              )
            },
          )
        }
        .sortedByDescending { it.amount }

    when (kind) {
      DashListKind.BILLS -> summaries
        .filter { abs(it.totalBilled) > 0.005 }
        .map { s ->
          DashRow(
            customerId = s.customer.id,
            name = s.customer.fullName,
            subtitle = "${s.jobs.count { it.status != JobStatus.CANCELLED.code }} টি কাজ",
            amount = s.totalBilled,
            details = emptyList(),
          )
        }
        .sortedByDescending { it.amount }

      DashListKind.COLLECTED -> paymentRows(payments, withDate = true)

      DashListKind.DUES -> summaries
        .filter { it.totalOutstandingBalance > 0.005 }
        .map { s ->
          DashRow(
            customerId = s.customer.id,
            name = s.customer.fullName,
            subtitle = s.customer.village.ifBlank { s.customer.mobileNumber },
            amount = s.totalOutstandingBalance,
            details = s.lands
              .filter { it.currentBalance > 0.005 }
              .map { DashDetail(it.land.landName, FormatUtils.formatTaka(it.currentBalance, currencySymbol)) },
          )
        }
        .sortedByDescending { it.amount }

      DashListKind.TODAY_WORK -> jobs
        .filter {
          !it.isDeleted && it.status != JobStatus.CANCELLED.code && it.workDate in todayStart..todayEnd
        }
        .groupBy { it.customerId }
        .map { (cid, js) ->
          // জমির পরিমাণ (কাঠা) × কয়বার চাষ = মোট কাঠা
          fun workedKathaOf(j: AgriculturalJobEntity): Double {
            if (j.billingMethod == com.example.data.local.entity.BillingMethod.PER_HOUR.code || j.landArea <= 0.0) return 0.0
            val u = com.example.data.local.entity.LandUnit.entries.firstOrNull { it.code == j.areaUnit }
              ?: com.example.data.local.entity.LandUnit.KATHA
            val base = com.example.domain.billing.BillingCalculator.convertArea(
              j.landArea, u, com.example.data.local.entity.LandUnit.KATHA,
            )
            return base * (j.numberOfPasses ?: 1).coerceAtLeast(1)
          }
          DashRow(
            customerId = cid,
            workedKatha = js.sumOf { workedKathaOf(it) },
            name = nameOf[cid] ?: "অজানা কাস্টমার",
            subtitle = "${js.size} টি কাজ",
            amount = js.sumOf { it.totalBill },
            details = js.map { j ->
              val wk = workedKathaOf(j)
              val passes = (j.numberOfPasses ?: 1).coerceAtLeast(1)
              val areaText = if (wk > 0.0)
                " • ${FormatUtils.formatNumber(wk / passes)} × $passes বার = ${FormatUtils.formatNumber(wk)} কাঠা"
              else ""
              DashDetail(
                left = "${landNameOf[j.landId] ?: "—"} • ${strings.workTypeLabel(j.workType, j.customWorkName)}$areaText",
                right = FormatUtils.formatTaka(j.totalBill, currencySymbol),
              )
            },
          )
        }
        .sortedByDescending { it.amount }

      else -> paymentRows(
        payments.filter { it.paymentDate in todayStart..todayEnd },
        withDate = false,
      )
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text(title) },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.Rounded.ArrowBack, contentDescription = "ফিরে যান")
          }
        },
      )
    },
  ) { padding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(padding),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.12f)),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
          ) {
            Column(
              modifier = Modifier.weight(1f),
              verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
              Text(title, style = MaterialTheme.typography.labelLarge)
              Text(
                FormatUtils.formatTaka(rows.sumOf { it.amount }, currencySymbol),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = accent,
              )
              Text(
                "মোট ${rows.size} $countLabel",
                style = MaterialTheme.typography.bodySmall,
              )
            }
            if (kind == DashListKind.TODAY_WORK) {
              Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                Text("মোট জমি (চাষসহ)", style = MaterialTheme.typography.labelMedium)
                Text(
                  "${FormatUtils.formatNumber(rows.sumOf { it.workedKatha })} কাঠা",
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.Bold,
                  color = accent,
                )
              }
            }
          }
        }
      }

      if (rows.isEmpty()) {
        item { EmptyStateCard(icon = Icons.Rounded.Inbox, message = emptyMessage) }
      }

      items(rows, key = { it.customerId }) { row ->
        Card(
          onClick = { onSelectCustomer(row.customerId) },
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        ) {
          Column(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  row.name,
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                if (row.subtitle.isNotBlank()) {
                  Text(row.subtitle, style = MaterialTheme.typography.bodySmall)
                }
              }
              Text(
                FormatUtils.formatTaka(row.amount, currencySymbol),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = accent,
                textAlign = TextAlign.End,
              )
            }
            if (row.details.isNotEmpty()) {
              HorizontalDivider(color = Color.Gray.copy(alpha = 0.25f))
              row.details.forEach { d ->
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Text(
                    d.left,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.weight(1f),
                  )
                  Text(
                    d.right,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}
