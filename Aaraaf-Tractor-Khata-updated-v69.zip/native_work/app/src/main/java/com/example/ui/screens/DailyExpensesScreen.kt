@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.DailyExpenseEntity
import com.example.domain.billing.FormatUtils

private enum class ExpenseFilter(val label: String) {
  ALL("সব"),
  TODAY("আজ"),
  MONTH("এই মাস"),
}

private fun expenseNumText(v: Double): String = if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()

/** দৈনিক খরচের পেজ: কোন দিন, কোথায়, কী বাবদ, কত টাকা — সাথে আজ/এই মাস/মোট খরচ। */
@Composable
fun DailyExpensesScreen(
  expenses: List<DailyExpenseEntity>,
  currencySymbol: String,
  onBack: () -> Unit,
  onSave: (Long, String, String, Double) -> Unit,
  onUpdate: (DailyExpenseEntity, Long, String, String, Double) -> Unit,
  onDelete: (DailyExpenseEntity) -> Unit,
) {
  var showDialog by remember { mutableStateOf(false) }
  var editing by remember { mutableStateOf<DailyExpenseEntity?>(null) }
  var pendingDelete by remember { mutableStateOf<DailyExpenseEntity?>(null) }
  var filter by remember { mutableStateOf(ExpenseFilter.ALL) }

  val nowMillis = System.currentTimeMillis()
  val todayKey = FormatUtils.formatDate(nowMillis)
  val monthKey = FormatUtils.formatDate(nowMillis, "MM-yyyy")

  val todayTotal = expenses.filter { FormatUtils.formatDate(it.expenseDate) == todayKey }.sumOf { it.amount }
  val monthTotal = expenses.filter { FormatUtils.formatDate(it.expenseDate, "MM-yyyy") == monthKey }.sumOf { it.amount }
  val allTotal = expenses.sumOf { it.amount }

  val visible = when (filter) {
    ExpenseFilter.ALL -> expenses
    ExpenseFilter.TODAY -> expenses.filter { FormatUtils.formatDate(it.expenseDate) == todayKey }
    ExpenseFilter.MONTH -> expenses.filter { FormatUtils.formatDate(it.expenseDate, "MM-yyyy") == monthKey }
  }
  val visibleTotal = visible.sumOf { it.amount }
  // তারিখ অনুযায়ী ভাগ (তালিকা আগে থেকেই নতুন থেকে পুরনো ক্রমে সাজানো)
  val grouped = visible.groupBy { FormatUtils.formatDate(it.expenseDate) }.toList()
  val knownPlaces = expenses.map { it.place }.filter { it.isNotBlank() }.distinct()

  Scaffold(
    floatingActionButton = {
      ExtendedFloatingActionButton(
        onClick = { showDialog = true },
        icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
        text = { Text("খরচ লিখুন") },
      )
    },
  ) { innerPadding ->
    Column(
      modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        IconButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "ফিরে যান")
        }
        Text("দৈনিক খরচ", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
      }

      LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Text(
                when (filter) {
                  ExpenseFilter.ALL -> "মোট খরচ"
                  ExpenseFilter.TODAY -> "আজকের মোট খরচ"
                  ExpenseFilter.MONTH -> "এই মাসের মোট খরচ"
                },
                style = MaterialTheme.typography.titleSmall,
              )
              Text(
                FormatUtils.formatTaka(visibleTotal, currencySymbol),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
              )
              Text("${visible.size} টি খরচ", style = MaterialTheme.typography.bodySmall)
              Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(top = 4.dp)) {
                Column {
                  Text("আজ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(FormatUtils.formatTaka(todayTotal, currencySymbol), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                }
                Column {
                  Text("এই মাস", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(FormatUtils.formatTaka(monthTotal, currencySymbol), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                }
                Column {
                  Text("সর্বমোট", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(FormatUtils.formatTaka(allTotal, currencySymbol), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                }
              }
            }
          }
        }

        item {
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          ) {
            ExpenseFilter.values().forEach { f ->
              FilterChip(
                selected = filter == f,
                onClick = { filter = f },
                label = { Text(f.label) },
              )
            }
          }
        }

        if (visible.isEmpty()) {
          item { Text("এখনো কোনো খরচ লেখা হয়নি") }
        }

        grouped.forEach { (dateKey, dayList) ->
          item(key = "header_$dateKey") {
            Row(
              modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                if (dateKey == todayKey) "$dateKey (আজ)" else dateKey,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
              )
              Text(
                "দিনের খরচ ${FormatUtils.formatTaka(dayList.sumOf { it.amount }, currencySymbol)}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.secondary,
                fontWeight = FontWeight.SemiBold,
              )
            }
          }
          items(dayList, key = { it.id }) { e ->
            Card(
              modifier = Modifier.fillMaxWidth().clickable { editing = e },
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
              elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            ) {
              Row(
                modifier = Modifier.fillMaxWidth().padding(start = 16.dp, top = 10.dp, bottom = 10.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                  Text(e.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                  if (e.place.isNotBlank()) {
                    Text("স্থান: ${e.place}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }
                Text(
                  FormatUtils.formatTaka(e.amount, currencySymbol),
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary,
                )
                IconButton(onClick = { pendingDelete = e }) {
                  Icon(Icons.Rounded.Delete, contentDescription = "মুছুন", tint = MaterialTheme.colorScheme.error)
                }
              }
            }
          }
        }
        item { Spacer(Modifier.padding(bottom = 72.dp)) }
      }
    }
  }

  if (showDialog) {
    DailyExpenseDialog(
      title = "নতুন খরচ",
      knownPlaces = knownPlaces,
      initial = null,
      onDismiss = { showDialog = false },
      onSave = { date, place, title, amount ->
        onSave(date, place, title, amount)
        showDialog = false
      },
    )
  }

  editing?.let { e ->
    DailyExpenseDialog(
      title = "খরচ সংশোধন",
      knownPlaces = knownPlaces,
      initial = e,
      onDismiss = { editing = null },
      onSave = { date, place, title, amount ->
        onUpdate(e, date, place, title, amount)
        editing = null
      },
    )
  }

  pendingDelete?.let { e ->
    AlertDialog(
      onDismissRequest = { pendingDelete = null },
      title = { Text("খরচ মুছবেন?") },
      text = { Text("${e.title} • ${FormatUtils.formatTaka(e.amount, currencySymbol)} • ${FormatUtils.formatDate(e.expenseDate)}") },
      confirmButton = {
        Button(onClick = {
          onDelete(e)
          pendingDelete = null
        }) { Text("মুছুন") }
      },
      dismissButton = { OutlinedButton(onClick = { pendingDelete = null }) { Text("বাতিল") } },
    )
  }
}

@Composable
private fun DailyExpenseDialog(
  title: String,
  knownPlaces: List<String>,
  initial: DailyExpenseEntity?,
  onDismiss: () -> Unit,
  onSave: (Long, String, String, Double) -> Unit,
) {
  var itemText by remember { mutableStateOf(initial?.title ?: "") }
  var place by remember { mutableStateOf(initial?.place ?: "") }
  var amountText by remember { mutableStateOf(initial?.let { expenseNumText(it.amount) } ?: "") }
  var dateText by remember {
    mutableStateOf(FormatUtils.formatDate(initial?.expenseDate ?: System.currentTimeMillis()))
  }

  val amount = amountText.toDoubleOrNull() ?: 0.0
  val parsedDate = FormatUtils.parseDmyDate(dateText)
  val canSave = itemText.isNotBlank() && amount > 0.0 && parsedDate != null

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(title) },
    text = {
      Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.verticalScroll(rememberScrollState()),
      ) {
        OutlinedTextField(
          value = itemText,
          onValueChange = { itemText = it },
          label = { Text("কী খরচ করলেন") },
          modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
          value = place,
          onValueChange = { place = it },
          label = { Text("কোথায় (ঐচ্ছিক)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        val suggestions = knownPlaces.filter {
          place.isNotBlank() && it.contains(place.trim(), ignoreCase = true) && !it.equals(place.trim(), ignoreCase = true)
        }.take(4)
        if (suggestions.isNotEmpty()) {
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            suggestions.forEach { s -> TextButton(onClick = { place = s }) { Text(s) } }
          }
        }
        OutlinedTextField(
          value = amountText,
          onValueChange = { amountText = it },
          label = { Text("কত টাকা") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
          value = dateText,
          onValueChange = { dateText = it },
          label = { Text("তারিখ") },
          placeholder = { Text("DD-MM-YYYY") },
          isError = parsedDate == null,
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    },
    confirmButton = {
      Button(
        enabled = canSave,
        onClick = { onSave(parsedDate ?: System.currentTimeMillis(), place, itemText, amount) },
      ) { Text("সংরক্ষণ করুন") }
    },
    dismissButton = { OutlinedButton(onClick = onDismiss) { Text("বাতিল") } },
  )
}
