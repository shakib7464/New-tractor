package com.example

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Process
import androidx.core.content.IntentCompat

/**
 * আলাদা প্রসেসে (:restart) চলে। পুরনো প্রসেস বন্ধ নিশ্চিত করে মূল অ্যাপ নতুন প্রসেসে চালু করে,
 * তারপর নিজেও বন্ধ হয়। AraafApplication এই প্রসেসে ডাটাবেস খোলে না।
 */
class RestartActivity : Activity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    val oldPid = intent.getIntExtra(EXTRA_OLD_PID, -1)
    if (oldPid > 0 && oldPid != Process.myPid()) runCatching { Process.killProcess(oldPid) }
    val next = IntentCompat.getParcelableExtra(intent, EXTRA_NEXT_INTENT, Intent::class.java)
    if (next != null) startActivity(next)
    finish()
    Process.killProcess(Process.myPid())
  }

  companion object {
    const val EXTRA_NEXT_INTENT = "araaf_next_intent"
    const val EXTRA_OLD_PID = "araaf_old_pid"
  }
}
