package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import com.example.data.profile.ProfileManager
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.AdvancePaymentDao
import com.example.data.local.dao.AgriculturalJobDao
import com.example.data.local.dao.AttachmentDao
import com.example.data.local.dao.AuditLogDao
import com.example.data.local.dao.BackupHistoryDao
import com.example.data.local.dao.CustomerDao
import com.example.data.local.dao.DeviceInfoDao
import com.example.data.local.dao.FuelDao
import com.example.data.local.dao.LandDao
import com.example.data.local.dao.LandRateHistoryDao
import com.example.data.local.dao.LedgerTransactionDao
import com.example.data.local.dao.PaymentDao
import com.example.data.local.dao.SyncQueueDao
import com.example.data.local.dao.TractorDao
import com.example.data.local.entity.AdvancePaymentEntity
import com.example.data.local.entity.AgriculturalJobEntity
import com.example.data.local.entity.AttachmentEntity
import com.example.data.local.entity.AuditLogEntity
import com.example.data.local.entity.BackupHistoryEntity
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.DeviceInformationEntity
import com.example.data.local.entity.FuelDealerEntity
import com.example.data.local.entity.FuelEntryEntity
import com.example.data.local.entity.LandEntity
import com.example.data.local.entity.LandRateHistoryEntity
import com.example.data.local.entity.LedgerTransactionEntity
import com.example.data.local.entity.PaymentEntity
import com.example.data.local.entity.SyncQueueEntity
import com.example.data.local.entity.TractorEntity
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

@Database(
  entities = [
    CustomerEntity::class,
    LandEntity::class,
    LandRateHistoryEntity::class,
    TractorEntity::class,
    AgriculturalJobEntity::class,
    PaymentEntity::class,
    AdvancePaymentEntity::class,
    LedgerTransactionEntity::class,
    AttachmentEntity::class,
    AuditLogEntity::class,
    BackupHistoryEntity::class,
    SyncQueueEntity::class,
    DeviceInformationEntity::class,
    FuelDealerEntity::class,
    FuelEntryEntity::class,
  ],
  version = 3,
  exportSchema = false,
)
abstract class AraafDatabase : RoomDatabase() {
  abstract fun customerDao(): CustomerDao
  abstract fun landDao(): LandDao
  abstract fun landRateHistoryDao(): LandRateHistoryDao
  abstract fun tractorDao(): TractorDao
  abstract fun jobDao(): AgriculturalJobDao
  abstract fun paymentDao(): PaymentDao
  abstract fun advancePaymentDao(): AdvancePaymentDao
  abstract fun ledgerTransactionDao(): LedgerTransactionDao
  abstract fun attachmentDao(): AttachmentDao
  abstract fun auditLogDao(): AuditLogDao
  abstract fun backupHistoryDao(): BackupHistoryDao
  abstract fun syncQueueDao(): SyncQueueDao
  abstract fun deviceInfoDao(): DeviceInfoDao
  abstract fun fuelDao(): FuelDao

  companion object {
    const val DB_NAME = "araaf_tractor_khata.db"

    val MIGRATION_2_3: Migration = object : Migration(2, 3) {
      override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `fuel_dealers` (`id` TEXT NOT NULL, `name` TEXT NOT NULL, `mobile` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, `isDeleted` INTEGER NOT NULL, PRIMARY KEY(`id`))")
        db.execSQL("CREATE TABLE IF NOT EXISTS `fuel_entries` (`id` TEXT NOT NULL, `dealerId` TEXT NOT NULL, `entryType` TEXT NOT NULL, `entryDate` INTEGER NOT NULL, `liters` REAL NOT NULL, `ratePerLiter` REAL NOT NULL, `totalAmount` REAL NOT NULL, `paidAmount` REAL NOT NULL, `driverName` TEXT NOT NULL, `note` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, `isDeleted` INTEGER NOT NULL, PRIMARY KEY(`id`))")
      }
    }

    @Volatile private var INSTANCE: AraafDatabase? = null

    fun getInstance(context: Context): AraafDatabase {
      return INSTANCE ?: synchronized(this) {
        INSTANCE ?: buildDatabase(context.applicationContext).also { INSTANCE = it }
      }
    }

    private fun buildDatabase(context: Context): AraafDatabase {
      return Room.databaseBuilder(context, AraafDatabase::class.java, ProfileManager.activeDbName(context))
        .addMigrations(MIGRATION_2_3)
        // সতর্কতা: আগে যেকোনো ভার্সন-অমিলে সব গ্রাহক/হিসাব মুছে যেত। এখন শুধু একদম পুরনো ভার্সন ১ থেকে রিসেট হবে;
        // ভবিষ্যতে স্কিমা বদলালে অবশ্যই Migration লিখতে হবে, নইলে ডেটা মুছবে না (বরং ক্র্যাশ করে ধরা পড়বে)।
        .fallbackToDestructiveMigrationFrom(dropAllTables = true, 1)
        .addCallback(
          object : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
              super.onCreate(db)
              CoroutineScope(Dispatchers.IO).launch {
                seedInitialTractorAndDevice(getInstance(context))
              }
            }
          }
        )
        .build()
    }

    private val seedMutex = Mutex()

    // Application.onCreate ও Room onCreate দুটোই এটা চালায়; মিউটেক্স না থাকলে নতুন প্রোফাইলে দুটো ডিফল্ট ট্রাক্টর তৈরি হত
    suspend fun seedInitialTractorAndDevice(database: AraafDatabase): Unit = seedMutex.withLock {
      val now = System.currentTimeMillis()
      val existingDevice = database.deviceInfoDao().getDeviceInfoNow()
      val deviceId = existingDevice?.deviceId ?: UUID.randomUUID().toString()
      if (existingDevice == null) {
        database.deviceInfoDao().upsert(
          DeviceInformationEntity(
            deviceId = deviceId,
            deviceName = android.os.Build.MODEL ?: "Android Device",
            appVersion = "1.0",
            updatedAt = now,
          )
        )
      }
      if (database.tractorDao().getActiveCount() == 0) {
        database.tractorDao().insert(
          TractorEntity(
            id = UUID.randomUUID().toString(),
            tractorCode = "TRC-01",
            name = "আরাফ ট্রাক্টর-০১",
            brand = "Mahindra / Sonalika",
            model = "575 DI",
            registrationInfo = "প্রাথমিক নিবন্ধিত ট্রাক্টর",
            notes = "ডিফল্ট ট্রাক্টর",
            isActive = true,
            createdAt = now,
            updatedAt = now,
            deviceId = deviceId,
          )
        )
      }
    }
  }
}
