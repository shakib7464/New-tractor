package com.example.ui.components

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.backup.DriveAuth
import com.google.android.gms.auth.api.identity.Identity
import kotlinx.coroutines.launch

/**
 * প্রথমবার অ্যাপ খুললে Google দিয়ে লগইন।
 * লগইন সফল হলে সেই একাউন্টের Google Drive-ই ডেটা সিঙ্কের জায়গা হয়।
 *
 * onLogin(emailHint, token): সফল হলে null, ব্যর্থ হলে দেখানোর মতো বার্তা ফেরত দেয়।
 */
@Composable
fun GoogleLoginScreen(
  appName: String,
  onLogin: suspend (emailHint: String?, accessToken: String?) -> String?,
  onSkip: () -> Unit,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  var busy by remember { mutableStateOf(false) }
  var errorText by remember { mutableStateOf<String?>(null) }
  var failedOnce by remember { mutableStateOf(false) }

  fun finish(emailHint: String?, token: String?) {
    scope.launch {
      val err = onLogin(emailHint, token)
      busy = false
      if (err != null) {
        errorText = err
        failedOnce = true
      }
    }
  }

  fun fail(message: String) {
    busy = false
    errorText = message
    failedOnce = true
  }

  val authLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartIntentSenderForResult()
  ) { result ->
    if (result.resultCode == Activity.RESULT_OK) {
      try {
        val authResult = Identity.getAuthorizationClient(context)
          .getAuthorizationResultFromIntent(result.data)
        val token = authResult.accessToken
        if (token.isNullOrBlank()) {
          fail("টোকেন পাওয়া যায়নি। আবার চেষ্টা করুন।")
        } else {
          finish(authResult.toGoogleSignInAccount()?.email, token)
        }
      } catch (e: Exception) {
        fail("Google লগইন ব্যর্থ: ${e.localizedMessage}")
      }
    } else {
      fail("লগইন সম্পন্ন হয়নি। Google-এর পাতায় কোনো error থাকলে সেটা দেখুন, অথবা নিচের \"লগইন ছাড়া চালিয়ে যান\" বাটন চাপুন।")
    }
  }

  fun startLogin() {
    busy = true
    errorText = null
    Identity.getAuthorizationClient(context)
      .authorize(DriveAuth.buildRequest())
      .addOnSuccessListener { res ->
        if (res.hasResolution()) {
          val sender = res.pendingIntent?.intentSender
          if (sender != null) {
            authLauncher.launch(IntentSenderRequest.Builder(sender).build())
          } else {
            fail("লগইন স্ক্রিন খোলা যায়নি")
          }
        } else {
          val token = res.accessToken
          if (token.isNullOrBlank()) {
            fail("টোকেন পাওয়া যায়নি। আবার চেষ্টা করুন।")
          } else {
            finish(res.toGoogleSignInAccount()?.email, token)
          }
        }
      }
      .addOnFailureListener { e ->
        fail("Google লগইন কনফিগারেশন প্রয়োজন (SHA-1 / Client ID): ${e.localizedMessage}")
      }
  }

  Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(28.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      BrandLogo(size = 112.dp, contentDescription = appName)
      Spacer(Modifier.height(20.dp))
      Text(
        text = appName,
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center,
      )
      Spacer(Modifier.height(8.dp))
      Text(
        text = "Google একাউন্ট দিয়ে লগইন করুন। আপনার খাতার ডেটা ওই একাউন্টের Google Drive-এ নিরাপদে থাকবে এবং এক ফোন থেকে আরেক ফোনে মিলে যাবে।",
        style = MaterialTheme.typography.bodyMedium,
        textAlign = TextAlign.Center,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Spacer(Modifier.height(28.dp))

      if (busy) {
        CircularProgressIndicator()
      } else {
        Button(
          onClick = { startLogin() },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("google_login_button"),
        ) {
          Icon(Icons.Rounded.AccountCircle, contentDescription = null)
          Spacer(Modifier.size(8.dp))
          Text("Google দিয়ে লগইন")
        }
      }

      errorText?.let {
        Spacer(Modifier.height(16.dp))
        Text(
          text = it,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.error,
          textAlign = TextAlign.Center,
        )
      }

      if (failedOnce && !busy) {
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = onSkip, modifier = Modifier.testTag("login_skip_button")) {
          Text("লগইন ছাড়া চালিয়ে যান (শুধু এই ফোনে, সিঙ্ক বন্ধ)")
        }
      }
    }
  }
}
