package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.LandEntity
import com.example.data.local.entity.LandUnit
import com.example.localization.AppStrings
import com.example.domain.billing.BillingCalculator
import com.example.domain.billing.FormatUtils
import com.example.domain.model.CustomerFinancialSummary
import androidx.compose.material3.TextButton
import androidx.compose.runtime.LaunchedEffect

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun LandFormDialog(
  customers: List<CustomerEntity>,
  preselectedCustomerId: String?,
  existing: LandEntity? = null,
  existingCultivationPasses: Int? = null,
  existingCultivationRate: Double? = null,
  customerSummaries: List<CustomerFinancialSummary> = emptyList(),
  onAddNewCustomer: (String) -> Unit = {},
  newCustomer: Pair<String, String>? = null,
  onNewCustomerConsumed: () -> Unit = {},
  defaultUnit: String,
  strings: AppStrings,
  onDismiss: () -> Unit,
  onSave: (
    customerId: String,
    landName: String,
    village: String,
    locationDetails: String,
    sizeValue: Double,
    unit: String,
    cropInfo: String,
    season: String,
    openingBalance: Double,
    notes: String,
    cultivationRatePerKatha: Double,
    cultivationCount: Int,
    depositAmount: Double,
  ) -> Unit,
) {
  var selectedCustomerId by remember {
    mutableStateOf(existing?.customerId ?: preselectedCustomerId ?: customers.firstOrNull()?.id ?: "")
  }
  var custQuery by remember {
    mutableStateOf(customers.firstOrNull { it.id == selectedCustomerId }?.fullName ?: "")
  }

  var customerExpanded by remember { mutableStateOf(false) }
  var landName by remember { mutableStateOf(existing?.landName ?: "") }
  var village by remember { mutableStateOf(existing?.village ?: "") }
  var locationDetails by remember { mutableStateOf(existing?.locationDetails ?: "") }
  var sizeText by remember { mutableStateOf(existing?.let {
    val oldUnit = LandUnit.entries.firstOrNull { u -> u.code == it.unit } ?: LandUnit.KATHA
    BillingCalculator.convertArea(it.sizeValue, oldUnit, LandUnit.KATHA).toString()
  } ?: "") }
  var unit by remember { mutableStateOf(LandUnit.KATHA.code) }
  var cropInfo by remember { mutableStateOf(existing?.cropInfo ?: "") }
  var season by remember { mutableStateOf(existing?.cultivationSeason ?: "") }
  var openingText by remember { mutableStateOf(existing?.openingBalance?.takeIf { it > 0 }?.toString() ?: "") }
  var notes by remember { mutableStateOf(existing?.notes ?: "") }
  var passesText by remember { mutableStateOf(existingCultivationPasses?.toString() ?: "0") }
  var rateText by remember {
    mutableStateOf(
      existingCultivationRate?.takeIf { it > 0 }?.let { r -> if (r % 1.0 == 0.0) r.toLong().toString() else r.toString() } ?: ""
    )
  }
  var errorMsg by remember { mutableStateOf<String?>(null) }
  var depositText by remember { mutableStateOf("") }

  // শুধু নতুন জমি যোগের সময় প্রথম চাষের বিল হিসাব হবে
  val isNewLand = existing == null
  // নতুন জমিতে সবসময়; পুরোনো জমিতে শুধু যদি আগে থেকে চাষের বিল থাকে (সংশোধনের জন্য)
  val showCultivation = isNewLand || existingCultivationRate != null
  val sizeNow = sizeText.toDoubleOrNull() ?: 0.0
  val passesNow = (passesText.toIntOrNull() ?: 0).coerceAtLeast(0)
  val rateNow = rateText.toDoubleOrNull() ?: 0.0
  val customerDueNow = if (isNewLand) {
    (customerSummaries.firstOrNull { it.customer.id == selectedCustomerId }?.totalOutstandingBalance ?: 0.0)
  } else 0.0
  val openingNow = if (isNewLand) customerDueNow else (openingText.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
  val cultivationBill = BillingCalculator.roundCurrency(sizeNow * passesNow * rateNow)
  val grandTotal = BillingCalculator.roundCurrency(openingNow + cultivationBill)
  val depositNow = if (isNewLand) (depositText.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0) else 0.0
  val netTotal = BillingCalculator.roundCurrency(grandTotal - depositNow)
  val afterSaveTotal = netTotal

  LaunchedEffect(newCustomer) {
    newCustomer?.let { (id, name) ->
      selectedCustomerId = id
      custQuery = name
      customerExpanded = false
      onNewCustomerConsumed()
    }
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(if (existing == null) strings.addLand else "${strings.edit}: ${existing.landName}") },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        if (existing == null && preselectedCustomerId == null) {
          ExposedDropdownMenuBox(
            expanded = customerExpanded,
            onExpandedChange = { customerExpanded = it },
          ) {
            OutlinedTextField(
              value = custQuery,
              onValueChange = { custQuery = it; customerExpanded = true; errorMsg = null },
              label = { Text(strings.navCustomers) },
              placeholder = { Text("নাম বা মোবাইল লিখে খুঁজুন") },
              singleLine = true,
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = customerExpanded) },
              modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryEditable).fillMaxWidth().testTag("land_customer_search"),
            )
            ExposedDropdownMenu(
              expanded = customerExpanded,
              onDismissRequest = { customerExpanded = false },
            ) {
              customers
                .filter { c ->
                  custQuery.isBlank() ||
                    c.fullName.contains(custQuery, ignoreCase = true) ||
                    c.mobileNumber.contains(custQuery)
                }
                .forEach { c ->
                  DropdownMenuItem(
                    text = {
                      Text(if (c.mobileNumber.isBlank()) c.fullName else "${c.fullName} (${c.mobileNumber})")
                    },
                    onClick = {
                      selectedCustomerId = c.id
                      custQuery = c.fullName
                      customerExpanded = false
                    },
                  )
                }
              if (custQuery.isNotBlank() && customers.none { it.fullName.equals(custQuery.trim(), ignoreCase = true) }) {
                DropdownMenuItem(
                  text = { Text("'${custQuery.trim()}' নামে নতুন কাস্টমার তৈরি করুন") },
                  onClick = {
                    onAddNewCustomer(custQuery.trim())
                    customerExpanded = false
                  },
                )
              }
            }
          }
          TextButton(onClick = { onAddNewCustomer(custQuery.trim()) }) { Text("+ নতুন কাস্টমার যোগ করুন") }
        }

        OutlinedTextField(
          value = landName,
          onValueChange = { landName = it; errorMsg = null },
          label = { Text(strings.landName.replace("*", "").trim()) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("land_name_input"),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = sizeText,
            onValueChange = { sizeText = it; errorMsg = null },
            label = { Text(strings.landSize) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.weight(1f).testTag("land_size_input"),
          )
          if (showCultivation) {
            OutlinedTextField(
              value = passesText,
              onValueChange = { passesText = it.filter { ch -> ch.isDigit() }.trimStart('0'); errorMsg = null },
              label = { Text("কয়বার চাষ") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              singleLine = true,
              modifier = Modifier.weight(1f).testTag("land_passes_input"),
            )
          }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = if (isNewLand) customerDueNow.let { d -> if (d % 1.0 == 0.0) d.toLong().toString() else d.toString() } else openingText,
            onValueChange = { if (!isNewLand) openingText = it },
            readOnly = isNewLand,
            label = { Text(if (isNewLand) "পূর্বের বকেয়া (কাস্টমারের মোট)" else strings.openingBalance) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.weight(1f).testTag("land_opening_input"),
          )
          if (isNewLand) {
            OutlinedTextField(
              value = depositText,
              onValueChange = { depositText = it },
              label = { Text("জমা (এখনই দেওয়া টাকা)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              singleLine = true,
              modifier = Modifier.weight(1f).testTag("land_deposit_input"),
            )
          }
        }
        Text(strings.landUnit, style = MaterialTheme.typography.labelMedium)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          listOf(LandUnit.KATHA).forEach { u ->
            FilterChip(
              selected = unit == u.code,
              onClick = { unit = u.code },
              label = { Text(strings.unitLabel(u.code)) },
            )
          }
        }
        if (!isNewLand && showCultivation) {
          Text(
            "জমির মাপ বদলালে এই জমির পুরো মাপে হওয়া সব কাঠা-ভিত্তিক কাজের বিল নতুন মাপে সংশোধন হবে " +
              "(নিজ নিজ রেট ও চাষসংখ্যা ঠিক থাকবে)। আংশিক মাপে হওয়া কাজ বদলাবে না।",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        if (showCultivation) {
          OutlinedTextField(
            value = rateText,
            onValueChange = { rateText = it; errorMsg = null },
            label = { Text("প্রতি কাঠায় চাষের রেট") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("land_rate_input"),
          )
          Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            Text(
              (if (isNewLand) "চাষের মোট বিল: " else "নতুন চাষের বিল: ") + FormatUtils.formatTaka(cultivationBill),
              style = MaterialTheme.typography.bodyMedium,
            )
            if (!isNewLand) {
              Text(
                "জমি, চাষ বা রেট বদলালে বিল নতুন করে হিসাব হবে। আগের জমা ও পেমেন্টের ইতিহাস মুছবে না।",
                style = MaterialTheme.typography.bodySmall,
              )
            }
            Text(
              "আগের বকেয়া: ${FormatUtils.formatTaka(openingNow)}",
              style = MaterialTheme.typography.bodyMedium,
            )
            Text(
              "আগের বকেয়াসহ মোট পাওনা: ${FormatUtils.formatTaka(grandTotal)}",
              style = MaterialTheme.typography.titleSmall,
            )
            if (depositNow > 0.0) {
              Text(
                "জমা: ${FormatUtils.formatTaka(depositNow)}",
                style = MaterialTheme.typography.bodyMedium,
              )
              Text(
                "জমা বাদে মোট বাকি: ${FormatUtils.formatTaka(netTotal)}",
                style = MaterialTheme.typography.titleSmall,
              )
            }
            if (isNewLand) {
              Text(
                "জমি যোগের পর কাস্টমারের মোট বাকি: ${FormatUtils.formatTaka(afterSaveTotal)}",
                style = MaterialTheme.typography.titleSmall,
              )
            }
          }
        }
        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text(strings.notes) },
          modifier = Modifier.fillMaxWidth(),
        )
        if (errorMsg != null) {
          Text(errorMsg!!, color = MaterialTheme.colorScheme.error)
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val size = sizeText.toDoubleOrNull()
          if (existing == null && preselectedCustomerId == null &&
            customers.firstOrNull { it.id == selectedCustomerId }?.fullName != custQuery
          ) {
            errorMsg = "তালিকা থেকে কাস্টমার বেছে নিন"
            return@Button
          }
          if (selectedCustomerId.isBlank() || size == null || size <= 0) {
            errorMsg = "কাস্টমার ও সঠিক পরিমাণ দিন"
            return@Button
          }
          onSave(
            selectedCustomerId,
            landName.trim().ifBlank { "জমি ${sizeText.trim()} কাঠা" },
            village,
            locationDetails,
            size,
            unit,
            cropInfo,
            season,
            if (isNewLand) 0.0 else (openingText.toDoubleOrNull() ?: 0.0),
            notes,
            if (showCultivation) rateNow else 0.0,
            if (showCultivation) passesNow else 1,
            depositNow,
          )
        },
        modifier = Modifier.height(48.dp).testTag("save_land_btn"),
      ) {
        Text(strings.save)
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss, modifier = Modifier.height(48.dp)) {
        Text(strings.cancel)
      }
    },
  )
}
