package com.example.ui.screens

import com.example.ui.components.GlassCard
import com.example.ui.components.GlassAlertDialog
import com.example.ui.components.GlowOutlinedTextField
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.RestoreFromTrash
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.AgriculturalJobEntity
import com.example.data.local.entity.AuditLogEntity
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.LandEntity
import com.example.data.local.entity.PaymentEntity
import com.example.data.local.entity.TractorEntity
import com.example.domain.billing.FormatUtils
import com.example.localization.AppStrings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TractorsScreen(
  tractors: List<TractorEntity>,
  strings: AppStrings,
  onBack: () -> Unit,
  onSaveTractor: (id: String?, name: String, brand: String, model: String, reg: String, notes: String, active: Boolean) -> Unit,
) {
  var editingTractor by remember { mutableStateOf<TractorEntity?>(null) }
  var showAddDialog by remember { mutableStateOf(false) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text(strings.tractorsTitle) },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
          }
        },
      )
    },
    floatingActionButton = {
      FloatingActionButton(
        onClick = { editingTractor = null; showAddDialog = true },
        modifier = Modifier.testTag("add_tractor_fab"),
      ) {
        Icon(Icons.Rounded.Add, contentDescription = strings.addTractor)
      }
    },
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      items(tractors, key = { it.id }) { t ->
        GlassCard(
          onClick = { editingTractor = t; showAddDialog = true },
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(modifier = Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
              Text("${t.name} (${t.tractorCode})", fontWeight = FontWeight.Bold)
              Text("${t.brand} ${t.model}".trim().ifBlank { "-" }, style = MaterialTheme.typography.bodySmall)
              if (t.registrationInfo.isNotBlank()) {
                Text(t.registrationInfo, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
            Surface(
              shape = MaterialTheme.shapes.small,
              color = if (t.isActive) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            ) {
              Text(
                if (t.isActive) strings.activeStatus else "নিষ্ক্রিয়",
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
              )
            }
          }
        }
      }
    }
  }

  if (showAddDialog) {
    val t = editingTractor
    var name by remember(t) { mutableStateOf(t?.name ?: "") }
    var brand by remember(t) { mutableStateOf(t?.brand ?: "") }
    var model by remember(t) { mutableStateOf(t?.model ?: "") }
    var reg by remember(t) { mutableStateOf(t?.registrationInfo ?: "") }
    var notes by remember(t) { mutableStateOf(t?.notes ?: "") }
    var isActive by remember(t) { mutableStateOf(t?.isActive ?: true) }

    GlassAlertDialog(
      onDismissRequest = { showAddDialog = false },
      title = { Text(if (t == null) strings.addTractor else strings.edit) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          GlowOutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(strings.tractorName) }, modifier = Modifier.fillMaxWidth())
          GlowOutlinedTextField(value = brand, onValueChange = { brand = it }, label = { Text(strings.tractorBrand) }, modifier = Modifier.fillMaxWidth())
          GlowOutlinedTextField(value = model, onValueChange = { model = it }, label = { Text(strings.tractorModel) }, modifier = Modifier.fillMaxWidth())
          GlowOutlinedTextField(value = reg, onValueChange = { reg = it }, label = { Text(strings.tractorReg) }, modifier = Modifier.fillMaxWidth())
          GlowOutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text(strings.notes) }, modifier = Modifier.fillMaxWidth())
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(strings.activeStatus)
            Switch(checked = isActive, onCheckedChange = { isActive = it })
          }
        }
      },
      confirmButton = {
        Button(onClick = {
          if (name.isNotBlank()) {
            onSaveTractor(t?.id, name, brand, model, reg, notes, isActive)
            showAddDialog = false
          }
        }) { Text(strings.save) }
      },
      dismissButton = {
        OutlinedButton(onClick = { showAddDialog = false }) { Text(strings.cancel) }
      },
    )
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecycleBinScreen(
  deletedCustomers: List<CustomerEntity>,
  deletedLands: List<LandEntity>,
  deletedJobs: List<AgriculturalJobEntity>,
  deletedPayments: List<PaymentEntity>,
  strings: AppStrings,
  onBack: () -> Unit,
  onRestoreCustomer: (String) -> Unit,
  onRestoreLand: (String) -> Unit,
  onRestoreJob: (String) -> Unit,
  onRestorePayment: (String) -> Unit,
  onPermanentDeleteCustomer: (String) -> Unit,
  onPermanentDeleteJob: (String) -> Unit,
) {
  var confirmPermDelete by remember { mutableStateOf<Pair<String, () -> Unit>?>(null) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text(strings.recycleBinTitle) },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
          }
        },
      )
    },
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      item {
        GlassCard(modifier = Modifier.fillMaxWidth(), accent = MaterialTheme.colorScheme.secondary) {
          Text(strings.recycleBinRetentionNote, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
        }
      }
      items(deletedCustomers, key = { "c_${it.id}" }) { c ->
        RecycleBinRow(
          title = "কাস্টমার: ${c.fullName}",
          subtitle = "মুছে ফেলা: ${c.deletedAt?.let { FormatUtils.formatDateTime(it) } ?: "-"}",
          onRestore = { onRestoreCustomer(c.id) },
          onDeletePermanent = { confirmPermDelete = c.fullName to { onPermanentDeleteCustomer(c.id) } },
        )
      }
      items(deletedLands, key = { "l_${it.id}" }) { l ->
        RecycleBinRow(
          title = "জমি: ${l.landName} (${l.landCode})",
          subtitle = "মুছে ফেলা: ${l.deletedAt?.let { FormatUtils.formatDateTime(it) } ?: "-"}",
          onRestore = { onRestoreLand(l.id) },
          onDeletePermanent = null,
        )
      }
      items(deletedJobs, key = { "j_${it.id}" }) { j ->
        RecycleBinRow(
          title = "কাজ: ${j.jobCode} (৳${FormatUtils.formatNumber(j.totalBill)})",
          subtitle = "মুছে ফেলা: ${j.deletedAt?.let { FormatUtils.formatDateTime(it) } ?: "-"}",
          onRestore = { onRestoreJob(j.id) },
          onDeletePermanent = { confirmPermDelete = j.jobCode to { onPermanentDeleteJob(j.id) } },
        )
      }
      items(deletedPayments, key = { "p_${it.id}" }) { p ->
        RecycleBinRow(
          title = "পেমেন্ট: ${p.receiptNumber} (৳${FormatUtils.formatNumber(p.amount)})",
          subtitle = "মুছে ফেলা: ${p.deletedAt?.let { FormatUtils.formatDateTime(it) } ?: "-"}",
          onRestore = { onRestorePayment(p.id) },
          onDeletePermanent = null,
        )
      }
    }
  }

  confirmPermDelete?.let { (name, action) ->
    GlassAlertDialog(
    actionsOnTop = false,
      onDismissRequest = { confirmPermDelete = null },
      title = { Text("স্থায়ীভাবে মুছবেন?") },
      text = { Text("'$name' স্থায়ীভাবে মুছে ফেলা হলে আর পুনরুদ্ধার করা যাবে না।") },
      confirmButton = {
        Button(onClick = { action(); confirmPermDelete = null }) { Text(strings.permanentDelete) }
      },
      dismissButton = {
        TextButton(onClick = { confirmPermDelete = null }) { Text(strings.cancel) }
      },
    )
  }
}

@Composable
private fun RecycleBinRow(
  title: String,
  subtitle: String,
  onRestore: () -> Unit,
  onDeletePermanent: (() -> Unit)?,
) {
  GlassCard(modifier = Modifier.fillMaxWidth()) {
    Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
      Column(modifier = Modifier.weight(1f)) {
        Text(title, fontWeight = FontWeight.SemiBold)
        Text(subtitle, style = MaterialTheme.typography.bodySmall)
      }
      Row {
        IconButton(onClick = onRestore) {
          Icon(Icons.Rounded.RestoreFromTrash, contentDescription = "Restore", tint = MaterialTheme.colorScheme.primary)
        }
        if (onDeletePermanent != null) {
          IconButton(onClick = onDeletePermanent) {
            Icon(Icons.Rounded.DeleteForever, contentDescription = "Delete Permanently", tint = MaterialTheme.colorScheme.error)
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuditLogScreen(
  logs: List<AuditLogEntity>,
  strings: AppStrings,
  onBack: () -> Unit,
) {
  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text(strings.auditLogTitle) },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
          }
        },
      )
    },
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      items(logs, key = { it.id }) { log ->
        GlassCard(modifier = Modifier.fillMaxWidth()) {
          Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("${log.entityType} • ${log.action}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
              Text(FormatUtils.formatDateTime(log.timestamp), style = MaterialTheme.typography.labelSmall)
            }
            Text(log.summary, style = MaterialTheme.typography.bodyMedium)
          }
        }
      }
    }
  }
}
