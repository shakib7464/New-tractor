package com.example.ui.screens

import com.example.ui.components.GlassCard
import com.example.ui.components.FxConfig
import com.example.ui.components.GlassAlertDialog
import com.example.ui.components.GlowOutlinedTextField
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.data.local.entity.LandUnit
import com.example.data.preferences.AppLanguage
import com.example.data.preferences.AppSettingsState
import com.example.data.preferences.AppThemeMode
import com.example.localization.AppStrings
import com.example.data.preferences.AppLockType
import com.example.ui.components.PATTERN_MIN_DOTS
import com.example.ui.components.PatternLockPad
import com.example.ui.components.patternToSecret
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.runtime.mutableIntStateOf

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
  settings: AppSettingsState,
  strings: AppStrings,
  onBack: () -> Unit,
  onLanguageChange: (AppLanguage) -> Unit,
  onThemeChange: (AppThemeMode) -> Unit,
  onDefaultUnitChange: (String) -> Unit,
  onSaveDefaultRates: (Double, Double, Double, Double) -> Unit,
  onSetLock: (AppLockType, String) -> Unit,
  onDisablePin: () -> Unit,
  onToggleBiometric: (Boolean) -> Unit,
  onOpenBackup: () -> Unit,
  accountEmail: String? = null,
  onAutoLockChange: (Int) -> Unit = {},
) {
  var rateDec by remember(settings.defaultRatePerDecimal) { mutableStateOf((settings.defaultRatePerDecimal * 1.65).toString()) }
  var rateBigha by remember(settings.defaultRatePerBigha) { mutableStateOf(settings.defaultRatePerBigha.toString()) }
  var rateAcre by remember(settings.defaultRatePerAcre) { mutableStateOf(settings.defaultRatePerAcre.toString()) }
  var showLockChooser by remember { mutableStateOf(false) }
  var setupLockType by remember { mutableStateOf<AppLockType?>(null) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("${strings.appName} • ${strings.settingsTitle}") },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
          }
        },
      )
    },
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      // লগইন করা Gmail
      if (!accountEmail.isNullOrBlank()) {
        item {
          GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Text("লগইন করা Gmail", style = MaterialTheme.typography.labelLarge)
              Text(accountEmail, fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      // Language & Theme
      item {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(strings.languageLabel, fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              AppLanguage.entries.forEach { lang ->
                FilterChip(
                  selected = settings.language == lang,
                  onClick = { onLanguageChange(lang) },
                  label = { Text(lang.displayName) },
                  modifier = Modifier.testTag("lang_chip_${lang.code}"),
                )
              }
            }
            Text(strings.themeLabel, fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              listOf(
                AppThemeMode.SYSTEM to "সিস্টেম",
                AppThemeMode.LIGHT to "লাইট",
                AppThemeMode.DARK to "ডার্ক",
              ).forEach { (mode, label) ->
                FilterChip(
                  selected = settings.themeMode == mode,
                  onClick = { onThemeChange(mode) },
                  label = { Text(label) },
                )
              }
            }
            Text("মুদ্রা: ${settings.currencySymbol} (BDT) • তারিখ: DD-MM-YYYY", style = MaterialTheme.typography.bodySmall)
            Text("অ্যাপ ভার্সন: ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodySmall)
          }
        }
      }

      // Units & Default Rates
      item {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(strings.defaultRatesLabel, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              GlowOutlinedTextField(
                value = rateDec, onValueChange = { rateDec = it },
                label = { Text("প্রতি কাঠা (৳)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.weight(1f),
              )
            }
            Button(
              onClick = {
                onSaveDefaultRates(
                  (rateDec.toDoubleOrNull() ?: (settings.defaultRatePerDecimal * 1.65)) / 1.65,
                  settings.defaultRatePerBigha,
                  settings.defaultRatePerAcre,
                  settings.defaultRatePerHour,
                )
              },
              modifier = Modifier.fillMaxWidth().height(48.dp),
            ) {
              Text(strings.save)
            }
          }
        }
      }

      // Reduce effects: কম RAM-এর ফোনে গ্লো/ব্লার/অ্যানিমেশন কমানো
      item {
        val fxContext = androidx.compose.ui.platform.LocalContext.current
        GlassCard(modifier = Modifier.fillMaxWidth()) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
              Column(modifier = Modifier.weight(1f)) {
                Text("ইফেক্ট কমান (Reduce effects)", fontWeight = FontWeight.Bold)
                Text(
                  "গ্লো, ব্লার ও অ্যানিমেশন বন্ধ থাকবে — ধীর ফোনে অ্যাপ দ্রুত চলবে",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
              Switch(
                checked = FxConfig.reduced,
                onCheckedChange = { FxConfig.set(fxContext, it) },
              )
            }
          }
        }
      }

      // Security: PIN & Biometric
      item {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("নিরাপত্তা (Security)", fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
              Text(strings.pinLockLabel)
              Switch(
                checked = settings.pinLockEnabled,
                onCheckedChange = { enabled ->
                  if (enabled) showLockChooser = true else onDisablePin()
                },
              )
            }
            if (settings.pinLockEnabled) {
              Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(
                  when (settings.lockType) {
                    AppLockType.PIN -> "লকের ধরন: পিন"
                    AppLockType.PATTERN -> "লকের ধরন: প্যাটার্ন"
                    AppLockType.PASSWORD -> "লকের ধরন: পাসওয়ার্ড"
                  }
                )
                TextButton(onClick = { showLockChooser = true }) { Text("পরিবর্তন") }
              }
            }
            if (settings.pinLockEnabled) {
              Text("অ্যাপ ব্যাকগ্রাউন্ডে কতক্ষণ থাকলে আবার লক হবে", style = MaterialTheme.typography.bodyMedium)
              FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                  0 to "সাথে সাথে",
                  15 to "১৫ সেকেন্ড",
                  30 to "৩০ সেকেন্ড",
                  60 to "১ মিনিট",
                  300 to "৫ মিনিট",
                  900 to "১৫ মিনিট",
                ).forEach { (sec, label) ->
                  FilterChip(
                    selected = settings.autoLockSeconds == sec,
                    onClick = { onAutoLockChange(sec) },
                    label = { Text(label) },
                    modifier = Modifier.testTag("auto_lock_$sec"),
                  )
                }
              }
            }
            if (settings.pinLockEnabled) {
              Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(strings.biometricLabel)
                Switch(
                  checked = settings.biometricEnabled,
                  onCheckedChange = onToggleBiometric,
                )
              }
            }
            OutlinedButton(
              onClick = onOpenBackup,
              modifier = Modifier.fillMaxWidth().height(48.dp),
            ) {
              Text(strings.backupRestoreTitle)
            }
          }
        }
      }

      item { Spacer(Modifier.height(16.dp)) }
    }
  }

  if (showLockChooser) {
    GlassAlertDialog(
    actionsOnTop = false,
      onDismissRequest = { showLockChooser = false },
      title = { Text("লকের ধরন বেছে নিন") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedButton(
            onClick = { showLockChooser = false; setupLockType = AppLockType.PIN },
            modifier = Modifier.fillMaxWidth(),
          ) { Text("পিন (৪–৬ সংখ্যা)") }
          OutlinedButton(
            onClick = { showLockChooser = false; setupLockType = AppLockType.PATTERN },
            modifier = Modifier.fillMaxWidth(),
          ) { Text("প্যাটার্ন লক") }
          OutlinedButton(
            onClick = { showLockChooser = false; setupLockType = AppLockType.PASSWORD },
            modifier = Modifier.fillMaxWidth(),
          ) { Text("পাসওয়ার্ড লক") }
        }
      },
      confirmButton = {},
      dismissButton = { TextButton(onClick = { showLockChooser = false }) { Text(strings.cancel) } },
    )
  }

  when (setupLockType) {
    AppLockType.PIN -> SecretSetupDialog(
      title = "নতুন পিন কোড সেট করুন",
      label = "৪ থেকে ৬ সংখ্যার পিন",
      isPin = true,
      minLength = 4,
      strings = strings,
      onDismiss = { setupLockType = null },
      onConfirm = { onSetLock(AppLockType.PIN, it); setupLockType = null },
    )
    AppLockType.PASSWORD -> SecretSetupDialog(
      title = "নতুন পাসওয়ার্ড সেট করুন",
      label = "পাসওয়ার্ড (কমপক্ষে ৪ অক্ষর)",
      isPin = false,
      minLength = 4,
      strings = strings,
      onDismiss = { setupLockType = null },
      onConfirm = { onSetLock(AppLockType.PASSWORD, it); setupLockType = null },
    )
    AppLockType.PATTERN -> PatternSetupDialog(
      strings = strings,
      onDismiss = { setupLockType = null },
      onConfirm = { onSetLock(AppLockType.PATTERN, it); setupLockType = null },
    )
    null -> Unit
  }
}

@Composable
private fun SecretSetupDialog(
  title: String,
  label: String,
  isPin: Boolean,
  minLength: Int,
  strings: AppStrings,
  onDismiss: () -> Unit,
  onConfirm: (String) -> Unit,
) {
  var first by remember { mutableStateOf("") }
  var second by remember { mutableStateOf("") }
  var show by remember { mutableStateOf(false) }
  var error by remember { mutableStateOf<String?>(null) }

  fun accept(v: String) = if (isPin) v.length <= 6 && v.all { c -> c.isDigit() } else true
  val transformation = if (isPin || !show) PasswordVisualTransformation() else VisualTransformation.None
  val keyboard = KeyboardOptions(keyboardType = if (isPin) KeyboardType.NumberPassword else KeyboardType.Password)

  GlassAlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(title) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        GlowOutlinedTextField(
          value = first,
          onValueChange = { if (accept(it)) { first = it; error = null } },
          label = { Text(label) },
          visualTransformation = transformation,
          keyboardOptions = keyboard,
          trailingIcon = if (isPin) null else {
            {
              IconButton(onClick = { show = !show }) {
                Icon(if (show) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, contentDescription = null)
              }
            }
          },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("lock_setup_first"),
        )
        GlowOutlinedTextField(
          value = second,
          onValueChange = { if (accept(it)) { second = it; error = null } },
          label = { Text("আবার লিখুন (নিশ্চিত করুন)") },
          visualTransformation = transformation,
          keyboardOptions = keyboard,
          singleLine = true,
          isError = error != null,
          supportingText = error?.let { msg -> { Text(msg) } },
          modifier = Modifier.fillMaxWidth().testTag("lock_setup_second"),
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          when {
            first.length < minLength -> error = "কমপক্ষে $minLength টি অক্ষর/সংখ্যা দিন"
            first != second -> error = "দুটি মান মিলছে না"
            else -> onConfirm(first)
          }
        }
      ) { Text(strings.save) }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } },
  )
}

@Composable
private fun PatternSetupDialog(
  strings: AppStrings,
  onDismiss: () -> Unit,
  onConfirm: (String) -> Unit,
) {
  var firstPattern by remember { mutableStateOf<String?>(null) }
  var message by remember { mutableStateOf<String?>(null) }
  var isError by remember { mutableStateOf(false) }
  var resetKey by remember { mutableIntStateOf(0) }

  GlassAlertDialog(
    actionsOnTop = false,
    onDismissRequest = onDismiss,
    title = { Text(if (firstPattern == null) "নতুন প্যাটার্ন আঁকুন" else "প্যাটার্নটি আবার আঁকুন") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          message ?: "কমপক্ষে $PATTERN_MIN_DOTS টি বিন্দু যুক্ত করুন",
          color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
        )
        PatternLockPad(
          resetKey = resetKey,
          isError = isError,
          onPatternStart = { isError = false; message = null },
          onPatternComplete = { nodes ->
            val secret = patternToSecret(nodes)
            when {
              nodes.size < PATTERN_MIN_DOTS -> {
                isError = true
                message = "কমপক্ষে $PATTERN_MIN_DOTS টি বিন্দু লাগবে, আবার চেষ্টা করুন"
                resetKey++
              }
              firstPattern == null -> {
                firstPattern = secret
                message = "নিশ্চিত করতে একই প্যাটার্ন আবার আঁকুন"
                resetKey++
              }
              firstPattern == secret -> onConfirm(secret)
              else -> {
                isError = true
                message = "প্যাটার্ন মিলছে না, আবার প্রথম থেকে আঁকুন"
                firstPattern = null
                resetKey++
              }
            }
          },
          modifier = Modifier.testTag("lock_setup_pattern"),
        )
      }
    },
    confirmButton = {},
    dismissButton = { TextButton(onClick = onDismiss) { Text(strings.cancel) } },
  )
}
