package com.example

import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.preferences.AppThemeMode
import com.example.ui.MainViewModel
import com.example.ui.navigation.AraafAppRoot
import com.example.ui.theme.AraafKhataTheme

class MainActivity : FragmentActivity() {
  private fun requestHighestRefreshRate() {
    runCatching {
      @Suppress("DEPRECATION")
      val disp = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) display else windowManager.defaultDisplay
      val current = disp?.mode ?: return
      // একই রেজোলিউশনের মোডগুলোর মধ্যে সর্বোচ্চ রিফ্রেশ রেট বেছে নেওয়া (রেজোলিউশন বদলায় না)
      val best = disp.supportedModes
        .filter { it.physicalWidth == current.physicalWidth && it.physicalHeight == current.physicalHeight }
        .maxByOrNull { it.refreshRate } ?: return
      window.attributes = window.attributes.apply {
        preferredDisplayModeId = best.modeId
        preferredRefreshRate = best.refreshRate
      }
    }
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    // ডিভাইসের সর্বোচ্চ রিফ্রেশ রেট (৯০/১২০/১৪৪/১৬৫/২৪০Hz যেটা সাপোর্ট করে) ব্যবহারের অনুরোধ
    requestHighestRefreshRate()
    enableEdgeToEdge()
    setContent {
      val mainViewModel: MainViewModel = viewModel()
      val settings by mainViewModel.settings.collectAsStateWithLifecycle()
      val useDarkTheme = when (settings.themeMode) {
        AppThemeMode.LIGHT -> false
        AppThemeMode.DARK -> true
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
      }
      AraafKhataTheme(darkTheme = useDarkTheme) {
        AraafAppRoot(viewModel = mainViewModel)
      }
    }
  }
}
