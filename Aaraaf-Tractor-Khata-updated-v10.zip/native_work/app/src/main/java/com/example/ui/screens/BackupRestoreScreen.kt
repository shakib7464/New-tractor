package com.example.ui.screens

import android.app.Activity
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.backup.DriveBackupRemoteFile
import com.example.data.local.entity.BackupHistoryEntity
import com.example.data.preferences.AppSettingsState
import com.example.domain.billing.FormatUtils
import com.example.export.PdfPrintHelper
import com.example.localization.AppStrings
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupRestoreScreen(
  settings: AppSettingsState,
  history: List<BackupHistoryEntity>,
  driveBackups: List<DriveBackupRemoteFile>,
  isBusy: Boolean,
  strings: AppStrings,
  onBack: () -> Unit,
  onDriveAuthorized: (email: String, accessToken: String) -> Unit,
  onDisconnectDrive: () -> Unit,
  onBackupDriveNow: (passphrase: String?) -> Unit,
  onRefreshDriveList: () -> Unit,
  onRestoreFromDrive: (fileId: String, passphrase: String?, mergeOnly: Boolean) -> Unit,
  onToggleAutoBackup: (enabled: Boolean, wifiOnly: Boolean) -> Unit,
  onExportJson: (passphrase: String?, onFileReady: (File) -> Unit) -> Unit,
  onImportJsonUri: (uri: Uri, passphrase: String?, mergePreventDuplicates: Boolean) -> Unit,
  onShowMessage: (String) -> Unit,
  isSyncing: Boolean = false,
  onSyncNow: () -> Unit = {},
) {
  val context = LocalContext.current
  var encryptionPassphrase by remember { mutableStateOf("") }
  var mergeOnImport by remember { mutableStateOf(true) }
  var pendingExportFile by remember { mutableStateOf<File?>(null) }
  var selectedRestoreDriveFile by remember { mutableStateOf<DriveBackupRemoteFile?>(null) }

  val saveJsonLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.CreateDocument("application/json")
  ) { uri ->
    val src = pendingExportFile
    if (uri != null && src != null) {
      PdfPrintHelper.copyFileToUri(context, src, uri)
        .onSuccess { onShowMessage("JSON ব্যাকআপ সেভ হয়েছে") }
        .onFailure { onShowMessage("সেভ ব্যর্থ: ${it.message}") }
    }
    pendingExportFile = null
  }

  val importJsonLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument()
  ) { uri ->
    if (uri != null) {
      onImportJsonUri(uri, encryptionPassphrase.takeIf { it.isNotBlank() }, mergeOnImport)
    }
  }

  val driveAuthLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartIntentSenderForResult()
  ) { result ->
    if (result.resultCode == Activity.RESULT_OK) {
      try {
        val authResult = Identity.getAuthorizationClient(context)
          .getAuthorizationResultFromIntent(result.data)
        val token = authResult.accessToken
        val email = authResult.toGoogleSignInAccount()?.email ?: "Google Drive Connected"
        if (!token.isNullOrBlank()) {
          onDriveAuthorized(email, token)
        } else {
          onShowMessage("টোকেন পাওয়া যায়নি")
        }
      } catch (e: Exception) {
        onShowMessage("Google Drive অনুমোদন ব্যর্থ: ${e.message}")
      }
    }
  }

  fun startGoogleDriveAuth() {
    val authRequest = AuthorizationRequest.builder()
      .setRequestedScopes(
        listOf(
          Scope("https://www.googleapis.com/auth/drive.appdata"),
          Scope("https://www.googleapis.com/auth/drive.file"),
        )
      )
      .build()

    Identity.getAuthorizationClient(context)
      .authorize(authRequest)
      .addOnSuccessListener { res ->
        if (res.hasResolution()) {
          res.pendingIntent?.intentSender?.let { sender ->
            driveAuthLauncher.launch(IntentSenderRequest.Builder(sender).build())
          }
        } else {
          val token = res.accessToken
          val email = res.toGoogleSignInAccount()?.email ?: "Google Account"
          if (!token.isNullOrBlank()) {
            onDriveAuthorized(email, token)
          }
        }
      }
      .addOnFailureListener { e ->
        onShowMessage("Google OAuth কনফিগারেশন প্রয়োজন (SHA-1 / Client ID): ${e.localizedMessage}")
      }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text(strings.backupRestoreTitle) },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
          }
        },
      )
    },
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      if (isBusy) {
        item { LinearProgressIndicator(modifier = Modifier.fillMaxWidth()) }
      }

      // Google Drive Connection Card
      item {
        Card(
          shape = MaterialTheme.shapes.large,
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Icon(
                if (settings.driveAccountEmail != null) Icons.Rounded.CloudDone else Icons.Rounded.CloudUpload,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
              )
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  if (settings.driveAccountEmail != null) "${strings.googleDriveConnected}: ${settings.driveAccountEmail}" else strings.googleDriveConnect,
                  fontWeight = FontWeight.Bold,
                )
                Text(
                  "${strings.lastBackupLabel}: ${settings.lastSuccessfulBackupMillis?.let { FormatUtils.formatDateTime(it) } ?: "এখনো হয়নি"}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
              Button(
                onClick = { startGoogleDriveAuth() },
                modifier = Modifier.weight(1f).height(48.dp).testTag("connect_drive_btn"),
              ) {
                Text(if (settings.driveAccountEmail != null) "রি-কানেক্ট" else strings.googleDriveConnect, maxLines = 1)
              }
              if (settings.driveAccountEmail != null) {
                OutlinedButton(
                  onClick = onDisconnectDrive,
                  modifier = Modifier.height(48.dp),
                ) {
                  Text("বিচ্ছিন্ন")
                }
              }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
              Text(strings.autoBackup, modifier = Modifier.weight(1f))
              Switch(
                checked = settings.autoDriveBackupEnabled,
                onCheckedChange = { onToggleAutoBackup(it, settings.wifiOnlyBackup) },
              )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
              Text(strings.wifiOnlyBackup, modifier = Modifier.weight(1f))
              Switch(
                checked = settings.wifiOnlyBackup,
                onCheckedChange = { onToggleAutoBackup(settings.autoDriveBackupEnabled, it) },
              )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
              Button(
                onClick = { onBackupDriveNow(encryptionPassphrase.takeIf { it.isNotBlank() }) },
                enabled = settings.driveAccountEmail != null && !isBusy,
                modifier = Modifier.weight(1f).height(48.dp).testTag("drive_backup_now_btn"),
              ) {
                Text(strings.backupNow, maxLines = 1)
              }
              OutlinedButton(
                onClick = onRefreshDriveList,
                enabled = settings.driveAccountEmail != null && !isBusy,
                modifier = Modifier.height(48.dp),
              ) {
                Text("তালিকা দেখুন")
              }
            }
          }
        }
      }

      // Google Drive Sync Card
      item {
        Card(
          shape = MaterialTheme.shapes.large,
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Icon(Icons.Rounded.Sync, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
              Column(modifier = Modifier.weight(1f)) {
                Text("Google Drive সিঙ্ক", fontWeight = FontWeight.Bold)
                Text(
                  if (settings.driveAccountEmail.isNullOrBlank()) {
                    "সিঙ্ক চালু করতে আগে Google একাউন্ট যুক্ত করুন"
                  } else {
                    "শেষ সিঙ্ক: ${settings.lastSyncMillis?.let { FormatUtils.formatDateTime(it) } ?: "এখনো হয়নি"}"
                  },
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
            Text(
              "ডেটা বদলালে নিজে থেকে Drive-এ যায়, আর অ্যাপ খোলা থাকলে প্রতি ৪৫ সেকেন্ডে নতুন ডেটা আসে। কোনো এন্ট্রি মুছে যায় না, দুই ফোনের এন্ট্রিই যোগ হয়।",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (isSyncing) {
              LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            Button(
              onClick = onSyncNow,
              enabled = !settings.driveAccountEmail.isNullOrBlank() && !isSyncing,
              modifier = Modifier.fillMaxWidth().height(48.dp).testTag("sync_now_btn"),
            ) {
              Text("এখনই সিঙ্ক করুন", maxLines = 1)
            }
          }
        }
      }

      // Encryption + Local JSON Import/Export
      item {
        Card(
          shape = MaterialTheme.shapes.large,
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("অফলাইন JSON ব্যাকআপ ও এনক্রিপশন", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            OutlinedTextField(
              value = encryptionPassphrase,
              onValueChange = { encryptionPassphrase = it },
              label = { Text("ব্যাকআপ পাসওয়ার্ড (ঐচ্ছিক - AES-256 এনক্রিপশন)") },
              visualTransformation = PasswordVisualTransformation(),
              singleLine = true,
              modifier = Modifier.fillMaxWidth(),
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
              Text("ইমপোর্টে ডুপ্লিকেট এড়িয়ে মার্জ করুন", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
              Switch(checked = mergeOnImport, onCheckedChange = { mergeOnImport = it })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
              Button(
                onClick = {
                  onExportJson(encryptionPassphrase.takeIf { it.isNotBlank() }) { file ->
                    pendingExportFile = file
                    saveJsonLauncher.launch(file.name)
                  }
                },
                modifier = Modifier.weight(1f).height(48.dp).testTag("export_json_btn"),
              ) {
                Icon(Icons.Rounded.Download, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text(strings.exportJson, maxLines = 1)
              }
              OutlinedButton(
                onClick = { importJsonLauncher.launch(arrayOf("application/json", "*/*")) },
                modifier = Modifier.weight(1f).height(48.dp).testTag("import_json_btn"),
              ) {
                Icon(Icons.Rounded.UploadFile, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text(strings.importJson, maxLines = 1)
              }
            }
          }
        }
      }

      // Multi-device Sync Architecture Note
      item {
        Surface(
          shape = MaterialTheme.shapes.medium,
          color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Text(
            strings.multiDeviceSyncNote,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(12.dp),
          )
        }
      }

      // Remote Google Drive Backups
      if (driveBackups.isNotEmpty()) {
        item {
          Text("Google Drive-এ সংরক্ষিত ব্যাকআপ (সর্বশেষ ১০টি)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        items(driveBackups, key = { it.id }) { remote ->
          Surface(shape = MaterialTheme.shapes.medium, tonalElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
            Row(
              modifier = Modifier.padding(12.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(remote.name, fontWeight = FontWeight.SemiBold)
                Text("${remote.sizeBytes / 1024} KB • ${remote.createdTime}", style = MaterialTheme.typography.bodySmall)
              }
              OutlinedButton(onClick = { selectedRestoreDriveFile = remote }) {
                Icon(Icons.Rounded.Restore, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text(strings.restoreBackup)
              }
            }
          }
        }
      }

      // Local Backup History
      if (history.isNotEmpty()) {
        item {
          Text("ব্যাকআপ ইতিহাস", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        items(history.take(15), key = { it.id }) { item ->
          Surface(shape = MaterialTheme.shapes.medium, tonalElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
              Column(modifier = Modifier.weight(1f)) {
                Text(item.fileName, fontWeight = FontWeight.SemiBold)
                Text(
                  "${item.backupType} • ${item.status} • ${item.recordCount} রেকর্ড • ${FormatUtils.formatDateTime(item.createdAt)}",
                  style = MaterialTheme.typography.bodySmall,
                )
                item.errorMessage?.let {
                  Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
              }
            }
          }
        }
      }
    }
  }

  selectedRestoreDriveFile?.let { remote ->
    AlertDialog(
      onDismissRequest = { selectedRestoreDriveFile = null },
      title = { Text("ব্যাকআপ রিস্টোর করবেন?") },
      text = {
        Text("রিস্টোরের আগে বর্তমান ডেটার একটি সেফটি ব্যাকআপ স্বয়ংক্রিয়ভাবে তৈরি করা হবে।\nফাইল: ${remote.name}")
      },
      confirmButton = {
        Button(onClick = {
          onRestoreFromDrive(remote.id, encryptionPassphrase.takeIf { it.isNotBlank() }, mergeOnImport)
          selectedRestoreDriveFile = null
        }) { Text(strings.restoreBackup) }
      },
      dismissButton = {
        TextButton(onClick = { selectedRestoreDriveFile = null }) { Text(strings.cancel) }
      },
    )
  }
}
