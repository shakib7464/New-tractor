package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.profile.AppProfile

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountsScreen(
  profiles: List<AppProfile>,
  activeId: String,
  onBack: () -> Unit,
  onAddProfile: (String) -> AppProfile,
  onRename: (id: String, name: String) -> Unit,
  onDelete: (id: String) -> Unit,
  onSwitch: (id: String) -> Unit,
) {
  var showAddDialog by remember { mutableStateOf(false) }
  var newName by remember { mutableStateOf("") }
  var renameTarget by remember { mutableStateOf<AppProfile?>(null) }
  var renameText by remember { mutableStateOf("") }
  var deleteTarget by remember { mutableStateOf<AppProfile?>(null) }
  var switchTarget by remember { mutableStateOf<AppProfile?>(null) }
  var justAdded by remember { mutableStateOf<AppProfile?>(null) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("অ্যাকাউন্ট / প্রোফাইল") },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "ফিরে যান")
          }
        },
      )
    },
    floatingActionButton = {
      ExtendedFloatingActionButton(
        onClick = {
          newName = ""
          showAddDialog = true
        },
        icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
        text = { Text("নতুন প্রোফাইল") },
        modifier = Modifier.testTag("add_profile_fab"),
      )
    },
  ) { padding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(padding),
      contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      item {
        Text(
          "প্রতিটি প্রোফাইলের কাস্টমার, জমি, কাজ ও পেমেন্টের হিসাব সম্পূর্ণ আলাদা থাকে। প্রোফাইল বদলালে অ্যাপ নতুন করে চালু হবে।",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.padding(bottom = 4.dp),
        )
      }
      items(profiles, key = { it.id }) { profile ->
        val isActive = profile.id == activeId
        Card(
          onClick = { if (!isActive) switchTarget = profile },
          shape = MaterialTheme.shapes.large,
          colors = CardDefaults.cardColors(
            containerColor = if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
            else MaterialTheme.colorScheme.surface,
          ),
          border = BorderStroke(
            if (isActive) 1.5.dp else 1.dp,
            if (isActive) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
          ),
          modifier = Modifier.fillMaxWidth().testTag("profile_${profile.id}"),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Surface(
              shape = CircleShape,
              color = if (isActive) MaterialTheme.colorScheme.primary
              else MaterialTheme.colorScheme.secondary.copy(alpha = 0.18f),
              modifier = Modifier.size(46.dp),
            ) {
              Box(contentAlignment = Alignment.Center) {
                Text(
                  profile.name.trim().firstOrNull()?.toString() ?: "?",
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.Bold,
                  color = if (isActive) MaterialTheme.colorScheme.onPrimary
                  else MaterialTheme.colorScheme.secondary,
                )
              }
            }
            Column(modifier = Modifier.weight(1f)) {
              Text(
                profile.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Row(verticalAlignment = Alignment.CenterVertically) {
                if (isActive) {
                  Icon(
                    Icons.Rounded.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(14.dp),
                  )
                  Text(
                    "  এখন চালু আছে",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                  )
                } else {
                  Text(
                    "বদলাতে ট্যাপ করুন",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                }
              }
            }
            IconButton(onClick = {
              renameTarget = profile
              renameText = profile.name
            }) {
              Icon(Icons.Rounded.Edit, contentDescription = "নাম বদলান")
            }
            if (!isActive) {
              IconButton(onClick = { deleteTarget = profile }) {
                Icon(
                  Icons.Rounded.Delete,
                  contentDescription = "মুছুন",
                  tint = MaterialTheme.colorScheme.error,
                )
              }
            }
          }
        }
      }
    }
  }

  // নতুন প্রোফাইল
  if (showAddDialog) {
    AlertDialog(
      onDismissRequest = { showAddDialog = false },
      title = { Text("নতুন প্রোফাইল") },
      text = {
        OutlinedTextField(
          value = newName,
          onValueChange = { newName = it },
          label = { Text("প্রোফাইলের নাম") },
          placeholder = { Text("যেমন: ট্রাক্টর-০২ / রহিমের হিসাব") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("new_profile_name"),
        )
      },
      confirmButton = {
        TextButton(
          enabled = newName.isNotBlank(),
          onClick = {
            justAdded = onAddProfile(newName)
            showAddDialog = false
          },
        ) { Text("যোগ করুন") }
      },
      dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text("বাতিল") } },
    )
  }

  // নতুন প্রোফাইল যোগ হওয়ার পর সরাসরি যাওয়ার প্রস্তাব
  justAdded?.let { added ->
    AlertDialog(
      onDismissRequest = { justAdded = null },
      title = { Text("\"${added.name}\" তৈরি হয়েছে") },
      text = { Text("এখনই এই প্রোফাইলে যেতে চান? অ্যাপ নতুন করে চালু হবে।") },
      confirmButton = {
        TextButton(onClick = {
          justAdded = null
          onSwitch(added.id)
        }) { Text("এখনই যান") }
      },
      dismissButton = { TextButton(onClick = { justAdded = null }) { Text("পরে") } },
    )
  }

  // নাম বদল
  renameTarget?.let { target ->
    AlertDialog(
      onDismissRequest = { renameTarget = null },
      title = { Text("প্রোফাইলের নাম বদলান") },
      text = {
        OutlinedTextField(
          value = renameText,
          onValueChange = { renameText = it },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
      },
      confirmButton = {
        TextButton(
          enabled = renameText.isNotBlank(),
          onClick = {
            onRename(target.id, renameText)
            renameTarget = null
          },
        ) { Text("সংরক্ষণ") }
      },
      dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("বাতিল") } },
    )
  }

  // প্রোফাইল বদল নিশ্চিতকরণ
  switchTarget?.let { target ->
    AlertDialog(
      onDismissRequest = { switchTarget = null },
      title = { Text("\"${target.name}\" প্রোফাইলে যাবেন?") },
      text = { Text("অ্যাপ নতুন করে চালু হবে এবং ওই প্রোফাইলের হিসাব দেখাবে।") },
      confirmButton = {
        TextButton(onClick = {
          switchTarget = null
          onSwitch(target.id)
        }) { Text("যান") }
      },
      dismissButton = { TextButton(onClick = { switchTarget = null }) { Text("বাতিল") } },
    )
  }

  // মোছার নিশ্চিতকরণ
  deleteTarget?.let { target ->
    AlertDialog(
      onDismissRequest = { deleteTarget = null },
      title = { Text("\"${target.name}\" মুছবেন?") },
      text = {
        Text("এই প্রোফাইলের সব কাস্টমার, জমি, কাজ ও পেমেন্টের হিসাব স্থায়ীভাবে মুছে যাবে। এটি আর ফেরানো যাবে না।")
      },
      confirmButton = {
        TextButton(onClick = {
          onDelete(target.id)
          deleteTarget = null
        }) { Text("মুছে ফেলুন", color = MaterialTheme.colorScheme.error) }
      },
      dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("বাতিল") } },
    )
  }
}
