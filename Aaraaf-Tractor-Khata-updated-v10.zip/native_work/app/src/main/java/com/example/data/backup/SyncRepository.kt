package com.example.data.backup

import android.content.Context
import androidx.room.withTransaction
import com.example.data.local.AraafDatabase
import com.example.data.local.entity.AuditLogEntity
import com.example.data.local.entity.TractorEntity
import com.example.data.preferences.AppPreferencesManager
import com.example.data.profile.AppProfile
import com.example.data.profile.ProfileManager
import java.security.MessageDigest
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

data class SyncSummary(
  val mergedFromCloud: Int,
  val uploaded: Boolean,
  val syncedAt: Long,
)

class SyncAccountMismatchException(val expected: String) :
  IllegalStateException("এই ফোনের খাতা $expected একাউন্টের সাথে যুক্ত। সেই একাউন্টে লগইন করুন।")

/**
 * Google Drive (appDataFolder) কে সিঙ্ক সার্ভার হিসেবে ব্যবহার করে।
 *
 * নিয়ম:
 * - Drive-এ একটাই সিঙ্ক ফাইল থাকে, তাতে সব ডিভাইসের ডেটার সমষ্টি।
 * - সিঙ্কের সময় Drive-এর ডেটা ফোনে মেলানো হয়: যে এন্ট্রির updatedAt নতুন সেটা জেতে।
 * - মেলানোর সময় ফোন বা Drive কোনো এন্ট্রি মোছে না। দুই দিকের এন্ট্রিই যোগ হয়।
 *   (মুছে ফেলা মানে isDeleted চিহ্ন, সেটাও একই নিয়মে মেলে।)
 * - তারপর মেলানো ডেটা আবার Drive-এ রাখা হয়।
 */
class SyncRepository(
  private val context: Context,
  private val db: AraafDatabase,
  private val prefs: AppPreferencesManager,
  private val driveService: GoogleDriveService = GoogleDriveService(),
) {
  /** প্রতিটি প্রোফাইলের জন্য Drive-এ আলাদা সিঙ্ক ফাইল (প্রথম প্রোফাইল আগের নামই রাখে) */
  private val syncFileName: String
    get() = fileNameFor(ProfileManager.active(context))

  private val json = Json {
    prettyPrint = false
    ignoreUnknownKeys = true
    encodeDefaults = true
  }

  suspend fun syncNow(): Result<SyncSummary> = withContext(Dispatchers.IO) {
    syncMutex.withLock {
      runCatching { doSync() }
    }
  }

  /**
   * Google লগইন সম্পন্ন করে: ইমেইল নিশ্চিত করে, এই ফোন অন্য একাউন্টের সাথে যুক্ত থাকলে আটকায়,
   * তারপর একাউন্ট সংরক্ষণ করে। সফল হলে ইমেইল ফেরত দেয়।
   */
  suspend fun connectAccount(emailHint: String?, token: String?): Result<String> =
    withContext(Dispatchers.IO) {
      runCatching {
        val accessToken = token?.takeIf { it.isNotBlank() }
          ?: throw IllegalStateException("টোকেন পাওয়া যায়নি")
        val email = if (DriveAuth.looksLikeEmail(emailHint)) {
          emailHint.orEmpty()
        } else {
          driveService.fetchAccountEmail(accessToken).getOrElse {
            throw IllegalStateException("Google একাউন্টের ইমেইল পাওয়া যায়নি: ${it.message}")
          }
        }
        val bound = prefs.getSettingsNow().syncAccountEmail
        if (!bound.isNullOrBlank() && !bound.equals(email, ignoreCase = true)) {
          throw SyncAccountMismatchException(bound)
        }
        prefs.setDriveSession(email, accessToken)
        prefs.setSyncAccountEmail(email)
        prefs.setLoginSkipped(false)
        email
      }
    }

  private suspend fun doSync(): SyncSummary {
    val settings = prefs.getSettingsNow()
    if (settings.driveAccountEmail.isNullOrBlank()) {
      throw IllegalStateException("Google একাউন্ট যুক্ত নেই")
    }
    val token = DriveAuth.freshAccessToken(context, prefs)
      ?: throw IllegalStateException("Google অনুমতি নবায়ন করা যায়নি। আবার লগইন করুন।")

    // এই ফোন অন্য একাউন্টের সাথে যুক্ত থাকলে মেলানো বন্ধ (ডেটা মিশে যাওয়া ঠেকাতে)
    val accountEmail = settings.driveAccountEmail
    val resolvedEmail = if (DriveAuth.looksLikeEmail(accountEmail)) {
      accountEmail
    } else {
      driveService.fetchAccountEmail(token).getOrNull()
    }
    val boundEmail = settings.syncAccountEmail
    if (!boundEmail.isNullOrBlank() && !resolvedEmail.isNullOrBlank() &&
      !boundEmail.equals(resolvedEmail, ignoreCase = true)
    ) {
      throw SyncAccountMismatchException(boundEmail)
    }
    if (boundEmail.isNullOrBlank() && !resolvedEmail.isNullOrBlank()) {
      prefs.setSyncAccountEmail(resolvedEmail)
    }

    var attempt = 0
    var mergedTotal = 0
    while (true) {
      attempt++
      val before = driveService.listSyncFiles(token, syncFileName).getOrThrow()

      // ১) Drive-এর সব সিঙ্ক ফাইল ফোনে মেলানো
      var mergedThisRound = 0
      for (meta in before) {
        val bytes = driveService.downloadBackup(token, meta.id).getOrThrow()
        val remote = runCatching {
          json.decodeFromString<BackupPayload>(String(bytes, Charsets.UTF_8))
        }.getOrElse { throw IllegalStateException("Drive-এর সিঙ্ক ফাইল পড়া যায়নি: ${it.message}") }
        mergedThisRound += mergeRemote(remote)
      }
      mergedTotal += mergedThisRound

      // ২) ফোনের মেলানো ডেটা তৈরি
      val localPayload = buildLocalPayload()
      val hash = payloadHash(localPayload)
      val marker = prefs.getSyncMarker()
      val newestBefore = before.firstOrNull()

      // কিছুই বদলায়নি এবং Drive-এর ফাইলও আগের মতো থাকলে আপলোড দরকার নেই
      val unchanged = mergedThisRound == 0 &&
        before.size == 1 &&
        newestBefore != null &&
        marker == "$hash|${newestBefore.version}"
      if (unchanged) {
        val now = System.currentTimeMillis()
        prefs.setLastSyncAt(now)
        return SyncSummary(mergedTotal, uploaded = false, syncedAt = now)
      }

      // ৩) আপলোডের আগে দেখা: ইতিমধ্যে অন্য ফোন ফাইল বদলেছে কি না
      val after = driveService.listSyncFiles(token, syncFileName).getOrThrow()
      val changedMeanwhile = after.map { it.id to it.version } != before.map { it.id to it.version }
      if (changedMeanwhile && attempt < MAX_ATTEMPTS) continue

      // ৪) আপলোড (ফাইল থাকলে বদলানো, না থাকলে নতুন)
      val bytes = json.encodeToString(localPayload).toByteArray(Charsets.UTF_8)
      val target = after.firstOrNull()
      val newVersion = if (target != null) {
        driveService.updateFileContent(token, target.id, bytes).getOrThrow().version
      } else {
        val created = driveService.uploadBackupToAppData(token, syncFileName, bytes).getOrThrow()
        driveService.listSyncFiles(token, syncFileName).getOrNull()
          ?.firstOrNull { it.id == created.id }?.version.orEmpty()
      }
      // একসাথে দুই ফোন প্রথমবার ফাইল বানালে বাড়তি ফাইল থাকে। ডেটা এখন নতুন ফাইলে আছে, বাকিগুলো মোছা
      after.drop(1).forEach { extra -> driveService.deleteFile(token, extra.id) }

      prefs.setSyncMarker("$hash|$newVersion")
      val now = System.currentTimeMillis()
      prefs.setLastSyncAt(now)
      return SyncSummary(mergedTotal, uploaded = true, syncedAt = now)
    }
  }

  private fun isDefaultSeedTractor(t: TractorEntity): Boolean =
    t.tractorCode == "TRC-01" && t.notes == "ডিফল্ট ট্রাক্টর"

  private fun newerWins(local: Long?, remote: Long, localVersion: Long?, remoteVersion: Long): Boolean {
    if (local == null) return true
    if (remote > local) return true
    return remote == local && remoteVersion > (localVersion ?: 0L)
  }

  private suspend fun mergeRemote(remote: BackupPayload): Int {
    val purgeCutoff = System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000
    fun expiredDeleted(isDeleted: Boolean, deletedAt: Long?) =
      isDeleted && deletedAt != null && deletedAt < purgeCutoff

    var changed = 0
    db.withTransaction {
      // কাস্টমার
      val localCustomers = db.customerDao().getAllCustomersIncludingDeleted().associateBy { it.id }
      val customersToWrite = remote.customers.filter { r ->
        val l = localCustomers[r.id]
        (l != null || !expiredDeleted(r.isDeleted, r.deletedAt)) &&
          newerWins(l?.updatedAt, r.updatedAt, l?.version, r.version)
      }
      if (customersToWrite.isNotEmpty()) db.customerDao().upsertAll(customersToWrite)
      val customerIds = localCustomers.keys + customersToWrite.map { it.id }
      changed += customersToWrite.size

      // ট্রাক্টর
      val localTractors = db.tractorDao().getAllIncludingDeleted().associateBy { it.id }
      // প্রতি ফোনে নিজে থেকে একটা ডিফল্ট ট্রাক্টর তৈরি হয়; সিঙ্কে সেটা যেন দ্বিগুণ না হয়
      val tractorAlias = HashMap<String, String>()
      val localDefaultTractor = localTractors.values.firstOrNull { isDefaultSeedTractor(it) && !it.isDeleted }
      val tractorsToWrite = remote.tractors.filter { r ->
        val l = localTractors[r.id]
        if (l == null && localDefaultTractor != null && isDefaultSeedTractor(r)) {
          tractorAlias[r.id] = localDefaultTractor.id
          false
        } else {
          newerWins(l?.updatedAt, r.updatedAt, l?.version, r.version)
        }
      }
      if (tractorsToWrite.isNotEmpty()) db.tractorDao().upsertAll(tractorsToWrite)
      val tractorIds = localTractors.keys + tractorsToWrite.map { it.id }
      changed += tractorsToWrite.size

      // জমি
      val localLands = db.landDao().getAllLandsIncludingDeleted().associateBy { it.id }
      val landsToWrite = remote.lands.filter { r ->
        val l = localLands[r.id]
        r.customerId in customerIds &&
          (l != null || !expiredDeleted(r.isDeleted, r.deletedAt)) &&
          newerWins(l?.updatedAt, r.updatedAt, l?.version, r.version)
      }
      if (landsToWrite.isNotEmpty()) db.landDao().upsertAll(landsToWrite)
      val landOwner = HashMap<String, String>().apply {
        localLands.values.forEach { put(it.id, it.customerId) }
        landsToWrite.forEach { put(it.id, it.customerId) }
      }
      changed += landsToWrite.size

      // জমির রেট ইতিহাস (শুধু নতুনগুলো যোগ)
      val localRateIds = db.landRateHistoryDao().getAllNow().map { it.id }.toSet()
      val ratesToWrite = remote.landRateHistory.filter { it.id !in localRateIds && it.landId in landOwner }
      if (ratesToWrite.isNotEmpty()) db.landRateHistoryDao().insertAll(ratesToWrite)

      // কাজের বিল
      val localJobs = db.jobDao().getAllJobsIncludingDeleted().associateBy { it.id }
      val jobsToWrite = remote.jobs.filter { r ->
        val l = localJobs[r.id]
        r.customerId in customerIds &&
          landOwner[r.landId] == r.customerId &&
          (l != null || !expiredDeleted(r.isDeleted, r.deletedAt)) &&
          newerWins(l?.updatedAt, r.updatedAt, l?.version, r.version)
      }.map { r ->
        val mappedTractor = r.tractorId?.let { tractorAlias[it] ?: it }
        r.copy(tractorId = mappedTractor?.takeIf { it in tractorIds })
      }
      if (jobsToWrite.isNotEmpty()) db.jobDao().upsertAll(jobsToWrite)
      val jobIds = localJobs.keys + jobsToWrite.map { it.id }
      changed += jobsToWrite.size

      // পেমেন্ট
      val localPayments = db.paymentDao().getAllIncludingDeleted().associateBy { it.id }
      val paymentsToWrite = remote.payments.filter { r ->
        val l = localPayments[r.id]
        r.customerId in customerIds &&
          landOwner[r.landId] == r.customerId &&
          (l != null || !expiredDeleted(r.isDeleted, r.deletedAt)) &&
          newerWins(l?.updatedAt, r.updatedAt, l?.version, r.version)
      }.map { r ->
        if (r.jobId != null && r.jobId !in jobIds) r.copy(jobId = null) else r
      }
      if (paymentsToWrite.isNotEmpty()) db.paymentDao().upsertAll(paymentsToWrite)
      val paymentIds = localPayments.keys + paymentsToWrite.map { it.id }
      changed += paymentsToWrite.size

      // অগ্রিম
      val localAdvances = db.advancePaymentDao().getAllIncludingDeleted().associateBy { it.id }
      val advancesToWrite = remote.advances.filter { r ->
        val l = localAdvances[r.id]
        r.customerId in customerIds &&
          (l != null || !expiredDeleted(r.isDeleted, r.deletedAt)) &&
          newerWins(l?.updatedAt, r.updatedAt, l?.version, r.version)
      }.map { r ->
        r.copy(
          landId = r.landId?.takeIf { it in landOwner },
          jobId = r.jobId?.takeIf { it in jobIds },
        )
      }
      if (advancesToWrite.isNotEmpty()) db.advancePaymentDao().upsertAll(advancesToWrite)
      val advanceIds = localAdvances.keys + advancesToWrite.map { it.id }
      changed += advancesToWrite.size

      // লেজার
      val localTxns = db.ledgerTransactionDao().getAllIncludingDeleted().associateBy { it.id }
      val txnsToWrite = remote.transactions.filter { r ->
        val l = localTxns[r.id]
        r.customerId in customerIds &&
          landOwner[r.landId] == r.customerId &&
          (l != null || !expiredDeleted(r.isDeleted, r.deletedAt)) &&
          newerWins(l?.updatedAt, r.updatedAt, l?.version, r.version)
      }.map { r ->
        r.copy(
          jobId = r.jobId?.takeIf { it in jobIds },
          paymentId = r.paymentId?.takeIf { it in paymentIds },
          advanceId = r.advanceId?.takeIf { it in advanceIds },
        )
      }
      if (txnsToWrite.isNotEmpty()) db.ledgerTransactionDao().upsertAll(txnsToWrite)
      changed += txnsToWrite.size

            // তেলের হিসাব: দোকান ও এন্ট্রি
            val localDealers = db.fuelDao().getAllDealersIncludingDeleted().associateBy { it.id }
            val dealersToWrite = remote.fuelDealers.filter { r ->
              val l = localDealers[r.id]
              newerWins(l?.updatedAt, r.updatedAt, null, 0L)
            }
            if (dealersToWrite.isNotEmpty()) db.fuelDao().upsertAllDealers(dealersToWrite)
            changed += dealersToWrite.size

            val localFuelEntries = db.fuelDao().getAllEntriesIncludingDeleted().associateBy { it.id }
            val fuelEntriesToWrite = remote.fuelEntries.filter { r ->
              val l = localFuelEntries[r.id]
              newerWins(l?.updatedAt, r.updatedAt, null, 0L)
            }
            if (fuelEntriesToWrite.isNotEmpty()) db.fuelDao().upsertAllEntries(fuelEntriesToWrite)
            changed += fuelEntriesToWrite.size

      // অডিট লগ (শুধু নতুনগুলো যোগ)
      val localLogIds = db.auditLogDao().getAllNow().map { it.id }.toSet()
      val logsToWrite = remote.auditLogs.filter { it.id !in localLogIds }
      if (logsToWrite.isNotEmpty()) db.auditLogDao().insertAll(logsToWrite)

      if (changed > 0) {
        val devId = db.deviceInfoDao().getDeviceInfoNow()?.deviceId ?: "android-device"
        db.auditLogDao().insert(
          AuditLogEntity(
            id = UUID.randomUUID().toString(),
            entityType = "SYNC",
            entityId = remote.backupId,
            action = "CLOUD_SYNC_MERGE",
            summary = "Google Drive থেকে $changed টি এন্ট্রি মেলানো হয়েছে",
            timestamp = System.currentTimeMillis(),
            deviceId = devId,
          )
        )
      }
    }
    return changed
  }

  private suspend fun buildLocalPayload(): BackupPayload {
    val deviceId = db.deviceInfoDao().getDeviceInfoNow()?.deviceId ?: "android-device"
    return BackupPayload(
      appName = "Araaf Tractor Khata",
      schemaVersion = 1,
      backupId = UUID.randomUUID().toString(),
      createdAt = System.currentTimeMillis(),
      deviceId = deviceId,
      customers = db.customerDao().getAllCustomersIncludingDeleted().sortedBy { it.id },
      lands = db.landDao().getAllLandsIncludingDeleted().sortedBy { it.id },
      landRateHistory = db.landRateHistoryDao().getAllNow().sortedBy { it.id },
      tractors = db.tractorDao().getAllIncludingDeleted().sortedBy { it.id },
      jobs = db.jobDao().getAllJobsIncludingDeleted().sortedBy { it.id },
      payments = db.paymentDao().getAllIncludingDeleted().sortedBy { it.id },
      advances = db.advancePaymentDao().getAllIncludingDeleted().sortedBy { it.id },
      transactions = db.ledgerTransactionDao().getAllIncludingDeleted().sortedBy { it.id },
      fuelDealers = db.fuelDao().getAllDealersIncludingDeleted().sortedBy { it.id },
      fuelEntries = db.fuelDao().getAllEntriesIncludingDeleted().sortedBy { it.id },
      attachments = emptyList(),
      auditLogs = db.auditLogDao().getAllNow()
        .sortedWith(compareByDescending<AuditLogEntity> { it.timestamp }.thenBy { it.id })
        .take(MAX_AUDIT_LOGS_IN_SYNC)
        .sortedBy { it.id },
      attachmentBlobsBase64 = emptyMap(),
    )
  }

  private fun payloadHash(payload: BackupPayload): String {
    val normalized = payload.copy(backupId = "", createdAt = 0L, deviceId = "")
    val bytes = json.encodeToString(normalized).toByteArray(Charsets.UTF_8)
    return MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
  }

  companion object {
    const val SYNC_FILE_NAME = "AraafTractorKhata_Sync.json"

    fun fileNameFor(profile: AppProfile): String =
      if (profile.id == ProfileManager.DEFAULT_ID) SYNC_FILE_NAME
      else "AraafTractorKhata_Sync_${profile.id}.json"
    private const val MAX_ATTEMPTS = 3
    private const val MAX_AUDIT_LOGS_IN_SYNC = 1000
    private val syncMutex = Mutex()
  }
}
