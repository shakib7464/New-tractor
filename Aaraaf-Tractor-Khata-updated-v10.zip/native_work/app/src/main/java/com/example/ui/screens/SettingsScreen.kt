package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.LandUnit
import com.example.data.preferences.AppLanguage
import com.example.data.preferences.AppSettingsState
import com.example.data.preferences.AppThemeMode
import com.example.localization.AppStrings

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
  settings: AppSettingsState,
  strings: AppStrings,
  onBack: () -> Unit,
  onLanguageChange: (AppLanguage) -> Unit,
  onThemeChange: (AppThemeMode) -> Unit,
  onDefaultUnitChange: (String) -> Unit,
  onSaveDefaultRates: (Double, Double, Double, Double) -> Unit,
  onSetPin: (String) -> Unit,
  onDisablePin: () -> Unit,
  onToggleBiometric: (Boolean) -> Unit,
  onOpenBackup: () -> Unit,
) {
  var rateDec by remember(settings.defaultRatePerDecimal) { mutableStateOf((settings.defaultRatePerDecimal * 1.65).toString()) }
  var rateBigha by remember(settings.defaultRatePerBigha) { mutableStateOf(settings.defaultRatePerBigha.toString()) }
  var rateAcre by remember(settings.defaultRatePerAcre) { mutableStateOf(settings.defaultRatePerAcre.toString()) }
  var rateHour by remember(settings.defaultRatePerHour) { mutableStateOf(settings.defaultRatePerHour.toString()) }
  var showPinDialog by remember { mutableStateOf(false) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("${strings.appName} • ${strings.settingsTitle}") },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
          }
        },
      )
    },
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      // Language & Theme
      item {
        Card(shape = MaterialTheme.shapes.medium) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(strings.languageLabel, fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              AppLanguage.entries.forEach { lang ->
                FilterChip(
                  selected = settings.language == lang,
                  onClick = { onLanguageChange(lang) },
                  label = { Text(lang.displayName) },
                  modifier = Modifier.testTag("lang_chip_${lang.code}"),
                )
              }
            }
            Text(strings.themeLabel, fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              listOf(
                AppThemeMode.SYSTEM to "সিস্টেম",
                AppThemeMode.LIGHT to "লাইট",
                AppThemeMode.DARK to "ডার্ক",
              ).forEach { (mode, label) ->
                FilterChip(
                  selected = settings.themeMode == mode,
                  onClick = { onThemeChange(mode) },
                  label = { Text(label) },
                )
              }
            }
            Text("মুদ্রা: ${settings.currencySymbol} (BDT) • তারিখ: DD-MM-YYYY", style = MaterialTheme.typography.bodySmall)
            Text("অ্যাপ ভার্সন: 2.0", style = MaterialTheme.typography.bodySmall)
          }
        }
      }

      // Units & Default Rates
      item {
        Card(shape = MaterialTheme.shapes.medium) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(strings.landUnit, fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              listOf(LandUnit.KATHA).forEach { u ->
                FilterChip(
                  selected = settings.defaultLandUnit == u.code,
                  onClick = { onDefaultUnitChange(u.code) },
                  label = { Text(strings.unitLabel(u.code)) },
                )
              }
            }
            Text(strings.defaultRatesLabel, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              OutlinedTextField(
                value = rateDec, onValueChange = { rateDec = it },
                label = { Text("প্রতি কাঠা (৳)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.weight(1f),
              )
              OutlinedTextField(
                value = rateHour, onValueChange = { rateHour = it },
                label = { Text("প্রতি ঘণ্টা (৳)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.weight(1f),
              )
            }
            Button(
              onClick = {
                onSaveDefaultRates(
                  (rateDec.toDoubleOrNull() ?: (settings.defaultRatePerDecimal * 1.65)) / 1.65,
                  settings.defaultRatePerBigha,
                  settings.defaultRatePerAcre,
                  rateHour.toDoubleOrNull() ?: settings.defaultRatePerHour,
                )
              },
              modifier = Modifier.fillMaxWidth().height(48.dp),
            ) {
              Text(strings.save)
            }
          }
        }
      }

      // Security: PIN & Biometric
      item {
        Card(shape = MaterialTheme.shapes.medium) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("নিরাপত্তা (Security)", fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
              Text(strings.pinLockLabel)
              Switch(
                checked = settings.pinLockEnabled,
                onCheckedChange = { enabled ->
                  if (enabled) showPinDialog = true else onDisablePin()
                },
              )
            }
            if (settings.pinLockEnabled) {
              Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(strings.biometricLabel)
                Switch(
                  checked = settings.biometricEnabled,
                  onCheckedChange = onToggleBiometric,
                )
              }
            }
            OutlinedButton(
              onClick = onOpenBackup,
              modifier = Modifier.fillMaxWidth().height(48.dp),
            ) {
              Text(strings.backupRestoreTitle)
            }
          }
        }
      }

      item { Spacer(Modifier.height(16.dp)) }
    }
  }

  if (showPinDialog) {
    var pinInput by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { showPinDialog = false },
      title = { Text("নতুন পিন কোড সেট করুন") },
      text = {
        OutlinedTextField(
          value = pinInput,
          onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) pinInput = it },
          label = { Text("৪ থেকে ৬ সংখ্যার পিন") },
          visualTransformation = PasswordVisualTransformation(),
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
      },
      confirmButton = {
        Button(
          onClick = {
            if (pinInput.length >= 4) {
              onSetPin(pinInput)
              showPinDialog = false
            }
          }
        ) { Text(strings.save) }
      },
      dismissButton = {
        TextButton(onClick = { showPinDialog = false }) { Text(strings.cancel) }
      },
    )
  }
}
