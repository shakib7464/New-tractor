package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.material3.Surface
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.ManageAccounts
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.localization.AppStrings

data class MoreMenuItem(
  val title: String,
  val subtitle: String,
  val icon: ImageVector,
  val tag: String,
  val onClick: () -> Unit,
)

@Composable
fun MoreHubScreen(
  strings: AppStrings,
  profileName: String,
  profileCount: Int,
  trashCount: Int,
  lastBackupText: String,
  onOpenJobs: () -> Unit,
  onOpenReports: () -> Unit,
  onOpenAccounts: () -> Unit,
  onOpenBackup: () -> Unit,
  onOpenRecycleBin: () -> Unit,
  onOpenSettings: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val items = listOf(
    MoreMenuItem(
      title = "অ্যাকাউন্ট (Account)",
      subtitle = "প্রোফাইল বদলান ও নতুন প্রোফাইল যোগ করুন • মোট $profileCount টি",
      icon = Icons.Rounded.ManageAccounts,
      tag = "more_accounts",
      onClick = onOpenAccounts,
    ),
    MoreMenuItem(
      title = strings.navJobs,
      subtitle = "কাজ, বিল ও বকেয়ার তালিকা",
      icon = Icons.Rounded.ReceiptLong,
      tag = "more_jobs",
      onClick = onOpenJobs,
    ),
    MoreMenuItem(
      title = strings.navReports,
      subtitle = "সারসংক্ষেপ ও বিভিন্ন হিসাবের রিপোর্ট",
      icon = Icons.Rounded.Assessment,
      tag = "more_reports",
      onClick = onOpenReports,
    ),
    MoreMenuItem(
      title = strings.backupRestoreTitle,
      subtitle = lastBackupText,
      icon = Icons.Rounded.CloudUpload,
      tag = "more_backup",
      onClick = onOpenBackup,
    ),
    MoreMenuItem(
      title = strings.recycleBinTitle,
      subtitle = "$trashCount টি পুনরুদ্ধারযোগ্য রেকর্ড (৩০ দিন)",
      icon = Icons.Rounded.DeleteSweep,
      tag = "more_recycle_bin",
      onClick = onOpenRecycleBin,
    ),
    MoreMenuItem(
      title = strings.settingsTitle,
      subtitle = "ভাষা, থিম, ডিফল্ট রেট, পিন ও ফিঙ্গারপ্রিন্ট লক",
      icon = Icons.Rounded.Settings,
      tag = "more_settings",
      onClick = onOpenSettings,
    ),
  )

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    item {
      Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp).testTag("profile_header"),
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(14.dp),
          modifier = Modifier
            .background(
              Brush.horizontalGradient(
                listOf(Color(0xFF1B4332), Color(0xFF2D6A4F), Color(0xFF40916C)),
              ),
            )
            .padding(horizontal = 18.dp, vertical = 18.dp),
        ) {
          Surface(
            shape = CircleShape,
            color = Color(0xFFFDE68A),
            modifier = Modifier.size(56.dp),
          ) {
            Box(contentAlignment = Alignment.Center) {
              Text(
                text = profileName.trim().firstOrNull()?.toString() ?: "?",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1B4332),
              )
            }
          }
          Column(modifier = Modifier.weight(1f)) {
            Text(
              "সক্রিয় প্রোফাইল",
              style = MaterialTheme.typography.labelMedium,
              color = Color.White.copy(alpha = 0.78f),
            )
            Text(
              profileName,
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Bold,
              color = Color.White,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            Text(
              "শুধু এই প্রোফাইলের হিসাব দেখানো হচ্ছে",
              style = MaterialTheme.typography.bodySmall,
              color = Color(0xFFFDE68A),
            )
          }
        }
      }
    }
    items(items, key = { it.tag }) { item ->
      Card(
        onClick = item.onClick,
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth().testTag(item.tag),
      ) {
        Row(
          modifier = Modifier.padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
          Icon(
            item.icon,
            contentDescription = item.title,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(28.dp),
          )
          Column(modifier = Modifier.weight(1f)) {
            Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(item.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }
          Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = null)
        }
      }
    }
  }
}
