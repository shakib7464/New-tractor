package com.example.data.backup

import com.example.data.local.entity.FuelDealerEntity
import com.example.data.local.entity.FuelEntryEntity

import com.example.data.local.entity.AdvancePaymentEntity
import com.example.data.local.entity.AgriculturalJobEntity
import com.example.data.local.entity.AttachmentEntity
import com.example.data.local.entity.AuditLogEntity
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.LandEntity
import com.example.data.local.entity.LandRateHistoryEntity
import com.example.data.local.entity.LedgerTransactionEntity
import com.example.data.local.entity.PaymentEntity
import com.example.data.local.entity.TractorEntity
import kotlinx.serialization.Serializable

@Serializable
data class BackupPayload(
  val appName: String = "Araaf Tractor Khata",
  val schemaVersion: Int = 1,
  val backupId: String,
  val createdAt: Long,
  val deviceId: String,
  val customers: List<CustomerEntity> = emptyList(),
  val lands: List<LandEntity> = emptyList(),
  val landRateHistory: List<LandRateHistoryEntity> = emptyList(),
  val tractors: List<TractorEntity> = emptyList(),
  val jobs: List<AgriculturalJobEntity> = emptyList(),
  val payments: List<PaymentEntity> = emptyList(),
  val advances: List<AdvancePaymentEntity> = emptyList(),
  val transactions: List<LedgerTransactionEntity> = emptyList(),
  val fuelDealers: List<FuelDealerEntity> = emptyList(),
  val fuelEntries: List<FuelEntryEntity> = emptyList(),
  val attachments: List<AttachmentEntity> = emptyList(),
  val auditLogs: List<AuditLogEntity> = emptyList(),
  val attachmentBlobsBase64: Map<String, String> = emptyMap(),
)

@Serializable
data class BackupEnvelope(
  val appName: String = "Araaf Tractor Khata",
  val schemaVersion: Int = 1,
  val checksumSha256: String,
  val isEncrypted: Boolean = false,
  val encryptedPayloadBase64: String? = null,
  val payload: BackupPayload? = null,
)

data class DriveBackupRemoteFile(
  val id: String,
  val name: String,
  val sizeBytes: Long,
  val createdTime: String,
)

data class DriveSyncFileMeta(
  val id: String,
  val version: String,
  val modifiedTime: String,
  val sizeBytes: Long,
)
