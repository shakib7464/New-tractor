package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import androidx.room.Upsert
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.LandEntity
import com.example.data.local.entity.LandRateHistoryEntity
import com.example.data.local.entity.TractorEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerDao {
  @Query("SELECT * FROM customers WHERE isDeleted = 0 ORDER BY fullName COLLATE NOCASE ASC")
  fun observeActiveCustomers(): Flow<List<CustomerEntity>>

  @Query("SELECT * FROM customers WHERE isDeleted = 1 ORDER BY deletedAt DESC")
  fun observeDeletedCustomers(): Flow<List<CustomerEntity>>

  @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
  fun observeCustomerById(id: String): Flow<CustomerEntity?>

  @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
  suspend fun getById(id: String): CustomerEntity?

  @Query("SELECT * FROM customers WHERE isDeleted = 0 ORDER BY fullName COLLATE NOCASE ASC")
  suspend fun getActiveCustomersNow(): List<CustomerEntity>

  @Query("SELECT * FROM customers")
  suspend fun getAllCustomersIncludingDeleted(): List<CustomerEntity>

  @Query("SELECT COUNT(*) FROM customers")
  suspend fun getTotalCountIncludingDeleted(): Int

  @Query(
    "SELECT * FROM customers WHERE isDeleted = 0 AND ((:mobile <> '' AND mobileNumber = :mobile) OR (LOWER(fullName) = LOWER(:name) AND LOWER(village) = LOWER(:village))) LIMIT 1"
  )
  suspend fun findDuplicateCustomer(mobile: String, name: String, village: String): CustomerEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(customer: CustomerEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(customers: List<CustomerEntity>)

  @Upsert
  suspend fun upsertAll(customers: List<CustomerEntity>)

  @Update
  suspend fun update(customer: CustomerEntity)

  @Query(
    "UPDATE customers SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt, version = version + 1 WHERE id = :id"
  )
  suspend fun softDelete(id: String, deletedAt: Long)

  @Query(
    "UPDATE customers SET isDeleted = 0, deletedAt = NULL, updatedAt = :now, version = version + 1 WHERE id = :id"
  )
  suspend fun restore(id: String, now: Long)

  @Query("DELETE FROM customers WHERE id = :id")
  suspend fun hardDeleteById(id: String)

  @Query("DELETE FROM customers WHERE isDeleted = 1 AND deletedAt IS NOT NULL AND deletedAt < :cutoff")
  suspend fun purgeExpired(cutoff: Long)

  @Query("DELETE FROM customers")
  suspend fun deleteAll()
}

@Dao
interface LandDao {
  @Query("SELECT * FROM lands WHERE isDeleted = 0 ORDER BY landName COLLATE NOCASE ASC")
  fun observeActiveLands(): Flow<List<LandEntity>>

  @Query("SELECT * FROM lands WHERE customerId = :customerId AND isDeleted = 0 ORDER BY landName COLLATE NOCASE ASC")
  fun observeLandsByCustomer(customerId: String): Flow<List<LandEntity>>

  @Query("SELECT * FROM lands WHERE isDeleted = 1 ORDER BY deletedAt DESC")
  fun observeDeletedLands(): Flow<List<LandEntity>>

  @Query("SELECT * FROM lands WHERE id = :id LIMIT 1")
  fun observeLandById(id: String): Flow<LandEntity?>

  @Query("SELECT * FROM lands WHERE id = :id LIMIT 1")
  suspend fun getById(id: String): LandEntity?

  @Query("SELECT * FROM lands WHERE customerId = :customerId AND isDeleted = 0")
  suspend fun getLandsByCustomerNow(customerId: String): List<LandEntity>

  @Query("SELECT * FROM lands WHERE isDeleted = 0")
  suspend fun getActiveLandsNow(): List<LandEntity>

  @Query("SELECT * FROM lands")
  suspend fun getAllLandsIncludingDeleted(): List<LandEntity>

  @Query("SELECT COUNT(*) FROM lands")
  suspend fun getTotalCountIncludingDeleted(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(land: LandEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(lands: List<LandEntity>)

  @Upsert
  suspend fun upsertAll(lands: List<LandEntity>)

  @Update
  suspend fun update(land: LandEntity)

  @Query(
    "UPDATE lands SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt, version = version + 1 WHERE id = :id"
  )
  suspend fun softDelete(id: String, deletedAt: Long)

  @Query(
    "UPDATE lands SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt, version = version + 1 WHERE customerId = :customerId AND isDeleted = 0"
  )
  suspend fun softDeleteByCustomer(customerId: String, deletedAt: Long)

  @Query(
    "UPDATE lands SET isDeleted = 0, deletedAt = NULL, updatedAt = :now, version = version + 1 WHERE id = :id"
  )
  suspend fun restore(id: String, now: Long)

  @Query(
    "UPDATE lands SET isDeleted = 0, deletedAt = NULL, updatedAt = :now, version = version + 1 WHERE customerId = :customerId"
  )
  suspend fun restoreByCustomer(customerId: String, now: Long)

  @Query("DELETE FROM lands WHERE id = :id")
  suspend fun hardDeleteById(id: String)

  @Query("DELETE FROM lands WHERE isDeleted = 1 AND deletedAt IS NOT NULL AND deletedAt < :cutoff")
  suspend fun purgeExpired(cutoff: Long)

  @Query("DELETE FROM lands")
  suspend fun deleteAll()
}

@Dao
interface LandRateHistoryDao {
  @Query("SELECT * FROM land_rate_history WHERE landId = :landId ORDER BY effectiveDate DESC")
  fun observeByLand(landId: String): Flow<List<LandRateHistoryEntity>>

  @Query("SELECT * FROM land_rate_history WHERE landId = :landId AND workType = :workType ORDER BY effectiveDate DESC LIMIT 1")
  suspend fun getLatestRate(landId: String, workType: String): LandRateHistoryEntity?

  @Query("SELECT * FROM land_rate_history")
  suspend fun getAllNow(): List<LandRateHistoryEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(entry: LandRateHistoryEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(entries: List<LandRateHistoryEntity>)

  @Query("DELETE FROM land_rate_history")
  suspend fun deleteAll()
}

@Dao
interface TractorDao {
  @Query("SELECT * FROM tractors WHERE isDeleted = 0 ORDER BY isActive DESC, name ASC")
  fun observeActiveTractors(): Flow<List<TractorEntity>>

  @Query("SELECT * FROM tractors WHERE isDeleted = 0 ORDER BY isActive DESC, name ASC")
  suspend fun getActiveTractorsNow(): List<TractorEntity>

  @Query("SELECT * FROM tractors")
  suspend fun getAllIncludingDeleted(): List<TractorEntity>

  @Query("SELECT COUNT(*) FROM tractors WHERE isDeleted = 0")
  suspend fun getActiveCount(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(tractor: TractorEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(tractors: List<TractorEntity>)

  @Upsert
  suspend fun upsertAll(tractors: List<TractorEntity>)

  @Update
  suspend fun update(tractor: TractorEntity)

  @Query("UPDATE tractors SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt WHERE id = :id")
  suspend fun softDelete(id: String, deletedAt: Long)

  @Query("DELETE FROM tractors")
  suspend fun deleteAll()
}
