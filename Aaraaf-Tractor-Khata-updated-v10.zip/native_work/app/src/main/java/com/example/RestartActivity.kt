package com.example

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Process
import androidx.core.content.IntentCompat

/**
 * প্রোফাইল বদলের পর অ্যাপ পুরোপুরি (নতুন প্রসেসে) চালু করার জন্য আলাদা প্রসেসের ছোট স্বচ্ছ Activity।
 * আগের প্রসেস বন্ধ করে, তারপর মূল অ্যাপ চালু করে — ফলে আগের প্রোফাইলের ডাটাবেস মেমরিতে থেকে যায় না।
 */
class RestartActivity : Activity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    val mainPid = intent.getIntExtra(EXTRA_MAIN_PID, -1)
    val launchIntent = IntentCompat.getParcelableExtra(intent, EXTRA_LAUNCH_INTENT, Intent::class.java)

    if (mainPid > 0 && mainPid != Process.myPid()) {
      Process.killProcess(mainPid)
    }
    if (launchIntent != null) {
      startActivity(launchIntent)
    }
    finish()
    Runtime.getRuntime().exit(0)
  }

  companion object {
    const val EXTRA_MAIN_PID = "restart_main_pid"
    const val EXTRA_LAUNCH_INTENT = "restart_launch_intent"
  }
}
