package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.LandEntity
import com.example.data.local.entity.PaymentEntity
import com.example.domain.billing.FormatUtils
import com.example.localization.AppStrings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentsScreen(
  payments: List<PaymentEntity>,
  customers: List<CustomerEntity>,
  lands: List<LandEntity>,
  strings: AppStrings,
  currencySymbol: String,
  onBack: () -> Unit,
  onAddPayment: () -> Unit,
) {
  val activePayments = payments.filter { !it.isDeleted }.sortedByDescending { it.paymentDate }
  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("পেমেন্ট হিসাব") },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, contentDescription = "ফিরে যান") } },
        actions = { Button(onClick = onAddPayment, modifier = Modifier.padding(end = 8.dp)) { Icon(Icons.Rounded.Add, contentDescription = null); Text("পেমেন্ট") } },
      )
    },
  ) { padding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(padding),
      contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      item {
        val total = activePayments.sumOf { it.amount }
        Card(colors = CardDefaults.cardColors()) {
          Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("মোট জমা", fontWeight = FontWeight.Medium)
            Text(FormatUtils.formatTaka(total, currencySymbol), fontWeight = FontWeight.Bold)
            Text("মোট ${activePayments.size}টি পেমেন্ট", style = androidx.compose.material3.MaterialTheme.typography.bodySmall)
          }
        }
      }
      if (activePayments.isEmpty()) {
        item { Text("এখনো কোনো পেমেন্টের তথ্য নেই।") }
      }
      items(activePayments, key = { it.id }) { payment ->
        val customer = customers.firstOrNull { it.id == payment.customerId }
        val land = lands.firstOrNull { it.id == payment.landId }
        Card {
          Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text(customer?.fullName ?: "অজানা কাস্টমার", fontWeight = FontWeight.Bold)
              Text(FormatUtils.formatTaka(payment.amount, currencySymbol), fontWeight = FontWeight.Bold)
            }
            Text("জমি: ${land?.landName ?: "—"}")
            Text("তারিখ ও সময়: ${FormatUtils.formatDateTime(payment.paymentDate)}")
            Text("মাধ্যম: ${strings.paymentMethodLabel(payment.paymentMethod)}")
            if (payment.notes.isNotBlank()) Text("নোট: ${payment.notes}")
            Text("রসিদ: ${payment.receiptNumber}", style = androidx.compose.material3.MaterialTheme.typography.bodySmall)
          }
        }
      }
    }
  }
}
