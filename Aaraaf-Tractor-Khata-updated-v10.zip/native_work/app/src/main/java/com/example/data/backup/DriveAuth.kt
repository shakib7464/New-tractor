package com.example.data.backup

import android.content.Context
import com.example.data.preferences.AppPreferencesManager
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * Google অ্যাকাউন্টের অনুমোদন (লগইন + Drive) সামলায়।
 * Access token প্রায় ১ ঘণ্টায় মেয়াদ শেষ হয়, তাই প্রতিবার সিঙ্ক/ব্যাকআপের আগে নতুন token আনা হয়।
 */
object DriveAuth {
  const val SCOPE_APPDATA = "https://www.googleapis.com/auth/drive.appdata"
  const val SCOPE_FILE = "https://www.googleapis.com/auth/drive.file"

  fun buildRequest(): AuthorizationRequest =
    AuthorizationRequest.builder()
      .setRequestedScopes(listOf(Scope(SCOPE_APPDATA), Scope(SCOPE_FILE)))
      .build()

  /** ব্যবহারকারীকে কিছু না দেখিয়ে নতুন token আনার চেষ্টা। আগে অনুমতি দেওয়া না থাকলে null। */
  suspend fun silentAccessToken(context: Context): Pair<String, String?>? =
    suspendCancellableCoroutine { cont ->
      try {
        Identity.getAuthorizationClient(context.applicationContext)
          .authorize(buildRequest())
          .addOnSuccessListener { res ->
            if (res.hasResolution()) {
              if (cont.isActive) cont.resume(null)
            } else {
              val token = res.accessToken
              val email = res.toGoogleSignInAccount()?.email
              if (cont.isActive) {
                cont.resume(if (token.isNullOrBlank()) null else token to email)
              }
            }
          }
          .addOnFailureListener {
            if (cont.isActive) cont.resume(null)
          }
      } catch (_: Throwable) {
        if (cont.isActive) cont.resume(null)
      }
    }

  /** নতুন token পেলে সেটা সংরক্ষণ করে ফেরত দেয়; না পেলে আগের সংরক্ষিত token। */
  suspend fun freshAccessToken(context: Context, prefs: AppPreferencesManager): String? {
    val fresh = silentAccessToken(context)?.first
    if (!fresh.isNullOrBlank()) {
      prefs.setDriveAccessToken(fresh)
      return fresh
    }
    return prefs.getDriveAccessToken()
  }

  fun looksLikeEmail(value: String?): Boolean =
    !value.isNullOrBlank() && value.contains("@") && !value.contains(" ")
}
