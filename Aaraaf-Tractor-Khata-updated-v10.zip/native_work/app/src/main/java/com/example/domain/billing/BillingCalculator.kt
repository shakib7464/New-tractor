package com.example.domain.billing

import com.example.data.local.entity.AdvanceEntryType
import com.example.data.local.entity.AdvancePaymentEntity
import com.example.data.local.entity.AgriculturalJobEntity
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.JobStatus
import com.example.data.local.entity.LandEntity
import com.example.data.local.entity.LandUnit
import com.example.data.local.entity.LedgerTransactionEntity
import com.example.data.local.entity.PaymentEntity
import com.example.data.local.entity.TransactionType
import com.example.domain.model.BulkConsolidatedSummary
import com.example.domain.model.BulkPrintFilter
import com.example.domain.model.CustomerFinancialSummary
import com.example.domain.model.LandFinancialSummary
import kotlin.math.roundToLong

data class JobBillCalculation(
  val baseBill: Double,
  val additionalCharges: Double,
  val discount: Double,
  val totalBill: Double,
  val advanceAdjustment: Double,
  val amountPaid: Double,
  val remainingDue: Double,
)

object BillingCalculator {

  fun roundCurrency(value: Double): Double {
    return (value * 100.0).roundToLong() / 100.0
  }

  fun convertArea(area: Double, fromUnit: LandUnit, toUnit: LandUnit): Double {
    if (fromUnit == toUnit) return area
    val decimals = when (fromUnit) {
      LandUnit.DECIMAL -> area
      LandUnit.KATHA -> area * 1.65
      LandUnit.BIGHA -> area * 33.0
      LandUnit.ACRE -> area * 100.0
    }
    return when (toUnit) {
      LandUnit.DECIMAL -> roundCurrency(decimals)
      LandUnit.KATHA -> roundCurrency(decimals / 1.65)
      LandUnit.BIGHA -> roundCurrency(decimals / 33.0)
      LandUnit.ACRE -> roundCurrency(decimals / 100.0)
    }
  }

  fun calculateJobBill(
    billingMethodCode: String,
    landArea: Double,
    rate: Double,
    workingHours: Double?,
    additionalCharges: Double,
    discount: Double,
    advanceAdjustment: Double,
    amountPaid: Double,
  ): JobBillCalculation {
    val safeArea = landArea.coerceAtLeast(0.0)
    val safeRate = rate.coerceAtLeast(0.0)
    val safeHours = (workingHours ?: 0.0).coerceAtLeast(0.0)
    val safeAdditional = additionalCharges.coerceAtLeast(0.0)
    val safeDiscount = discount.coerceAtLeast(0.0)

    val rawBase = when (billingMethodCode) {
      "PER_DECIMAL", "PER_KATHA", "PER_BIGHA", "PER_ACRE" -> safeArea * safeRate
      "PER_HOUR" -> safeHours * safeRate
      "FIXED_AMOUNT", "CUSTOM_AMOUNT" -> safeRate
      else -> safeArea * safeRate
    }

    val baseBill = roundCurrency(rawBase)
    val totalBill = roundCurrency((baseBill + safeAdditional - safeDiscount).coerceAtLeast(0.0))
    val safeAdvanceAdj = roundCurrency(advanceAdjustment.coerceIn(0.0, totalBill))
    val maxCashAfterAdv = roundCurrency((totalBill - safeAdvanceAdj).coerceAtLeast(0.0))
    val safePaid = roundCurrency(amountPaid.coerceIn(0.0, maxCashAfterAdv))
    val remaining = roundCurrency((totalBill - safeAdvanceAdj - safePaid).coerceAtLeast(0.0))

    return JobBillCalculation(
      baseBill = baseBill,
      additionalCharges = roundCurrency(safeAdditional),
      discount = roundCurrency(safeDiscount),
      totalBill = totalBill,
      advanceAdjustment = safeAdvanceAdj,
      amountPaid = safePaid,
      remainingDue = remaining,
    )
  }

  /**
   * Computes a land's exact independent financial summary purely from original transaction rows.
   * Never trusts cached totals.
   */
  fun computeLandSummary(
    land: LandEntity,
    landTransactions: List<LedgerTransactionEntity>,
    landJobs: List<AgriculturalJobEntity>,
    startDateMillis: Long? = null,
    endDateMillis: Long? = null,
  ): LandFinancialSummary {
    val activeTxns = landTransactions
      .filter { !it.isDeleted && it.landId == land.id }
      .sortedWith(compareBy({ it.transactionDate }, { it.createdAt }))

    val beforeStartTxns = if (startDateMillis != null) {
      activeTxns.filter { it.transactionDate < startDateMillis }
    } else emptyList()

    val inRangeTxns = activeTxns.filter { txn ->
      val afterStart = startDateMillis == null || txn.transactionDate >= startDateMillis
      val beforeEnd = endDateMillis == null || txn.transactionDate <= endDateMillis
      afterStart && beforeEnd
    }

    val carryForwardBeforeRange = roundCurrency(
      beforeStartTxns.sumOf { it.debitAmount - it.creditAmount }
    )

    var opening = carryForwardBeforeRange
    var workCharges = 0.0
    var additional = 0.0
    var discounts = 0.0
    var payments = 0.0
    var advanceAdj = 0.0
    var refunds = 0.0
    var manualNet = 0.0

    for (txn in inRangeTxns) {
      when (txn.transactionType) {
        TransactionType.OPENING_BALANCE.code -> opening += (txn.debitAmount - txn.creditAmount)
        TransactionType.WORK_CHARGE.code -> workCharges += (txn.debitAmount - txn.creditAmount)
        TransactionType.ADDITIONAL_CHARGE.code -> additional += txn.debitAmount
        TransactionType.DISCOUNT.code -> discounts += txn.creditAmount
        TransactionType.PAYMENT.code -> payments += txn.creditAmount
        TransactionType.ADVANCE_ADJUSTMENT.code -> advanceAdj += txn.creditAmount
        TransactionType.REFUND.code -> refunds += (txn.debitAmount - txn.creditAmount)
        TransactionType.MANUAL_ADJUSTMENT.code -> manualNet += (txn.debitAmount - txn.creditAmount)
      }
    }

    val exactBalance = roundCurrency(
      activeTxns
        .filter { endDateMillis == null || it.transactionDate <= endDateMillis }
        .sumOf { it.debitAmount - it.creditAmount }
    )

    val filteredJobs = landJobs.filter { job ->
      !job.isDeleted &&
        job.landId == land.id &&
        job.status != JobStatus.CANCELLED.code &&
        (startDateMillis == null || job.workDate >= startDateMillis) &&
        (endDateMillis == null || job.workDate <= endDateMillis)
    }

    return LandFinancialSummary(
      land = land,
      openingBalance = roundCurrency(opening),
      workCharges = roundCurrency(workCharges),
      additionalCharges = roundCurrency(additional),
      discounts = roundCurrency(discounts),
      payments = roundCurrency(payments),
      advanceAdjustments = roundCurrency(advanceAdj),
      refunds = roundCurrency(refunds),
      manualAdjustmentsNet = roundCurrency(manualNet),
      currentBalance = exactBalance,
      jobs = filteredJobs,
      transactions = inRangeTxns,
    )
  }

  /**
   * Computes a customer's complete financial summary from their lands' independent ledgers
   * and separate advance payment entries.
   */
  fun computeCustomerSummary(
    customer: CustomerEntity,
    customerLands: List<LandEntity>,
    customerJobs: List<AgriculturalJobEntity>,
    customerPayments: List<PaymentEntity>,
    customerAdvances: List<AdvancePaymentEntity>,
    customerTransactions: List<LedgerTransactionEntity>,
    landFilterIds: Set<String> = emptySet(),
    startDateMillis: Long? = null,
    endDateMillis: Long? = null,
  ): CustomerFinancialSummary {
    val activeLands = customerLands
      .filter { !it.isDeleted && it.customerId == customer.id }
      .filter { landFilterIds.isEmpty() || it.id in landFilterIds }

    val landSummaries = activeLands.map { land ->
      computeLandSummary(
        land = land,
        landTransactions = customerTransactions.filter { it.landId == land.id },
        landJobs = customerJobs.filter { it.landId == land.id },
        startDateMillis = startDateMillis,
        endDateMillis = endDateMillis,
      )
    }

    val filteredLandIds = activeLands.map { it.id }.toSet()

    val filteredJobs = customerJobs.filter { job ->
      !job.isDeleted &&
        job.customerId == customer.id &&
        (landFilterIds.isEmpty() || job.landId in filteredLandIds) &&
        (startDateMillis == null || job.workDate >= startDateMillis) &&
        (endDateMillis == null || job.workDate <= endDateMillis)
    }

    val filteredPayments = customerPayments.filter { pay ->
      !pay.isDeleted &&
        pay.customerId == customer.id &&
        (landFilterIds.isEmpty() || pay.landId in filteredLandIds) &&
        (startDateMillis == null || pay.paymentDate >= startDateMillis) &&
        (endDateMillis == null || pay.paymentDate <= endDateMillis)
    }

    val activeAdvances = customerAdvances.filter { adv ->
      !adv.isDeleted &&
        adv.customerId == customer.id &&
        (endDateMillis == null || adv.transactionDate <= endDateMillis)
    }

    val advInRange = activeAdvances.filter { adv ->
      (startDateMillis == null || adv.transactionDate >= startDateMillis) &&
        (endDateMillis == null || adv.transactionDate <= endDateMillis)
    }

    val totalAdvReceivedAllTime = roundCurrency(
      activeAdvances.filter { it.entryType == AdvanceEntryType.RECEIVED.code }.sumOf { it.amount }
    )
    val totalAdvUsedAllTime = roundCurrency(
      activeAdvances.filter { it.entryType == AdvanceEntryType.ADJUSTED.code }.sumOf { it.amount }
    )
    val totalAdvRefundedAllTime = roundCurrency(
      activeAdvances.filter { it.entryType == AdvanceEntryType.REFUNDED.code }.sumOf { it.amount }
    )
    val remainingAdvance = roundCurrency(
      (totalAdvReceivedAllTime - totalAdvUsedAllTime - totalAdvRefundedAllTime).coerceAtLeast(0.0)
    )

    val openingTotal = roundCurrency(landSummaries.sumOf { it.openingBalance })
    val workChargesTotal = roundCurrency(landSummaries.sumOf { it.workCharges })
    val additionalTotal = roundCurrency(landSummaries.sumOf { it.additionalCharges })
    val discountsTotal = roundCurrency(landSummaries.sumOf { it.discounts })
    val paidTotal = roundCurrency(landSummaries.sumOf { it.payments })
    val outstandingTotal = roundCurrency(landSummaries.sumOf { it.currentBalance })

    val allTxnsInRange = landSummaries.flatMap { it.transactions }
      .sortedWith(compareBy({ it.transactionDate }, { it.createdAt }))

    return CustomerFinancialSummary(
      customer = customer,
      lands = landSummaries,
      jobs = filteredJobs,
      payments = filteredPayments,
      advanceEntries = advInRange,
      allTransactions = allTxnsInRange,
      openingBalance = openingTotal,
      totalBilled = roundCurrency(workChargesTotal + additionalTotal - discountsTotal),
      totalAdditionalCharges = additionalTotal,
      totalDiscounts = discountsTotal,
      totalPaid = paidTotal,
      totalAdvanceReceived = roundCurrency(
        advInRange.filter { it.entryType == AdvanceEntryType.RECEIVED.code }.sumOf { it.amount }
      ),
      totalAdvanceUsed = roundCurrency(
        advInRange.filter { it.entryType == AdvanceEntryType.ADJUSTED.code }.sumOf { it.amount }
      ),
      totalAdvanceRefunded = roundCurrency(
        advInRange.filter { it.entryType == AdvanceEntryType.REFUNDED.code }.sumOf { it.amount }
      ),
      remainingAdvance = remainingAdvance,
      totalOutstandingBalance = outstandingTotal,
    )
  }

  fun computeBulkConsolidatedSummary(
    customerSummaries: List<CustomerFinancialSummary>,
  ): BulkConsolidatedSummary {
    return BulkConsolidatedSummary(
      totalCustomers = customerSummaries.size,
      totalLands = customerSummaries.sumOf { it.lands.size },
      totalJobs = customerSummaries.sumOf { summary ->
        summary.jobs.count { it.status != JobStatus.CANCELLED.code }
      },
      totalBilledAmount = roundCurrency(customerSummaries.sumOf { it.totalBilled }),
      totalAdditionalCharges = roundCurrency(customerSummaries.sumOf { it.totalAdditionalCharges }),
      totalDiscounts = roundCurrency(customerSummaries.sumOf { it.totalDiscounts }),
      totalPaymentsCollected = roundCurrency(customerSummaries.sumOf { it.totalPaid }),
      totalAdvancesReceived = roundCurrency(customerSummaries.sumOf { it.totalAdvanceReceived }),
      totalAdvanceAdjustments = roundCurrency(customerSummaries.sumOf { it.totalAdvanceUsed }),
      totalOutstandingAmount = roundCurrency(customerSummaries.sumOf { it.totalOutstandingBalance }),
    )
  }

  fun filterCustomerSummariesForBulkPrint(
    customers: List<CustomerEntity>,
    lands: List<LandEntity>,
    jobs: List<AgriculturalJobEntity>,
    payments: List<PaymentEntity>,
    advances: List<AdvancePaymentEntity>,
    transactions: List<LedgerTransactionEntity>,
    filter: BulkPrintFilter,
  ): List<CustomerFinancialSummary> {
    return customers
      .filter { !it.isDeleted }
      .filter { filter.selectedCustomerIds.isEmpty() || it.id in filter.selectedCustomerIds }
      .map { customer ->
        computeCustomerSummary(
          customer = customer,
          customerLands = lands.filter { it.customerId == customer.id },
          customerJobs = jobs.filter { it.customerId == customer.id },
          customerPayments = payments.filter { it.customerId == customer.id },
          customerAdvances = advances.filter { it.customerId == customer.id },
          customerTransactions = transactions.filter { it.customerId == customer.id },
          landFilterIds = filter.selectedLandIds,
          startDateMillis = filter.startDateMillis,
          endDateMillis = filter.endDateMillis,
        )
      }
      .filter { summary ->
        if (filter.onlyWithOutstandingDues) {
          summary.totalOutstandingBalance > 0.01
        } else {
          true
        }
      }
      .filter { summary ->
        filter.selectedLandIds.isEmpty() || summary.lands.isNotEmpty()
      }
  }
}
