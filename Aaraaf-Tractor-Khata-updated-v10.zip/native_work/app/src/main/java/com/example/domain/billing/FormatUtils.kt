package com.example.domain.billing

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object FormatUtils {
  private val dateFormatDmy = SimpleDateFormat("dd-MM-yyyy", Locale.US)
  private val dateTimeFormat = SimpleDateFormat("dd-MM-yyyy hh:mm a", Locale.US)
  private val fileDateTimeFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
  private val currencyFormat = DecimalFormat("#,##,##0.##", DecimalFormatSymbols(Locale.US))

  fun formatDate(millis: Long, pattern: String = "dd-MM-yyyy"): String {
    return if (pattern == "dd-MM-yyyy") {
      dateFormatDmy.format(Date(millis))
    } else {
      SimpleDateFormat(pattern, Locale.US).format(Date(millis))
    }
  }

  fun formatDateTime(millis: Long): String = dateTimeFormat.format(Date(millis))

  fun formatTimestampForFile(millis: Long = System.currentTimeMillis()): String =
    fileDateTimeFormat.format(Date(millis))

  fun formatTaka(amount: Double, symbol: String = "৳"): String {
    val clean = if (kotlin.math.abs(amount) < 0.005) 0.0 else amount
    return "$symbol ${currencyFormat.format(clean)}"
  }

  fun formatNumber(value: Double): String {
    val clean = if (kotlin.math.abs(value) < 0.005) 0.0 else value
    return currencyFormat.format(clean)
  }

  fun startOfDayMillis(millis: Long = System.currentTimeMillis()): Long {
    val cal = Calendar.getInstance().apply {
      timeInMillis = millis
      set(Calendar.HOUR_OF_DAY, 0)
      set(Calendar.MINUTE, 0)
      set(Calendar.SECOND, 0)
      set(Calendar.MILLISECOND, 0)
    }
    return cal.timeInMillis
  }

  fun endOfDayMillis(millis: Long = System.currentTimeMillis()): Long {
    val cal = Calendar.getInstance().apply {
      timeInMillis = millis
      set(Calendar.HOUR_OF_DAY, 23)
      set(Calendar.MINUTE, 59)
      set(Calendar.SECOND, 59)
      set(Calendar.MILLISECOND, 999)
    }
    return cal.timeInMillis
  }

  fun startOfWeekMillis(millis: Long = System.currentTimeMillis()): Long {
    val cal = Calendar.getInstance().apply {
      timeInMillis = millis
      set(Calendar.DAY_OF_WEEK, firstDayOfWeek)
      set(Calendar.HOUR_OF_DAY, 0)
      set(Calendar.MINUTE, 0)
      set(Calendar.SECOND, 0)
      set(Calendar.MILLISECOND, 0)
    }
    return cal.timeInMillis
  }

  fun startOfMonthMillis(millis: Long = System.currentTimeMillis()): Long {
    val cal = Calendar.getInstance().apply {
      timeInMillis = millis
      set(Calendar.DAY_OF_MONTH, 1)
      set(Calendar.HOUR_OF_DAY, 0)
      set(Calendar.MINUTE, 0)
      set(Calendar.SECOND, 0)
      set(Calendar.MILLISECOND, 0)
    }
    return cal.timeInMillis
  }

  fun startOfYearMillis(millis: Long = System.currentTimeMillis()): Long {
    val cal = Calendar.getInstance().apply {
      timeInMillis = millis
      set(Calendar.DAY_OF_YEAR, 1)
      set(Calendar.HOUR_OF_DAY, 0)
      set(Calendar.MINUTE, 0)
      set(Calendar.SECOND, 0)
      set(Calendar.MILLISECOND, 0)
    }
    return cal.timeInMillis
  }

  fun parseDmyDate(text: String): Long? {
    return try {
      dateFormatDmy.isLenient = false
      dateFormatDmy.parse(text.trim())?.time
    } catch (_: Exception) {
      null
    }
  }
}
