@file:OptIn(kotlinx.coroutines.FlowPreview::class)

package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.room.withTransaction
import com.example.data.local.AraafDatabase
import com.example.data.local.entity.AdvanceEntryType
import com.example.data.local.entity.AdvancePaymentEntity
import com.example.data.local.entity.AgriculturalJobEntity
import com.example.data.local.entity.AttachmentEntity
import com.example.data.local.entity.AuditLogEntity
import com.example.data.local.entity.BillingMethod
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.FuelDealerEntity
import com.example.data.local.entity.FuelEntryEntity
import com.example.data.local.entity.FuelEntryType
import com.example.data.local.entity.JobStatus
import com.example.data.local.entity.LandEntity
import com.example.data.local.entity.LandRateHistoryEntity
import com.example.data.local.entity.LandUnit
import com.example.data.local.entity.LedgerTransactionEntity
import com.example.data.local.entity.PaymentEntity
import com.example.data.local.entity.PaymentMethod
import com.example.data.local.entity.PaymentTargetType
import com.example.data.local.entity.SyncQueueEntity
import com.example.data.local.entity.SyncStatus
import com.example.data.local.entity.TractorEntity
import com.example.data.local.entity.TransactionType
import com.example.data.local.entity.WorkType
import com.example.domain.billing.BillingCalculator
import com.example.domain.billing.FormatUtils
import com.example.domain.model.ActivityFeedItem
import com.example.domain.model.ActivityType
import com.example.domain.model.BulkPrintFilter
import com.example.domain.model.CustomerFinancialSummary
import com.example.domain.model.DashboardSummary
import com.example.domain.model.LandFinancialSummary
import java.io.File
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.shareIn

class DuplicateCustomerException(message: String) : Exception(message)

class KhataRepository(
  private val context: Context,
  private val db: AraafDatabase,
) {
  private val customerDao = db.customerDao()
  private val landDao = db.landDao()
  private val landRateDao = db.landRateHistoryDao()
  private val tractorDao = db.tractorDao()
  private val jobDao = db.jobDao()
  private val paymentDao = db.paymentDao()
  private val advanceDao = db.advancePaymentDao()
  private val txnDao = db.ledgerTransactionDao()
  private val attachmentDao = db.attachmentDao()
  private val auditDao = db.auditLogDao()
  private val syncQueueDao = db.syncQueueDao()
  private val deviceInfoDao = db.deviceInfoDao()

  val customersFlow: Flow<List<CustomerEntity>> = customerDao.observeActiveCustomers()
  val landsFlow: Flow<List<LandEntity>> = landDao.observeActiveLands()
  val tractorsFlow: Flow<List<TractorEntity>> = tractorDao.observeActiveTractors()
  val jobsFlow: Flow<List<AgriculturalJobEntity>> = jobDao.observeActiveJobs()
  val paymentsFlow: Flow<List<PaymentEntity>> = paymentDao.observeActivePayments()
  val advancesFlow: Flow<List<AdvancePaymentEntity>> = advanceDao.observeActiveAdvances()
  val transactionsFlow: Flow<List<LedgerTransactionEntity>> = txnDao.observeActiveTransactions()
  val auditLogsFlow: Flow<List<AuditLogEntity>> = auditDao.observeRecentLogs()
  val syncQueueFlow: Flow<List<SyncQueueEntity>> = syncQueueDao.observeAll()
  val fuelDealersFlow: Flow<List<FuelDealerEntity>> = db.fuelDao().observeDealers()
  val fuelEntriesFlow: Flow<List<FuelEntryEntity>> = db.fuelDao().observeEntries()

  val deletedCustomersFlow: Flow<List<CustomerEntity>> = customerDao.observeDeletedCustomers()
  val deletedLandsFlow: Flow<List<LandEntity>> = landDao.observeDeletedLands()
  val deletedJobsFlow: Flow<List<AgriculturalJobEntity>> = jobDao.observeDeletedJobs()
  val deletedPaymentsFlow: Flow<List<PaymentEntity>> = paymentDao.observeDeletedPayments()

  // হিসাবের ভারী গণনা Default থ্রেডে হয় (মূল থ্রেডে নয়), এবং একবারই হয় — ড্যাশবোর্ড ও কাস্টমার তালিকা একসাথে ব্যবহার করলেও
  private val summaryScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
  val customerSummariesFlow: Flow<List<CustomerFinancialSummary>> = combine(
    customersFlow,
    landsFlow,
    jobsFlow,
    paymentsFlow,
    advancesFlow,
    transactionsFlow,
  ) { arr ->
    @Suppress("UNCHECKED_CAST")
    val customers = arr[0] as List<CustomerEntity>
    @Suppress("UNCHECKED_CAST")
    val lands = arr[1] as List<LandEntity>
    @Suppress("UNCHECKED_CAST")
    val jobs = arr[2] as List<AgriculturalJobEntity>
    @Suppress("UNCHECKED_CAST")
    val payments = arr[3] as List<PaymentEntity>
    @Suppress("UNCHECKED_CAST")
    val advances = arr[4] as List<AdvancePaymentEntity>
    @Suppress("UNCHECKED_CAST")
    val txns = arr[5] as List<LedgerTransactionEntity>

    // প্রতি গ্রাহকের জন্য সব তালিকা ছাঁকার বদলে একবারই গ্রাহক-ভিত্তিক ভাগ করা (O(গ্রাহক × সব ডেটা) → O(সব ডেটা))
    val landsBy = lands.groupBy { it.customerId }
    val jobsBy = jobs.groupBy { it.customerId }
    val paymentsBy = payments.groupBy { it.customerId }
    val advancesBy = advances.groupBy { it.customerId }
    val txnsBy = txns.groupBy { it.customerId }
    customers.map { c ->
      BillingCalculator.computeCustomerSummary(
        customer = c,
        customerLands = landsBy[c.id].orEmpty(),
        customerJobs = jobsBy[c.id].orEmpty(),
        customerPayments = paymentsBy[c.id].orEmpty(),
        customerAdvances = advancesBy[c.id].orEmpty(),
        customerTransactions = txnsBy[c.id].orEmpty(),
      )
    }
  }
    // সিঙ্ক/ব্যাকআপে একসাথে অনেক টেবিল বদলায়; প্রতিবার না গণনা করে একবারে গণনা
    .debounce(60)
    .flowOn(Dispatchers.Default)
    .shareIn(summaryScope, SharingStarted.WhileSubscribed(5000), replay = 1)

  val dashboardSummaryFlow: Flow<DashboardSummary> = combine(
    customerSummariesFlow,
    jobsFlow,
    paymentsFlow,
    advancesFlow,
    auditLogsFlow,
  ) { summaries, jobs, payments, advances, audits ->
    val todayStart = FormatUtils.startOfDayMillis()
    val todayEnd = FormatUtils.endOfDayMillis()
    val monthStart = FormatUtils.startOfMonthMillis()

    val nonCancelledJobs = jobs.filter { it.status != JobStatus.CANCELLED.code }
    val todaysJobs = nonCancelledJobs.filter { it.workDate in todayStart..todayEnd }
    val monthlyJobs = nonCancelledJobs.filter { it.workDate >= monthStart }
    val todaysPayments = payments.filter { it.paymentDate in todayStart..todayEnd }
    val monthlyPayments = payments.filter { it.paymentDate >= monthStart }

    val activities = buildList {
      jobs.take(6).forEach { j ->
        add(
          ActivityFeedItem(
            id = "job_${j.id}",
            title = "${j.jobCode} • ${j.workType}",
            subtitle = FormatUtils.formatDate(j.workDate),
            amount = j.totalBill,
            timestamp = j.createdAt,
            type = ActivityType.JOB,
          )
        )
      }
      payments.take(6).forEach { p ->
        add(
          ActivityFeedItem(
            id = "pay_${p.id}",
            title = "${p.receiptNumber} (${p.paymentMethod})",
            subtitle = FormatUtils.formatDate(p.paymentDate),
            amount = p.amount,
            timestamp = p.createdAt,
            type = ActivityType.PAYMENT,
          )
        )
      }
      advances.filter { it.entryType == AdvanceEntryType.RECEIVED.code }.take(4).forEach { a ->
        add(
          ActivityFeedItem(
            id = "adv_${a.id}",
            title = "${a.receiptNumber} (অগ্রিম)",
            subtitle = FormatUtils.formatDate(a.transactionDate),
            amount = a.amount,
            timestamp = a.createdAt,
            type = ActivityType.ADVANCE,
          )
        )
      }
      audits.take(4).forEach { log ->
        if (none { it.timestamp == log.timestamp }) {
          add(
            ActivityFeedItem(
              id = "aud_${log.id}",
              title = log.summary,
              subtitle = FormatUtils.formatDateTime(log.timestamp),
              amount = null,
              timestamp = log.timestamp,
              type = ActivityType.ADJUSTMENT,
            )
          )
        }
      }
    }.sortedByDescending { it.timestamp }.take(12)

    DashboardSummary(
      totalCustomers = summaries.size,
      totalLands = summaries.sumOf { it.lands.size },
      totalJobs = nonCancelledJobs.size,
      completedJobs = nonCancelledJobs.count { it.status == JobStatus.COMPLETED.code },
      pendingJobs = nonCancelledJobs.count {
        it.status == JobStatus.PENDING.code || it.status == JobStatus.IN_PROGRESS.code
      },
      totalBilledAmount = BillingCalculator.roundCurrency(summaries.sumOf { it.totalBilled }),
      totalCollectedAmount = BillingCalculator.roundCurrency(summaries.sumOf { it.totalPaid }),
      totalOutstandingAmount = BillingCalculator.roundCurrency(
        summaries.sumOf { it.totalOutstandingBalance }
      ),
      totalAdvanceReceived = BillingCalculator.roundCurrency(
        advances.filter { it.entryType == AdvanceEntryType.RECEIVED.code }.sumOf { it.amount }
      ),
      totalRemainingAdvance = BillingCalculator.roundCurrency(
        summaries.sumOf { it.remainingAdvance }
      ),
      todaysJobCount = todaysJobs.size,
      todaysBilledAmount = BillingCalculator.roundCurrency(todaysJobs.sumOf { it.totalBill }),
      todaysCollectionAmount = BillingCalculator.roundCurrency(todaysPayments.sumOf { it.amount }),
      monthlyBilledAmount = BillingCalculator.roundCurrency(monthlyJobs.sumOf { it.totalBill }),
      monthlyCollectionAmount = BillingCalculator.roundCurrency(monthlyPayments.sumOf { it.amount }),
      recentActivities = activities,
    )
  }
    .flowOn(Dispatchers.Default)

  private suspend fun deviceId(): String {
    val info = deviceInfoDao.getDeviceInfoNow()
    if (info != null) return info.deviceId
    AraafDatabase.seedInitialTractorAndDevice(db)
    return deviceInfoDao.getDeviceInfoNow()?.deviceId ?: "android-device"
  }

  private suspend fun logAudit(
    entityType: String,
    entityId: String,
    action: String,
    summary: String,
    previousJson: String? = null,
    newJson: String? = null,
  ) {
    val devId = deviceId()
    val now = System.currentTimeMillis()
    auditDao.insert(
      AuditLogEntity(
        id = UUID.randomUUID().toString(),
        entityType = entityType,
        entityId = entityId,
        action = action,
        summary = summary,
        previousValueJson = previousJson,
        newValueJson = newJson,
        timestamp = now,
        deviceId = devId,
      )
    )
    syncQueueDao.insert(
      SyncQueueEntity(
        id = UUID.randomUUID().toString(),
        entityType = entityType,
        entityId = entityId,
        operation = action,
        payloadJson = newJson ?: summary,
        status = SyncStatus.PENDING_SYNC.code,
        createdAt = now,
        updatedAt = now,
      )
    )
  }

  suspend fun saveCustomer(
    id: String? = null,
    fullName: String,
    mobileNumber: String,
    address: String,
    village: String,
    unionName: String,
    upazila: String,
    district: String,
    notes: String,
    registrationDate: Long,
    customRatePerUnit: Double? = null,
    customRateMethod: String? = null,
  ): Result<CustomerEntity> = runCatching {
    val cleanName = fullName.trim()
    val cleanMobile = mobileNumber.trim()
    val cleanVillage = village.trim()
    require(cleanName.isNotEmpty()) { "Customer name is required" }

    db.withTransaction {
      val existingDuplicate = customerDao.findDuplicateCustomer(cleanMobile, cleanName, cleanVillage)
      if (existingDuplicate != null && existingDuplicate.id != id) {
        throw DuplicateCustomerException(existingDuplicate.fullName)
      }

      val now = System.currentTimeMillis()
      val devId = deviceId()

      if (id == null) {
        val count = customerDao.getTotalCountIncludingDeleted() + 1
        val customer = CustomerEntity(
          id = UUID.randomUUID().toString(),
          customerCode = "CUS-%04d".format(count),
          fullName = cleanName,
          mobileNumber = cleanMobile,
          address = address.trim(),
          village = cleanVillage,
          unionName = unionName.trim(),
          upazila = upazila.trim(),
          district = district.trim(),
          notes = notes.trim(),
          registrationDate = registrationDate,
          customRatePerUnit = customRatePerUnit,
          customRateMethod = customRateMethod,
          createdAt = now,
          updatedAt = now,
          deviceId = devId,
        )
        customerDao.insert(customer)
        logAudit("CUSTOMER", customer.id, "CREATE", "Added customer ${customer.fullName}", null, customer.toString())
        customer
      } else {
        val old = customerDao.getById(id) ?: error("Customer not found")
        val updated = old.copy(
          fullName = cleanName,
          mobileNumber = cleanMobile,
          address = address.trim(),
          village = cleanVillage,
          unionName = unionName.trim(),
          upazila = upazila.trim(),
          district = district.trim(),
          notes = notes.trim(),
          registrationDate = registrationDate,
          customRatePerUnit = customRatePerUnit,
          customRateMethod = customRateMethod,
          updatedAt = now,
          version = old.version + 1,
          syncStatus = SyncStatus.PENDING_SYNC.code,
        )
        customerDao.update(updated)
        logAudit("CUSTOMER", updated.id, "UPDATE", "Updated customer ${updated.fullName}", old.toString(), updated.toString())
        updated
      }
    }
  }

  suspend fun saveLand(
    id: String? = null,
    customerId: String,
    landName: String,
    village: String,
    locationDetails: String,
    sizeValue: Double,
    unit: String,
    cropInfo: String,
    cultivationSeason: String,
    openingBalance: Double,
    notes: String,
    firstCultivationRatePerKatha: Double = 0.0,
    firstCultivationCount: Int = 1,
    depositAmount: Double = 0.0,
  ): Result<LandEntity> = runCatching {
    require(landName.trim().isNotEmpty()) { "Land name is required" }
    require(sizeValue > 0.0) { "Land size must be > 0" }

    db.withTransaction {
      val now = System.currentTimeMillis()
      val devId = deviceId()
      val safeOpening = BillingCalculator.roundCurrency(openingBalance.coerceAtLeast(0.0))

      if (id == null) {
        val count = landDao.getTotalCountIncludingDeleted() + 1
        val land = LandEntity(
          id = UUID.randomUUID().toString(),
          landCode = "LND-%04d".format(count),
          customerId = customerId,
          landName = landName.trim(),
          village = village.trim(),
          locationDetails = locationDetails.trim(),
          sizeValue = sizeValue,
          unit = unit,
          cropInfo = cropInfo.trim(),
          cultivationSeason = cultivationSeason.trim(),
          openingBalance = safeOpening,
          notes = notes.trim(),
          createdAt = now,
          updatedAt = now,
          deviceId = devId,
        )
        landDao.insert(land)
        if (safeOpening > 0.0) {
          val txnCount = txnDao.getTotalCountIncludingDeleted() + 1
          txnDao.insert(
            LedgerTransactionEntity(
              id = UUID.randomUUID().toString(),
              transactionCode = "TXN-%05d".format(txnCount),
              customerId = customerId,
              landId = land.id,
              transactionDate = now,
              transactionType = TransactionType.OPENING_BALANCE.code,
              debitAmount = safeOpening,
              creditAmount = 0.0,
              description = "পূর্বের বকেয়া (${land.landName})",
              notes = notes.trim(),
              createdAt = now,
              updatedAt = now,
              deviceId = devId,
            )
          )
        }
        // নতুন জমি যোগের সময় চাষের রেট দিলে প্রথম চাষের বিল তৈরি হবে
        // (জমির পরিমাণ × কয়বার চাষ × প্রতি কাঠার রেট)। পুরোনো জমি এডিটে এটি হয় না।
        if (firstCultivationRatePerKatha > 0.0 && firstCultivationCount > 0) {
          val landUnit = LandUnit.entries.firstOrNull { it.code == unit } ?: LandUnit.KATHA
          val areaInKatha = BillingCalculator.convertArea(sizeValue, landUnit, LandUnit.KATHA)
          createAgriculturalJob(
            customerId = customerId,
            landId = land.id,
            tractorId = null,
            workDate = now,
            workType = WorkType.LAND_PLOUGHING.code,
            customWorkName = "",
            billingMethod = BillingMethod.PER_KATHA.code,
            landArea = areaInKatha,
            areaUnit = LandUnit.KATHA.code,
            rate = firstCultivationRatePerKatha,
            workingHours = null,
            additionalCharges = 0.0,
            discount = 0.0,
            advanceAdjustmentRequested = 0.0,
            amountPaidNow = 0.0,
            paymentMethod = PaymentMethod.CASH.code,
            status = JobStatus.COMPLETED.code,
            rotavatorWidth = "",
            workingDepth = "",
            numberOfPasses = firstCultivationCount.coerceAtLeast(1),
            startTime = "",
            finishTime = "",
            operatorName = "",
            notes = "জমি যোগের সময় প্রথম চাষের হিসাব",
          ).getOrThrow()
        }
        // নতুন জমি যোগের সময় দেওয়া জমা: পেমেন্ট হিসেবে সংরক্ষণ হবে, তাই বকেয়া থেকে বাদ যাবে
        if (depositAmount > 0.0) {
          recordPayment(
            customerId = customerId,
            landId = land.id,
            jobId = null,
            targetType = PaymentTargetType.LAND.code,
            paymentDate = now,
            amount = depositAmount,
            paymentMethod = PaymentMethod.CASH.code,
            notes = "জমি যোগের সময় জমা",
          ).getOrThrow()
        }
        logAudit("LAND", land.id, "CREATE", "Added land ${land.landName}", null, land.toString())
        land
      } else {
        val old = landDao.getById(id) ?: error("Land not found")
        val updated = old.copy(
          landName = landName.trim(),
          village = village.trim(),
          locationDetails = locationDetails.trim(),
          sizeValue = sizeValue,
          unit = unit,
          cropInfo = cropInfo.trim(),
          cultivationSeason = cultivationSeason.trim(),
          openingBalance = safeOpening,
          notes = notes.trim(),
          updatedAt = now,
          version = old.version + 1,
          syncStatus = SyncStatus.PENDING_SYNC.code,
        )
        landDao.update(updated)
        if (old.openingBalance != safeOpening) {
          val diff = BillingCalculator.roundCurrency(safeOpening - old.openingBalance)
          val txnCount = txnDao.getTotalCountIncludingDeleted() + 1
          txnDao.insert(
            LedgerTransactionEntity(
              id = UUID.randomUUID().toString(),
              transactionCode = "TXN-%05d".format(txnCount),
              customerId = customerId,
              landId = updated.id,
              transactionDate = now,
              transactionType = TransactionType.MANUAL_ADJUSTMENT.code,
              debitAmount = if (diff > 0) diff else 0.0,
              creditAmount = if (diff < 0) -diff else 0.0,
              description = "পূর্বের বকেয়া সংশোধন (${updated.landName})",
              createdAt = now,
              updatedAt = now,
              deviceId = devId,
            )
          )
        }
        // পুরোনো জমি এডিট: জমির পরিমাণ / কয়বার চাষ / রেট বদলালে প্রথম চাষের বিল নতুন করে হিসাব হবে।
        // আগের জমা, পেমেন্ট ও তারিখ অপরিবর্তিত থাকে; শুধু বিলের পার্থক্য লেজারে সমন্বয় হিসেবে যোগ হয়।
        if (firstCultivationRatePerKatha > 0.0) {
          val primaryJob = jobDao.getActiveJobsNow()
            .filter {
              it.landId == updated.id &&
                it.status != JobStatus.CANCELLED.code &&
                it.billingMethod == BillingMethod.PER_KATHA.code
            }
            .minByOrNull { it.createdAt }
          if (primaryJob != null) {
            val landUnit = LandUnit.entries.firstOrNull { it.code == unit } ?: LandUnit.KATHA
            val areaInKatha = BillingCalculator.convertArea(sizeValue, landUnit, LandUnit.KATHA)
            val passes = firstCultivationCount.coerceAtLeast(0)
            val newBase = BillingCalculator.roundCurrency(areaInKatha * passes * firstCultivationRatePerKatha)
            val oldBase = primaryJob.baseBill
            val newTotal = BillingCalculator.roundCurrency(
              (newBase + primaryJob.additionalCharges - primaryJob.discount).coerceAtLeast(0.0)
            )
            val newRemaining = BillingCalculator.roundCurrency(
              (newTotal - primaryJob.advanceAdjustment - primaryJob.amountPaid).coerceAtLeast(0.0)
            )
            val changed = newBase != oldBase ||
              primaryJob.rate != firstCultivationRatePerKatha ||
              (primaryJob.numberOfPasses ?: 1) != passes ||
              primaryJob.landArea != areaInKatha
            if (changed) {
              val revisedJob = primaryJob.copy(
                landArea = areaInKatha,
                areaUnit = LandUnit.KATHA.code,
                rate = firstCultivationRatePerKatha,
                numberOfPasses = passes,
                baseBill = newBase,
                totalBill = newTotal,
                remainingDue = newRemaining,
                updatedAt = now,
                version = primaryJob.version + 1,
                syncStatus = SyncStatus.PENDING_SYNC.code,
              )
              jobDao.update(revisedJob)

              val billDiff = BillingCalculator.roundCurrency(newBase - oldBase)
              if (billDiff != 0.0) {
                val txnCount = txnDao.getTotalCountIncludingDeleted() + 1
                txnDao.insert(
                  LedgerTransactionEntity(
                    id = UUID.randomUUID().toString(),
                    transactionCode = "TXN-%05d".format(txnCount),
                    customerId = customerId,
                    landId = updated.id,
                    jobId = primaryJob.id,
                    transactionDate = now,
                    // WORK_CHARGE হিসেবে রাখা হয়েছে যাতে "মোট বিল" ও PDF/ড্যাশবোর্ডের যোগফলে সংশোধিত বিল ঠিকভাবে আসে
                    transactionType = TransactionType.WORK_CHARGE.code,
                    debitAmount = if (billDiff > 0) billDiff else 0.0,
                    creditAmount = if (billDiff < 0) -billDiff else 0.0,
                    description = "${primaryJob.jobCode}: বিল সংশোধন (৳${oldBase} → ৳${newBase})",
                    notes = "জমি ${FormatAreaForAudit.fmt(primaryJob.landArea)} → ${FormatAreaForAudit.fmt(areaInKatha)} কাঠা, " +
                      "চাষ ${primaryJob.numberOfPasses ?: 1} → $passes বার, " +
                      "রেট ${FormatAreaForAudit.fmt(primaryJob.rate)} → ${FormatAreaForAudit.fmt(firstCultivationRatePerKatha)}",
                    createdAt = now,
                    updatedAt = now,
                    deviceId = devId,
                  )
                )
              }

              landRateDao.insert(
                LandRateHistoryEntity(
                  id = UUID.randomUUID().toString(),
                  landId = updated.id,
                  workType = primaryJob.workType,
                  billingMethod = BillingMethod.PER_KATHA.code,
                  rate = firstCultivationRatePerKatha,
                  effectiveDate = now,
                  notes = "${primaryJob.jobCode} বিল সংশোধন",
                )
              )

              logAudit(
                "JOB", primaryJob.id, "UPDATE",
                "বিল সংশোধন ${primaryJob.jobCode}: ৳$oldBase → ৳$newBase",
                primaryJob.toString(), revisedJob.toString(),
              )
            }
          }
        }
        logAudit("LAND", updated.id, "UPDATE", "Updated land ${updated.landName}", old.toString(), updated.toString())
        updated
      }
    }
  }

  suspend fun createAgriculturalJob(
    customerId: String,
    landId: String,
    tractorId: String?,
    workDate: Long,
    workType: String,
    customWorkName: String,
    billingMethod: String,
    landArea: Double,
    areaUnit: String,
    rate: Double,
    workingHours: Double?,
    additionalCharges: Double,
    discount: Double,
    advanceAdjustmentRequested: Double,
    amountPaidNow: Double,
    paymentMethod: String,
    status: String,
    rotavatorWidth: String,
    workingDepth: String,
    numberOfPasses: Int?,
    startTime: String,
    finishTime: String,
    operatorName: String,
    notes: String,
  ): Result<AgriculturalJobEntity> = runCatching {
    db.withTransaction {
      val now = System.currentTimeMillis()
      val devId = deviceId()

      // Verify available advance if adjustment requested
      val advEntries = advanceDao.getAdvancesByCustomerNow(customerId)
      val advAvail = BillingCalculator.roundCurrency(
        (advEntries.filter { it.entryType == AdvanceEntryType.RECEIVED.code }.sumOf { it.amount } -
          advEntries.filter { it.entryType == AdvanceEntryType.ADJUSTED.code }.sumOf { it.amount } -
          advEntries.filter { it.entryType == AdvanceEntryType.REFUNDED.code }.sumOf { it.amount })
          .coerceAtLeast(0.0)
      )
      val safeAdvAdj = advanceAdjustmentRequested.coerceIn(0.0, advAvail)

      val calc = BillingCalculator.calculateJobBill(
        billingMethodCode = billingMethod,
        landArea = landArea * (numberOfPasses?.coerceAtLeast(1) ?: 1),
        rate = rate,
        workingHours = workingHours,
        additionalCharges = additionalCharges,
        discount = discount,
        advanceAdjustment = safeAdvAdj,
        amountPaid = amountPaidNow,
      )

      val jobCount = jobDao.getTotalCountIncludingDeleted() + 1
      val jobId = UUID.randomUUID().toString()
      val jobCode = "JOB-%04d".format(jobCount)

      val job = AgriculturalJobEntity(
        id = jobId,
        jobCode = jobCode,
        customerId = customerId,
        landId = landId,
        tractorId = tractorId,
        workDate = workDate,
        workType = workType,
        customWorkName = customWorkName.trim(),
        billingMethod = billingMethod,
        landArea = landArea,
        areaUnit = areaUnit,
        rate = rate,
        workingHours = workingHours,
        baseBill = calc.baseBill,
        additionalCharges = calc.additionalCharges,
        discount = calc.discount,
        totalBill = calc.totalBill,
        advanceAdjustment = calc.advanceAdjustment,
        amountPaid = calc.amountPaid,
        remainingDue = calc.remainingDue,
        status = status,
        rotavatorWidth = rotavatorWidth.trim(),
        workingDepth = workingDepth.trim(),
        numberOfPasses = numberOfPasses,
        startTime = startTime.trim(),
        finishTime = finishTime.trim(),
        operatorName = operatorName.trim(),
        notes = notes.trim(),
        createdAt = now,
        updatedAt = now,
        deviceId = devId,
      )
      jobDao.insert(job)

      // Save land-specific rate history
      landRateDao.insert(
        LandRateHistoryEntity(
          id = UUID.randomUUID().toString(),
          landId = landId,
          workType = workType,
          billingMethod = billingMethod,
          rate = rate,
          effectiveDate = workDate,
          notes = jobCode,
        )
      )

      if (status != JobStatus.CANCELLED.code) {
        recordJobLedgerTransactions(job, paymentMethod, now, devId)
      }

      logAudit("JOB", job.id, "CREATE", "Recorded job ${job.jobCode} (৳${job.totalBill})", null, job.toString())
      job
    }
  }

  private suspend fun recordJobLedgerTransactions(
    job: AgriculturalJobEntity,
    paymentMethod: String,
    now: Long,
    devId: String,
  ) {
    var txnCounter = txnDao.getTotalCountIncludingDeleted()

    if (job.baseBill > 0.0) {
      txnCounter++
      txnDao.insert(
        LedgerTransactionEntity(
          id = UUID.randomUUID().toString(),
          transactionCode = "TXN-%05d".format(txnCounter),
          customerId = job.customerId,
          landId = job.landId,
          jobId = job.id,
          transactionDate = job.workDate,
          transactionType = TransactionType.WORK_CHARGE.code,
          debitAmount = job.baseBill,
          creditAmount = 0.0,
          description = "${job.jobCode}: ${job.workType}",
          notes = job.notes,
          createdAt = now,
          updatedAt = now,
          deviceId = devId,
        )
      )
    }

    if (job.additionalCharges > 0.0) {
      txnCounter++
      txnDao.insert(
        LedgerTransactionEntity(
          id = UUID.randomUUID().toString(),
          transactionCode = "TXN-%05d".format(txnCounter),
          customerId = job.customerId,
          landId = job.landId,
          jobId = job.id,
          transactionDate = job.workDate,
          transactionType = TransactionType.ADDITIONAL_CHARGE.code,
          debitAmount = job.additionalCharges,
          creditAmount = 0.0,
          description = "${job.jobCode}: অতিরিক্ত চার্জ",
          createdAt = now,
          updatedAt = now,
          deviceId = devId,
        )
      )
    }

    if (job.discount > 0.0) {
      txnCounter++
      txnDao.insert(
        LedgerTransactionEntity(
          id = UUID.randomUUID().toString(),
          transactionCode = "TXN-%05d".format(txnCounter),
          customerId = job.customerId,
          landId = job.landId,
          jobId = job.id,
          transactionDate = job.workDate,
          transactionType = TransactionType.DISCOUNT.code,
          debitAmount = 0.0,
          creditAmount = job.discount,
          description = "${job.jobCode}: ডিসকাউন্ট",
          createdAt = now,
          updatedAt = now,
          deviceId = devId,
        )
      )
    }

    if (job.advanceAdjustment > 0.0) {
      val advCount = advanceDao.getTotalCountIncludingDeleted() + 1
      val advId = UUID.randomUUID().toString()
      advanceDao.insert(
        AdvancePaymentEntity(
          id = advId,
          receiptNumber = "ADV-ADJ-%04d".format(advCount),
          customerId = job.customerId,
          landId = job.landId,
          jobId = job.id,
          entryType = AdvanceEntryType.ADJUSTED.code,
          amount = job.advanceAdjustment,
          paymentMethod = paymentMethod,
          transactionDate = job.workDate,
          notes = "${job.jobCode} বিলে অগ্রিম সমন্বয়",
          createdAt = now,
          updatedAt = now,
          deviceId = devId,
        )
      )
      txnCounter++
      txnDao.insert(
        LedgerTransactionEntity(
          id = UUID.randomUUID().toString(),
          transactionCode = "TXN-%05d".format(txnCounter),
          customerId = job.customerId,
          landId = job.landId,
          jobId = job.id,
          advanceId = advId,
          transactionDate = job.workDate,
          transactionType = TransactionType.ADVANCE_ADJUSTMENT.code,
          debitAmount = 0.0,
          creditAmount = job.advanceAdjustment,
          description = "${job.jobCode}: অগ্রিম সমন্বয়",
          createdAt = now,
          updatedAt = now,
          deviceId = devId,
        )
      )
    }

    if (job.amountPaid > 0.0) {
      val payCount = paymentDao.getTotalCountIncludingDeleted() + 1
      val payId = UUID.randomUUID().toString()
      val landBalanceAfter = computeLandBalanceNow(job.landId)
      val prevBal = BillingCalculator.roundCurrency(landBalanceAfter)
      val remBal = BillingCalculator.roundCurrency((prevBal - job.amountPaid).coerceAtLeast(0.0))

      paymentDao.insert(
        PaymentEntity(
          id = payId,
          receiptNumber = "ATK-RCP-%05d".format(payCount),
          customerId = job.customerId,
          landId = job.landId,
          jobId = job.id,
          targetType = PaymentTargetType.JOB.code,
          paymentDate = now,
          amount = job.amountPaid,
          paymentMethod = paymentMethod,
          previousBalanceSnapshot = prevBal,
          remainingBalanceSnapshot = remBal,
          referenceNote = job.jobCode,
          notes = "কাজের সাথে নগদ/তাৎক্ষণিক জমা",
          createdAt = now,
          updatedAt = now,
          deviceId = devId,
        )
      )
      txnCounter++
      txnDao.insert(
        LedgerTransactionEntity(
          id = UUID.randomUUID().toString(),
          transactionCode = "TXN-%05d".format(txnCounter),
          customerId = job.customerId,
          landId = job.landId,
          jobId = job.id,
          paymentId = payId,
          transactionDate = now,
          transactionType = TransactionType.PAYMENT.code,
          debitAmount = 0.0,
          creditAmount = job.amountPaid,
          description = "${job.jobCode}: পেমেন্ট জমা ($paymentMethod)",
          createdAt = now,
          updatedAt = now,
          deviceId = devId,
        )
      )
    }
  }

  suspend fun updateJobStatus(jobId: String, newStatus: String): Result<Unit> = runCatching {
    db.withTransaction {
      val old = jobDao.getById(jobId) ?: error("Job not found")
      if (old.status == newStatus) return@withTransaction
      val now = System.currentTimeMillis()
      val devId = deviceId()
      val updated = old.copy(
        status = newStatus,
        updatedAt = now,
        version = old.version + 1,
      )
      jobDao.update(updated)
      if (newStatus == JobStatus.CANCELLED.code && old.status != JobStatus.CANCELLED.code) {
        txnDao.softDeleteByJob(jobId, now)
        paymentDao.softDeleteByJob(jobId, now)
        advanceDao.softDeleteByJob(jobId, now)
      } else if (old.status == JobStatus.CANCELLED.code && newStatus != JobStatus.CANCELLED.code) {
        txnDao.restoreByJob(jobId, now)
        paymentDao.restoreByJob(jobId, now)
        advanceDao.restoreByJob(jobId, now)
      }
      logAudit("JOB", jobId, "UPDATE", "Status ${old.status} -> $newStatus for ${old.jobCode}", old.status, newStatus)
    }
  }

  suspend fun recordPayment(
    customerId: String,
    landId: String,
    jobId: String?,
    targetType: String,
    paymentDate: Long,
    amount: Double,
    paymentMethod: String,
    notes: String,
  ): Result<PaymentEntity> = runCatching {
    val cleanAmount = BillingCalculator.roundCurrency(amount)
    require(cleanAmount > 0.0) { "Payment amount must be greater than zero" }

    db.withTransaction {
      val now = System.currentTimeMillis()
      val devId = deviceId()
      val prevLandBalance = computeLandBalanceNow(landId)
      val remainingLandBalance = BillingCalculator.roundCurrency(prevLandBalance - cleanAmount)

      val payCount = paymentDao.getTotalCountIncludingDeleted() + 1
      val payment = PaymentEntity(
        id = UUID.randomUUID().toString(),
        receiptNumber = "ATK-RCP-%05d".format(payCount),
        customerId = customerId,
        landId = landId,
        jobId = jobId,
        targetType = targetType,
        paymentDate = paymentDate,
        amount = cleanAmount,
        paymentMethod = paymentMethod,
        previousBalanceSnapshot = prevLandBalance,
        remainingBalanceSnapshot = remainingLandBalance,
        notes = notes.trim(),
        createdAt = now,
        updatedAt = now,
        deviceId = devId,
      )
      paymentDao.insert(payment)

      val txnCount = txnDao.getTotalCountIncludingDeleted() + 1
      txnDao.insert(
        LedgerTransactionEntity(
          id = UUID.randomUUID().toString(),
          transactionCode = "TXN-%05d".format(txnCount),
          customerId = customerId,
          landId = landId,
          jobId = jobId,
          paymentId = payment.id,
          transactionDate = paymentDate,
          transactionType = TransactionType.PAYMENT.code,
          debitAmount = 0.0,
          creditAmount = cleanAmount,
          description = "${payment.receiptNumber}: পেমেন্ট ($paymentMethod)",
          notes = notes.trim(),
          createdAt = now,
          updatedAt = now,
          deviceId = devId,
        )
      )

      if (jobId != null) {
        val job = jobDao.getById(jobId)
        if (job != null) {
          val newPaid = BillingCalculator.roundCurrency(job.amountPaid + cleanAmount)
          val newRem = BillingCalculator.roundCurrency((job.totalBill - job.advanceAdjustment - newPaid).coerceAtLeast(0.0))
          jobDao.update(job.copy(amountPaid = newPaid, remainingDue = newRem, updatedAt = now, version = job.version + 1))
        }
      }

      logAudit("PAYMENT", payment.id, "PAYMENT_CHANGE", "Payment ${payment.receiptNumber} ৳$cleanAmount", null, payment.toString())
      payment
    }
  }

  suspend fun recordAdvanceReceived(
    customerId: String,
    landId: String?,
    amount: Double,
    paymentMethod: String,
    transactionDate: Long,
    notes: String,
  ): Result<AdvancePaymentEntity> = runCatching {
    val cleanAmount = BillingCalculator.roundCurrency(amount)
    require(cleanAmount > 0.0) { "Advance amount must be > 0" }
    db.withTransaction {
      val now = System.currentTimeMillis()
      val devId = deviceId()
      val count = advanceDao.getTotalCountIncludingDeleted() + 1
      val entry = AdvancePaymentEntity(
        id = UUID.randomUUID().toString(),
        receiptNumber = "ATK-ADV-%05d".format(count),
        customerId = customerId,
        landId = landId,
        entryType = AdvanceEntryType.RECEIVED.code,
        amount = cleanAmount,
        paymentMethod = paymentMethod,
        transactionDate = transactionDate,
        notes = notes.trim(),
        createdAt = now,
        updatedAt = now,
        deviceId = devId,
      )
      advanceDao.insert(entry)

      // Informational memo on specific land ledger if landId selected (0 debit, 0 credit so dues aren't auto-deducted)
      if (landId != null) {
        val txnCount = txnDao.getTotalCountIncludingDeleted() + 1
        txnDao.insert(
          LedgerTransactionEntity(
            id = UUID.randomUUID().toString(),
            transactionCode = "TXN-%05d".format(txnCount),
            customerId = customerId,
            landId = landId,
            advanceId = entry.id,
            transactionDate = transactionDate,
            transactionType = TransactionType.ADVANCE_RECEIVED.code,
            debitAmount = 0.0,
            creditAmount = 0.0,
            description = "${entry.receiptNumber}: অগ্রিম গ্রহণ ৳$cleanAmount ($paymentMethod)",
            notes = notes.trim(),
            createdAt = now,
            updatedAt = now,
            deviceId = devId,
          )
        )
      }
      logAudit("ADVANCE", entry.id, "CREATE", "Advance received ৳$cleanAmount", null, entry.toString())
      entry
    }
  }

  suspend fun adjustAdvanceToLand(
    customerId: String,
    landId: String,
    jobId: String?,
    amount: Double,
    transactionDate: Long,
    notes: String,
  ): Result<AdvancePaymentEntity> = runCatching {
    val cleanAmount = BillingCalculator.roundCurrency(amount)
    require(cleanAmount > 0.0) { "Adjustment amount must be > 0" }

    db.withTransaction {
      val advEntries = advanceDao.getAdvancesByCustomerNow(customerId)
      val remainingAdv = BillingCalculator.roundCurrency(
        advEntries.filter { it.entryType == AdvanceEntryType.RECEIVED.code }.sumOf { it.amount } -
          advEntries.filter { it.entryType == AdvanceEntryType.ADJUSTED.code }.sumOf { it.amount } -
          advEntries.filter { it.entryType == AdvanceEntryType.REFUNDED.code }.sumOf { it.amount }
      )
      require(cleanAmount <= remainingAdv + 0.001) { "অবশিষ্ট অগ্রিমের চেয়ে বেশি সমন্বয় করা যাবে না (Available: ৳$remainingAdv)" }

      val now = System.currentTimeMillis()
      val devId = deviceId()
      val count = advanceDao.getTotalCountIncludingDeleted() + 1
      val entry = AdvancePaymentEntity(
        id = UUID.randomUUID().toString(),
        receiptNumber = "ATK-ADJ-%05d".format(count),
        customerId = customerId,
        landId = landId,
        jobId = jobId,
        entryType = AdvanceEntryType.ADJUSTED.code,
        amount = cleanAmount,
        paymentMethod = "ADVANCE",
        transactionDate = transactionDate,
        notes = notes.trim(),
        createdAt = now,
        updatedAt = now,
        deviceId = devId,
      )
      advanceDao.insert(entry)

      val txnCount = txnDao.getTotalCountIncludingDeleted() + 1
      txnDao.insert(
        LedgerTransactionEntity(
          id = UUID.randomUUID().toString(),
          transactionCode = "TXN-%05d".format(txnCount),
          customerId = customerId,
          landId = landId,
          jobId = jobId,
          advanceId = entry.id,
          transactionDate = transactionDate,
          transactionType = TransactionType.ADVANCE_ADJUSTMENT.code,
          debitAmount = 0.0,
          creditAmount = cleanAmount,
          description = "${entry.receiptNumber}: অগ্রিম থেকে বকেয়া সমন্বয়",
          notes = notes.trim(),
          createdAt = now,
          updatedAt = now,
          deviceId = devId,
        )
      )
      logAudit("ADVANCE", entry.id, "FINANCIAL_ADJUSTMENT", "Adjusted advance ৳$cleanAmount to land", null, entry.toString())
      entry
    }
  }

  suspend fun recordManualLandAdjustment(
    customerId: String,
    landId: String,
    amount: Double,
    isChargeIncrease: Boolean,
    isRefund: Boolean,
    description: String,
    notes: String,
    dateMillis: Long,
  ): Result<Unit> = runCatching {
    val cleanAmount = BillingCalculator.roundCurrency(amount)
    require(cleanAmount > 0.0) { "Amount must be > 0" }
    db.withTransaction {
      val now = System.currentTimeMillis()
      val devId = deviceId()
      val txnCount = txnDao.getTotalCountIncludingDeleted() + 1
      val type = if (isRefund) TransactionType.REFUND.code else TransactionType.MANUAL_ADJUSTMENT.code
      txnDao.insert(
        LedgerTransactionEntity(
          id = UUID.randomUUID().toString(),
          transactionCode = "TXN-%05d".format(txnCount),
          customerId = customerId,
          landId = landId,
          transactionDate = dateMillis,
          transactionType = type,
          debitAmount = if (isChargeIncrease || isRefund) cleanAmount else 0.0,
          creditAmount = if (!isChargeIncrease && !isRefund) cleanAmount else 0.0,
          description = description.ifBlank { if (isRefund) "রিফান্ড (Refund)" else "ম্যানুয়াল হিসাব সমন্বয়" },
          notes = notes.trim(),
          createdAt = now,
          updatedAt = now,
          deviceId = devId,
        )
      )
      logAudit("LEDGER", landId, "FINANCIAL_ADJUSTMENT", "$type: ৳$cleanAmount ($description)")
    }
  }

  suspend fun saveTractor(
    id: String? = null,
    name: String,
    brand: String,
    model: String,
    registrationInfo: String,
    notes: String,
    isActive: Boolean,
  ): Result<TractorEntity> = runCatching {
    require(name.trim().isNotEmpty()) { "Tractor name required" }
    db.withTransaction {
      val now = System.currentTimeMillis()
      val devId = deviceId()
      if (id == null) {
        val count = tractorDao.getAllIncludingDeleted().size + 1
        val tractor = TractorEntity(
          id = UUID.randomUUID().toString(),
          tractorCode = "TRC-%02d".format(count),
          name = name.trim(),
          brand = brand.trim(),
          model = model.trim(),
          registrationInfo = registrationInfo.trim(),
          notes = notes.trim(),
          isActive = isActive,
          createdAt = now,
          updatedAt = now,
          deviceId = devId,
        )
        tractorDao.insert(tractor)
        logAudit("TRACTOR", tractor.id, "CREATE", "Added tractor ${tractor.name}")
        tractor
      } else {
        val existing = tractorDao.getAllIncludingDeleted().firstOrNull { it.id == id } ?: error("Not found")
        val updated = existing.copy(
          name = name.trim(),
          brand = brand.trim(),
          model = model.trim(),
          registrationInfo = registrationInfo.trim(),
          notes = notes.trim(),
          isActive = isActive,
          updatedAt = now,
          version = existing.version + 1,
        )
        tractorDao.update(updated)
        logAudit("TRACTOR", updated.id, "UPDATE", "Updated tractor ${updated.name}")
        updated
      }
    }
  }

  suspend fun softDeleteCustomer(customerId: String) {
    db.withTransaction {
      val now = System.currentTimeMillis()
      customerDao.softDelete(customerId, now)
      landDao.softDeleteByCustomer(customerId, now)
      jobDao.softDeleteByCustomer(customerId, now)
      paymentDao.softDeleteByCustomer(customerId, now)
      advanceDao.softDeleteByCustomer(customerId, now)
      txnDao.softDeleteByCustomer(customerId, now)
      logAudit("CUSTOMER", customerId, "DELETE", "Moved customer and linked records to Recycle Bin")
    }
  }

  suspend fun softDeleteLand(landId: String) {
    db.withTransaction {
      val now = System.currentTimeMillis()
      landDao.softDelete(landId, now)
      jobDao.softDeleteByLand(landId, now)
      paymentDao.softDeleteByLand(landId, now)
      txnDao.softDeleteByLand(landId, now)
      logAudit("LAND", landId, "DELETE", "Moved land and linked records to Recycle Bin")
    }
  }

  suspend fun softDeleteJob(jobId: String) {
    db.withTransaction {
      val now = System.currentTimeMillis()
      jobDao.softDelete(jobId, now)
      paymentDao.softDeleteByJob(jobId, now)
      advanceDao.softDeleteByJob(jobId, now)
      txnDao.softDeleteByJob(jobId, now)
      logAudit("JOB", jobId, "DELETE", "Moved job to Recycle Bin")
    }
  }

  suspend fun softDeletePayment(paymentId: String) {
    db.withTransaction {
      val now = System.currentTimeMillis()
      paymentDao.softDelete(paymentId, now)
      txnDao.softDeleteByPayment(paymentId, now)
      logAudit("PAYMENT", paymentId, "DELETE", "Moved payment to Recycle Bin")
    }
  }

  suspend fun restoreCustomer(customerId: String) {
    db.withTransaction {
      val now = System.currentTimeMillis()
      // কাস্টমার মোছার সময়ের এন্ট্রিগুলোই ফেরত আসবে (আগে ব্যবহারকারীর আগে মোছা পেমেন্ট/জমিও ফিরে আসত)
      val stamp = customerDao.getById(customerId)?.deletedAt
      customerDao.restore(customerId, now)
      if (stamp != null) {
        landDao.restoreCascadeByCustomer(customerId, stamp, now)
        jobDao.restoreCascadeByCustomer(customerId, stamp, now)
        paymentDao.restoreCascadeByCustomer(customerId, stamp, now)
        advanceDao.restoreCascadeByCustomer(customerId, stamp, now)
        txnDao.restoreCascadeByCustomer(customerId, stamp, now)
      }
      logAudit("CUSTOMER", customerId, "RESTORE", "Restored customer from Recycle Bin")
    }
  }

  suspend fun restoreLand(landId: String) {
    db.withTransaction {
      val now = System.currentTimeMillis()
      val land = landDao.getById(landId) ?: return@withTransaction
      val stamp = land.deletedAt
      customerDao.restore(land.customerId, now)
      landDao.restore(landId, now)
      if (stamp != null) {
        jobDao.restoreCascadeByLand(landId, stamp, now)
        paymentDao.restoreCascadeByLand(landId, stamp, now)
        txnDao.restoreCascadeByLand(landId, stamp, now)
      }
      logAudit("LAND", landId, "RESTORE", "Restored land from Recycle Bin")
    }
  }

  suspend fun restoreJob(jobId: String) {
    db.withTransaction {
      val now = System.currentTimeMillis()
      val job = jobDao.getById(jobId) ?: return@withTransaction
      val stamp = job.deletedAt
      customerDao.restore(job.customerId, now)
      landDao.restore(job.landId, now)
      jobDao.restore(jobId, now)
      if (stamp != null) {
        paymentDao.restoreCascadeByJob(jobId, stamp, now)
        advanceDao.restoreCascadeByJob(jobId, stamp, now)
        txnDao.restoreCascadeByJob(jobId, stamp, now)
      }
      logAudit("JOB", jobId, "RESTORE", "Restored job from Recycle Bin")
    }
  }

  suspend fun restorePayment(paymentId: String) {
    db.withTransaction {
      val now = System.currentTimeMillis()
      val pay = paymentDao.getById(paymentId) ?: return@withTransaction
      val stamp = pay.deletedAt
      customerDao.restore(pay.customerId, now)
      landDao.restore(pay.landId, now)
      paymentDao.restore(paymentId, now)
      if (stamp != null) txnDao.restoreCascadeByPayment(paymentId, stamp, now)
      logAudit("PAYMENT", paymentId, "RESTORE", "Restored payment from Recycle Bin")
    }
  }

  suspend fun permanentlyDeleteJob(jobId: String) {
    db.withTransaction {
      txnDao.hardDeleteByJob(jobId)
      jobDao.hardDeleteById(jobId)
    }
  }

  suspend fun permanentlyDeleteCustomer(customerId: String) {
    db.withTransaction {
      val lands = landDao.getAllLandsIncludingDeleted().filter { it.customerId == customerId }
      val jobs = jobDao.getAllJobsIncludingDeleted().filter { it.customerId == customerId }
      val payments = paymentDao.getAllIncludingDeleted().filter { it.customerId == customerId }
      txnDao.hardDeleteByCustomer(customerId)
      payments.forEach { paymentDao.hardDeleteById(it.id) }
      advanceDao.hardDeleteByCustomer(customerId)
      jobs.forEach { jobDao.hardDeleteById(it.id) }
      lands.forEach { landDao.hardDeleteById(it.id) }
      customerDao.hardDeleteById(customerId)
    }
  }

  suspend fun purgeExpiredRecycleBin() {
    val thirtyDaysAgo = System.currentTimeMillis() - (30L * 24 * 60 * 60 * 1000)
    db.withTransaction {
      txnDao.purgeExpired(thirtyDaysAgo)
      paymentDao.purgeExpired(thirtyDaysAgo)
      advanceDao.purgeExpired(thirtyDaysAgo)
      jobDao.purgeExpired(thirtyDaysAgo)
      landDao.purgeExpired(thirtyDaysAgo)
      customerDao.purgeExpired(thirtyDaysAgo)
    }
  }

  /** কাস্টমারের মোট বকেয়া থেকে পেমেন্ট: সবচেয়ে পুরোনো জমি থেকে শুরু; বাড়তি টাকা অগ্রিম হিসেবে থাকবে। */
  suspend fun recordCustomerPayment(
    customerId: String,
    paymentDate: Long,
    amount: Double,
    paymentMethod: String,
    notes: String,
  ): Result<Unit> = runCatching {
    val cleanAmount = BillingCalculator.roundCurrency(amount)
    require(cleanAmount > 0.0) { "Payment amount must be greater than zero" }
    val summary = getRecalculatedCustomerSummaryNow(customerId) ?: error("Customer not found")
    var remaining = cleanAmount
    for (ls in summary.lands.sortedBy { it.land.createdAt }) {
      if (remaining <= 0.01) break
      val due = BillingCalculator.roundCurrency(ls.currentBalance)
      if (due <= 0.01) continue
      val pay = minOf(due, remaining)
      recordPayment(
        customerId, ls.land.id, null, PaymentTargetType.LAND.code,
        paymentDate, pay, paymentMethod, notes,
      ).getOrThrow()
      remaining = BillingCalculator.roundCurrency(remaining - pay)
    }
    if (remaining > 0.01) {
      recordAdvanceReceived(customerId, null, remaining, paymentMethod, paymentDate, notes).getOrThrow()
    }
    Unit
  }

  suspend fun saveFuelDealer(name: String, mobile: String): Result<FuelDealerEntity> = runCatching {
    val cleanName = name.trim()
    require(cleanName.isNotEmpty()) { "দোকানের নাম দিন" }
    val now = System.currentTimeMillis()
    val dealer = FuelDealerEntity(
      id = UUID.randomUUID().toString(),
      name = cleanName,
      mobile = mobile.trim(),
      createdAt = now,
      updatedAt = now,
    )
    db.fuelDao().upsertDealer(dealer)
    dealer
  }

  suspend fun saveFuelEntry(
    dealerId: String,
    isPurchase: Boolean,
    entryDate: Long,
    liters: Double,
    ratePerLiter: Double,
    amount: Double,
    driverName: String,
    note: String,
  ): Result<FuelEntryEntity> = runCatching {
    require(dealerId.isNotBlank()) { "দোকান বেছে নিন" }
    require(amount >= 0.0) { "জমার পরিমাণ সঠিক দিন" }
    val now = System.currentTimeMillis()
    val entry = if (isPurchase) {
      require(liters > 0.0) { "লিটার সঠিক দিন" }
      require(ratePerLiter > 0.0) { "দর সঠিক দিন" }
      FuelEntryEntity(
        id = UUID.randomUUID().toString(),
        dealerId = dealerId,
        entryType = FuelEntryType.PURCHASE,
        entryDate = entryDate,
        liters = liters,
        ratePerLiter = ratePerLiter,
        totalAmount = BillingCalculator.roundCurrency(liters * ratePerLiter),
        paidAmount = BillingCalculator.roundCurrency(amount),
        driverName = driverName.trim(),
        note = note.trim(),
        createdAt = now,
        updatedAt = now,
      )
    } else {
      require(amount > 0.0) { "জমার পরিমাণ সঠিক দিন" }
      FuelEntryEntity(
        id = UUID.randomUUID().toString(),
        dealerId = dealerId,
        entryType = FuelEntryType.DEPOSIT,
        entryDate = entryDate,
        liters = 0.0,
        ratePerLiter = 0.0,
        totalAmount = 0.0,
        paidAmount = BillingCalculator.roundCurrency(amount),
        driverName = "",
        note = note.trim(),
        createdAt = now,
        updatedAt = now,
      )
    }
    db.fuelDao().upsertEntry(entry)
    entry
  }

  suspend fun updateFuelDealer(dealer: FuelDealerEntity, name: String, mobile: String): Result<FuelDealerEntity> = runCatching {
    val cleanName = name.trim()
    require(cleanName.isNotEmpty()) { "দোকানের নাম দিন" }
    val updated = dealer.copy(name = cleanName, mobile = mobile.trim(), updatedAt = System.currentTimeMillis())
    db.fuelDao().upsertDealer(updated)
    updated
  }

  suspend fun deleteFuelDealer(dealer: FuelDealerEntity): Result<Unit> = runCatching {
    require(db.fuelDao().countActiveEntriesForDealer(dealer.id) == 0) { "এই দোকানের হিসাব আছে, আগে সেগুলো মুছুন" }
    db.fuelDao().upsertDealer(dealer.copy(isDeleted = true, updatedAt = System.currentTimeMillis()))
  }

  suspend fun updateFuelEntry(
    entry: FuelEntryEntity,
    dealerId: String,
    isPurchase: Boolean,
    entryDate: Long,
    liters: Double,
    ratePerLiter: Double,
    amount: Double,
    driverName: String,
    note: String,
  ): Result<FuelEntryEntity> = runCatching {
    require(dealerId.isNotBlank()) { "দোকান বেছে নিন" }
    require(amount >= 0.0) { "জমার পরিমাণ সঠিক দিন" }
    val now = System.currentTimeMillis()
    val updated = if (isPurchase) {
      require(liters > 0.0) { "লিটার সঠিক দিন" }
      require(ratePerLiter > 0.0) { "দর সঠিক দিন" }
      entry.copy(
        dealerId = dealerId,
        entryType = FuelEntryType.PURCHASE,
        entryDate = entryDate,
        liters = liters,
        ratePerLiter = ratePerLiter,
        totalAmount = BillingCalculator.roundCurrency(liters * ratePerLiter),
        paidAmount = BillingCalculator.roundCurrency(amount),
        driverName = driverName.trim(),
        note = note.trim(),
        updatedAt = now,
      )
    } else {
      require(amount > 0.0) { "জমার পরিমাণ সঠিক দিন" }
      entry.copy(
        dealerId = dealerId,
        entryType = FuelEntryType.DEPOSIT,
        entryDate = entryDate,
        liters = 0.0,
        ratePerLiter = 0.0,
        totalAmount = 0.0,
        paidAmount = BillingCalculator.roundCurrency(amount),
        driverName = "",
        note = note.trim(),
        updatedAt = now,
      )
    }
    db.fuelDao().upsertEntry(updated)
    updated
  }

  suspend fun deleteFuelEntry(entry: FuelEntryEntity): Result<Unit> = runCatching {
    db.fuelDao().upsertEntry(entry.copy(isDeleted = true, updatedAt = System.currentTimeMillis()))
  }

  suspend fun computeLandBalanceNow(landId: String): Double {
    val txns = txnDao.getTransactionsByLandNow(landId)
    return BillingCalculator.roundCurrency(txns.sumOf { it.debitAmount - it.creditAmount })
  }

  suspend fun getRecalculatedCustomerSummaryNow(customerId: String): CustomerFinancialSummary? {
    val customer = customerDao.getById(customerId) ?: return null
    if (customer.isDeleted) return null
    return BillingCalculator.computeCustomerSummary(
      customer = customer,
      customerLands = landDao.getLandsByCustomerNow(customerId),
      customerJobs = jobDao.getActiveJobsNow().filter { it.customerId == customerId },
      customerPayments = paymentDao.getActivePaymentsNow().filter { it.customerId == customerId },
      customerAdvances = advanceDao.getAdvancesByCustomerNow(customerId),
      customerTransactions = txnDao.getTransactionsByCustomerNow(customerId),
    )
  }

  suspend fun getRecalculatedLandSummaryNow(landId: String): Pair<CustomerEntity, LandFinancialSummary>? {
    val land = landDao.getById(landId) ?: return null
    val customer = customerDao.getById(land.customerId) ?: return null
    val summary = BillingCalculator.computeLandSummary(
      land = land,
      landTransactions = txnDao.getTransactionsByLandNow(landId),
      landJobs = jobDao.getActiveJobsNow().filter { it.landId == landId },
    )
    return customer to summary
  }

  suspend fun getBulkCustomerSummariesNow(filter: BulkPrintFilter): List<CustomerFinancialSummary> {
    return BillingCalculator.filterCustomerSummariesForBulkPrint(
      customers = customerDao.getActiveCustomersNow(),
      lands = landDao.getActiveLandsNow(),
      jobs = jobDao.getActiveJobsNow(),
      payments = paymentDao.getActivePaymentsNow(),
      advances = advanceDao.getActiveAdvancesNow(),
      transactions = txnDao.getActiveTransactionsNow(),
      filter = filter,
    )
  }

  fun observeAttachments(ownerType: String, ownerId: String): Flow<List<AttachmentEntity>> =
    attachmentDao.observeByOwner(ownerType, ownerId)

  suspend fun saveAttachmentFromUri(
    ownerType: String,
    ownerId: String,
    uri: Uri,
    notes: String = "",
  ): Result<AttachmentEntity> = runCatching {
    val resolver = context.contentResolver
    val mimeType = resolver.getType(uri) ?: "image/jpeg"
    var displayName = "attachment_${System.currentTimeMillis()}.jpg"
    resolver.query(uri, null, null, null, null)?.use { cursor ->
      val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
      if (idx >= 0 && cursor.moveToFirst()) {
        displayName = cursor.getString(idx) ?: displayName
      }
    }

    val dir = File(context.filesDir, "attachments").apply { mkdirs() }
    val destFile = File(dir, "${UUID.randomUUID()}_$displayName")
    resolver.openInputStream(uri)?.use { input ->
      destFile.outputStream().use { output -> input.copyTo(output) }
    } ?: error("Unable to open attachment stream")

    val now = System.currentTimeMillis()
    val entity = AttachmentEntity(
      id = UUID.randomUUID().toString(),
      ownerType = ownerType,
      ownerId = ownerId,
      fileName = displayName,
      localPath = destFile.absolutePath,
      mimeType = mimeType,
      fileSizeBytes = destFile.length(),
      notes = notes,
      createdAt = now,
      updatedAt = now,
    )
    attachmentDao.insert(entity)
    entity
  }

  suspend fun deleteAttachment(id: String) {
    attachmentDao.softDelete(id, System.currentTimeMillis())
  }

  suspend fun getAllTractorsNow(): List<TractorEntity> = tractorDao.getActiveTractorsNow()

  suspend fun getLatestLandRate(landId: String, workType: String): LandRateHistoryEntity? =
    landRateDao.getLatestRate(landId, workType)
}

private object FormatAreaForAudit {
  fun fmt(v: Double): String = if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()
}
