package com.example.data.profile

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** একটি প্রোফাইল = আলাদা ডাটাবেস ফাইল (কাস্টমার, জমি, কাজ, পেমেন্ট সব আলাদা) */
data class AppProfile(
  val id: String,
  val name: String,
  val dbName: String,
  val createdAt: Long,
)

/**
 * একাধিক প্রোফাইলের তালিকা ও সক্রিয় প্রোফাইল SharedPreferences এ রাখা হয়।
 * ডাটাবেস চালু হওয়ার আগেই (synchronously) সক্রিয় প্রোফাইলের ডাটাবেসের নাম লাগে, তাই DataStore নয়।
 * প্রথম প্রোফাইল (default) আগের ডাটাবেস ফাইলই ব্যবহার করে, ফলে পুরনো সব তথ্য অক্ষত থাকে।
 */
object ProfileManager {
  private const val PREFS = "araaf_profiles"
  private const val KEY_LIST = "profiles_json"
  private const val KEY_ACTIVE = "active_profile_id"

  const val DEFAULT_ID = "default"
  private const val DEFAULT_DB_NAME = "araaf_tractor_khata.db"
  private const val DEFAULT_PROFILE_NAME = "আমার হিসাব"

  private fun prefs(context: Context) =
    context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

  @Synchronized
  fun list(context: Context): List<AppProfile> {
    val raw = prefs(context).getString(KEY_LIST, null)
    val parsed = if (raw.isNullOrBlank()) emptyList() else runCatching {
      val arr = JSONArray(raw)
      (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        AppProfile(
          id = o.getString("id"),
          name = o.getString("name"),
          dbName = o.getString("dbName"),
          createdAt = o.optLong("createdAt", 0L),
        )
      }
    }.getOrDefault(emptyList())
    if (parsed.isNotEmpty()) return parsed

    val default = AppProfile(DEFAULT_ID, DEFAULT_PROFILE_NAME, DEFAULT_DB_NAME, System.currentTimeMillis())
    save(context, listOf(default))
    return listOf(default)
  }

  private fun save(context: Context, profiles: List<AppProfile>) {
    val arr = JSONArray()
    profiles.forEach { p ->
      arr.put(
        JSONObject()
          .put("id", p.id)
          .put("name", p.name)
          .put("dbName", p.dbName)
          .put("createdAt", p.createdAt),
      )
    }
    prefs(context).edit().putString(KEY_LIST, arr.toString()).commit()
  }

  fun activeId(context: Context): String {
    val profiles = list(context)
    val saved = prefs(context).getString(KEY_ACTIVE, null)
    return if (saved != null && profiles.any { it.id == saved }) saved else profiles.first().id
  }

  fun active(context: Context): AppProfile {
    val id = activeId(context)
    return list(context).first { it.id == id }
  }

  fun activeDbName(context: Context): String = active(context).dbName

  @Synchronized
  fun add(context: Context, name: String): AppProfile {
    val id = UUID.randomUUID().toString().take(8)
    val profile = AppProfile(
      id = id,
      name = name.trim().ifBlank { "নতুন প্রোফাইল" },
      dbName = "araaf_khata_$id.db",
      createdAt = System.currentTimeMillis(),
    )
    save(context, list(context) + profile)
    return profile
  }

  @Synchronized
  fun rename(context: Context, id: String, newName: String) {
    val clean = newName.trim()
    if (clean.isBlank()) return
    save(context, list(context).map { if (it.id == id) it.copy(name = clean) else it })
  }

  fun setActive(context: Context, id: String) {
    if (list(context).any { it.id == id }) {
      prefs(context).edit().putString(KEY_ACTIVE, id).commit()
    }
  }

  /** সক্রিয় প্রোফাইল মোছা যাবে না। মুছলে তার ডাটাবেস ফাইলও মুছে যাবে। */
  @Synchronized
  fun delete(context: Context, id: String): Boolean {
    if (id == activeId(context)) return false
    val profiles = list(context)
    val target = profiles.firstOrNull { it.id == id } ?: return false
    if (profiles.size <= 1) return false
    context.applicationContext.deleteDatabase(target.dbName)
    save(context, profiles.filterNot { it.id == id })
    return true
  }

  /** প্রোফাইল বদলের পর অ্যাপ পুরো নতুন প্রসেসে চালু করা হয়, যাতে নতুন প্রোফাইলের ডাটাবেস লোড হয় */
  fun restartApp(context: Context) {
    val app = context.applicationContext
    val launch = app.packageManager.getLaunchIntentForPackage(app.packageName)
      ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
    if (launch != null) {
      // অ্যালার্ম দিয়ে অ্যাপ আবার চালু হবে; তার আগেই এই প্রসেস নিজে বন্ধ হবে।
      // আগের প্রসেস সম্পূর্ণ বন্ধ না হলে পুরোনো প্রোফাইলের ডাটাবেস মেমরিতে থেকে যায়।
      val pending = PendingIntent.getActivity(
        app, 0, launch, PendingIntent.FLAG_CANCEL_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )
      val alarm = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
      alarm.set(AlarmManager.RTC, System.currentTimeMillis() + 400L, pending)
    }
    android.os.Process.killProcess(android.os.Process.myPid())
  }
}
