package com.example.update

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import com.example.BuildConfig
import java.io.File
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/** GitHub Releases-এ থাকা সর্বশেষ APK-র তথ্য */
data class UpdateInfo(
  val versionCode: Int,
  val versionName: String,
  val downloadUrl: String,
  val sizeBytes: Long,
  val notes: String,
)

sealed interface UpdateOutcome {
  /** ইনস্টলার স্ক্রিন খোলা হয়েছে */
  data object Started : UpdateOutcome

  /** "অজানা সোর্স থেকে ইনস্টল" অনুমতি দিতে সেটিংস খোলা হয়েছে */
  data object NeedsPermission : UpdateOutcome

  data class Failed(val message: String) : UpdateOutcome
}

/**
 * অ্যাপের ভেতর থেকে আপডেট: GitHub Releases থেকে সর্বশেষ APK খুঁজে, ডাউনলোড করে, Android-এর ইনস্টলার খোলে।
 * রিলিজের tag হয় "build-<versionCode>" (workflow এভাবেই বানায়)।
 * BuildConfig.UPDATE_REPO খালি থাকলে (লোকাল বিল্ড) আপডেট ফিচার বন্ধ থাকে।
 */
object UpdateManager {
  private val client by lazy {
    OkHttpClient.Builder()
      .connectTimeout(15, TimeUnit.SECONDS)
      .readTimeout(60, TimeUnit.SECONDS)
      .build()
  }

  private val tagRegex = Regex("""build-(\d+)""")

  fun isConfigured(): Boolean = BuildConfig.UPDATE_REPO.contains('/')

  /** নতুন রিলিজ না থাকলে বা পড়া না গেলে null; নেটওয়ার্ক/সার্ভার সমস্যায় failure */
  suspend fun fetchLatest(): Result<UpdateInfo?> = withContext(Dispatchers.IO) {
    runCatching {
      val request = Request.Builder()
        .url("https://api.github.com/repos/${BuildConfig.UPDATE_REPO}/releases/latest")
        .header("Accept", "application/vnd.github+json")
        .build()
      val result: UpdateInfo? = client.newCall(request).execute().use { resp ->
        if (resp.code == 404) return@use null // এখনও কোনো রিলিজ নেই (বা রিপোজিটরি private)
        if (!resp.isSuccessful) error("GitHub থেকে উত্তর আসেনি (${resp.code})")
        val body = resp.body?.string() ?: error("খালি উত্তর")
        val json = JSONObject(body)
        val tag = json.optString("tag_name")
        val code = tagRegex.find(tag)?.groupValues?.get(1)?.toIntOrNull() ?: return@use null
        val assets = json.optJSONArray("assets") ?: return@use null
        var url: String? = null
        var size = 0L
        for (i in 0 until assets.length()) {
          val a = assets.getJSONObject(i)
          if (a.optString("name").endsWith(".apk", ignoreCase = true)) {
            url = a.optString("browser_download_url")
            size = a.optLong("size", 0L)
            break
          }
        }
        if (url.isNullOrBlank()) return@use null
        UpdateInfo(
          versionCode = code,
          versionName = json.optString("name").ifBlank { tag },
          downloadUrl = url,
          sizeBytes = size,
          notes = json.optString("body").trim(),
        )
      }
      result
    }
  }

  fun isNewer(info: UpdateInfo): Boolean = info.versionCode > BuildConfig.VERSION_CODE

  suspend fun downloadAndInstall(
    context: Context,
    info: UpdateInfo,
    onProgress: (Float) -> Unit,
  ): UpdateOutcome {
    val app = context.applicationContext
    val file = download(app, info, onProgress).getOrElse {
      return UpdateOutcome.Failed(it.message ?: "ডাউনলোড ব্যর্থ হয়েছে")
    }
    return withContext(Dispatchers.Main) { install(app, file) }
  }

  private suspend fun download(
    context: Context,
    info: UpdateInfo,
    onProgress: (Float) -> Unit,
  ): Result<File> = withContext(Dispatchers.IO) {
    runCatching {
      val dir = File(context.cacheDir, "updates").apply { mkdirs() }
      val file = File(dir, "araaf-update-${info.versionCode}.apk")
      // আগে পুরোটা নামানো থাকলে (যেমন অনুমতি দিতে সেটিংসে গিয়ে ফিরলে) আবার নামানো হবে না
      if (file.exists() && info.sizeBytes > 0 && file.length() == info.sizeBytes) {
        onProgress(1f)
        return@runCatching file
      }
      dir.listFiles()?.forEach { it.delete() }
      val request = Request.Builder().url(info.downloadUrl).build()
      client.newCall(request).execute().use { resp ->
        if (!resp.isSuccessful) error("ডাউনলোড ব্যর্থ (${resp.code})")
        val body = resp.body ?: error("খালি ফাইল")
        val total = if (body.contentLength() > 0) body.contentLength() else info.sizeBytes
        body.byteStream().use { input ->
          file.outputStream().use { out ->
            val buf = ByteArray(64 * 1024)
            var read = 0L
            while (true) {
              val n = input.read(buf)
              if (n < 0) break
              out.write(buf, 0, n)
              read += n
              if (total > 0) onProgress((read.toFloat() / total).coerceIn(0f, 1f))
            }
          }
        }
      }
      if (info.sizeBytes > 0 && file.length() != info.sizeBytes) {
        file.delete()
        error("ডাউনলোড অসম্পূর্ণ; আবার চেষ্টা করুন")
      }
      file
    }
  }

  private fun install(context: Context, file: File): UpdateOutcome {
    return try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !context.packageManager.canRequestPackageInstalls()) {
        context.startActivity(
          Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
        return UpdateOutcome.NeedsPermission
      }
      val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
      context.startActivity(
        Intent(Intent.ACTION_VIEW)
          .setDataAndType(uri, "application/vnd.android.package-archive")
          .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
      )
      UpdateOutcome.Started
    } catch (e: Exception) {
      UpdateOutcome.Failed(e.message ?: "ইনস্টলার খোলা যায়নি")
    }
  }
}
