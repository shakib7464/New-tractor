package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.update.UpdateInfo
import com.example.update.UpdateManager
import com.example.update.UpdateOutcome
import java.util.Locale
import kotlinx.coroutines.launch

private fun sizeText(bytes: Long): String =
  if (bytes > 0) String.format(Locale.US, "%.1f MB", bytes / 1048576.0) else ""

private sealed interface UpdateStatus {
  data object Idle : UpdateStatus
  data object Checking : UpdateStatus
  data object UpToDate : UpdateStatus
  data class Available(val info: UpdateInfo) : UpdateStatus
  data object Downloading : UpdateStatus
  data class NeedsPermission(val info: UpdateInfo) : UpdateStatus
  data class Error(val message: String, val info: UpdateInfo?) : UpdateStatus
}

/** সেটিংস স্ক্রিনের "অ্যাপ আপডেট" কার্ড: খুঁজুন → ডাউনলোড → ইনস্টল */
@Composable
fun UpdateCard() {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  var status by remember { mutableStateOf<UpdateStatus>(UpdateStatus.Idle) }
  var progress by remember { mutableFloatStateOf(0f) }

  val check: () -> Unit = {
    scope.launch {
      status = UpdateStatus.Checking
      val result = UpdateManager.fetchLatest()
      status = result.fold(
        onSuccess = { info ->
          if (info != null && UpdateManager.isNewer(info)) UpdateStatus.Available(info) else UpdateStatus.UpToDate
        },
        onFailure = { UpdateStatus.Error(it.message ?: "ইন্টারনেট সংযোগ পরীক্ষা করুন", null) },
      )
    }
  }

  val install: (UpdateInfo) -> Unit = { info ->
    scope.launch {
      status = UpdateStatus.Downloading
      progress = 0f
      status = when (val r = UpdateManager.downloadAndInstall(context, info) { progress = it }) {
        UpdateOutcome.Started -> UpdateStatus.Available(info)
        UpdateOutcome.NeedsPermission -> UpdateStatus.NeedsPermission(info)
        is UpdateOutcome.Failed -> UpdateStatus.Error(r.message, info)
      }
    }
  }

  Card(shape = MaterialTheme.shapes.medium) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
      Text("অ্যাপ আপডেট", fontWeight = FontWeight.Bold)
      Text(
        "বর্তমান ভার্সন: ${BuildConfig.VERSION_NAME} (বিল্ড ${BuildConfig.VERSION_CODE})",
        style = MaterialTheme.typography.bodySmall,
      )

      if (!UpdateManager.isConfigured()) {
        Text(
          "এই বিল্ডে আপডেট চালু নেই। GitHub Actions থেকে বানানো APK-তে এটি কাজ করবে।",
          style = MaterialTheme.typography.bodySmall,
        )
        return@Column
      }

      when (val s = status) {
        UpdateStatus.Idle -> Unit
        UpdateStatus.Checking -> Row(verticalAlignment = Alignment.CenterVertically) {
          CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
          Text("  নতুন ভার্সন খোঁজা হচ্ছে…")
        }
        UpdateStatus.UpToDate -> Text("✅ আপনি সর্বশেষ ভার্সন ব্যবহার করছেন।")
        is UpdateStatus.Available -> {
          Text(
            "নতুন ভার্সন পাওয়া গেছে: ${s.info.versionName} (বিল্ড ${s.info.versionCode}) ${sizeText(s.info.sizeBytes)}",
            fontWeight = FontWeight.SemiBold,
          )
          if (s.info.notes.isNotBlank()) {
            Text(s.info.notes, style = MaterialTheme.typography.bodySmall, maxLines = 6)
          }
        }
        UpdateStatus.Downloading -> {
          LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
          Text("ডাউনলোড হচ্ছে… ${(progress * 100).toInt()}%")
        }
        is UpdateStatus.NeedsPermission -> Text(
          "সেটিংসে এই অ্যাপকে \"অ্যাপ ইনস্টল করার অনুমতি\" দিন, তারপর ফিরে এসে আবার \"ডাউনলোড ও ইনস্টল\" চাপুন।",
        )
        is UpdateStatus.Error -> Text(s.message, color = MaterialTheme.colorScheme.error)
      }

      val pending: UpdateInfo? = when (val s = status) {
        is UpdateStatus.Available -> s.info
        is UpdateStatus.NeedsPermission -> s.info
        is UpdateStatus.Error -> s.info
        else -> null
      }
      val busy = status == UpdateStatus.Checking || status == UpdateStatus.Downloading
      if (pending != null && !busy) {
        Button(onClick = { install(pending) }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
          Text("ডাউনলোড ও ইনস্টল করুন")
        }
      }
      if (!busy) {
        OutlinedButton(onClick = check, modifier = Modifier.fillMaxWidth().height(48.dp)) {
          Text("আপডেট আছে কিনা দেখুন")
        }
      }
    }
  }
}

/** অ্যাপ খুললে নিঃশব্দে নতুন ভার্সন খোঁজে; পেলে একটি ডায়ালগ দেখায়। ব্যর্থ হলে কিছুই দেখায় না। */
@Composable
fun AutoUpdatePrompt() {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  var info by remember { mutableStateOf<UpdateInfo?>(null) }
  var dismissed by rememberSaveable { mutableStateOf(false) }
  var busy by remember { mutableStateOf(false) }
  var progress by remember { mutableFloatStateOf(0f) }
  var message by remember { mutableStateOf<String?>(null) }

  LaunchedEffect(Unit) {
    if (UpdateManager.isConfigured()) {
      info = UpdateManager.fetchLatest().getOrNull()?.takeIf { UpdateManager.isNewer(it) }
    }
  }

  val available = info
  if (available == null || dismissed) return

  AlertDialog(
    onDismissRequest = { if (!busy) dismissed = true },
    title = { Text("নতুন আপডেট এসেছে") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("ভার্সন ${available.versionName} (বিল্ড ${available.versionCode}) ${sizeText(available.sizeBytes)}")
        if (available.notes.isNotBlank()) {
          Text(available.notes, style = MaterialTheme.typography.bodySmall, maxLines = 6)
        }
        if (busy) {
          LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
          Text("ডাউনলোড হচ্ছে… ${(progress * 100).toInt()}%")
        }
        message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
      }
    },
    confirmButton = {
      TextButton(
        enabled = !busy,
        onClick = {
          scope.launch {
            busy = true
            message = null
            progress = 0f
            when (val r = UpdateManager.downloadAndInstall(context, available) { progress = it }) {
              UpdateOutcome.Started -> dismissed = true
              UpdateOutcome.NeedsPermission ->
                message = "সেটিংসে ইনস্টলের অনুমতি দিয়ে ফিরে এসে আবার \"আপডেট করুন\" চাপুন।"
              is UpdateOutcome.Failed -> message = r.message
            }
            busy = false
          }
        },
      ) { Text("আপডেট করুন") }
    },
    dismissButton = { TextButton(enabled = !busy, onClick = { dismissed = true }) { Text("পরে") } },
  )
}
