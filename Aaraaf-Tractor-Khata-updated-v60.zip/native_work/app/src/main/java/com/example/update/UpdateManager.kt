package com.example.update

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import com.example.BuildConfig
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** GitHub Releases-এ থাকা সর্বশেষ APK-র তথ্য */
data class UpdateInfo(
  val versionCode: Int,
  val versionName: String,
  val downloadUrl: String,
  val sizeBytes: Long,
  val notes: String,
)

sealed interface UpdateOutcome {
  /** ইনস্টলার স্ক্রিন খোলা হয়েছে */
  data object Started : UpdateOutcome

  /** "অজানা সোর্স থেকে ইনস্টল" অনুমতি দিতে সেটিংস খোলা হয়েছে */
  data object NeedsPermission : UpdateOutcome

  data class Failed(val message: String) : UpdateOutcome
}

/**
 * অ্যাপের ভেতর থেকে আপডেট: GitHub Releases থেকে সর্বশেষ APK খুঁজে, ডাউনলোড করে, Android-এর ইনস্টলার খোলে।
 * রিলিজের tag হয় "build-<versionCode>" (workflow এভাবেই বানায়)।
 * BuildConfig.UPDATE_REPO খালি থাকলে (লোকাল বিল্ড) আপডেট ফিচার বন্ধ থাকে।
 *
 * আগের সংস্করণের সমস্যা যা ঠিক করা হয়েছে:
 * - রিপোজিটরি private/রিলিজ নেই (404) হলে আগে "আপনি সর্বশেষ ভার্সনে আছেন" দেখাত; এখন স্পষ্ট বার্তা দেখায়।
 * - শুধু /releases/latest না দেখে সব রিলিজ থেকে সবচেয়ে বড় build নম্বর বাছা হয়।
 * - ডাউনলোড করা APK ইনস্টলের আগে যাচাই হয় (অন্য অ্যাপ বা পুরোনো/একই ভার্সন হলে ব্যর্থ বার্তা)।
 * - ইনস্টলের অনুমতি ডাউনলোডের আগেই চাওয়া হয়।
 * - পুরোনো ডাউনলোড করা APK নিজে থেকে মুছে যায়।
 */
object UpdateManager {
  private val client by lazy {
    OkHttpClient.Builder()
      .connectTimeout(15, TimeUnit.SECONDS)
      .readTimeout(60, TimeUnit.SECONDS)
      .retryOnConnectionFailure(true)
      .build()
  }

  private const val USER_AGENT = "AraafTractorKhata"
  private const val APK_MIME = "application/vnd.android.package-archive"

  private val tagRegex = Regex("""build-(\d+)""")
  private val versionNameRegex = Regex("""v(\d+(?:\.\d+)*)""")
  private val downloadNameRegex = Regex("""araaf-update-(\d+)""")

  fun isConfigured(): Boolean = BuildConfig.UPDATE_REPO.contains('/')

  /**
   * সবচেয়ে নতুন APK রিলিজ। পাওয়া না গেলে (নেটওয়ার্ক, private repo, রিলিজ নেই ইত্যাদি)
   * Result.failure এবং বাংলা বার্তা — কখনো "সর্বশেষ ভার্সন" বলে ভুল দেখায় না।
   */
  suspend fun fetchLatest(): Result<UpdateInfo> = withContext(Dispatchers.IO) {
    try {
      Result.success(loadLatest())
    } catch (e: CancellationException) {
      throw e
    } catch (e: IOException) {
      Result.failure<UpdateInfo>(IllegalStateException("ইন্টারনেট সংযোগ পরীক্ষা করুন (GitHub-এ পৌঁছানো যায়নি)", e))
    } catch (e: JSONException) {
      Result.failure<UpdateInfo>(IllegalStateException("GitHub-এর উত্তর পড়া যায়নি", e))
    } catch (e: Exception) {
      Result.failure<UpdateInfo>(e)
    }
  }

  private fun loadLatest(): UpdateInfo {
    // প্রথমে latest.json (github.com থেকে, API rate limit লাগে না); না পেলে পুরোনো API পদ্ধতি
    loadFromLatestJson()?.let { return it }
    return loadFromApi()
  }

  /**
   * workflow প্রতিটি রিলিজে latest.json যোগ করে। /releases/latest/download/ লিংক সবসময়
   * সর্বশেষ রিলিজের ফাইলে নিয়ে যায় এবং api.github.com-এর ঘণ্টায় ৬০ অনুরোধের সীমা এতে খাটে না।
   * ফাইল না থাকলে (পুরোনো রিলিজ) বা পড়া না গেলে null।
   */
  private fun loadFromLatestJson(): UpdateInfo? {
    val request = Request.Builder()
      .url("https://github.com/${BuildConfig.UPDATE_REPO}/releases/latest/download/latest.json")
      .header("User-Agent", USER_AGENT)
      .build()
    val body = client.newCall(request).execute().use { resp ->
      if (!resp.isSuccessful) return null
      resp.body?.string()
    } ?: return null
    return try {
      val o = JSONObject(body)
      val code = o.optInt("versionCode", 0)
      val url = o.optString("downloadUrl")
      if (code <= 0 || url.isBlank()) return null
      UpdateInfo(
        versionCode = code,
        versionName = o.optString("versionName").ifBlank { "build-$code" },
        downloadUrl = url,
        sizeBytes = o.optLong("sizeBytes", 0L),
        notes = o.optString("notes"),
      )
    } catch (e: JSONException) {
      null
    }
  }

  private fun loadFromApi(): UpdateInfo {
    val request = Request.Builder()
      .url("https://api.github.com/repos/${BuildConfig.UPDATE_REPO}/releases?per_page=30")
      .header("Accept", "application/vnd.github+json")
      .header("User-Agent", USER_AGENT)
      .build()
    val body = client.newCall(request).execute().use { resp ->
      when {
        resp.code == 404 ->
          error("GitHub-এ রিপোজিটরি বা রিলিজ পাওয়া যায়নি। রিপোজিটরি Public আছে কিনা এবং বিল্ড শেষ হয়েছে কিনা দেখুন।")
        resp.code == 403 || resp.code == 429 ->
          error("GitHub এই মুহূর্তে অনেক অনুরোধ পাচ্ছে। কিছুক্ষণ পরে আবার চেষ্টা করুন।")
        !resp.isSuccessful -> error("GitHub থেকে উত্তর আসেনি (${resp.code})")
        else -> resp.body?.string() ?: error("GitHub থেকে খালি উত্তর এসেছে")
      }
    }
    val releases = JSONArray(body)
    var best: UpdateInfo? = null
    for (i in 0 until releases.length()) {
      val obj = releases.optJSONObject(i) ?: continue
      val info = parseRelease(obj) ?: continue
      if (best == null || info.versionCode > best.versionCode) best = info
    }
    return best ?: error("এখনও কোনো আপডেট রিলিজ হয়নি।")
  }

  /** draft/pre-release বা APK ছাড়া রিলিজ বাদ; tag "build-N" না হলে বাদ */
  private fun parseRelease(r: JSONObject): UpdateInfo? {
    if (r.optBoolean("draft") || r.optBoolean("prerelease")) return null
    val tag = r.optString("tag_name")
    val code = tagRegex.find(tag)?.groupValues?.get(1)?.toIntOrNull() ?: return null
    val assets = r.optJSONArray("assets") ?: return null
    var url: String? = null
    var size = 0L
    for (i in 0 until assets.length()) {
      val a = assets.optJSONObject(i) ?: continue
      if (a.optString("name").endsWith(".apk", ignoreCase = true)) {
        url = a.optString("browser_download_url")
        size = a.optLong("size", 0L)
        break
      }
    }
    if (url.isNullOrBlank()) return null
    // শিরোনাম: "Araaf Tractor Khata v3.7 (build 223)" → "3.7"
    val title = r.optString("name")
    val versionName = versionNameRegex.find(title)?.groupValues?.get(1) ?: tag
    return UpdateInfo(
      versionCode = code,
      versionName = versionName,
      downloadUrl = url,
      sizeBytes = size,
      notes = "",
    )
  }

  fun isNewer(info: UpdateInfo): Boolean = info.versionCode > BuildConfig.VERSION_CODE

  /** "অজানা সোর্স থেকে ইনস্টল" অনুমতি আছে কিনা (Android 8-এর আগে লাগে না) */
  fun hasInstallPermission(context: Context): Boolean =
    Build.VERSION.SDK_INT < Build.VERSION_CODES.O || context.packageManager.canRequestPackageInstalls()

  fun openInstallPermissionSettings(context: Context): UpdateOutcome {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return UpdateOutcome.NeedsPermission
    return try {
      context.startActivity(
        Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
          .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
      )
      UpdateOutcome.NeedsPermission
    } catch (e: Exception) {
      UpdateOutcome.Failed("ইনস্টলের অনুমতির সেটিংস খোলা যায়নি। ফোনের Settings থেকে এই অ্যাপকে \"Install unknown apps\" অনুমতি দিন।")
    }
  }

  suspend fun downloadAndInstall(
    context: Context,
    info: UpdateInfo,
    onProgress: (Float) -> Unit,
  ): UpdateOutcome {
    val app = context.applicationContext
    // অনুমতি আগে: না থাকলে সেটিংস খুলে ফিরে আসার অপেক্ষা, ডাউনলোড তারপর
    if (!hasInstallPermission(app)) {
      return withContext(Dispatchers.Main) { openInstallPermissionSettings(app) }
    }
    val file = download(app, info, onProgress).getOrElse {
      return UpdateOutcome.Failed(it.message ?: "ডাউনলোড ব্যর্থ হয়েছে")
    }
    return withContext(Dispatchers.Main) { install(app, file) }
  }

  /** ইনস্টল হয়ে যাওয়া বা পুরোনো ভার্সনের ডাউনলোড করা APK ও অসম্পূর্ণ ফাইল মুছে দেয় */
  fun cleanupOldDownloads(context: Context) {
    runCatching {
      File(context.cacheDir, "updates").listFiles()?.forEach { f ->
        val code = downloadNameRegex.find(f.name)?.groupValues?.get(1)?.toIntOrNull()
        if (code == null || code <= BuildConfig.VERSION_CODE || f.name.endsWith(".part")) f.delete()
      }
    }
  }

  private suspend fun download(
    context: Context,
    info: UpdateInfo,
    onProgress: (Float) -> Unit,
  ): Result<File> = withContext(Dispatchers.IO) {
    try {
      Result.success(downloadBlocking(context, info, onProgress))
    } catch (e: CancellationException) {
      throw e
    } catch (e: IOException) {
      Result.failure<File>(IllegalStateException("ডাউনলোড ব্যর্থ। ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন", e))
    } catch (e: Exception) {
      Result.failure<File>(e)
    }
  }

  private fun downloadBlocking(context: Context, info: UpdateInfo, onProgress: (Float) -> Unit): File {
    val dir = File(context.cacheDir, "updates").apply { mkdirs() }
    val file = File(dir, "araaf-update-${info.versionCode}.apk")

    // আগে পুরোটা নামানো ও ঠিক থাকলে (যেমন অনুমতি দিতে সেটিংসে গিয়ে ফিরলে) আবার নামানো হবে না
    val sizeOk = info.sizeBytes <= 0 || file.length() == info.sizeBytes
    if (file.exists() && sizeOk && apkProblem(context, file) == null) {
      onProgress(1f)
      return file
    }

    dir.listFiles()?.forEach { it.delete() }
    val part = File(dir, "${file.name}.part")
    val request = Request.Builder().url(info.downloadUrl).header("User-Agent", USER_AGENT).build()
    client.newCall(request).execute().use { resp ->
      if (!resp.isSuccessful) error("ডাউনলোড ব্যর্থ (${resp.code})")
      val body = resp.body ?: error("খালি ফাইল")
      val total = if (body.contentLength() > 0) body.contentLength() else info.sizeBytes
      body.byteStream().use { input ->
        part.outputStream().use { out ->
          val buf = ByteArray(64 * 1024)
          var read = 0L
          var lastPercent = -1
          while (true) {
            val n = input.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
            read += n
            if (total > 0) {
              val percent = (read * 100 / total).toInt()
              if (percent != lastPercent) {
                lastPercent = percent
                onProgress((read.toFloat() / total).coerceIn(0f, 1f))
              }
            }
          }
        }
      }
    }
    if (info.sizeBytes > 0 && part.length() != info.sizeBytes) {
      part.delete()
      error("ডাউনলোড অসম্পূর্ণ; আবার চেষ্টা করুন")
    }
    if (!part.renameTo(file)) {
      part.delete()
      error("ডাউনলোড করা ফাইল সংরক্ষণ করা যায়নি")
    }
    apkProblem(context, file)?.let {
      file.delete()
      error(it)
    }
    return file
  }

  /**
   * ডাউনলোড করা APK-তে স্পষ্ট সমস্যা থাকলে বার্তা, ঠিক থাকলে null।
   * APK পড়া না গেলে আটকানো হয় না (ইনস্টলারই জানাবে), যাতে ভুল করে আপডেট বন্ধ না হয়।
   */
  private fun apkProblem(context: Context, file: File): String? {
    @Suppress("DEPRECATION")
    val pkg = context.packageManager.getPackageArchiveInfo(file.absolutePath, 0) ?: return null
    if (pkg.packageName != context.packageName) return "এই APK অন্য অ্যাপের; ইনস্টল করা হয়নি"
    val code = PackageInfoCompat.getLongVersionCode(pkg)
    if (code <= BuildConfig.VERSION_CODE) {
      return "ডাউনলোড করা APK-র বিল্ড ($code) বর্তমান বিল্ডের (${BuildConfig.VERSION_CODE}) চেয়ে নতুন নয়"
    }
    return null
  }

  private fun install(context: Context, file: File): UpdateOutcome {
    if (!hasInstallPermission(context)) return openInstallPermissionSettings(context)
    return try {
      val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
      context.startActivity(
        Intent(Intent.ACTION_VIEW)
          .setDataAndType(uri, APK_MIME)
          .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
      )
      UpdateOutcome.Started
    } catch (e: Exception) {
      UpdateOutcome.Failed(e.message ?: "ইনস্টলার খোলা যায়নি")
    }
  }
}
