package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.billing.FormatUtils
import com.example.domain.model.CustomerFinancialSummary

/**
 * নোট/মন্তব্যের ঘরে যে কাস্টমারের নাম লেখা থাকবে, তার সব হিসাব একসাথে দেখায়।
 * একাধিক নাম লেখা থাকলে প্রত্যেকের হিসাব আলাদা কার্ডে আসে।
 */
fun findCustomersMentionedInNote(
  note: String,
  summaries: List<CustomerFinancialSummary>,
): List<CustomerFinancialSummary> {
  val text = note.trim()
  if (text.length < 2) return emptyList()
  return summaries.filter { s ->
    val name = s.customer.fullName.trim()
    name.length >= 2 && text.contains(name, ignoreCase = true)
  }
}

@Composable
fun NoteNameHisabSection(
  note: String,
  summaries: List<CustomerFinancialSummary>,
  currencySymbol: String = "৳",
  modifier: Modifier = Modifier,
) {
  val matches = remember(note, summaries) { findCustomersMentionedInNote(note, summaries) }
  if (matches.isEmpty()) return
  Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    matches.forEach { s -> NoteNameHisabCard(s, currencySymbol) }
  }
}

@Composable
private fun HisabRow(label: String, value: String, bold: Boolean = false) {
  Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
    Text(
      label,
      style = MaterialTheme.typography.bodySmall,
      fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
      modifier = Modifier.weight(1f),
    )
    Text(
      value,
      style = MaterialTheme.typography.bodySmall,
      fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium,
    )
  }
}

@Composable
private fun NoteNameHisabCard(s: CustomerFinancialSummary, cs: String) {
  Surface(
    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
    shape = MaterialTheme.shapes.small,
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
      Text(
        "${s.customer.fullName} এর সব হিসাব",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
      )
      if (s.customer.mobileNumber.isNotBlank()) {
        Text(s.customer.mobileNumber, style = MaterialTheme.typography.bodySmall)
      }
      HisabRow("আগের বকেয়া", FormatUtils.formatTaka(s.openingBalance, cs))
      HisabRow("মোট বিল (কাজ)", FormatUtils.formatTaka(s.totalBilled, cs))
      if (s.totalAdditionalCharges > 0.0) {
        HisabRow("অতিরিক্ত চার্জ", FormatUtils.formatTaka(s.totalAdditionalCharges, cs))
      }
      if (s.totalDiscounts > 0.0) {
        HisabRow("ছাড়", FormatUtils.formatTaka(s.totalDiscounts, cs))
      }
      HisabRow("মোট জমা/পেমেন্ট", FormatUtils.formatTaka(s.totalPaid, cs))
      if (s.totalAdvanceReceived > 0.0 || s.remainingAdvance > 0.0) {
        HisabRow("অগ্রিম নেওয়া", FormatUtils.formatTaka(s.totalAdvanceReceived, cs))
        HisabRow("অগ্রিম ব্যবহার", FormatUtils.formatTaka(s.totalAdvanceUsed, cs))
        HisabRow("অবশিষ্ট অগ্রিম", FormatUtils.formatTaka(s.remainingAdvance, cs))
      }
      HisabRow("মোট বকেয়া", FormatUtils.formatTaka(s.totalOutstandingBalance, cs), bold = true)

      if (s.lands.isNotEmpty()) {
        Text(
          "জমি অনুযায়ী (${s.lands.size}টি)",
          style = MaterialTheme.typography.labelMedium,
          fontWeight = FontWeight.SemiBold,
          modifier = Modifier.padding(top = 4.dp),
        )
        s.lands.forEach { ls ->
          HisabRow(
            "${ls.land.landName} • বিল ${FormatUtils.formatTaka(ls.workCharges, cs)} • জমা ${FormatUtils.formatTaka(ls.payments, cs)}",
            "বাকি ${FormatUtils.formatTaka(ls.currentBalance, cs)}",
          )
        }
      }
      Text(
        "কাজ: ${s.jobs.size}টি • পেমেন্ট: ${s.payments.size}টি",
        style = MaterialTheme.typography.bodySmall,
      )

      val txs = s.allTransactions.filter { !it.isDeleted }.sortedByDescending { it.transactionDate }
      if (txs.isNotEmpty()) {
        var showAll by remember { mutableStateOf(false) }
        val shown = if (showAll) txs else txs.take(5)
        Text(
          "লেনদেনের তালিকা (${txs.size}টি)",
          style = MaterialTheme.typography.labelMedium,
          fontWeight = FontWeight.SemiBold,
          modifier = Modifier.padding(top = 4.dp),
        )
        shown.forEach { t ->
          val isDebit = t.debitAmount > 0.0
          val amt = if (isDebit) t.debitAmount else t.creditAmount
          HisabRow(
            "${FormatUtils.formatDate(t.transactionDate)} • ${t.description}",
            (if (isDebit) "বিল " else "জমা ") + FormatUtils.formatTaka(amt, cs),
          )
        }
        if (txs.size > 5) {
          TextButton(onClick = { showAll = !showAll }) {
            Text(if (showAll) "কম দেখান" else "সব ${txs.size}টি দেখান")
          }
        }
      }
    }
  }
}
