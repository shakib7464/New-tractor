package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.AgriculturalJobEntity
import com.example.data.local.entity.BillingMethod
import com.example.domain.billing.LastWorkTypeResolver
import com.example.data.local.entity.JobStatus
import com.example.data.local.entity.LandUnit
import com.example.data.local.entity.PaymentMethod
import com.example.data.local.entity.TractorEntity
import com.example.data.local.entity.WorkType
import com.example.data.preferences.AppSettingsState
import com.example.domain.billing.BillingCalculator
import com.example.domain.billing.FormatUtils
import com.example.domain.model.CustomerFinancialSummary
import com.example.localization.AppStrings

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddJobDialog(
  summaries: List<CustomerFinancialSummary>,
  tractors: List<TractorEntity>,
  jobs: List<AgriculturalJobEntity> = emptyList(),
  settings: AppSettingsState,
  strings: AppStrings,
  preselectedCustomerId: String? = null,
  preselectedLandId: String? = null,
  onAddNewCustomer: () -> Unit = {},
  onAddNewLand: (customerId: String) -> Unit = {},
  pendingCustomerId: String? = null,
  pendingLandId: String? = null,
  onPendingCustomerConsumed: () -> Unit = {},
  onPendingLandConsumed: () -> Unit = {},
  onDismiss: () -> Unit,
  onSaveJob: (
    customerId: String,
    landId: String,
    tractorId: String?,
    workDate: Long,
    workType: String,
    customWorkName: String,
    billingMethod: String,
    landArea: Double,
    areaUnit: String,
    rate: Double,
    workingHours: Double?,
    additionalCharges: Double,
    discount: Double,
    advanceAdjustment: Double,
    amountPaidNow: Double,
    paymentMethod: String,
    status: String,
    rotavatorWidth: String,
    workingDepth: String,
    numberOfPasses: Int?,
    startTime: String,
    finishTime: String,
    operatorName: String,
    notes: String,
  ) -> Unit,
) {
  var selectedCustomerId by remember {
    mutableStateOf(preselectedCustomerId ?: summaries.firstOrNull()?.customer?.id ?: "")
  }
  val activeSummary = summaries.firstOrNull { it.customer.id == selectedCustomerId }
  val customerLands = activeSummary?.lands.orEmpty()

  var selectedLandId by remember(selectedCustomerId) {
    mutableStateOf(
      preselectedLandId?.takeIf { id -> customerLands.any { it.land.id == id } }
        ?: customerLands.firstOrNull()?.land?.id
        ?: ""
    )
  }
  val selectedLandSummary = customerLands.firstOrNull { it.land.id == selectedLandId }
  val selectedLand = selectedLandSummary?.land

  // নতুন যোগ করা কাস্টমার/জমি তৈরি হওয়ার পর স্বয়ংক্রিয়ভাবে নির্বাচন
  LaunchedEffect(pendingCustomerId, summaries) {
    val p = pendingCustomerId
    if (p != null && summaries.any { it.customer.id == p }) {
      selectedCustomerId = p
      onPendingCustomerConsumed()
    }
  }
  LaunchedEffect(pendingLandId, customerLands) {
    val p = pendingLandId
    if (p != null && customerLands.any { it.land.id == p }) {
      selectedLandId = p
      onPendingLandConsumed()
    }
  }

  var selectedTractorId by remember {
    mutableStateOf(tractors.firstOrNull { it.isActive }?.id ?: tractors.firstOrNull()?.id)
  }
  var workDateText by remember { mutableStateOf(FormatUtils.formatDate(System.currentTimeMillis())) }
  // কাজের ধরন: এই জমির (না থাকলে এই কাস্টমারের) আগের কাজের ধরনই নিজে থেকে বসে; চাইলে বদলানো যায়
  var workType by remember(selectedCustomerId, selectedLandId) {
    mutableStateOf(
      LastWorkTypeResolver.resolve(jobs, selectedCustomerId, selectedLandId)?.workType
        ?: WorkType.ROTAVATOR.code
    )
  }
  var customWorkName by remember(selectedCustomerId, selectedLandId) {
    mutableStateOf(LastWorkTypeResolver.resolve(jobs, selectedCustomerId, selectedLandId)?.customWorkName.orEmpty())
  }
  var billingMethod by remember(selectedLand?.id) {
    val defaultMethod = BillingMethod.PER_KATHA.code
    mutableStateOf(defaultMethod)
  }

  fun defaultRateForMethod(method: String): Double {
    val custCustom = activeSummary?.customer?.customRatePerUnit
    if (custCustom != null && custCustom > 0) return custCustom
    return when (method) {
      BillingMethod.PER_KATHA.code -> settings.defaultRatePerDecimal * 1.65
      BillingMethod.PER_DECIMAL.code -> settings.defaultRatePerDecimal
      BillingMethod.PER_BIGHA.code -> settings.defaultRatePerBigha
      BillingMethod.PER_ACRE.code -> settings.defaultRatePerAcre
      BillingMethod.PER_HOUR.code -> settings.defaultRatePerHour
      else -> 0.0
    }
  }

  var areaText by remember(selectedLand?.id) {
    val oldUnit = LandUnit.entries.firstOrNull { it.code == selectedLand?.unit } ?: LandUnit.KATHA
    mutableStateOf(selectedLand?.let { BillingCalculator.convertArea(it.sizeValue, oldUnit, LandUnit.KATHA).toString() } ?: "0")
  }
  var rateText by remember(selectedCustomerId, billingMethod) {
    mutableStateOf(defaultRateForMethod(billingMethod).toString())
  }
  var hoursText by remember { mutableStateOf("") }
  var additionalText by remember { mutableStateOf("0") }
  var discountText by remember { mutableStateOf("0") }
  var advanceAdjText by remember { mutableStateOf("0") }
  var paidNowText by remember { mutableStateOf("0") }
  var payMethod by remember { mutableStateOf(PaymentMethod.CASH.code) }
  var jobStatus by remember { mutableStateOf(JobStatus.COMPLETED.code) }

  var showOptionalFields by remember { mutableStateOf(false) }
  var rotavatorWidth by remember { mutableStateOf("") }
  var workingDepth by remember { mutableStateOf("") }
  var passesText by remember { mutableStateOf("1") }
  var startTime by remember { mutableStateOf("") }
  var finishTime by remember { mutableStateOf("") }
  var operatorName by remember { mutableStateOf("") }
  var notes by remember { mutableStateOf("") }
  var errorMsg by remember { mutableStateOf<String?>(null) }

  var custExpanded by remember { mutableStateOf(false) }
  var landExpanded by remember { mutableStateOf(false) }
  var tractorExpanded by remember { mutableStateOf(false) }

  val calc = BillingCalculator.calculateJobBill(
    billingMethodCode = billingMethod,
    landArea = (areaText.toDoubleOrNull() ?: 0.0) * (passesText.toIntOrNull()?.coerceAtLeast(1) ?: 1),
    rate = rateText.toDoubleOrNull() ?: 0.0,
    workingHours = hoursText.toDoubleOrNull(),
    additionalCharges = additionalText.toDoubleOrNull() ?: 0.0,
    discount = discountText.toDoubleOrNull() ?: 0.0,
    advanceAdjustment = 0.0,
    amountPaid = paidNowText.toDoubleOrNull() ?: 0.0,
  )

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(strings.addJob) },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Text(
          strings.repeatWorkHint,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        // Customer picker
        ExposedDropdownMenuBox(expanded = custExpanded, onExpandedChange = { custExpanded = !custExpanded }) {
          OutlinedTextField(
            value = activeSummary?.customer?.fullName ?: "কাস্টমার নির্বাচন করুন",
            onValueChange = {},
            readOnly = true,
            label = { Text(strings.navCustomers) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(custExpanded) },
            modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
          )
          ExposedDropdownMenu(expanded = custExpanded, onDismissRequest = { custExpanded = false }) {
            DropdownMenuItem(
              text = { Text(strings.addNewCustomerOption, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) },
              onClick = { custExpanded = false; onAddNewCustomer() },
            )
            if (summaries.isNotEmpty()) HorizontalDivider()
            summaries.forEach { s ->
              DropdownMenuItem(
                text = { Text(if (s.customer.mobileNumber.isBlank()) s.customer.fullName else "${s.customer.fullName} (${s.customer.mobileNumber})") },
                onClick = { selectedCustomerId = s.customer.id; custExpanded = false },
              )
            }
          }
        }

        // Land picker
        ExposedDropdownMenuBox(expanded = landExpanded, onExpandedChange = { landExpanded = !landExpanded }) {
          OutlinedTextField(
            value = selectedLand?.let { "${it.landName} (${FormatUtils.formatNumber(it.sizeValue)} ${strings.unitLabel(it.unit)})" }
              ?: "আগে এই কাস্টমারের জমি যোগ করুন",
            onValueChange = {},
            readOnly = true,
            label = { Text(strings.landName) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(landExpanded) },
            modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
          )
          ExposedDropdownMenu(expanded = landExpanded, onDismissRequest = { landExpanded = false }) {
            if (selectedCustomerId.isNotBlank()) {
              DropdownMenuItem(
                text = { Text(strings.addNewLandOption, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) },
                onClick = { landExpanded = false; onAddNewLand(selectedCustomerId) },
              )
              if (customerLands.isNotEmpty()) HorizontalDivider()
            }
            customerLands.forEach { ls ->
              DropdownMenuItem(
                text = { Text("${ls.land.landName} (${FormatUtils.formatNumber(ls.land.sizeValue)} ${strings.unitLabel(ls.land.unit)})") },
                onClick = { selectedLandId = ls.land.id; landExpanded = false },
              )
            }
          }
        }

        // Tractor & Date
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = workDateText,
            onValueChange = { workDateText = it },
            label = { Text(strings.workDate) },
            singleLine = true,
            modifier = Modifier.weight(1f),
          )
          ExposedDropdownMenuBox(
            expanded = tractorExpanded,
            onExpandedChange = { tractorExpanded = !tractorExpanded },
            modifier = Modifier.weight(1f),
          ) {
            val tName = tractors.firstOrNull { it.id == selectedTractorId }?.name ?: "-"
            OutlinedTextField(
              value = tName,
              onValueChange = {},
              readOnly = true,
              label = { Text(strings.tractorLabel) },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(tractorExpanded) },
              modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
            )
            ExposedDropdownMenu(expanded = tractorExpanded, onDismissRequest = { tractorExpanded = false }) {
              tractors.filter { it.isActive }.forEach { t ->
                DropdownMenuItem(
                  text = { Text(t.name) },
                  onClick = { selectedTractorId = t.id; tractorExpanded = false },
                )
              }
            }
          }
        }

        // Work Type
        Text(strings.workType, style = MaterialTheme.typography.labelMedium)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          WorkType.entries.forEach { wt ->
            FilterChip(
              selected = workType == wt.code,
              onClick = { workType = wt.code },
              label = { Text(strings.workTypeLabel(wt.code)) },
            )
          }
        }
        if (workType == WorkType.CUSTOM.code) {
          OutlinedTextField(
            value = customWorkName,
            onValueChange = { customWorkName = it },
            label = { Text(strings.customWorkName) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
        }

        // Billing Method
        Text(strings.billingMethod, style = MaterialTheme.typography.labelMedium)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          (listOf(BillingMethod.PER_KATHA, BillingMethod.PER_HOUR, BillingMethod.FIXED_AMOUNT, BillingMethod.CUSTOM_AMOUNT)).forEach { bm ->
            FilterChip(
              selected = billingMethod == bm.code,
              onClick = { billingMethod = bm.code },
              label = { Text(strings.billingMethodLabel(bm.code)) },
            )
          }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          if (billingMethod == BillingMethod.PER_HOUR.code) {
            OutlinedTextField(
              value = hoursText,
              onValueChange = { hoursText = it },
              label = { Text(strings.workingHours) },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              singleLine = true,
              modifier = Modifier.weight(1f),
            )
          } else {
            OutlinedTextField(
              value = areaText,
              onValueChange = { areaText = it },
              label = { Text(strings.landArea) },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              singleLine = true,
              modifier = Modifier.weight(1f).testTag("job_area_input"),
            )
          }
          if (billingMethod != BillingMethod.PER_HOUR.code) {
            OutlinedTextField(
              value = passesText,
              onValueChange = { passesText = it },
              label = { Text("চাষ (বার)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              singleLine = true,
              modifier = Modifier.weight(1f),
            )
          }
        }
        OutlinedTextField(
          value = rateText,
          onValueChange = { rateText = it },
          label = {
            Text(
              if (billingMethod == BillingMethod.FIXED_AMOUNT.code || billingMethod == BillingMethod.CUSTOM_AMOUNT.code)
                strings.totalBill else "দর (প্রতি কাঠা)"
            )
          },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("job_rate_input"),
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = additionalText,
            onValueChange = { additionalText = it },
            label = { Text(strings.additionalCharges) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.weight(1f).testTag("job_additional_input"),
          )
          OutlinedTextField(
            value = discountText,
            onValueChange = { discountText = it },
            label = { Text(strings.discount) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.weight(1f).testTag("job_discount_input"),
          )
        }

        OutlinedTextField(
          value = paidNowText,
          onValueChange = { paidNowText = it },
          label = { Text(strings.amountPaidNow) },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("job_paid_input"),
        )

        // Live Bill Preview Box
        Surface(
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
          shape = MaterialTheme.shapes.small,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            val baseArea = areaText.toDoubleOrNull() ?: 0.0
            val passCount = passesText.toIntOrNull()?.coerceAtLeast(1) ?: 1
            val workedArea = baseArea * passCount
            Text("${FormatUtils.formatNumber(baseArea)} কাঠা × $passCount = ${FormatUtils.formatNumber(workedArea)} কাঠা", style = MaterialTheme.typography.bodyMedium)
            Text("${FormatUtils.formatNumber(workedArea)} × ${FormatUtils.formatNumber(rateText.toDoubleOrNull() ?: 0.0)} টাকা = ${FormatUtils.formatTaka(calc.baseBill, settings.currencySymbol)}", style = MaterialTheme.typography.bodyMedium)
            val previousDue = (selectedLandSummary?.currentBalance ?: 0.0).coerceAtLeast(0.0)
            Text("আগের বকেয়া: ${FormatUtils.formatTaka(previousDue, settings.currencySymbol)}", style = MaterialTheme.typography.bodySmall)
            Text(
              "${strings.totalBill}: ${FormatUtils.formatTaka(calc.totalBill, settings.currencySymbol)}",
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.Bold,
            )
            Text("আগের বকেয়াসহ মোট: ${FormatUtils.formatTaka(previousDue + calc.totalBill, settings.currencySymbol)}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text(
              "জমা দেওয়ার পর মোট বকেয়া: ${FormatUtils.formatTaka(previousDue + calc.remainingDue, settings.currencySymbol)}",
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.SemiBold,
            )
          }
        }

        // Status chips
        Text(strings.jobStatus, style = MaterialTheme.typography.labelMedium)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          JobStatus.entries.forEach { st ->
            FilterChip(
              selected = jobStatus == st.code,
              onClick = { jobStatus = st.code },
              label = { Text(strings.jobStatusLabel(st.code)) },
            )
          }
        }

        // Optional technical details toggle
        OutlinedButton(
          onClick = { showOptionalFields = !showOptionalFields },
          modifier = Modifier.fillMaxWidth(),
        ) {
          Text(if (showOptionalFields) "ঐচ্ছিক তথ্য লুকান" else "ঐচ্ছিক তথ্য (রোটাভেটর প্রস্থ, গভীরতা, সময়, অপারেটর)")
        }

        if (showOptionalFields) {
          HorizontalDivider()
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = rotavatorWidth,
              onValueChange = { rotavatorWidth = it },
              label = { Text(strings.rotavatorWidth) },
              modifier = Modifier.weight(1f),
            )
            OutlinedTextField(
              value = workingDepth,
              onValueChange = { workingDepth = it },
              label = { Text(strings.workingDepth) },
              modifier = Modifier.weight(1f),
            )
          }
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = operatorName,
              onValueChange = { operatorName = it },
              label = { Text(strings.operatorName) },
              modifier = Modifier.weight(1f),
            )
          }
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = startTime,
              onValueChange = { startTime = it },
              label = { Text(strings.startTime) },
              modifier = Modifier.weight(1f),
            )
            OutlinedTextField(
              value = finishTime,
              onValueChange = { finishTime = it },
              label = { Text(strings.finishTime) },
              modifier = Modifier.weight(1f),
            )
          }
        }

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("পেমেন্ট গ্রহণকারীর নাম") },
          modifier = Modifier.fillMaxWidth(),
        )

        if (errorMsg != null) {
          Text(errorMsg!!, color = MaterialTheme.colorScheme.error)
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (selectedCustomerId.isBlank() || selectedLandId.isBlank()) {
            errorMsg = "কাস্টমার এবং জমি নির্বাচন করুন"
            return@Button
          }
          val parsedDate = FormatUtils.parseDmyDate(workDateText) ?: System.currentTimeMillis()
          val nowCalendar = java.util.Calendar.getInstance()
          val dateCalendar = java.util.Calendar.getInstance().apply { timeInMillis = parsedDate }
          dateCalendar.set(java.util.Calendar.HOUR_OF_DAY, nowCalendar.get(java.util.Calendar.HOUR_OF_DAY))
          dateCalendar.set(java.util.Calendar.MINUTE, nowCalendar.get(java.util.Calendar.MINUTE))
          dateCalendar.set(java.util.Calendar.SECOND, nowCalendar.get(java.util.Calendar.SECOND))
          val dateMs = dateCalendar.timeInMillis
          onSaveJob(
            selectedCustomerId,
            selectedLandId,
            selectedTractorId,
            dateMs,
            workType,
            customWorkName,
            billingMethod,
            areaText.toDoubleOrNull() ?: 0.0,
            LandUnit.KATHA.code,
            rateText.toDoubleOrNull() ?: 0.0,
            hoursText.toDoubleOrNull(),
            additionalText.toDoubleOrNull() ?: 0.0,
            discountText.toDoubleOrNull() ?: 0.0,
            0.0,
            paidNowText.toDoubleOrNull() ?: 0.0,
            payMethod,
            jobStatus,
            rotavatorWidth,
            workingDepth,
            passesText.toIntOrNull(),
            startTime,
            finishTime,
            operatorName,
            notes,
          )
        },
        modifier = Modifier.height(48.dp).testTag("save_job_btn"),
      ) {
        Text(strings.save)
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss, modifier = Modifier.height(48.dp)) {
        Text(strings.cancel)
      }
    },
  )
}
