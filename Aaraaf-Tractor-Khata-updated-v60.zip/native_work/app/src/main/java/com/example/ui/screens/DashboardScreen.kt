package com.example.ui.screens

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.LocalGasStation
import androidx.compose.material.icons.rounded.AddBusiness
import androidx.compose.material.icons.rounded.AddTask
import androidx.compose.material.icons.rounded.Agriculture
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Engineering
import androidx.compose.material.icons.rounded.Landscape
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.PendingActions
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Savings
import androidx.compose.material.icons.rounded.Today
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.billing.FormatUtils
import com.example.domain.model.DashboardSummary
import com.example.localization.AppStrings
import com.example.ui.components.BrandLogo
import com.example.ui.components.BulkPrintProminentCard
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.MetricStatCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.LocalLedgerColors
import com.example.ui.theme.AppTitleFont
import com.example.ui.theme.BengaliDisplayFont
import com.example.ui.theme.SignatureLabelFont
import com.example.ui.theme.SignatureNameFont

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
  summary: DashboardSummary,
  strings: AppStrings,
  currencySymbol: String,
  onAddCustomer: () -> Unit,
  onAddLand: () -> Unit,
  onAddJob: () -> Unit,
  onReceivePayment: () -> Unit,
  onOpenPayments: () -> Unit,
  onViewOutstandingDues: () -> Unit,
  onViewReports: () -> Unit,
  onOneClickBulkPrint: () -> Unit,
  onConfigureBulkPrint: () -> Unit,
  onOpenFuel: () -> Unit,
  modifier: Modifier = Modifier,
  onOpenHelperDriver: () -> Unit = {},
  onOpenTractorOwner: () -> Unit = {},
  onOpenBills: () -> Unit = {},
  onOpenCollected: () -> Unit = {},
  onOpenDues: () -> Unit = onViewOutstandingDues,
  profileName: String = "",
  onOpenTodaysWork: () -> Unit = {},
  onOpenTodaysCollection: () -> Unit = {},
) {
  val ledgerColors = LocalLedgerColors.current
  var showLogoPreview by remember { mutableStateOf(false) }

  if (showLogoPreview) {
    Dialog(onDismissRequest = { showLogoPreview = false }) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .aspectRatio(16f / 9f)
          .clip(RoundedCornerShape(20.dp))
          .background(Brush.linearGradient(listOf(Color(0xFF0D281D), Color(0xFF1B4332), Color(0xFF40916C))))
          .clickable { showLogoPreview = false },
        contentAlignment = Alignment.Center,
      ) {
        Image(
          painter = painterResource(id = R.drawable.aaraaf_brand_logo),
          contentDescription = strings.appName,
          contentScale = ContentScale.Fit,
          modifier = Modifier.fillMaxSize().padding(10.dp),
        )
      }
    }
  }

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 24.dp),
    verticalArrangement = Arrangement.spacedBy(18.dp),
  ) {
    // Hero Brand Banner
    item {
      Card(
        shape = RoundedCornerShape(28.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Box(modifier = Modifier.height(188.dp).fillMaxWidth()) {
          Image(
            painter = painterResource(id = R.drawable.img_tractor_banner),
            contentDescription = strings.appName,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
          )
          Box(
            modifier = Modifier
              .fillMaxSize()
              .background(
                Brush.verticalGradient(
                  colors = listOf(
                    Color(0x550D281D),
                    Color(0x991B4332),
                  )
                )
              )
              .padding(18.dp)
          ) {
            // বিসমিল্লাহ: এখন ব্যানারের ভিতরে, উপরের মাঝে
            Text(
              text = "বিসমিল্লাহির রাহমানির রাহীম",
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.SemiBold,
              letterSpacing = 0.5.sp,
              color = Color.White.copy(alpha = 0.92f),
              textAlign = TextAlign.Center,
              modifier = Modifier.align(Alignment.TopCenter),
            )

            // বাম উপরে: তারিখ, তার নিচে অ্যাকাউন্ট (প্রোফাইল) নাম
            Column(
              verticalArrangement = Arrangement.spacedBy(6.dp),
              modifier = Modifier.align(Alignment.TopStart).padding(top = 26.dp),
            ) {
              Surface(
                shape = RoundedCornerShape(50),
                color = Color.White.copy(alpha = 0.16f),
              ) {
                Text(
                  text = remember { FormatUtils.formatDate(System.currentTimeMillis(), "EEE, d MMM yyyy") },
                  style = MaterialTheme.typography.labelMedium,
                  color = Color.White,
                  maxLines = 1,
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                )
              }
              if (profileName.isNotBlank()) {
                Surface(
                  shape = RoundedCornerShape(50),
                  color = Color(0xFFFDE68A).copy(alpha = 0.22f),
                ) {
                  Text(
                    text = profileName,
                    style = MaterialTheme.typography.labelMedium,
                    color = Color(0xFFFDE68A),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                      .widthIn(max = 150.dp)
                      .padding(horizontal = 12.dp, vertical = 5.dp),
                  )
                }
              }
            }

            // ডানে উপরে: লোগো, তার নিচে ছোট "Developed by Shakib Ahmed"
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier.align(Alignment.CenterEnd).padding(bottom = 16.dp),
            ) {
              BrandLogo(
                size = 96.dp,
                contentDescription = strings.appName,
                modifier = Modifier.clickable(
                  interactionSource = remember { MutableInteractionSource() },
                  indication = null,
                ) { showLogoPreview = true },
              )
              Spacer(Modifier.height(2.dp))
              Text(
                text = "Developed by",
                style = TextStyle(
                  fontFamily = SignatureLabelFont,
                  fontSize = 7.5.sp,
                  letterSpacing = 0.5.sp,
                  color = Color.White.copy(alpha = 0.75f),
                ),
              )
              Text(
                text = "Shakib Ahmed",
                style = TextStyle(
                  fontFamily = SignatureNameFont,
                  fontStyle = FontStyle.Italic,
                  fontWeight = FontWeight.SemiBold,
                  fontSize = 11.sp,
                  letterSpacing = 0.6.sp,
                  brush = Brush.horizontalGradient(
                    listOf(Color(0xFFFDE68A), Color(0xFFF59E0B), Color(0xFFFFF3C4)),
                  ),
                  shadow = Shadow(
                    color = Color.Black.copy(alpha = 0.45f),
                    offset = Offset(1.2f, 1.6f),
                    blurRadius = 3f,
                  ),
                ),
              )
              // ডেভেলপারের নম্বর — নামের নিচে আরও ছোট করে
              Text(
                text = "01781707294",
                style = TextStyle(
                  fontFamily = SignatureLabelFont,
                  fontWeight = FontWeight.Bold,
                  fontSize = 10.sp,
                  letterSpacing = 0.6.sp,
                  color = Color(0xFFFDE68A),
                  shadow = Shadow(color = Color.Black.copy(alpha = 0.5f), offset = Offset(1f, 1.2f), blurRadius = 2f),
                ),
              )
            }

            // বাম নিচে: অ্যাপের নাম (সুন্দর ফন্টে) ও সাবটাইটেল
            Column(
              modifier = Modifier.align(Alignment.BottomStart),
              verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
              Text(
                text = strings.appName,
                style = TextStyle(
                  fontFamily = if (strings.appName == "Tractor Khata") AppTitleFont else BengaliDisplayFont,
                  fontStyle = if (strings.appName == "Tractor Khata") FontStyle.Italic else FontStyle.Normal,
                  fontWeight = FontWeight.Bold,
                  fontSize = 32.sp,
                  letterSpacing = 0.4.sp,
                  color = Color.White,
                  shadow = Shadow(
                    color = Color.Black.copy(alpha = 0.5f),
                    offset = Offset(1.5f, 2f),
                    blurRadius = 5f,
                  ),
                ),
              )
              Text(
                text = strings.dashboardSubtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFFDE68A),
              )
            }
          }
        }
      }
    }

    // Quick Access Actions
    item {
      SectionHeader(title = strings.quickActions)
      Spacer(Modifier.height(8.dp))
      val actions = listOf(
        QuickTile(
          strings.addCustomer, "নতুন কাস্টমার নিবন্ধন", Icons.Rounded.PersonAdd, "quick_add_customer",
          Color(0xFF1B4332), Color(0xFF40916C), onAddCustomer,
        ),
        QuickTile(
          strings.addLand, "জমির কাজ ও বিল যোগ", Icons.Rounded.AddBusiness, "quick_add_land",
          Color(0xFFB45309), Color(0xFFF59E0B), onAddLand,
        ),
        QuickTile(
          strings.receivePayment, "নগদ / বিকাশ জমা নিন", Icons.Rounded.Payments, "quick_receive_payment",
          Color(0xFF0F766E), Color(0xFF2DD4BF), onReceivePayment,
        ),
        QuickTile(
          strings.printStatements, "সবার হিসাব PDF", Icons.Rounded.Print, "quick_print_statements",
          Color(0xFF4338CA), Color(0xFF818CF8), onConfigureBulkPrint,
        ),
        QuickTile(
          "বেতন", "কর্মীদের বেতন ও পরিশোধের হিসাব", Icons.Rounded.Engineering, "quick_helper_driver",
          Color(0xFFBE185D), Color(0xFFF472B6), onOpenHelperDriver,
        ),
        QuickTile(
          "গাড়ির মালিক", "মালিককে কত টাকা, কবে দিলেন", Icons.Rounded.Agriculture, "quick_tractor_owner",
          Color(0xFF0369A1), Color(0xFF38BDF8), onOpenTractorOwner,
        ),
      )
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        actions.chunked(2).forEach { rowActions ->
          Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            rowActions.forEach { tile ->
              QuickActionTile(tile = tile, modifier = Modifier.weight(1f))
            }
          }
        }
      }
    }

    // Fuel account highlight card
    item {
      Surface(
        onClick = onOpenFuel,
        shape = RoundedCornerShape(22.dp),
        color = Color.Transparent,
        shadowElevation = 5.dp,
        modifier = Modifier.fillMaxWidth().animateContentSize().testTag("dashboard_fuel_btn"),
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .background(Brush.linearGradient(listOf(Color(0xFF123B32), Color(0xFF167D78), Color(0xFF36A89A))))
            .drawBehind {
              drawCircle(
                Color.White.copy(alpha = 0.10f),
                radius = 42.dp.toPx(),
                center = androidx.compose.ui.geometry.Offset(size.width - 42.dp.toPx(), 42.dp.toPx()),
              )
            }
            .padding(horizontal = 18.dp, vertical = 16.dp),
        ) {
          Surface(
            shape = CircleShape,
            color = Color.White.copy(alpha = 0.22f),
            modifier = Modifier.size(46.dp),
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                Icons.Rounded.LocalGasStation,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(26.dp),
              )
            }
          }
          Spacer(Modifier.width(14.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              "তেলের হিসাব",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = Color.White,
            )
            Text(
              "ডিজেল কেনা ও খরচের হিসাব দেখুন",
              style = MaterialTheme.typography.bodySmall,
              color = Color.White.copy(alpha = 0.78f),
            )
          }
          Icon(
            Icons.Rounded.ChevronRight,
            contentDescription = null,
            tint = Color.White,
          )
        }
      }
    }


    // Financial summary
    item {
      SectionHeader(title = "আর্থিক সারসংক্ষেপ")
      Spacer(Modifier.height(10.dp))
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
          horizontalArrangement = Arrangement.spacedBy(12.dp),
          modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
        ) {
          MetricStatCard(
            title = strings.totalBilled,
            value = FormatUtils.formatTaka(summary.totalBilledAmount, currencySymbol),
            icon = Icons.Rounded.ReceiptLong,
            accentColor = MaterialTheme.colorScheme.primary,
            onClick = onOpenBills,
            gradientStart = Color(0xFF344B78),
            gradientEnd = Color(0xFF587FC0),
            modifier = Modifier.weight(1f).fillMaxHeight(),
          )
          MetricStatCard(
            title = strings.totalCollected,
            value = FormatUtils.formatTaka(summary.totalCollectedAmount, currencySymbol),
            icon = Icons.Rounded.AccountBalanceWallet,
            accentColor = ledgerColors.paidColor,
            onClick = onOpenCollected,
            gradientStart = Color(0xFF087F5B),
            gradientEnd = Color(0xFF36B58A),
            modifier = Modifier.weight(1f).fillMaxHeight(),
          )
        }
        MetricStatCard(
          title = strings.totalOutstanding,
          value = FormatUtils.formatTaka(summary.totalOutstandingAmount, currencySymbol),
          icon = Icons.Rounded.WarningAmber,
          accentColor = ledgerColors.dueColor,
          onClick = onOpenDues,
          gradientStart = Color(0xFF9F3A38),
          gradientEnd = Color(0xFFE47769),
          modifier = Modifier.fillMaxWidth(),
        )
      }
    }

    // Today
    item {
      SectionHeader(title = "আজকের হিসাব")
      Spacer(Modifier.height(10.dp))
      Row(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
      ) {
        MetricStatCard(
          title = strings.todaysWork,
          value = "${summary.todaysJobCount} টি",
          subtitle = FormatUtils.formatTaka(summary.todaysBilledAmount, currencySymbol),
          icon = Icons.Rounded.Today,
          accentColor = MaterialTheme.colorScheme.secondary,
          onClick = onOpenTodaysWork,
          gradientStart = Color(0xFF334155),
          gradientEnd = Color(0xFF64748B),
          modifier = Modifier.weight(1f).fillMaxHeight(),
        )
        MetricStatCard(
          title = strings.todaysCollection,
          value = FormatUtils.formatTaka(summary.todaysCollectionAmount, currencySymbol),
          icon = Icons.Rounded.Payments,
          accentColor = ledgerColors.paidColor,
          onClick = onOpenTodaysCollection,
          gradientStart = Color(0xFF0E7490),
          gradientEnd = Color(0xFF22D3EE),
          modifier = Modifier.weight(1f).fillMaxHeight(),
        )
      }
    }

    item { Spacer(Modifier.height(16.dp)) }
  }
}

@Composable
private fun QuickActionChipCard(
  label: String,
  icon: ImageVector,
  tag: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  FilledTonalButton(
    onClick = onClick,
    modifier = modifier
      .height(52.dp)
      .testTag(tag),
    shape = RoundedCornerShape(50),
    contentPadding = PaddingValues(horizontal = 18.dp),
  ) {
    Icon(icon, contentDescription = label, modifier = Modifier.size(18.dp))
    Spacer(Modifier.width(8.dp))
    Text(label, style = MaterialTheme.typography.labelLarge, maxLines = 1)
  }
}

private data class QuickTile(
  val label: String,
  val subtitle: String,
  val icon: ImageVector,
  val tag: String,
  val colorStart: Color,
  val colorEnd: Color,
  val onClick: () -> Unit,
)

@Composable
private fun QuickActionTile(tile: QuickTile, modifier: Modifier = Modifier) {
  val interactionSource = remember { MutableInteractionSource() }
  val pressed by interactionSource.collectIsPressedAsState()
  val pressScale by animateFloatAsState(
    targetValue = if (pressed) 0.975f else 1f,
    label = "quick_action_press",
  )
  Surface(
    onClick = tile.onClick,
    interactionSource = interactionSource,
    shape = RoundedCornerShape(24.dp),
    color = Color.Transparent,
    shadowElevation = if (pressed) 2.dp else 5.dp,
    modifier = modifier
      .height(116.dp)
      .graphicsLayer { scaleX = pressScale; scaleY = pressScale }
      .animateContentSize()
      .testTag(tile.tag),
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(Brush.linearGradient(listOf(tile.colorStart, tile.colorEnd))),
    ) {
      // নরম glass-orb decoration, যাতে লেখা ও আইকন পরিষ্কার থাকে
      Box(
        modifier = Modifier
          .align(Alignment.TopEnd)
          .size(96.dp)
          .background(Color.White.copy(alpha = 0.085f), CircleShape),
      )
      Box(
        modifier = Modifier
          .align(Alignment.BottomEnd)
          .padding(end = 13.dp, bottom = 12.dp)
          .size(7.dp)
          .background(Color.White.copy(alpha = 0.55f), CircleShape),
      )
      Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 15.dp, vertical = 13.dp),
        verticalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(15.dp),
            color = Color.White.copy(alpha = 0.19f),
            modifier = Modifier.size(42.dp),
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(tile.icon, contentDescription = tile.label, tint = Color.White, modifier = Modifier.size(23.dp))
            }
          }
          Spacer(Modifier.weight(1f))
          Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Color.White.copy(alpha = 0.82f))
        }
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
          Text(
            tile.label,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            tile.subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = Color.White.copy(alpha = 0.84f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
    }
  }
}
