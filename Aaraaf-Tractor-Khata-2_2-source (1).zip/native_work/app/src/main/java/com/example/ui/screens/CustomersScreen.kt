package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.billing.FormatUtils
import com.example.domain.model.CustomerFinancialSummary
import com.example.localization.AppStrings
import com.example.ui.components.EmptyStateCard
import com.example.ui.theme.LocalLedgerColors

@Composable
fun CustomersScreen(
  summaries: List<CustomerFinancialSummary>,
  strings: AppStrings,
  currencySymbol: String,
  initialFilterDuesOnly: Boolean = false,
  onSelectCustomer: (String) -> Unit,
  onAddCustomer: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var searchQuery by remember { mutableStateOf("") }
  var filterIndex by remember(initialFilterDuesOnly) {
    mutableIntStateOf(if (initialFilterDuesOnly) 1 else 0)
  }
  val ledgerColors = LocalLedgerColors.current

  val filtered = remember(summaries, searchQuery, filterIndex) {
    val q = searchQuery.trim().lowercase()
    summaries
      .filter { s ->
        when (filterIndex) {
          1 -> s.totalOutstandingBalance > 0.01
          2 -> s.remainingAdvance > 0.01
          else -> true
        }
      }
      .filter { s ->
        if (q.isEmpty()) true
        else {
          s.customer.fullName.lowercase().contains(q) ||
            s.customer.mobileNumber.lowercase().contains(q) ||
            s.customer.village.lowercase().contains(q)
        }
      }
  }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    floatingActionButton = {
      FloatingActionButton(
        onClick = onAddCustomer,
        modifier = Modifier.testTag("customers_add_fab"),
      ) {
        Icon(Icons.Rounded.PersonAdd, contentDescription = strings.addCustomer)
      }
    },
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Spacer(Modifier.height(4.dp))
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
        placeholder = { Text(strings.searchCustomersHint) },
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("customer_search_input"),
      )

      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(
          selected = filterIndex == 0,
          onClick = { filterIndex = 0 },
          label = { Text("${strings.allFilter} (${summaries.size})") },
        )
        FilterChip(
          selected = filterIndex == 1,
          onClick = { filterIndex = 1 },
          label = { Text(strings.withDuesFilter) },
        )
        FilterChip(
          selected = filterIndex == 2,
          onClick = { filterIndex = 2 },
          label = { Text(strings.withAdvanceFilter) },
        )
      }

      if (filtered.isEmpty()) {
        EmptyStateCard(
          icon = Icons.Rounded.PersonAdd,
          message = strings.noCustomersFound,
          actionLabel = strings.addCustomer,
          onAction = onAddCustomer,
        )
      } else {
        LazyColumn(
          contentPadding = PaddingValues(bottom = 88.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          items(filtered, key = { it.customer.id }) { summary ->
            val c = summary.customer
            Card(
              onClick = { onSelectCustomer(c.id) },
              shape = MaterialTheme.shapes.medium,
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
              modifier = Modifier
                .fillMaxWidth()
                .testTag("customer_card_${c.customerCode}"),
            ) {
              Row(
                modifier = Modifier.padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                  Text(
                    "${c.fullName} (${c.customerCode})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                  )
                  Text(
                    "${c.mobileNumber} • ${c.village.ifBlank { c.address.ifBlank { "-" } }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                  Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                      shape = MaterialTheme.shapes.small,
                      color = MaterialTheme.colorScheme.surfaceVariant,
                    ) {
                      Text(
                        "${summary.lands.size} জমি • ${summary.jobs.size} কাজ",
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                      )
                    }
                    if (summary.remainingAdvance > 0.01) {
                      Surface(
                        shape = MaterialTheme.shapes.small,
                        color = ledgerColors.advanceColor.copy(alpha = 0.14f),
                      ) {
                        Text(
                          "অগ্রিম: ${FormatUtils.formatTaka(summary.remainingAdvance, currencySymbol)}",
                          style = MaterialTheme.typography.labelSmall,
                          color = ledgerColors.advanceColor,
                          modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        )
                      }
                    }
                  }
                }
                Column(horizontalAlignment = Alignment.End) {
                  Text(
                    "বকেয়া",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                  Text(
                    FormatUtils.formatTaka(summary.totalOutstandingBalance, currencySymbol),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (summary.totalOutstandingBalance > 0.01) ledgerColors.dueColor else ledgerColors.paidColor,
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}
