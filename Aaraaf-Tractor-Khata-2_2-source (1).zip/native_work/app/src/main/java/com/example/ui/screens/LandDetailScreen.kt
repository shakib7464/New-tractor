package com.example.ui.screens

import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.AttachmentEntity
import com.example.data.local.entity.CustomerEntity
import com.example.domain.billing.BillingCalculator
import com.example.domain.billing.FormatUtils
import com.example.domain.model.LandFinancialSummary
import com.example.localization.AppStrings
import com.example.ui.components.AttachmentSection
import com.example.ui.components.SectionHeader
import com.example.ui.theme.LocalLedgerColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LandDetailScreen(
  customer: CustomerEntity,
  landSummary: LandFinancialSummary,
  attachments: List<AttachmentEntity>,
  strings: AppStrings,
  currencySymbol: String,
  onBack: () -> Unit,
  onEditLand: () -> Unit,
  onDeleteLand: () -> Unit,
  onAddJobForLand: () -> Unit,
  onReceivePaymentForLand: () -> Unit,
  onPrintLandStatement: () -> Unit,
  onRecordAdjustment: (amount: Double, isChargeIncrease: Boolean, isRefund: Boolean, desc: String, notes: String) -> Unit,
  onAddAttachment: (Uri) -> Unit,
  onDeleteAttachment: (String) -> Unit,
) {
  val land = landSummary.land
  val ledgerColors = LocalLedgerColors.current
  var showAdjustDialog by remember { mutableStateOf(false) }
  var confirmDelete by remember { mutableStateOf(false) }

  var running = 0.0
  val ledgerWithBalance = remember(landSummary.transactions) {
    landSummary.transactions.map { txn ->
      running = BillingCalculator.roundCurrency(running + txn.debitAmount - txn.creditAmount)
      txn to running
    }.reversed()
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("${land.landName} (${land.landCode})") },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
          }
        },
        actions = {
          IconButton(onClick = onPrintLandStatement, modifier = Modifier.testTag("land_print_btn")) {
            Icon(Icons.Rounded.Print, contentDescription = strings.printLandStatement)
          }
          IconButton(onClick = onEditLand) {
            Icon(Icons.Rounded.Edit, contentDescription = strings.edit)
          }
          IconButton(onClick = { confirmDelete = true }) {
            Icon(Icons.Rounded.DeleteOutline, contentDescription = strings.delete)
          }
        },
      )
    },
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item {
        Card(
          shape = MaterialTheme.shapes.large,
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
              "মালিক: ${customer.fullName} (${customer.mobileNumber})",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.SemiBold,
            )
            Text(
              "জমির পরিমাণ: ${FormatUtils.formatNumber(land.sizeValue)} ${strings.unitLabel(land.unit)}",
              style = MaterialTheme.typography.bodyMedium,
            )

            Spacer(Modifier.height(4.dp))
            LedgerSummaryRow(strings.openingBalance, FormatUtils.formatTaka(landSummary.openingBalance, currencySymbol))
            LedgerSummaryRow("মোট কাজের বিল", FormatUtils.formatTaka(landSummary.workCharges, currencySymbol))
            LedgerSummaryRow(strings.additionalCharges, FormatUtils.formatTaka(landSummary.additionalCharges, currencySymbol))
            LedgerSummaryRow(strings.discount, "- ${FormatUtils.formatTaka(landSummary.discounts, currencySymbol)}")
            LedgerSummaryRow("মোট পেমেন্ট", "- ${FormatUtils.formatTaka(landSummary.payments, currencySymbol)}")
            LedgerSummaryRow("অগ্রিম সমন্বয়", "- ${FormatUtils.formatTaka(landSummary.advanceAdjustments, currencySymbol)}")

            Surface(
              color = (if (landSummary.currentBalance > 0.01) ledgerColors.dueColor else ledgerColors.paidColor).copy(alpha = 0.12f),
              shape = MaterialTheme.shapes.small,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Text("জমির বর্তমান বকেয়া", fontWeight = FontWeight.Bold)
                Text(
                  FormatUtils.formatTaka(landSummary.currentBalance, currencySymbol),
                  fontWeight = FontWeight.Bold,
                  color = if (landSummary.currentBalance > 0.01) ledgerColors.dueColor else ledgerColors.paidColor,
                )
              }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
              Button(
                onClick = onAddJobForLand,
                modifier = Modifier.weight(1f).height(48.dp),
              ) {
                Icon(Icons.Rounded.Add, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text(strings.addJob, maxLines = 1)
              }
              FilledTonalButton(
                onClick = onReceivePaymentForLand,
                modifier = Modifier.weight(1f).height(48.dp),
              ) {
                Icon(Icons.Rounded.Payments, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text(strings.receivePayment, maxLines = 1)
              }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
              OutlinedButton(
                onClick = { showAdjustDialog = true },
                modifier = Modifier.weight(1f).height(48.dp),
              ) {
                Icon(Icons.Rounded.Tune, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("${strings.manualAdjustment} / ${strings.refundEntry}", maxLines = 1)
              }
              OutlinedButton(
                onClick = onPrintLandStatement,
                modifier = Modifier.weight(1f).height(48.dp),
              ) {
                Icon(Icons.Rounded.Print, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text(strings.printLandStatement, maxLines = 1)
              }
            }
          }
        }
      }

      item {
        AttachmentSection(
          title = strings.attachmentsTitle,
          attachments = attachments,
          onAddAttachmentUri = onAddAttachment,
          onDeleteAttachment = onDeleteAttachment,
        )
      }

      item { SectionHeader(title = strings.landLedger) }

      items(ledgerWithBalance, key = { it.first.id }) { (txn, balanceAfter) ->
        Surface(shape = MaterialTheme.shapes.medium, tonalElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(strings.transactionTypeLabel(txn.transactionType), fontWeight = FontWeight.SemiBold)
              Text(txn.description, style = MaterialTheme.typography.bodySmall)
              Text(FormatUtils.formatDate(txn.transactionDate), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(horizontalAlignment = Alignment.End) {
              if (txn.debitAmount > 0) {
                Text("+${FormatUtils.formatTaka(txn.debitAmount, currencySymbol)}", color = ledgerColors.dueColor, fontWeight = FontWeight.Bold)
              } else if (txn.creditAmount > 0) {
                Text("-${FormatUtils.formatTaka(txn.creditAmount, currencySymbol)}", color = ledgerColors.paidColor, fontWeight = FontWeight.Bold)
              }
              Text("জের: ${FormatUtils.formatTaka(balanceAfter, currencySymbol)}", style = MaterialTheme.typography.labelSmall)
            }
          }
        }
      }
    }
  }

  if (showAdjustDialog) {
    var amtText by remember { mutableStateOf("") }
    var descText by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(0) } // 0 = Add charge, 1 = Waive/Credit, 2 = Refund
    AlertDialog(
      onDismissRequest = { showAdjustDialog = false },
      title = { Text("${strings.manualAdjustment} / ${strings.refundEntry}") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = mode == 0, onClick = { mode = 0 }, label = { Text("বকেয়া যোগ (+)") })
            FilterChip(selected = mode == 1, onClick = { mode = 1 }, label = { Text("ছাড় / ক্রেডিট (-)") })
            FilterChip(selected = mode == 2, onClick = { mode = 2 }, label = { Text(strings.refundEntry) })
          }
          OutlinedTextField(
            value = amtText,
            onValueChange = { amtText = it },
            label = { Text(strings.paymentAmount) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
          OutlinedTextField(
            value = descText,
            onValueChange = { descText = it },
            label = { Text("কারণ / বিবরণ") },
            modifier = Modifier.fillMaxWidth(),
          )
          OutlinedTextField(
            value = notesText,
            onValueChange = { notesText = it },
            label = { Text(strings.notes) },
            modifier = Modifier.fillMaxWidth(),
          )
        }
      },
      confirmButton = {
        Button(onClick = {
          val amt = amtText.toDoubleOrNull() ?: return@Button
          if (amt <= 0) return@Button
          onRecordAdjustment(amt, mode == 0, mode == 2, descText, notesText)
          showAdjustDialog = false
        }) { Text(strings.save) }
      },
      dismissButton = {
        TextButton(onClick = { showAdjustDialog = false }) { Text(strings.cancel) }
      },
    )
  }

  if (confirmDelete) {
    AlertDialog(
      onDismissRequest = { confirmDelete = false },
      title = { Text("জমি মুছবেন?") },
      text = { Text("${land.landName} রিসাইকেল বিনে পাঠানো হবে।") },
      confirmButton = {
        TextButton(onClick = { confirmDelete = false; onDeleteLand() }) { Text(strings.confirm) }
      },
      dismissButton = {
        TextButton(onClick = { confirmDelete = false }) { Text(strings.cancel) }
      },
    )
  }
}

@Composable
private fun LedgerSummaryRow(label: String, value: String) {
  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
    Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
  }
}
