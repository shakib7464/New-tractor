package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.AddBusiness
import androidx.compose.material.icons.rounded.AddTask
import androidx.compose.material.icons.rounded.Agriculture
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Landscape
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.PendingActions
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Savings
import androidx.compose.material.icons.rounded.Today
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.billing.FormatUtils
import com.example.domain.model.DashboardSummary
import com.example.localization.AppStrings
import com.example.ui.components.BulkPrintProminentCard
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.MetricStatCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.LocalLedgerColors

@Composable
fun DashboardScreen(
  summary: DashboardSummary,
  strings: AppStrings,
  currencySymbol: String,
  onAddCustomer: () -> Unit,
  onAddLand: () -> Unit,
  onAddJob: () -> Unit,
  onReceivePayment: () -> Unit,
  onOpenPayments: () -> Unit,
  onViewOutstandingDues: () -> Unit,
  onViewReports: () -> Unit,
  onOneClickBulkPrint: () -> Unit,
  onConfigureBulkPrint: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val ledgerColors = LocalLedgerColors.current

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // Hero Brand Banner with Generated Farm Tractor Illustration
    item {
      Card(
        shape = MaterialTheme.shapes.large,
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Box(modifier = Modifier.height(152.dp).fillMaxWidth()) {
          Image(
            painter = painterResource(id = R.drawable.img_tractor_banner),
            contentDescription = strings.appName,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
          )
          Box(
            modifier = Modifier
              .fillMaxSize()
              .background(
                Brush.verticalGradient(
                  colors = listOf(
                    Color(0xBB0D281D),
                    Color(0xE61B4332),
                  )
                )
              )
              .padding(18.dp)
          ) {
          Image(
            painter = painterResource(id = R.drawable.aaraaf_brand_logo),
            contentDescription = strings.appName,
            contentScale = ContentScale.Fit,
            modifier = Modifier
              .align(Alignment.TopEnd)
              .padding(10.dp)
              .size(76.dp)
              .clip(CircleShape),
          )
            Column(
              modifier = Modifier.align(Alignment.BottomStart),
              verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
              Text(
                text = strings.appName,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White,
              )
              Text(
                text = strings.dashboardSubtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFFDE68A),
              )
              Spacer(Modifier.height(4.dp))
              Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(
                  text = "${strings.totalOutstanding}: ${FormatUtils.formatTaka(summary.totalOutstandingAmount, currencySymbol)}",
                  style = MaterialTheme.typography.labelLarge,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFFFCA5A5),
                )
                Text(
                  text = "${strings.remainingAdvance}: ${FormatUtils.formatTaka(summary.totalRemainingAdvance, currencySymbol)}",
                  style = MaterialTheme.typography.labelLarge,
                  color = Color(0xFF93C5FD),
                )
              }
            }
          }
        }
      }
    }

    // Prominent Mandatory One-Click Bulk Print Button
    item {
      BulkPrintProminentCard(
        title = strings.bulkPrintAllCustomersBtn,
        subtitle = strings.bulkPrintSubtitle,
        buttonTag = "dashboard_bulk_print_btn",
        onOneClickPrint = onOneClickBulkPrint,
        onConfigureFilter = onConfigureBulkPrint,
      )
    }

    // Quick Access Actions
    item {
      SectionHeader(title = strings.quickActions)
      Spacer(Modifier.height(8.dp))
      val actions = listOf(
        Triple(strings.addCustomer, Icons.Rounded.PersonAdd, onAddCustomer) to "quick_add_customer",
        Triple(strings.addLand, Icons.Rounded.AddBusiness, onAddLand) to "quick_add_land",
        Triple(strings.addJob, Icons.Rounded.AddTask, onAddJob) to "quick_add_job",
        Triple(strings.receivePayment, Icons.Rounded.Payments, onReceivePayment) to "quick_receive_payment",
        Triple("পেমেন্ট হিসাব", Icons.Rounded.ReceiptLong, onOpenPayments) to "quick_payment_history",
        Triple(strings.outstandingDues, Icons.Rounded.WarningAmber, onViewOutstandingDues) to "quick_outstanding",
        Triple(strings.viewReports, Icons.Rounded.Assessment, onViewReports) to "quick_reports",
        Triple(strings.printStatements, Icons.Rounded.Print, onConfigureBulkPrint) to "quick_print_statements",
      )
      LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(actions) { (triple, tag) ->
          val (label, icon, action) = triple
          QuickActionChipCard(
            label = label,
            icon = icon,
            tag = tag,
            onClick = action,
          )
        }
      }
    }

    // Financial Overview Grid (All Required Metrics)
    item {
      SectionHeader(title = "আর্থিক ও কাজের সারসংক্ষেপ")
      Spacer(Modifier.height(8.dp))
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
          MetricStatCard(
            title = strings.totalBilled,
            value = FormatUtils.formatTaka(summary.totalBilledAmount, currencySymbol),
            icon = Icons.Rounded.ReceiptLong,
            accentColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier.weight(1f),
          )
          MetricStatCard(
            title = strings.totalCollected,
            value = FormatUtils.formatTaka(summary.totalCollectedAmount, currencySymbol),
            icon = Icons.Rounded.AccountBalanceWallet,
            accentColor = ledgerColors.paidColor,
            modifier = Modifier.weight(1f),
          )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
          MetricStatCard(
            title = strings.totalOutstanding,
            value = FormatUtils.formatTaka(summary.totalOutstandingAmount, currencySymbol),
            icon = Icons.Rounded.WarningAmber,
            accentColor = ledgerColors.dueColor,
            onClick = onViewOutstandingDues,
            modifier = Modifier.weight(1f),
          )
          MetricStatCard(
            title = strings.totalAdvanceReceived,
            value = FormatUtils.formatTaka(summary.totalAdvanceReceived, currencySymbol),
            subtitle = "${strings.remainingAdvance}: ${FormatUtils.formatTaka(summary.totalRemainingAdvance, currencySymbol)}",
            icon = Icons.Rounded.Savings,
            accentColor = ledgerColors.advanceColor,
            modifier = Modifier.weight(1f),
          )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
          MetricStatCard(
            title = strings.todaysWork,
            value = "${summary.todaysJobCount} টি",
            subtitle = FormatUtils.formatTaka(summary.todaysBilledAmount, currencySymbol),
            icon = Icons.Rounded.Today,
            accentColor = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.weight(1f),
          )
          MetricStatCard(
            title = strings.todaysCollection,
            value = FormatUtils.formatTaka(summary.todaysCollectionAmount, currencySymbol),
            icon = Icons.Rounded.Payments,
            accentColor = ledgerColors.paidColor,
            modifier = Modifier.weight(1f),
          )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
          MetricStatCard(
            title = strings.monthlyBilling,
            value = FormatUtils.formatTaka(summary.monthlyBilledAmount, currencySymbol),
            icon = Icons.Rounded.CalendarMonth,
            accentColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier.weight(1f),
          )
          MetricStatCard(
            title = strings.monthlyCollection,
            value = FormatUtils.formatTaka(summary.monthlyCollectionAmount, currencySymbol),
            icon = Icons.Rounded.AccountBalanceWallet,
            accentColor = ledgerColors.paidColor,
            modifier = Modifier.weight(1f),
          )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
          MetricStatCard(
            title = strings.totalCustomers,
            value = "${summary.totalCustomers}",
            subtitle = "${strings.totalLands}: ${summary.totalLands}",
            icon = Icons.Rounded.Landscape,
            accentColor = MaterialTheme.colorScheme.tertiary,
            modifier = Modifier.weight(1f),
          )
          MetricStatCard(
            title = strings.totalJobs,
            value = "${summary.totalJobs}",
            subtitle = "${strings.completedJobs}: ${summary.completedJobs} • ${strings.pendingJobs}: ${summary.pendingJobs}",
            icon = Icons.Rounded.Agriculture,
            accentColor = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.weight(1f),
          )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
          MetricStatCard(
            title = strings.completedJobs,
            value = "${summary.completedJobs}",
            icon = Icons.Rounded.CheckCircle,
            accentColor = ledgerColors.paidColor,
            modifier = Modifier.weight(1f),
          )
          MetricStatCard(
            title = strings.pendingJobs,
            value = "${summary.pendingJobs}",
            icon = Icons.Rounded.PendingActions,
            accentColor = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.weight(1f),
          )
        }
      }
    }

    // Recent Activities
    item {
      SectionHeader(title = strings.recentActivities)
    }

    if (summary.recentActivities.isEmpty()) {
      item {
        EmptyStateCard(
          icon = Icons.Rounded.Agriculture,
          message = strings.noActivitiesYet,
          actionLabel = strings.addCustomer,
          onAction = onAddCustomer,
        )
      }
    } else {
      items(summary.recentActivities, key = { it.id }) { item ->
        Surface(
          shape = MaterialTheme.shapes.medium,
          color = MaterialTheme.colorScheme.surface,
          tonalElevation = 1.dp,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                item.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                item.subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            item.amount?.let { amt ->
              Text(
                FormatUtils.formatTaka(amt, currencySymbol),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
              )
            }
          }
        }
      }
    }

    item { Spacer(Modifier.height(16.dp)) }
  }
}

@Composable
private fun QuickActionChipCard(
  label: String,
  icon: ImageVector,
  tag: String,
  onClick: () -> Unit,
) {
  FilledTonalButton(
    onClick = onClick,
    modifier = Modifier
      .height(52.dp)
      .clip(RoundedCornerShape(14.dp))
      .testTag(tag),
    shape = RoundedCornerShape(14.dp),
  ) {
    Icon(icon, contentDescription = label, modifier = Modifier.size(18.dp))
    Spacer(Modifier.width(8.dp))
    Text(label, style = MaterialTheme.typography.labelLarge, maxLines = 1)
  }
}
