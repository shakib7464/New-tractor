package com.example.ui.components

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.example.data.preferences.AppLockType
import kotlinx.coroutines.launch

@Composable
fun PinBiometricLockScreen(
  biometricEnabled: Boolean,
  onVerifyPin: suspend (String) -> Boolean,
  onBiometricSuccess: () -> Unit,
  lockRemainingMillis: suspend () -> Long = { 0L },
  lockType: AppLockType = AppLockType.PIN,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  var pin by remember { mutableStateOf("") }
  var error by remember { mutableStateOf<String?>(null) }
  var showPassword by remember { mutableStateOf(false) }
  var patternReset by remember { mutableIntStateOf(0) }

  fun launchBiometric() {
    val activity = context as? FragmentActivity ?: return
    val manager = BiometricManager.from(context)
    val canAuth = manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK)
    if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) return

    val executor = ContextCompat.getMainExecutor(context)
    val prompt = BiometricPrompt(
      activity,
      executor,
      object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
          super.onAuthenticationSucceeded(result)
          onBiometricSuccess()
        }
      },
    )
    val fallbackText = when (lockType) {
      AppLockType.PIN -> "পিন ব্যবহার করুন"
      AppLockType.PATTERN -> "প্যাটার্ন ব্যবহার করুন"
      AppLockType.PASSWORD -> "পাসওয়ার্ড ব্যবহার করুন"
    }
    val info = BiometricPrompt.PromptInfo.Builder()
      .setTitle("Tractor Khata")
      .setSubtitle("আনলক করতে ফিঙ্গারপ্রিন্ট দিন")
      .setNegativeButtonText(fallbackText)
      .build()
    prompt.authenticate(info)
  }

  LaunchedEffect(biometricEnabled) {
    if (biometricEnabled) {
      launchBiometric()
    }
  }

  suspend fun submit(secret: String) {
    if (!onVerifyPin(secret)) {
      val wait = lockRemainingMillis()
      val wrongText = when (lockType) {
        AppLockType.PIN -> "ভুল পিন কোড"
        AppLockType.PATTERN -> "ভুল প্যাটার্ন"
        AppLockType.PASSWORD -> "ভুল পাসওয়ার্ড"
      }
      error = if (wait > 0) {
        val sec = (wait + 999) / 1000
        if (sec >= 60) "অনেকবার ভুল হয়েছে। ${(sec + 59) / 60} মিনিট পরে চেষ্টা করুন"
        else "অনেকবার ভুল হয়েছে। $sec সেকেন্ড পরে চেষ্টা করুন"
      } else wrongText
      pin = ""
      patternReset++
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(28.dp),
    verticalArrangement = Arrangement.Center,
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Icon(
      imageVector = Icons.Rounded.Lock,
      contentDescription = "Locked",
      tint = MaterialTheme.colorScheme.primary,
      modifier = Modifier.size(64.dp),
    )
    Spacer(Modifier.height(16.dp))
    Text(
      text = "Tractor Khata",
      style = MaterialTheme.typography.headlineSmall,
      fontWeight = FontWeight.Bold,
    )
    Text(
      text = when (lockType) {
        AppLockType.PIN -> "হিসাব দেখতে পিন কোড দিন"
        AppLockType.PATTERN -> "হিসাব দেখতে প্যাটার্ন আঁকুন"
        AppLockType.PASSWORD -> "হিসাব দেখতে পাসওয়ার্ড দিন"
      },
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Spacer(Modifier.height(24.dp))

    when (lockType) {
      AppLockType.PATTERN -> {
        PatternLockPad(
          resetKey = patternReset,
          isError = error != null,
          onPatternStart = { error = null },
          onPatternComplete = { nodes ->
            scope.launch { submit(patternToSecret(nodes)) }
          },
          modifier = Modifier
            .padding(horizontal = 24.dp)
            .testTag("lock_pattern_pad"),
        )
        error?.let {
          Spacer(Modifier.height(8.dp))
          Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
        }
      }

      AppLockType.PIN, AppLockType.PASSWORD -> {
        val isPin = lockType == AppLockType.PIN
        GlowOutlinedTextField(
          value = pin,
          onValueChange = {
            if (isPin) {
              if (it.length <= 6 && it.all { ch -> ch.isDigit() }) {
                pin = it
                error = null
              }
            } else {
              pin = it
              error = null
            }
          },
          label = { Text(if (isPin) "পিন কোড (PIN)" else "পাসওয়ার্ড (Password)") },
          visualTransformation = if (isPin || !showPassword) PasswordVisualTransformation() else VisualTransformation.None,
          keyboardOptions = KeyboardOptions(keyboardType = if (isPin) KeyboardType.NumberPassword else KeyboardType.Password),
          trailingIcon = if (isPin) null else {
            {
              IconButton(onClick = { showPassword = !showPassword }) {
                Icon(
                  if (showPassword) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                  contentDescription = null,
                )
              }
            }
          },
          singleLine = true,
          isError = error != null,
          supportingText = error?.let { msg -> { Text(msg) } },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("lock_pin_input"),
        )
        Spacer(Modifier.height(14.dp))
        Button(
          onClick = { scope.launch { submit(pin) } },
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("lock_unlock_button"),
        ) {
          Text("আনলক করুন", fontWeight = FontWeight.Bold)
        }
      }
    }

    if (biometricEnabled) {
      Spacer(Modifier.height(12.dp))
      OutlinedButton(
        onClick = { launchBiometric() },
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp),
      ) {
        Icon(Icons.Rounded.Fingerprint, contentDescription = null)
        Text(" ফিঙ্গারপ্রিন্ট দিয়ে আনলক")
      }
    }
  }
}
