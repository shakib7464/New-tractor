package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.billing.FormatUtils

@Composable
fun MetricStatCard(
  title: String,
  value: String,
  icon: ImageVector,
  accentColor: Color,
  modifier: Modifier = Modifier,
  subtitle: String? = null,
  onClick: (() -> Unit)? = null,
  gradientStart: Color? = null,
  gradientEnd: Color? = null,
  amount: Double? = null,
  currencySymbol: String = "৳",
) {
  val solid = gradientStart != null && gradientEnd != null
  // amount দিলে সংখ্যাটি ০ থেকে গুনে উঠবে (Reduce effects চালু থাকলে সরাসরি দেখাবে)
  val animatedAmount = rememberCountUp(amount ?: 0.0)
  val displayValue = if (amount != null) FormatUtils.formatTaka(animatedAmount, currencySymbol) else value
  val contentColor = if (solid) Color.White else accentColor
  val labelColor = if (solid) Color.White.copy(alpha = 0.9f) else MaterialTheme.colorScheme.onSurfaceVariant
  Card(
    modifier = modifier.neonGlow(if (solid) gradientEnd!! else accentColor, 22.dp, if (solid) 0.9f else 0.5f),
    shape = RoundedCornerShape(22.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (solid) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surface.copy(alpha = 0.72f),
    ),
    border = if (solid) {
      BorderStroke(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.55f), Color.White.copy(alpha = 0.08f))))
    } else {
      BorderStroke(1.dp, Brush.linearGradient(listOf(accentColor.copy(alpha = 0.60f), MaterialTheme.colorScheme.secondary.copy(alpha = 0.25f))))
    },
    elevation = CardDefaults.cardElevation(defaultElevation = if (solid) 3.dp else 1.dp),
    onClick = { onClick?.invoke() },
    enabled = onClick != null,
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(
          if (solid) {
            Brush.linearGradient(listOf(gradientStart!!, gradientEnd!!))
          } else {
            Brush.linearGradient(
              colors = listOf(accentColor.copy(alpha = 0.14f), accentColor.copy(alpha = 0.02f)),
            )
          },
        ),
    ) {
      // গ্লাস শিন: ওপরের দিকে হালকা সাদা আভা
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(40.dp)
          .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.10f), Color.Transparent))),
      )
      if (solid) {
        // কুইক অ্যাকশন টাইলের মতো পিছনে হালকা বড় বৃত্ত
        Box(
          modifier = Modifier
            .align(Alignment.TopEnd)
            .size(84.dp)
            .background(Color.White.copy(alpha = 0.10f), CircleShape),
        )
      }
      Column(
        modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Surface(
            shape = CircleShape,
            color = if (solid) Color.White.copy(alpha = 0.22f) else accentColor.copy(alpha = 0.18f),
            modifier = Modifier.size(40.dp),
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = icon,
                contentDescription = title,
                tint = contentColor,
                modifier = Modifier.size(22.dp),
              )
            }
          }
          Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = labelColor,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
          )
          if (onClick != null) {
            Icon(
              imageVector = Icons.Rounded.ChevronRight,
              contentDescription = null,
              tint = contentColor.copy(alpha = 0.8f),
              modifier = Modifier.size(20.dp),
            )
          }
        }
        Text(
          text = displayValue,
          style = MaterialTheme.typography.headlineSmall.copy(fontFeatureSettings = "tnum"),
          fontWeight = FontWeight.ExtraBold,
          color = contentColor,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        if (!subtitle.isNullOrBlank()) {
          Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = labelColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
    }
  }
}

@Composable
fun BulkPrintProminentCard(
  title: String,
  subtitle: String,
  buttonTag: String,
  onOneClickPrint: () -> Unit,
  onConfigureFilter: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier = modifier.fillMaxWidth(),
    shape = MaterialTheme.shapes.large,
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
  ) {
    Column(
      modifier = Modifier.padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = MaterialTheme.colorScheme.secondary,
          modifier = Modifier.size(44.dp),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = Icons.Rounded.Print,
              contentDescription = title,
              tint = MaterialTheme.colorScheme.onSecondary,
              modifier = Modifier.size(24.dp),
            )
          }
        }
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onPrimary,
          )
          Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.86f),
          )
        }
      }
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Button(
          onClick = onOneClickPrint,
          modifier = Modifier
            .weight(1f)
            .height(48.dp)
            .testTag(buttonTag),
          colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.secondary,
            contentColor = MaterialTheme.colorScheme.onSecondary,
          ),
          shape = MaterialTheme.shapes.small,
        ) {
          Icon(Icons.Rounded.Print, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(Modifier.width(6.dp))
          Text("এক-ক্লিকে PDF তৈরি", fontWeight = FontWeight.Bold, maxLines = 1)
        }
        Button(
          onClick = onConfigureFilter,
          modifier = Modifier
            .height(48.dp)
            .testTag("${buttonTag}_filter"),
          colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.18f),
            contentColor = MaterialTheme.colorScheme.onPrimary,
          ),
          shape = MaterialTheme.shapes.small,
        ) {
          Text("ফিল্টার", fontWeight = FontWeight.SemiBold)
        }
      }
    }
  }
}

@Composable
fun SectionHeader(
  title: String,
  modifier: Modifier = Modifier,
  trailingAction: (@Composable () -> Unit)? = null,
) {
  Row(
    modifier = modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier = Modifier
          .size(width = 4.dp, height = 18.dp)
          .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(2.dp)),
      )
      Spacer(Modifier.width(8.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground,
      )
    }
    trailingAction?.invoke()
  }
}

@Composable
fun EmptyStateCard(
  icon: ImageVector,
  message: String,
  modifier: Modifier = Modifier,
  actionLabel: String? = null,
  onAction: (() -> Unit)? = null,
) {
  GlassCard(
    modifier = modifier.fillMaxWidth(),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
        modifier = Modifier.size(44.dp),
      )
      Text(
        text = message,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      if (actionLabel != null && onAction != null) {
        Button(onClick = onAction, modifier = Modifier.height(48.dp)) {
          Text(actionLabel)
        }
      }
    }
  }
}
