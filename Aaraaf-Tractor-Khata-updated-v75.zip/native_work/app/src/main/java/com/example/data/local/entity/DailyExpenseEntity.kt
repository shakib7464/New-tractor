package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/** দৈনিক খরচ: কোন তারিখে, কোথায়, কী বাবদ, কত টাকা খরচ হলো। */
@Serializable
@Entity(tableName = "daily_expenses")
data class DailyExpenseEntity(
  @PrimaryKey val id: String,
  val expenseDate: Long,
  val place: String,
  val title: String,
  val amount: Double,
  val createdAt: Long,
  val updatedAt: Long,
  val isDeleted: Boolean = false,
)
