package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// v62 Futuristic: Light = Violet + Cyan on soft lavender. (ভ্যারিয়েবলের নাম পুরনো, রঙ নতুন)
val EmeraldPrimary = Color(0xFF6D28D9)
val EmeraldOnPrimary = Color(0xFFFFFFFF)
val EmeraldPrimaryContainer = Color(0xFFEDE9FE)
val EmeraldOnPrimaryContainer = Color(0xFF2E1065)

val AmberSecondary = Color(0xFF0891B2)
val AmberOnSecondary = Color(0xFFFFFFFF)
val AmberSecondaryContainer = Color(0xFFCFFAFE)
val AmberOnSecondaryContainer = Color(0xFF083344)

val TealTertiary = Color(0xFF7C3AED)
val TealOnTertiary = Color(0xFFFFFFFF)
val TealTertiaryContainer = Color(0xFFF3E8FF)
val TealOnTertiaryContainer = Color(0xFF3B0764)

val WarmBackgroundLight = Color(0xFFF5F6FF)
val WarmSurfaceLight = Color(0xFFFFFFFF)
val WarmSurfaceVariantLight = Color(0xFFE9EBFA)
val WarmOutlineLight = Color(0xFFC9CDEA)
val TextPrimaryLight = Color(0xFF14172B)
val TextSecondaryLight = Color(0xFF545A80)

// Dark = Midnight Space + Neon Cyan + Plasma Violet
val EmeraldPrimaryDark = Color(0xFF22D3EE)
val EmeraldOnPrimaryDark = Color(0xFF001F26)
val EmeraldPrimaryContainerDark = Color(0xFF0E4A5A)
val EmeraldOnPrimaryContainerDark = Color(0xFFCFF8FF)

val AmberSecondaryDark = Color(0xFFA78BFA)
val AmberOnSecondaryDark = Color(0xFF1E0B4B)
val AmberSecondaryContainerDark = Color(0xFF4C2A9A)
val AmberOnSecondaryContainerDark = Color(0xFFEDE5FF)

val TealTertiaryDark = Color(0xFFC084FC)
val TealOnTertiaryDark = Color(0xFF2E0A4F)
val TealTertiaryContainerDark = Color(0xFF5B21B6)
val TealOnTertiaryContainerDark = Color(0xFFF3E8FF)

val PineBackgroundDark = Color(0xFF070B1A)
val PineSurfaceDark = Color(0xFF0F1530)
val PineSurfaceVariantDark = Color(0xFF1A2147)
val PineOutlineDark = Color(0xFF34407A)
val TextPrimaryDark = Color(0xFFE8EEFF)
val TextSecondaryDark = Color(0xFF9AA7D6)

// Semantic Ledger Tokens
val DueCrimsonLight = Color(0xFFC62828)
val DueCrimsonDark = Color(0xFFEF5350)
val PaidEmeraldLight = Color(0xFF1B5E20)
val PaidEmeraldDark = Color(0xFF66BB6A)
val AdvanceBlueLight = Color(0xFF0277BD)
val AdvanceBlueDark = Color(0xFF4FC3F7)
