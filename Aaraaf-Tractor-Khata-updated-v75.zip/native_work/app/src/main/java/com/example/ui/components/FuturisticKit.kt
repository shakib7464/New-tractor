package com.example.ui.components

import android.content.Context
import android.os.Build
import android.view.WindowManager
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AlertDialogDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import kotlinx.coroutines.delay

// ───────────────────────── Spacing scale (৪/৮/১২/১৬/২৪) ─────────────────────────
object Spacing {
  val xs: Dp = 4.dp
  val sm: Dp = 8.dp
  val md: Dp = 12.dp
  val lg: Dp = 16.dp
  val xl: Dp = 24.dp
}

// ───────────────────────── "Reduce effects" সুইচ ─────────────────────────
// চালু থাকলে গ্লো, ব্লার, শিমার, কাউন্ট-আপ ও এন্ট্রান্স অ্যানিমেশন বন্ধ থাকে (কম RAM-এর ফোনের জন্য)
object FxConfig {
  var reduced by mutableStateOf(false)
    private set

  private const val PREFS = "fx_prefs"
  private const val KEY = "reduce_effects"

  fun load(context: Context) {
    reduced = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY, false)
  }

  fun set(context: Context, value: Boolean) {
    reduced = value
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY, value).apply()
  }
}

// ───────────────────────── Haptics ─────────────────────────
class Haptics(private val feedback: HapticFeedback) {
  /** ট্যাব বদল, চিপ সিলেক্ট ইত্যাদির হালকা কম্পন */
  fun tick() = feedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)

  /** সেভ, ডিলিট, সোয়াইপ অ্যাকশনের জোরালো কম্পন */
  fun confirm() = feedback.performHapticFeedback(HapticFeedbackType.LongPress)
}

@Composable
fun rememberHaptics(): Haptics {
  val feedback = LocalHapticFeedback.current
  return remember(feedback) { Haptics(feedback) }
}

// ───────────────────────── নিয়ন গ্লো (কার্ড/বারের বাইরে আভা) ─────────────────────────
fun Modifier.neonGlow(color: Color, cornerRadius: Dp = 22.dp, intensity: Float = 1f): Modifier {
  if (FxConfig.reduced) return this
  return this.drawBehind {
    val r = cornerRadius.toPx()
    listOf(14.dp to 0.045f, 8.dp to 0.075f, 3.dp to 0.13f).forEach { (w, a) ->
      val wp = w.toPx()
      drawRoundRect(
        color = color.copy(alpha = (a * intensity).coerceIn(0f, 1f)),
        topLeft = Offset(-wp / 2f, -wp / 2f),
        size = Size(size.width + wp, size.height + wp),
        cornerRadius = CornerRadius(r + wp / 2f),
        style = Stroke(width = wp),
      )
    }
  }
}

// ───────────────────────── Shimmer ও স্কেলিটন ─────────────────────────
@Composable
fun Modifier.shimmer(): Modifier {
  val base = MaterialTheme.colorScheme.surfaceVariant
  val hi = MaterialTheme.colorScheme.primary
  val transition = rememberInfiniteTransition(label = "shimmer")
  val x by transition.animateFloat(
    initialValue = 0f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing)),
    label = "shimmer_x",
  )
  val reduced = FxConfig.reduced
  return this.drawBehind {
    drawRect(base.copy(alpha = 0.55f))
    if (!reduced) {
      val w = size.width.coerceAtLeast(1f)
      val start = -w + 2f * w * x
      drawRect(
        Brush.linearGradient(
          colors = listOf(Color.Transparent, hi.copy(alpha = 0.20f), Color.Transparent),
          start = Offset(start, 0f),
          end = Offset(start + w * 0.8f, size.height * 0.3f),
        ),
      )
    }
  }
}

@Composable
fun SkeletonCard(modifier: Modifier = Modifier, height: Dp = 84.dp) {
  Box(
    modifier = modifier
      .fillMaxWidth()
      .height(height)
      .clip(RoundedCornerShape(18.dp))
      .shimmer(),
  )
}

@Composable
fun ListSkeleton(count: Int = 5, itemHeight: Dp = 84.dp, modifier: Modifier = Modifier) {
  Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(Spacing.md)) {
    repeat(count) { SkeletonCard(height = itemHeight) }
  }
}

/** স্ক্রিন খোলার প্রথম কিছুক্ষণ true থাকে — ডাটা আসার আগে "খালি" কার্ড ঝলকানো ঠেকায় */
@Composable
fun rememberInitialLoading(millis: Long = 550L): Boolean {
  var loading by remember { mutableStateOf(true) }
  LaunchedEffect(Unit) {
    delay(millis)
    loading = false
  }
  return loading
}

// ───────────────────────── Count-up অ্যানিমেশন ─────────────────────────
@Composable
fun rememberCountUp(target: Double, durationMillis: Int = 900): Double {
  val anim = remember { Animatable(0f) }
  val reduced = FxConfig.reduced
  LaunchedEffect(target, reduced) {
    if (reduced) {
      anim.snapTo(target.toFloat())
    } else {
      anim.animateTo(target.toFloat(), tween(durationMillis, easing = FastOutSlowInEasing))
    }
  }
  val finished = !anim.isRunning && anim.value == target.toFloat()
  return if (reduced || finished) target else anim.value.toDouble()
}

// ───────────────────────── লিস্ট আইটেম স্ট্যাগার্ড এন্ট্রি ─────────────────────────
@Composable
fun Modifier.staggeredEntrance(index: Int): Modifier {
  val progress = remember { Animatable(if (FxConfig.reduced) 1f else 0f) }
  LaunchedEffect(Unit) {
    if (progress.value < 1f) {
      progress.animateTo(
        1f,
        tween(320, delayMillis = if (index < 8) index * 45 else 0, easing = FastOutSlowInEasing),
      )
    }
  }
  return this.graphicsLayer {
    alpha = progress.value
    translationY = (1f - progress.value) * 26.dp.toPx()
  }
}

// ───────────────────────── স্ট্যাটাস চিপ (গ্লো সহ) ─────────────────────────
@Composable
fun GlowStatusChip(text: String, color: Color, modifier: Modifier = Modifier) {
  val shape = RoundedCornerShape(12.dp)
  Surface(
    shape = shape,
    color = color.copy(alpha = 0.14f),
    border = BorderStroke(1.dp, color.copy(alpha = 0.55f)),
    modifier = modifier.neonGlow(color, 12.dp, 0.6f),
  ) {
    Text(
      text = text,
      style = MaterialTheme.typography.labelMedium,
      fontWeight = FontWeight.SemiBold,
      color = color,
      maxLines = 1,
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
    )
  }
}

// ───────────────────────── সোয়াইপ-অ্যাকশনের ব্যাকগ্রাউন্ড ─────────────────────────
@Composable
fun SwipeActionBackground(
  direction: SwipeToDismissBoxValue,
  startIcon: ImageVector,
  startColor: Color,
  endIcon: ImageVector,
  endColor: Color,
  modifier: Modifier = Modifier,
  shape: Shape = MaterialTheme.shapes.medium,
) {
  val target = when (direction) {
    SwipeToDismissBoxValue.StartToEnd -> startColor
    SwipeToDismissBoxValue.EndToStart -> endColor
    SwipeToDismissBoxValue.Settled -> Color.Transparent
  }
  val bg by animateColorAsState(target.copy(alpha = if (target == Color.Transparent) 0f else 0.30f), label = "swipe_bg")
  Box(
    modifier = modifier
      .fillMaxSize()
      .clip(shape)
      .background(bg)
      .padding(horizontal = 22.dp),
    contentAlignment = if (direction == SwipeToDismissBoxValue.StartToEnd) Alignment.CenterStart else Alignment.CenterEnd,
  ) {
    when (direction) {
      SwipeToDismissBoxValue.StartToEnd -> Icon(startIcon, contentDescription = null, tint = startColor)
      SwipeToDismissBoxValue.EndToStart -> Icon(endIcon, contentDescription = null, tint = endColor)
      SwipeToDismissBoxValue.Settled -> Unit
    }
  }
}

// ───────────────────────── গ্লাস ডায়ালগ + ব্যাকড্রপ ব্লার ─────────────────────────
/** ডায়ালগের পেছনের স্ক্রিন ঝাপসা করে (Android 12+; কম্পোজিশনে কিছু আঁকে না) */
@Composable
fun DialogBlurBehind(radius: Int = 28) {
  val view = LocalView.current
  val reduced = FxConfig.reduced
  SideEffect {
    if (!reduced && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      val window = (view.parent as? DialogWindowProvider)?.window
      if (window != null) {
        window.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
        val attrs = window.attributes
        attrs.blurBehindRadius = radius
        window.attributes = attrs
      }
    }
  }
}

@Composable
fun GlassAlertDialog(
  onDismissRequest: () -> Unit,
  confirmButton: @Composable () -> Unit,
  modifier: Modifier = Modifier,
  dismissButton: @Composable (() -> Unit)? = null,
  icon: @Composable (() -> Unit)? = null,
  title: @Composable (() -> Unit)? = null,
  text: @Composable (() -> Unit)? = null,
  shape: Shape = RoundedCornerShape(28.dp),
  containerColor: Color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.95f),
  iconContentColor: Color = AlertDialogDefaults.iconContentColor,
  titleContentColor: Color = AlertDialogDefaults.titleContentColor,
  textContentColor: Color = AlertDialogDefaults.textContentColor,
  tonalElevation: Dp = AlertDialogDefaults.TonalElevation,
  properties: DialogProperties = DialogProperties(),
) {
  AlertDialog(
    onDismissRequest = onDismissRequest,
    confirmButton = {
      DialogBlurBehind()
      confirmButton()
    },
    modifier = modifier,
    dismissButton = dismissButton,
    icon = icon,
    title = title,
    text = text,
    shape = shape,
    containerColor = containerColor,
    iconContentColor = iconContentColor,
    titleContentColor = titleContentColor,
    textContentColor = textContentColor,
    tonalElevation = tonalElevation,
    properties = properties,
  )
}

// ───────────────────────── ফোকাসে গ্লো করা টেক্সট ফিল্ড ─────────────────────────
@Composable
fun GlowOutlinedTextField(
  value: String,
  onValueChange: (String) -> Unit,
  modifier: Modifier = Modifier,
  enabled: Boolean = true,
  readOnly: Boolean = false,
  textStyle: TextStyle = LocalTextStyle.current,
  label: @Composable (() -> Unit)? = null,
  placeholder: @Composable (() -> Unit)? = null,
  leadingIcon: @Composable (() -> Unit)? = null,
  trailingIcon: @Composable (() -> Unit)? = null,
  prefix: @Composable (() -> Unit)? = null,
  suffix: @Composable (() -> Unit)? = null,
  supportingText: @Composable (() -> Unit)? = null,
  isError: Boolean = false,
  visualTransformation: VisualTransformation = VisualTransformation.None,
  keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
  keyboardActions: KeyboardActions = KeyboardActions.Default,
  singleLine: Boolean = false,
  maxLines: Int = if (singleLine) 1 else Int.MAX_VALUE,
  minLines: Int = 1,
  interactionSource: MutableInteractionSource? = null,
  shape: Shape = RoundedCornerShape(14.dp),
  colors: TextFieldColors = OutlinedTextFieldDefaults.colors(),
) {
  val source = interactionSource ?: remember { MutableInteractionSource() }
  val focused by source.collectIsFocusedAsState()
  val glowColor = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
  val strength by animateFloatAsState(
    targetValue = if (focused && !FxConfig.reduced) 1f else 0f,
    animationSpec = tween(220),
    label = "field_glow",
  )
  OutlinedTextField(
    value = value,
    onValueChange = onValueChange,
    modifier = modifier.drawBehind {
      if (strength > 0.01f) {
        val r = 14.dp.toPx()
        listOf(10.dp to 0.07f, 6.dp to 0.11f, 3.dp to 0.18f).forEach { (w, a) ->
          val wp = w.toPx()
          drawRoundRect(
            color = glowColor.copy(alpha = a * strength),
            topLeft = Offset(-wp / 2f, -wp / 2f),
            size = Size(size.width + wp, size.height + wp),
            cornerRadius = CornerRadius(r + wp / 2f),
            style = Stroke(width = wp),
          )
        }
      }
    },
    enabled = enabled,
    readOnly = readOnly,
    textStyle = textStyle,
    label = label,
    placeholder = placeholder,
    leadingIcon = leadingIcon,
    trailingIcon = trailingIcon,
    prefix = prefix,
    suffix = suffix,
    supportingText = supportingText,
    isError = isError,
    visualTransformation = visualTransformation,
    keyboardOptions = keyboardOptions,
    keyboardActions = keyboardActions,
    singleLine = singleLine,
    maxLines = maxLines,
    minLines = minLines,
    interactionSource = source,
    shape = shape,
    colors = colors,
  )
}

// ───────────────────────── নিয়ন ট্রেন্ড চার্ট (ড্র অ্যানিমেশন সহ) ─────────────────────────
private fun smoothLine(points: List<Offset>): Path {
  val path = Path()
  if (points.isEmpty()) return path
  path.moveTo(points[0].x, points[0].y)
  for (i in 1 until points.size) {
    val prev = points[i - 1]
    val cur = points[i]
    val cx = (prev.x + cur.x) / 2f
    path.cubicTo(cx, prev.y, cx, cur.y, cur.x, cur.y)
  }
  return path
}

private fun smoothFill(points: List<Offset>, bottom: Float): Path {
  val path = smoothLine(points)
  if (points.isNotEmpty()) {
    path.lineTo(points.last().x, bottom)
    path.lineTo(points.first().x, bottom)
    path.close()
  }
  return path
}

@Composable
fun NeonTrendChart(
  title: String,
  labels: List<String>,
  seriesA: List<Double>,
  seriesB: List<Double>,
  nameA: String,
  nameB: String,
  colorA: Color,
  colorB: Color,
  modifier: Modifier = Modifier,
) {
  val progress = remember { Animatable(0f) }
  val reduced = FxConfig.reduced
  LaunchedEffect(seriesA, seriesB, reduced) {
    if (reduced) {
      progress.snapTo(1f)
    } else {
      progress.snapTo(0f)
      progress.animateTo(1f, tween(1100, easing = FastOutSlowInEasing))
    }
  }
  val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)

  Card(
    modifier = modifier.fillMaxWidth().neonGlow(colorA, 22.dp, 0.5f),
    shape = RoundedCornerShape(22.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.75f)),
    border = BorderStroke(
      1.dp,
      Brush.linearGradient(listOf(colorA.copy(alpha = 0.55f), colorB.copy(alpha = 0.30f))),
    ),
  ) {
    Column(modifier = Modifier.padding(Spacing.lg), verticalArrangement = Arrangement.spacedBy(Spacing.sm)) {
      Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
      Row(horizontalArrangement = Arrangement.spacedBy(Spacing.lg), verticalAlignment = Alignment.CenterVertically) {
        LegendDot(colorA, nameA)
        LegendDot(colorB, nameB)
      }
      Canvas(modifier = Modifier.fillMaxWidth().height(150.dp)) {
        val count = maxOf(seriesA.size, seriesB.size, labels.size)
        if (count == 0) return@Canvas
        val maxV = maxOf(seriesA.maxOrNull() ?: 0.0, seriesB.maxOrNull() ?: 0.0, 1.0).toFloat()
        val padX = 12.dp.toPx()
        val padTop = 8.dp.toPx()
        val padBottom = 8.dp.toPx()
        val chartH = size.height - padTop - padBottom
        val stepX = if (count > 1) (size.width - 2 * padX) / (count - 1) else 0f

        fun pointsOf(series: List<Double>): List<Offset> = series.mapIndexed { i, v ->
          Offset(
            x = if (count > 1) padX + stepX * i else size.width / 2f,
            y = padTop + chartH * (1f - (v.toFloat() / maxV).coerceIn(0f, 1f)),
          )
        }

        // গ্রিড লাইন
        repeat(4) { i ->
          val y = padTop + chartH * i / 3f
          drawLine(
            color = gridColor,
            start = Offset(0f, y),
            end = Offset(size.width, y),
            strokeWidth = 1.dp.toPx(),
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 10f)),
          )
        }

        val bottom = size.height
        clipRect(left = 0f, top = 0f, right = size.width * progress.value, bottom = size.height) {
          listOf(seriesA to colorA, seriesB to colorB).forEach { (series, color) ->
            val pts = pointsOf(series)
            if (pts.size >= 2) {
              drawPath(
                path = smoothFill(pts, bottom),
                brush = Brush.verticalGradient(listOf(color.copy(alpha = 0.26f), Color.Transparent)),
              )
              // গ্লো স্ট্রোক + মূল লাইন
              drawPath(
                path = smoothLine(pts),
                color = color.copy(alpha = 0.22f),
                style = Stroke(width = 9.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
              )
              drawPath(
                path = smoothLine(pts),
                color = color,
                style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
              )
            }
            pts.forEach { p ->
              drawCircle(color = color.copy(alpha = 0.35f), radius = 6.dp.toPx(), center = p)
              drawCircle(color = color, radius = 3.5.dp.toPx(), center = p)
              drawCircle(color = Color.White, radius = 1.5.dp.toPx(), center = p)
            }
          }
        }
      }
      Row(modifier = Modifier.fillMaxWidth()) {
        labels.forEach { l ->
          Text(
            text = l,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            maxLines = 1,
            modifier = Modifier.weight(1f),
          )
        }
      }
    }
  }
}

@Composable
private fun LegendDot(color: Color, name: String) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    Box(Modifier.size(8.dp).background(color, CircleShape))
    Spacer(Modifier.width(6.dp))
    Text(name, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
  }
}


// ───────────────────────── সেভ বাটনের ডাবল-ট্যাপ গার্ড ─────────────────────────
// সেভ বাটনে দ্রুত দুইবার চাপ পড়লে দ্বিতীয়টা বাদ যায় — এতে একই পেমেন্ট/কাস্টমার/জমির ডুপ্লিকেট এন্ট্রি তৈরি হয় না।
// সেভ ব্যর্থ হলে ১.৫ সেকেন্ড পরে আবার চেষ্টা করা যায়।
class SaveGuard(private val windowMillis: Long) {
  private var last = 0L

  fun tryAcquire(): Boolean {
    val now = System.currentTimeMillis()
    if (now - last < windowMillis) return false
    last = now
    return true
  }
}

@Composable
fun rememberSaveGuard(windowMillis: Long = 1500L): SaveGuard = remember { SaveGuard(windowMillis) }

// ───────────────────────── গ্লাস কার্ড (ড্যাশবোর্ড কার্ডের একই স্টাইল) ─────────────────────────
// গ্লাস + গ্রেডিয়েন্ট বর্ডার + হালকা নিয়ন গ্লো। প্রোফাইল ট্যাব ও ভেতরের সব স্ক্রিনে এটাই ব্যবহার হয়,
// যাতে পুরো অ্যাপ ড্যাশবোর্ডের মতো একই রকম দেখায়।
@Composable
fun GlassCard(
  modifier: Modifier = Modifier,
  accent: Color = MaterialTheme.colorScheme.primary,
  cornerRadius: Dp = 22.dp,
  onClick: (() -> Unit)? = null,
  content: @Composable ColumnScope.() -> Unit,
) {
  val shape = RoundedCornerShape(cornerRadius)
  val container = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.72f))
  val borderStroke = BorderStroke(
    1.dp,
    Brush.linearGradient(listOf(accent.copy(alpha = 0.60f), MaterialTheme.colorScheme.secondary.copy(alpha = 0.25f))),
  )
  val glowModifier = modifier.neonGlow(accent, cornerRadius, 0.5f)
  val inner: @Composable ColumnScope.() -> Unit = {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .background(Brush.linearGradient(listOf(accent.copy(alpha = 0.14f), accent.copy(alpha = 0.02f)))),
    ) {
      // গ্লাস শিন: ওপরের দিকে হালকা সাদা আভা
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(36.dp)
          .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.10f), Color.Transparent))),
      )
      Column(modifier = Modifier.fillMaxWidth(), content = content)
    }
  }
  if (onClick != null) {
    Card(
      onClick = onClick,
      modifier = glowModifier,
      shape = shape,
      colors = container,
      border = borderStroke,
      elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
      content = inner,
    )
  } else {
    Card(
      modifier = glowModifier,
      shape = shape,
      colors = container,
      border = borderStroke,
      elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
      content = inner,
    )
  }
}
