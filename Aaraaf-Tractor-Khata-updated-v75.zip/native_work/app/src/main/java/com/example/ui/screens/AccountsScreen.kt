package com.example.ui.screens

import com.example.ui.components.GlassCard
import com.example.ui.components.GlassAlertDialog
import com.example.ui.components.GlowOutlinedTextField
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.profile.AppProfile

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountsScreen(
  profiles: List<AppProfile>,
  activeId: String,
  accountEmail: String? = null,
  onLogout: (force: Boolean, onResult: (String?) -> Unit) -> Unit = { _, _ -> },
  onBack: () -> Unit,
  onAddProfile: (String) -> AppProfile,
  onRename: (id: String, name: String) -> Unit,
  onDelete: (id: String) -> Unit,
  onSwitch: (id: String) -> Unit,
) {
  var showAddDialog by remember { mutableStateOf(false) }
  var newName by remember { mutableStateOf("") }
  var renameTarget by remember { mutableStateOf<AppProfile?>(null) }
  var renameText by remember { mutableStateOf("") }
  var deleteTarget by remember { mutableStateOf<AppProfile?>(null) }
  var switchTarget by remember { mutableStateOf<AppProfile?>(null) }
  var justAdded by remember { mutableStateOf<AppProfile?>(null) }
  var showLogoutDialog by remember { mutableStateOf(false) }
  var logoutBusy by remember { mutableStateOf(false) }
  var logoutError by remember { mutableStateOf<String?>(null) }

  val activeProfile = profiles.firstOrNull { it.id == activeId }
  val otherProfiles = profiles.filter { it.id != activeId }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("অ্যাকাউন্ট / প্রোফাইল") },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "ফিরে যান")
          }
        },
      )
    },
  ) { padding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(padding),
      contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 24.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      item {
        Text(
          "প্রতিটি প্রোফাইলের কাস্টমার, জমি, কাজ ও পেমেন্টের হিসাব সম্পূর্ণ আলাদা থাকে। প্রোফাইল বদলালে অ্যাপ নতুন করে চালু হবে।",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.padding(bottom = 4.dp),
        )
      }

      // চালু থাকা অ্যাকাউন্ট — সব অপশন (নাম বদল, নতুন প্রোফাইল) এর ভেতরেই
      if (activeProfile != null) {
        item(key = "active_${activeProfile.id}") {
          GlassCard(
            modifier = Modifier.fillMaxWidth().testTag("profile_${activeProfile.id}"),
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
              ) {
                Surface(
                  shape = CircleShape,
                  color = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(46.dp),
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Text(
                      activeProfile.name.trim().firstOrNull()?.toString() ?: "?",
                      style = MaterialTheme.typography.titleLarge,
                      fontWeight = FontWeight.Bold,
                      color = MaterialTheme.colorScheme.onPrimary,
                    )
                  }
                }
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    activeProfile.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                      Icons.Rounded.CheckCircle,
                      contentDescription = null,
                      tint = MaterialTheme.colorScheme.primary,
                      modifier = Modifier.size(14.dp),
                    )
                    Text(
                      "  এখন চালু আছে",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.primary,
                    )
                  }
                }
              }
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                  onClick = {
                    renameTarget = activeProfile
                    renameText = activeProfile.name
                  },
                  modifier = Modifier.weight(1f),
                ) {
                  Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                  Text("  নাম বদলান", maxLines = 1)
                }
                Button(
                  onClick = {
                    newName = ""
                    showAddDialog = true
                  },
                  modifier = Modifier.weight(1f).testTag("add_profile_fab"),
                ) {
                  Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                  Text("  নতুন প্রোফাইল", maxLines = 1)
                }
              }
            }
          }
        }
      }

      if (otherProfiles.isNotEmpty()) {
        item {
          Text(
            "অন্যান্য প্রোফাইল",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 6.dp),
          )
        }
      }
      items(otherProfiles, key = { it.id }) { profile ->
        var menuOpen by remember { mutableStateOf(false) }
        GlassCard(
          onClick = { switchTarget = profile },
          modifier = Modifier.fillMaxWidth().testTag("profile_${profile.id}"),
        ) {
          Row(
            modifier = Modifier.padding(start = 14.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Surface(
              shape = CircleShape,
              color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.18f),
              modifier = Modifier.size(40.dp),
            ) {
              Box(contentAlignment = Alignment.Center) {
                Text(
                  profile.name.trim().firstOrNull()?.toString() ?: "?",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.secondary,
                )
              }
            }
            Column(modifier = Modifier.weight(1f)) {
              Text(
                profile.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                "বদলাতে ট্যাপ করুন",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Box {
              IconButton(onClick = { menuOpen = true }) {
                Icon(Icons.Rounded.MoreVert, contentDescription = "আরও")
              }
              DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                  text = { Text("নাম বদলান") },
                  leadingIcon = { Icon(Icons.Rounded.Edit, contentDescription = null) },
                  onClick = {
                    menuOpen = false
                    renameTarget = profile
                    renameText = profile.name
                  },
                )
                DropdownMenuItem(
                  text = { Text("মুছুন", color = MaterialTheme.colorScheme.error) },
                  leadingIcon = {
                    Icon(Icons.Rounded.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                  },
                  onClick = {
                    menuOpen = false
                    deleteTarget = profile
                  },
                )
              }
            }
          }
        }
      }
      if (!accountEmail.isNullOrBlank()) {
        item(key = "google_account") {
          GlassCard(
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
          ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Text(
                "Google অ্যাকাউন্ট",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              Text(accountEmail, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
              Text(
                "এই Gmail-এর Google Drive-এর ডেটাই এই ফোনে দেখা যায়। অন্য Gmail-এ লগইন করলে এই ফোনের সব ডেটা মুছে ওই Gmail-এর ডেটা আসবে।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              OutlinedButton(
                onClick = { showLogoutDialog = true },
                modifier = Modifier.fillMaxWidth().testTag("logout_btn"),
              ) {
                Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                Text("  লগআউট / অন্য Gmail-এ লগইন", maxLines = 1)
              }
            }
          }
        }
      }
    }
  }

  // লগআউট / অ্যাকাউন্ট বদল
  if (showLogoutDialog) {
    GlassAlertDialog(
      onDismissRequest = { if (!logoutBusy) showLogoutDialog = false },
      title = { Text("লগআউট করবেন?") },
      text = {
        Text(
          "লগআউট করলে এই ফোনের সব প্রোফাইলের ডেটা মুছে যাবে। তারপর যে Gmail দিয়ে লগইন করবেন, সেই Gmail-এর Google Drive-এ থাকা ডেটাই দেখা যাবে।\n\n" +
            "লগআউটের আগে বর্তমান প্রোফাইলের ডেটা Drive-এ সিঙ্ক হবে। অন্য প্রোফাইলগুলো আগে একবার করে খুলে সিঙ্ক হতে দিন, নইলে সেগুলোর নতুন ডেটা হারাতে পারে।"
        )
      },
      confirmButton = {
        TextButton(
          enabled = !logoutBusy,
          onClick = {
            logoutBusy = true
            onLogout(false) { err ->
              logoutBusy = false
              if (err != null) {
                logoutError = err
                showLogoutDialog = false
              }
            }
          },
          modifier = Modifier.testTag("confirm_logout_btn"),
        ) { Text(if (logoutBusy) "অপেক্ষা করুন…" else "লগআউট করুন") }
      },
      dismissButton = {
        TextButton(enabled = !logoutBusy, onClick = { showLogoutDialog = false }) { Text("বাতিল") }
      },
    )
  }

  logoutError?.let { err ->
    GlassAlertDialog(
      onDismissRequest = { logoutError = null },
      title = { Text("সিঙ্ক হয়নি") },
      text = {
        Text(
          "$err\n\nইন্টারনেট ঠিক করে আবার চেষ্টা করা ভালো। তবুও লগআউট করলে যে ডেটা Drive-এ যায়নি তা হারাবে।"
        )
      },
      confirmButton = {
        TextButton(onClick = {
          logoutError = null
          onLogout(true) {}
        }) { Text("তবুও লগআউট", color = MaterialTheme.colorScheme.error) }
      },
      dismissButton = { TextButton(onClick = { logoutError = null }) { Text("বাতিল") } },
    )
  }

  // নতুন প্রোফাইল
  if (showAddDialog) {
    GlassAlertDialog(
      onDismissRequest = { showAddDialog = false },
      title = { Text("নতুন প্রোফাইল") },
      text = {
        GlowOutlinedTextField(
          value = newName,
          onValueChange = { newName = it },
          label = { Text("প্রোফাইলের নাম") },
          placeholder = { Text("যেমন: ট্রাক্টর-০২ / রহিমের হিসাব") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("new_profile_name"),
        )
      },
      confirmButton = {
        TextButton(
          enabled = newName.isNotBlank(),
          onClick = {
            justAdded = onAddProfile(newName)
            showAddDialog = false
          },
        ) { Text("যোগ করুন") }
      },
      dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text("বাতিল") } },
    )
  }

  // নতুন প্রোফাইল যোগ হওয়ার পর সরাসরি যাওয়ার প্রস্তাব
  justAdded?.let { added ->
    GlassAlertDialog(
      onDismissRequest = { justAdded = null },
      title = { Text("\"${added.name}\" তৈরি হয়েছে") },
      text = { Text("এখনই এই প্রোফাইলে যেতে চান? অ্যাপ নতুন করে চালু হবে।") },
      confirmButton = {
        TextButton(onClick = {
          justAdded = null
          onSwitch(added.id)
        }) { Text("এখনই যান") }
      },
      dismissButton = { TextButton(onClick = { justAdded = null }) { Text("পরে") } },
    )
  }

  // নাম বদল
  renameTarget?.let { target ->
    GlassAlertDialog(
      onDismissRequest = { renameTarget = null },
      title = { Text("প্রোফাইলের নাম বদলান") },
      text = {
        GlowOutlinedTextField(
          value = renameText,
          onValueChange = { renameText = it },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
      },
      confirmButton = {
        TextButton(
          enabled = renameText.isNotBlank(),
          onClick = {
            onRename(target.id, renameText)
            renameTarget = null
          },
        ) { Text("সংরক্ষণ") }
      },
      dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("বাতিল") } },
    )
  }

  // প্রোফাইল বদল নিশ্চিতকরণ
  switchTarget?.let { target ->
    GlassAlertDialog(
      onDismissRequest = { switchTarget = null },
      title = { Text("\"${target.name}\" প্রোফাইলে যাবেন?") },
      text = { Text("অ্যাপ নতুন করে চালু হবে এবং ওই প্রোফাইলের হিসাব দেখাবে।") },
      confirmButton = {
        TextButton(onClick = {
          switchTarget = null
          onSwitch(target.id)
        }) { Text("যান") }
      },
      dismissButton = { TextButton(onClick = { switchTarget = null }) { Text("বাতিল") } },
    )
  }

  // মোছার নিশ্চিতকরণ
  deleteTarget?.let { target ->
    GlassAlertDialog(
      onDismissRequest = { deleteTarget = null },
      title = { Text("\"${target.name}\" মুছবেন?") },
      text = {
        Text("এই প্রোফাইলের সব কাস্টমার, জমি, কাজ ও পেমেন্টের হিসাব স্থায়ীভাবে মুছে যাবে। এটি আর ফেরানো যাবে না।")
      },
      confirmButton = {
        TextButton(onClick = {
          onDelete(target.id)
          deleteTarget = null
        }) { Text("মুছে ফেলুন", color = MaterialTheme.colorScheme.error) }
      },
      dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("বাতিল") } },
    )
  }
}
