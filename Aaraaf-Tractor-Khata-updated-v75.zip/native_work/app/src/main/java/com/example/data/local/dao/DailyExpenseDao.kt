package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import com.example.data.local.entity.DailyExpenseEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DailyExpenseDao {
  @Query("SELECT * FROM daily_expenses WHERE isDeleted = 0 ORDER BY expenseDate DESC, createdAt DESC")
  fun observeAll(): Flow<List<DailyExpenseEntity>>

  @Query("SELECT * FROM daily_expenses")
  suspend fun getAllIncludingDeleted(): List<DailyExpenseEntity>

  @Upsert
  suspend fun upsert(expense: DailyExpenseEntity)

  @Upsert
  suspend fun upsertAll(expenses: List<DailyExpenseEntity>)

  @Query("DELETE FROM daily_expenses")
  suspend fun deleteAll()
}
