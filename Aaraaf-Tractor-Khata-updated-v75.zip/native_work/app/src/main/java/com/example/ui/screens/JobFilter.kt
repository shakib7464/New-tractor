package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DateRangePicker
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDateRangePickerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.AgriculturalJobEntity
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.LandEntity
import com.example.domain.billing.FormatUtils
import java.util.Calendar
import java.util.TimeZone

enum class DatePreset(val label: String) {
  ALL("সব তারিখ"),
  TODAY("আজ"),
  YESTERDAY("গতকাল"),
  WEEK("শেষ ৭ দিন"),
  MONTH("এই মাস"),
  CUSTOM("নির্দিষ্ট তারিখ"),
}

/** কাজের তালিকার ফিল্টার (স্ট্যাটাস ছাড়া বাকি সব)। */
data class JobFilter(
  val datePreset: DatePreset = DatePreset.ALL,
  val customStart: Long? = null,
  val customEnd: Long? = null,
  val land: String? = null,      // মাঠ / জমির নাম
  val village: String? = null,   // গ্রাম
  val address: String? = null,   // পাড়া / ঠিকানা
  val onlyDue: Boolean = false,  // শুধু বকেয়া আছে
) {
  val activeCount: Int
    get() = listOf(
      datePreset != DatePreset.ALL, land != null, village != null, address != null, onlyDue,
    ).count { it }

  /** তারিখের সীমা (শুরু, শেষ) — মিলিসেকেন্ডে, শেষ দিনসহ। */
  fun dateRange(now: Long = System.currentTimeMillis()): Pair<Long, Long>? {
    fun startOfDay(c: Calendar): Calendar = c.apply {
      set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
      set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }
    fun endOfDay(c: Calendar): Calendar = c.apply {
      set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59)
      set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
    }
    fun cal(t: Long) = Calendar.getInstance().apply { timeInMillis = t }
    return when (datePreset) {
      DatePreset.ALL -> null
      DatePreset.TODAY -> startOfDay(cal(now)).timeInMillis to endOfDay(cal(now)).timeInMillis
      DatePreset.YESTERDAY -> {
        val y = cal(now).apply { add(Calendar.DAY_OF_YEAR, -1) }
        startOfDay(cal(y.timeInMillis)).timeInMillis to endOfDay(cal(y.timeInMillis)).timeInMillis
      }
      DatePreset.WEEK -> {
        val s = cal(now).apply { add(Calendar.DAY_OF_YEAR, -6) }
        startOfDay(s).timeInMillis to endOfDay(cal(now)).timeInMillis
      }
      DatePreset.MONTH -> {
        val s = cal(now).apply { set(Calendar.DAY_OF_MONTH, 1) }
        startOfDay(s).timeInMillis to endOfDay(cal(now)).timeInMillis
      }
      DatePreset.CUSTOM -> {
        val s = customStart ?: return null
        val e = customEnd ?: s
        startOfDay(cal(s)).timeInMillis to endOfDay(cal(e)).timeInMillis
      }
    }
  }

  fun dateLabel(): String = when (datePreset) {
    DatePreset.CUSTOM -> {
      val s = customStart
      val e = customEnd ?: s
      if (s == null) "তারিখ"
      else if (s == e) FormatUtils.formatDate(s)
      else "${FormatUtils.formatDate(s)} → ${FormatUtils.formatDate(e!!)}"
    }
    else -> datePreset.label
  }

  fun matches(
    job: AgriculturalJobEntity,
    customer: CustomerEntity?,
    land: LandEntity?,
  ): Boolean {
    dateRange()?.let { (s, e) -> if (job.workDate < s || job.workDate > e) return false }
    if (this.land != null && land?.landName?.trim() != this.land) return false
    if (this.village != null && jobVillage(customer, land) != this.village) return false
    if (this.address != null && customer?.address?.trim() != this.address) return false
    if (onlyDue && job.remainingDue <= 0.01) return false
    return true
  }
}

/** গ্রাম: কাস্টমারের গ্রাম, না থাকলে জমির গ্রাম। */
fun jobVillage(customer: CustomerEntity?, land: LandEntity?): String =
  customer?.village?.trim().orEmpty().ifEmpty { land?.village?.trim().orEmpty() }

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun JobFilterSheet(
  filter: JobFilter,
  landOptions: List<String>,
  villageOptions: List<String>,
  addressOptions: List<String>,
  resultCount: Int,
  onChange: (JobFilter) -> Unit,
  onDismiss: () -> Unit,
) {
  var showRangePicker by remember { mutableStateOf(false) }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp)
        .navigationBarsPadding(),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Text("ফিল্টার", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        TextButton(onClick = { onChange(JobFilter()) }) { Text("সব মুছুন") }
      }

      SectionTitle("তারিখ")
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        DatePreset.entries.forEach { p ->
          FilterChip(
            selected = filter.datePreset == p,
            onClick = {
              if (p == DatePreset.CUSTOM) showRangePicker = true
              else onChange(filter.copy(datePreset = p, customStart = null, customEnd = null))
            },
            label = { Text(if (p == DatePreset.CUSTOM && filter.datePreset == p) filter.dateLabel() else p.label) },
          )
        }
      }

      OptionSection("মাঠ / জমি", landOptions, filter.land) { onChange(filter.copy(land = it)) }
      OptionSection("গ্রাম", villageOptions, filter.village) { onChange(filter.copy(village = it)) }
      OptionSection("পাড়া / ঠিকানা", addressOptions, filter.address) { onChange(filter.copy(address = it)) }

      SectionTitle("বকেয়া")
      FilterChip(
        selected = filter.onlyDue,
        onClick = { onChange(filter.copy(onlyDue = !filter.onlyDue)) },
        label = { Text("শুধু বকেয়া আছে এমন কাজ") },
      )

      Spacer(Modifier.height(4.dp))
      Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
        Text("$resultCount টি কাজ দেখুন")
      }
      Spacer(Modifier.height(12.dp))
    }
  }

  if (showRangePicker) {
    val state = rememberDateRangePickerState()
    DatePickerDialog(
      onDismissRequest = { showRangePicker = false },
      confirmButton = {
        TextButton(
          enabled = state.selectedStartDateMillis != null,
          onClick = {
            val s = utcDayToLocal(state.selectedStartDateMillis!!)
            val e = state.selectedEndDateMillis?.let { utcDayToLocal(it) } ?: s
            onChange(filter.copy(datePreset = DatePreset.CUSTOM, customStart = s, customEnd = e))
            showRangePicker = false
          },
        ) { Text("ঠিক আছে") }
      },
      dismissButton = { TextButton(onClick = { showRangePicker = false }) { Text("বাতিল") } },
    ) {
      DateRangePicker(
        state = state,
        modifier = Modifier.height(500.dp),
        title = { Text("তারিখ বাছুন (একদিন বা শুরু–শেষ)", modifier = Modifier.padding(16.dp)) },
      )
    }
  }
}

/** DatePicker UTC মধ্যরাত দেয়; এটাকে স্থানীয় সময়ের একই তারিখে বদলায়। */
private fun utcDayToLocal(utcMillis: Long): Long {
  val u = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = utcMillis }
  return Calendar.getInstance().apply {
    clear()
    set(u.get(Calendar.YEAR), u.get(Calendar.MONTH), u.get(Calendar.DAY_OF_MONTH), 12, 0, 0)
  }.timeInMillis
}

@Composable
private fun SectionTitle(text: String) {
  Text(
    text,
    style = MaterialTheme.typography.labelLarge,
    fontWeight = FontWeight.Bold,
    color = MaterialTheme.colorScheme.primary,
  )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun OptionSection(
  title: String,
  options: List<String>,
  selected: String?,
  onSelect: (String?) -> Unit,
) {
  if (options.isEmpty()) return
  SectionTitle(title)
  FlowRow(
    horizontalArrangement = Arrangement.spacedBy(6.dp),
    verticalArrangement = Arrangement.spacedBy(2.dp),
  ) {
    FilterChip(selected = selected == null, onClick = { onSelect(null) }, label = { Text("সব") })
    options.forEach { o ->
      FilterChip(
        selected = selected == o,
        onClick = { onSelect(if (selected == o) null else o) },
        label = { Text(o) },
      )
    }
  }
}
