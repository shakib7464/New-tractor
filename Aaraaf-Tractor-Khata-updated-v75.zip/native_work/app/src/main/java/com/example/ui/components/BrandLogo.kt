package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.R

/**
 * অ্যাপের গোল লোগো — সোনালি ধাতব রিম, নরম সোনালি আভা, হালকা ছায়া ও কাঁচের মতো ঝিলিক সহ।
 * লোগোর নিচের লাল ফিতেটা (খালি জায়গা) আসল ছবিতে ফাঁকা, তাই তার ওপর অ্যাপের বর্তমান ভার্সন লেখা হয়।
 * অ্যাপ আপডেট হলে BuildConfig বদলায়, ফলে লেখাও নিজে থেকে বদলে যায়।
 *
 * [size] হলো ভেতরের ছবির মাপ; রিম ও আভার জন্য বাইরে সামান্য বাড়তি জায়গা নেয়।
 */
@Composable
fun BrandLogo(size: Dp, contentDescription: String?, modifier: Modifier = Modifier) {
  // লোগো ছবি 512x512 (গোল সোনালি রিংসহ); ভেতরের ছবি ~81% মাপে বসানো।
  // ভার্সন-ফিতে: x≈192..326, y≈370..401 (লোগোর ভেতরের মাপে)
  val ribbonX = size * (192f / 512f)
  val ribbonY = size * (370f / 512f)
  val ribbonW = size * (134.6f / 512f)
  val ribbonH = size * (30.8f / 512f)
  val fontSize = with(LocalDensity.current) { (size.toPx() * 0.047f).toSp() }

  // ছবিতেই সোনালি রিং আছে, তাই বাইরের রিম খুব পাতলা রাখা হলো
  val rim = (size.value * 0.01f).coerceAtLeast(1f).dp
  val glow = size * 0.07f
  val rimBrush = remember {
    Brush.sweepGradient(
      listOf(
        Color(0xFFA5F3FC),
        Color(0xFF22D3EE),
        Color(0xFFA78BFA),
        Color(0xFF7C3AED),
        Color(0xFFA5F3FC),
      ),
    )
  }

  val glowPulse by rememberInfiniteTransition(label = "logo_glow").animateFloat(
    initialValue = 0.55f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
    label = "logo_glow_alpha",
  )

  Box(
    modifier = modifier.size(size + (rim + glow) * 2),
    contentAlignment = Alignment.Center,
  ) {
    // নরম সোনালি আভা (লোগোর চারপাশে)
    Box(
      modifier = Modifier.matchParentSize().graphicsLayer { alpha = glowPulse }.drawBehind {
        val r = this.size.minDimension / 2f
        drawCircle(
          brush = Brush.radialGradient(
            0.80f to Color(0x8022D3EE),
            1f to Color.Transparent,
            center = center,
            radius = r,
          ),
          radius = r,
          center = center,
        )
      },
    )

    // রিম + ছায়া + গোল করে কাটা ছবি
    Box(
      modifier = Modifier
        .size(size + rim * 2)
        .shadow(
          elevation = 8.dp,
          shape = CircleShape,
          ambientColor = Color(0xFF22D3EE),
          spotColor = Color(0xFF7C3AED),
        )
        .border(width = rim, brush = rimBrush, shape = CircleShape)
        .padding(rim)
        .clip(CircleShape),
    ) {
      Image(
        painter = painterResource(id = R.drawable.aaraaf_brand_logo),
        contentDescription = contentDescription,
        contentScale = ContentScale.Fit,
        modifier = Modifier.size(size),
      )
      // কাঁচের মতো হালকা ঝিলিক (উপরের বাম দিক থেকে)
      Box(
        modifier = Modifier.matchParentSize().background(
          Brush.linearGradient(
            0f to Color.White.copy(alpha = 0.16f),
            0.42f to Color.Transparent,
          ),
        ),
      )
      Box(
        modifier = Modifier.offset(x = ribbonX, y = ribbonY).size(width = ribbonW, height = ribbonH),
        contentAlignment = Alignment.Center,
      ) {
        Text(
          text = "v${BuildConfig.VERSION_NAME}.${BuildConfig.VERSION_CODE}",
          maxLines = 1,
          softWrap = false,
          textAlign = TextAlign.Center,
          style = TextStyle(
            color = Color(0xFFFDE68A),
            fontSize = fontSize,
            fontWeight = FontWeight.ExtraBold,
            shadow = Shadow(color = Color(0xB3000000), blurRadius = 2f),
          ),
        )
      }
    }
  }
}
