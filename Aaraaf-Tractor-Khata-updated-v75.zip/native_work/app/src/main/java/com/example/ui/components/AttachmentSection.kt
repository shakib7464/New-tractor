package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.local.entity.AttachmentEntity
import java.io.File

/**
 * Play-Policy compliant Attachment Section using zero-permission Android Photo Picker & SAF.
 */
@Composable
fun AttachmentSection(
  title: String,
  attachments: List<AttachmentEntity>,
  onAddAttachmentUri: (Uri) -> Unit,
  onDeleteAttachment: (String) -> Unit,
) {
  var previewItem by remember { mutableStateOf<AttachmentEntity?>(null) }

  val photoPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri -> uri?.let(onAddAttachmentUri) }

  val docPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument()
  ) { uri -> uri?.let(onAddAttachmentUri) }

  Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(title, style = MaterialTheme.typography.titleSmall)
      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedButton(
          onClick = {
            photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
          },
          modifier = Modifier.height(40.dp),
        ) {
          Icon(Icons.Rounded.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(Modifier.width(4.dp))
          Text("ছবি", style = MaterialTheme.typography.labelMedium)
        }
        OutlinedButton(
          onClick = { docPicker.launch(arrayOf("application/pdf", "image/*")) },
          modifier = Modifier.height(40.dp),
        ) {
          Icon(Icons.Rounded.Description, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(Modifier.width(4.dp))
          Text("ডকুমেন্ট", style = MaterialTheme.typography.labelMedium)
        }
      }
    }

    if (attachments.isNotEmpty()) {
      LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(attachments, key = { it.id }) { att ->
          GlassCard(
            modifier = Modifier
              .width(120.dp)
              .clickable { previewItem = att },
          ) {
            Column(modifier = Modifier.padding(6.dp)) {
              if (att.mimeType.startsWith("image")) {
                AsyncImage(
                  model = File(att.localPath),
                  contentDescription = att.fileName,
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(74.dp)
                    .clip(RoundedCornerShape(8.dp)),
                  contentScale = ContentScale.Crop,
                )
              } else {
                Icon(
                  Icons.Rounded.Description,
                  contentDescription = att.fileName,
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(74.dp)
                    .padding(16.dp),
                )
              }
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
              ) {
                Text(
                  att.fileName,
                  style = MaterialTheme.typography.labelSmall,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                  modifier = Modifier.weight(1f),
                )
                IconButton(
                  onClick = { onDeleteAttachment(att.id) },
                  modifier = Modifier.size(28.dp),
                ) {
                  Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete", modifier = Modifier.size(16.dp))
                }
              }
            }
          }
        }
      }
    }
  }

  previewItem?.let { att ->
    GlassAlertDialog(
      onDismissRequest = { previewItem = null },
      title = { Text(att.fileName, maxLines = 1, overflow = TextOverflow.Ellipsis) },
      text = {
        if (att.mimeType.startsWith("image")) {
          AsyncImage(
            model = File(att.localPath),
            contentDescription = att.fileName,
            modifier = Modifier
              .fillMaxWidth()
              .height(280.dp),
            contentScale = ContentScale.Fit,
          )
        } else {
          Text("ফাইল সংরক্ষিত আছে: ${att.fileName} (${att.fileSizeBytes / 1024} KB)")
        }
      },
      confirmButton = {
        TextButton(onClick = { previewItem = null }) { Text("বন্ধ করুন") }
      },
    )
  }
}
