package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import com.example.BuildConfig
import com.example.update.UpdateInfo
import com.example.update.UpdateManager
import com.example.update.UpdateOutcome
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val AUTO_CHECK_INTERVAL_MS = 10 * 60 * 1000L

/** শেষ সফল স্বয়ংক্রিয় চেকের সময় (প্রসেসের জীবনকাল পর্যন্ত); অ্যাপে ফিরলে ১০ মিনিটের আগে আবার চেক হয় না */
private var lastAutoCheckAt = 0L

private const val PERMISSION_HINT =
  "সেটিংসে এই অ্যাপকে \"অ্যাপ ইনস্টল করার অনুমতি\" দিন। ফিরে এলে নিজে থেকেই ডাউনলোড শুরু হবে।"

private fun sizeText(bytes: Long): String =
  if (bytes > 0) String.format(Locale.US, "%.1f MB", bytes / 1048576.0) else ""

private sealed interface UpdateStatus {
  data object Idle : UpdateStatus
  data object Checking : UpdateStatus
  data object UpToDate : UpdateStatus
  data class Available(val info: UpdateInfo) : UpdateStatus
  data object Downloading : UpdateStatus
  data class NeedsPermission(val info: UpdateInfo) : UpdateStatus
  data class Error(val message: String, val info: UpdateInfo?) : UpdateStatus
}

/** আপডেট স্ক্রিনের "অ্যাপ আপডেট" কার্ড: স্ক্রিন খুললেই নিজে খোঁজে → ডাউনলোড → ইনস্টল */
@Composable
fun UpdateCard() {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val lifecycleOwner = LocalLifecycleOwner.current
  var status by remember { mutableStateOf<UpdateStatus>(UpdateStatus.Idle) }
  var progress by remember { mutableFloatStateOf(0f) }

  val check: () -> Unit = {
    scope.launch {
      status = UpdateStatus.Checking
      status = UpdateManager.fetchLatest().fold(
        onSuccess = { info ->
          if (UpdateManager.isNewer(info)) UpdateStatus.Available(info) else UpdateStatus.UpToDate
        },
        onFailure = { UpdateStatus.Error(it.message ?: "ইন্টারনেট সংযোগ পরীক্ষা করুন", null) },
      )
    }
  }

  val install: (UpdateInfo) -> Unit = { info ->
    scope.launch {
      status = UpdateStatus.Downloading
      progress = 0f
      status = when (val r = UpdateManager.downloadAndInstall(context, info) { progress = it }) {
        UpdateOutcome.Started -> UpdateStatus.Available(info)
        UpdateOutcome.NeedsPermission -> UpdateStatus.NeedsPermission(info)
        is UpdateOutcome.Failed -> UpdateStatus.Error(r.message, info)
      }
    }
  }

  // স্ক্রিন খুললেই নিজে থেকে নতুন ভার্সন খোঁজা
  LaunchedEffect(Unit) {
    if (UpdateManager.isConfigured() && status == UpdateStatus.Idle) check()
  }

  // ইনস্টলের অনুমতি দিয়ে সেটিংস থেকে ফিরলে নিজে থেকেই ডাউনলোড ও ইনস্টল শুরু
  val latestStatus by rememberUpdatedState(status)
  DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_RESUME) {
        val s = latestStatus
        if (s is UpdateStatus.NeedsPermission && UpdateManager.hasInstallPermission(context)) install(s.info)
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }

  GlassCard(modifier = Modifier.fillMaxWidth()) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
      Text("অ্যাপ আপডেট", fontWeight = FontWeight.Bold)
      Text(
        "বর্তমান ভার্সন: ${BuildConfig.VERSION_NAME} (বিল্ড ${BuildConfig.VERSION_CODE})",
        style = MaterialTheme.typography.bodySmall,
      )

      if (!UpdateManager.isConfigured()) {
        Text(
          "এই বিল্ডে আপডেট চালু নেই। GitHub Actions থেকে বানানো APK-তে এটি কাজ করবে।",
          style = MaterialTheme.typography.bodySmall,
        )
        return@Column
      }

      when (val s = status) {
        UpdateStatus.Idle -> Unit
        UpdateStatus.Checking -> Row(verticalAlignment = Alignment.CenterVertically) {
          CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
          Text("  নতুন ভার্সন খোঁজা হচ্ছে…")
        }
        UpdateStatus.UpToDate -> Text("✅ আপনি সর্বশেষ ভার্সন ব্যবহার করছেন।")
        is UpdateStatus.Available -> {
          Text(
            "নতুন ভার্সন পাওয়া গেছে: ${s.info.versionName} (বিল্ড ${s.info.versionCode}) ${sizeText(s.info.sizeBytes)}",
            fontWeight = FontWeight.SemiBold,
          )
        }
        UpdateStatus.Downloading -> {
          LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
          Text("ডাউনলোড হচ্ছে… ${(progress * 100).toInt()}%")
        }
        is UpdateStatus.NeedsPermission -> Text(PERMISSION_HINT)
        is UpdateStatus.Error -> Text(s.message, color = MaterialTheme.colorScheme.error)
      }

      val pending: UpdateInfo? = when (val s = status) {
        is UpdateStatus.Available -> s.info
        is UpdateStatus.NeedsPermission -> s.info
        is UpdateStatus.Error -> s.info
        else -> null
      }
      val busy = status == UpdateStatus.Checking || status == UpdateStatus.Downloading
      if (pending != null && !busy) {
        Button(onClick = { install(pending) }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
          Text("ডাউনলোড ও ইনস্টল করুন")
        }
      }
      if (!busy) {
        OutlinedButton(onClick = check, modifier = Modifier.fillMaxWidth().height(48.dp)) {
          Text("আপডেট আছে কিনা দেখুন")
        }
      }
    }
  }
}

/**
 * অ্যাপ খুললে এবং (১০ মিনিটের বেশি পরে) আবার সামনে এলে নিঃশব্দে নতুন ভার্সন খোঁজে; পেলে একটি ডায়ালগ দেখায়।
 * "পরে" চাপলে শুধু ওই বিল্ডের জন্য লুকায়; আরও নতুন বিল্ড এলে আবার দেখায়। ব্যর্থ হলে কিছুই দেখায় না।
 * ইনস্টলের অনুমতি দিয়ে ফিরলে নিজে থেকেই ডাউনলোড ও ইনস্টল শুরু হয়।
 */
@Composable
fun AutoUpdatePrompt() {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val lifecycleOwner = LocalLifecycleOwner.current
  var info by remember { mutableStateOf<UpdateInfo?>(null) }
  var dismissedCode by rememberSaveable { mutableStateOf(0) }
  var busy by remember { mutableStateOf(false) }
  var progress by remember { mutableFloatStateOf(0f) }
  var message by remember { mutableStateOf<String?>(null) }
  var waitingPermission by remember { mutableStateOf(false) }

  val startInstall: (UpdateInfo) -> Unit = { target ->
    scope.launch {
      busy = true
      message = null
      waitingPermission = false
      progress = 0f
      when (val r = UpdateManager.downloadAndInstall(context, target) { progress = it }) {
        UpdateOutcome.Started -> Unit
        UpdateOutcome.NeedsPermission -> {
          waitingPermission = true
          message = PERMISSION_HINT
        }
        is UpdateOutcome.Failed -> message = r.message
      }
      busy = false
    }
  }

  LaunchedEffect(lifecycleOwner) {
    if (!UpdateManager.isConfigured()) return@LaunchedEffect
    withContext(Dispatchers.IO) { UpdateManager.cleanupOldDownloads(context) }
    lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
      val pending = info
      if (waitingPermission && pending != null && UpdateManager.hasInstallPermission(context)) {
        startInstall(pending)
      } else if (!busy && System.currentTimeMillis() - lastAutoCheckAt >= AUTO_CHECK_INTERVAL_MS) {
        UpdateManager.fetchLatest().onSuccess { latest ->
          lastAutoCheckAt = System.currentTimeMillis()
          if (UpdateManager.isNewer(latest) && !busy) info = latest
        }
      }
    }
  }

  val available = info
  if (available == null || available.versionCode <= dismissedCode) return

  GlassAlertDialog(
    onDismissRequest = { if (!busy) dismissedCode = available.versionCode },
    title = { Text("নতুন আপডেট এসেছে") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("ভার্সন ${available.versionName} (বিল্ড ${available.versionCode}) ${sizeText(available.sizeBytes)}")
        if (busy) {
          LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
          Text("ডাউনলোড হচ্ছে… ${(progress * 100).toInt()}%")
        }
        message?.let {
          Text(
            it,
            style = MaterialTheme.typography.bodySmall,
            color = if (waitingPermission) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
          )
        }
      }
    },
    confirmButton = {
      TextButton(enabled = !busy, onClick = { startInstall(available) }) { Text("আপডেট করুন") }
    },
    dismissButton = {
      TextButton(enabled = !busy, onClick = { dismissedCode = available.versionCode }) { Text("পরে") }
    },
  )
}
