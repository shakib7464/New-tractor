package com.example.ui.screens

import com.example.ui.components.GlowOutlinedTextField
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.ui.graphics.Color
import com.example.ui.components.GlowStatusChip
import com.example.ui.components.ListSkeleton
import com.example.ui.components.Spacing
import com.example.ui.components.SwipeActionBackground
import com.example.ui.components.rememberHaptics
import com.example.ui.components.rememberInitialLoading
import com.example.ui.components.staggeredEntrance
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddTask
import androidx.compose.material.icons.rounded.Agriculture
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.InputChip
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.AgriculturalJobEntity
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.JobStatus
import com.example.data.local.entity.LandEntity
import com.example.domain.billing.FormatUtils
import com.example.localization.AppStrings
import com.example.ui.components.EmptyStateCard
import com.example.ui.theme.LocalLedgerColors

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun JobsScreen(
  jobs: List<AgriculturalJobEntity>,
  customers: List<CustomerEntity>,
  lands: List<LandEntity>,
  strings: AppStrings,
  currencySymbol: String,
  onAddJob: () -> Unit,
  onUpdateStatus: (jobId: String, newStatus: String) -> Unit,
  onDeleteJob: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  var statusFilter by remember { mutableStateOf<String?>(null) }
  var searchQuery by remember { mutableStateOf("") }
  val ledgerColors = LocalLedgerColors.current
  val initialLoading = rememberInitialLoading()

  val custMap = remember(customers) { customers.associateBy { it.id } }
  val landMap = remember(lands) { lands.associateBy { it.id } }

  var filter by remember { mutableStateOf(JobFilter()) }
  var showFilterSheet by remember { mutableStateOf(false) }

  val filtered = remember(jobs, statusFilter, searchQuery, filter, custMap, landMap) {
    val q = searchQuery.trim().lowercase()
    jobs
      .filter { statusFilter == null || it.status == statusFilter }
      .filter { j -> filter.matches(j, custMap[j.customerId], landMap[j.landId]) }
      .filter { j ->
        if (q.isEmpty()) true
        else {
          val cName = custMap[j.customerId]?.fullName?.lowercase().orEmpty()
          val lName = landMap[j.landId]?.landName?.lowercase().orEmpty()
          j.jobCode.lowercase().contains(q) || cName.contains(q) || lName.contains(q)
        }
      }
  }
  val landOptions = remember(jobs, landMap) {
    jobs.mapNotNull { landMap[it.landId]?.landName?.trim() }.filter { it.isNotEmpty() }.distinct().sorted()
  }
  val villageOptions = remember(jobs, custMap, landMap) {
    jobs.map { jobVillage(custMap[it.customerId], landMap[it.landId]) }.filter { it.isNotEmpty() }.distinct().sorted()
  }
  val addressOptions = remember(jobs, custMap) {
    jobs.mapNotNull { custMap[it.customerId]?.address?.trim() }.filter { it.isNotEmpty() }.distinct().sorted()
  }
  val sumBill = filtered.sumOf { it.totalBill }
  val sumDue = filtered.sumOf { it.remainingDue }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    floatingActionButton = {
      FloatingActionButton(
        onClick = onAddJob,
        modifier = Modifier.testTag("jobs_add_fab"),
      ) {
        Icon(Icons.Rounded.AddTask, contentDescription = strings.addJob)
      }
    },
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Spacer(Modifier.height(4.dp))
      GlowOutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
        placeholder = { Text("কাজের কোড, কাস্টমার বা জমি খুঁজুন...") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
      )

      FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(
          selected = statusFilter == null,
          onClick = { statusFilter = null },
          label = { Text("${strings.allFilter} (${jobs.size})") },
        )
        JobStatus.entries.forEach { st ->
          FilterChip(
            selected = statusFilter == st.code,
            onClick = { statusFilter = st.code },
            label = { Text(strings.jobStatusLabel(st.code)) },
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        OutlinedButton(onClick = { showFilterSheet = true }) {
          Icon(Icons.Rounded.FilterList, contentDescription = null)
          Text(
            if (filter.activeCount > 0) "  ফিল্টার (${filter.activeCount})" else "  ফিল্টার",
          )
        }
        Text(
          "${filtered.size} টি • বিল ${FormatUtils.formatTaka(sumBill, currencySymbol)} • বকেয়া ${FormatUtils.formatTaka(sumDue, currencySymbol)}",
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }

      if (filter.activeCount > 0) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          @Composable
          fun active(label: String, onClear: () -> Unit) {
            InputChip(
              selected = true,
              onClick = onClear,
              label = { Text(label) },
              trailingIcon = { Icon(Icons.Rounded.Close, contentDescription = "মুছুন") },
            )
          }
          if (filter.datePreset != DatePreset.ALL) active(filter.dateLabel()) {
            filter = filter.copy(datePreset = DatePreset.ALL, customStart = null, customEnd = null)
          }
          filter.land?.let { v -> active("মাঠ: $v") { filter = filter.copy(land = null) } }
          filter.village?.let { v -> active("গ্রাম: $v") { filter = filter.copy(village = null) } }
          filter.address?.let { v -> active("পাড়া: $v") { filter = filter.copy(address = null) } }
          if (filter.onlyDue) active("শুধু বকেয়া") { filter = filter.copy(onlyDue = false) }
        }
      }

      if (filtered.isEmpty() && initialLoading && searchQuery.isBlank() && statusFilter == null && filter.activeCount == 0) {
        ListSkeleton()
      } else if (filtered.isEmpty()) {
        EmptyStateCard(
          icon = Icons.Rounded.Agriculture,
          message = "কোনো কৃষি কাজ পাওয়া যায়নি",
          actionLabel = strings.addJob,
          onAction = onAddJob,
        )
      } else {
        LazyColumn(
          contentPadding = PaddingValues(bottom = 88.dp),
          verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
          itemsIndexed(filtered, key = { _, item -> item.id }) { index, job ->
            val customer = custMap[job.customerId]
            val land = landMap[job.landId]
            var statusMenuOpen by remember { mutableStateOf(false) }

            val haptics = rememberHaptics()
            val dismissState = rememberSwipeToDismissBoxState(
              confirmValueChange = { value ->
                when (value) {
                  SwipeToDismissBoxValue.StartToEnd -> {
                    // ডানে সোয়াইপ → সম্পন্ন করুন
                    if (job.status != JobStatus.COMPLETED.code) {
                      haptics.confirm()
                      onUpdateStatus(job.id, JobStatus.COMPLETED.code)
                    }
                  }
                  SwipeToDismissBoxValue.EndToStart -> {
                    // বামে সোয়াইপ → ডিলিট
                    haptics.confirm()
                    onDeleteJob(job.id)
                  }
                  SwipeToDismissBoxValue.Settled -> Unit
                }
                false
              },
            )
            SwipeToDismissBox(
              state = dismissState,
              modifier = Modifier.staggeredEntrance(index),
              backgroundContent = {
                SwipeActionBackground(
                  direction = dismissState.dismissDirection,
                  startIcon = Icons.Rounded.CheckCircle,
                  startColor = ledgerColors.paidColor,
                  endIcon = Icons.Rounded.DeleteOutline,
                  endColor = ledgerColors.dueColor,
                )
              },
            ) {
              Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth(),
              ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Column(modifier = Modifier.weight(1f)) {
                      Text(
                        "${job.jobCode} • ${strings.workTypeLabel(job.workType, job.customWorkName)}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                      )
                      Text(
                        "${customer?.fullName ?: "-"} → ${land?.landName ?: "-"}",
                        style = MaterialTheme.typography.bodyMedium,
                      )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      GlowStatusChip(
                        text = strings.jobStatusLabel(job.status),
                        color = when (job.status) {
                          JobStatus.COMPLETED.code -> ledgerColors.paidColor
                          JobStatus.IN_PROGRESS.code -> ledgerColors.advanceColor
                          JobStatus.CANCELLED.code -> ledgerColors.dueColor
                          else -> Color(0xFFF59E0B)
                        },
                        modifier = Modifier.clickable { statusMenuOpen = true },
                      )
                      DropdownMenu(expanded = statusMenuOpen, onDismissRequest = { statusMenuOpen = false }) {
                        JobStatus.entries.forEach { st ->
                          DropdownMenuItem(
                            text = { Text(strings.jobStatusLabel(st.code)) },
                            onClick = {
                              statusMenuOpen = false
                              onUpdateStatus(job.id, st.code)
                            },
                          )
                        }
                      }
                      IconButton(onClick = {
                        haptics.confirm()
                        onDeleteJob(job.id)
                      }) {
                        Icon(Icons.Rounded.DeleteOutline, contentDescription = strings.delete)
                      }
                    }
                  }

                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                  ) {
                    Text(
                      "${FormatUtils.formatDate(job.workDate)} • ${FormatUtils.formatNumber(job.landArea)} ${strings.unitLabel(job.areaUnit)} × ${job.numberOfPasses?.coerceAtLeast(1) ?: 1} বার @ ${FormatUtils.formatTaka(job.rate, currencySymbol)}",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }

                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                  ) {
                    Text(
                      "${strings.totalBill}: ${FormatUtils.formatTaka(job.totalBill, currencySymbol)}",
                      style = MaterialTheme.typography.labelLarge,
                      fontWeight = FontWeight.Bold,
                    )
                    Text(
                      "${strings.remainingDue}: ${FormatUtils.formatTaka(job.remainingDue, currencySymbol)}",
                      style = MaterialTheme.typography.labelLarge,
                      fontWeight = FontWeight.Bold,
                      color = if (job.remainingDue > 0.01) ledgerColors.dueColor else ledgerColors.paidColor,
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  if (showFilterSheet) {
    JobFilterSheet(
      filter = filter,
      landOptions = landOptions,
      villageOptions = villageOptions,
      addressOptions = addressOptions,
      resultCount = filtered.size,
      onChange = { filter = it },
      onDismiss = { showFilterSheet = false },
    )
  }
}
