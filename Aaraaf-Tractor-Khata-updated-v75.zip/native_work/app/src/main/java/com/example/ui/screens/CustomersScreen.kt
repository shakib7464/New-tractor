package com.example.ui.screens

import com.example.ui.components.GlowOutlinedTextField
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.ui.platform.LocalContext
import com.example.ui.components.GlowStatusChip
import com.example.ui.components.ListSkeleton
import com.example.ui.components.Spacing
import com.example.ui.components.SwipeActionBackground
import com.example.ui.components.rememberHaptics
import com.example.ui.components.rememberInitialLoading
import com.example.ui.components.staggeredEntrance
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.billing.FormatUtils
import com.example.domain.model.CustomerFinancialSummary
import com.example.localization.AppStrings
import com.example.ui.components.EmptyStateCard
import com.example.ui.theme.LocalLedgerColors

@Composable
fun CustomersScreen(
  summaries: List<CustomerFinancialSummary>,
  strings: AppStrings,
  currencySymbol: String,
  initialFilterDuesOnly: Boolean = false,
  onSelectCustomer: (String) -> Unit,
  onAddCustomer: () -> Unit,
  onOneClickBulkPrint: () -> Unit,
  onConfigureBulkPrint: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var searchQuery by remember { mutableStateOf("") }
  var filterIndex by remember(initialFilterDuesOnly) {
    mutableIntStateOf(if (initialFilterDuesOnly) 1 else 0)
  }
  val ledgerColors = LocalLedgerColors.current
  val initialLoading = rememberInitialLoading()

  val filtered = remember(summaries, searchQuery, filterIndex) {
    val q = searchQuery.trim().lowercase()
    summaries
      .filter { s ->
        when (filterIndex) {
          1 -> s.totalOutstandingBalance > 0.01
          2 -> s.remainingAdvance > 0.01
          3 -> s.totalOutstandingBalance <= 0.01 && s.totalBilled > 0.01
          else -> true
        }
      }
      .filter { s ->
        if (q.isEmpty()) true
        else {
          s.customer.fullName.lowercase().contains(q) ||
            s.customer.mobileNumber.lowercase().contains(q) ||
            s.customer.village.lowercase().contains(q)
        }
      }
  }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    floatingActionButton = {
      FloatingActionButton(
        onClick = onAddCustomer,
        modifier = Modifier.padding(bottom = 72.dp).testTag("customers_add_fab"),
      ) {
        Icon(Icons.Rounded.PersonAdd, contentDescription = strings.addCustomer)
      }
    },
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      GlowOutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
        placeholder = { Text(strings.searchCustomersHint) },
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("customer_search_input"),
      )

      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()),
      ) {
        FilterChip(
          selected = filterIndex == 0,
          onClick = { filterIndex = 0 },
          label = { Text("${strings.allFilter} (${summaries.size})") },
        )
        FilterChip(
          selected = filterIndex == 1,
          onClick = { filterIndex = 1 },
          label = { Text(strings.withDuesFilter) },
        )
        FilterChip(
          selected = filterIndex == 2,
          onClick = { filterIndex = 2 },
          label = { Text(strings.withAdvanceFilter) },
        )
        FilterChip(
          selected = filterIndex == 3,
          onClick = { filterIndex = 3 },
          label = { Text("পেইড ✅") },
        )
      }

      if (filtered.isEmpty() && initialLoading && searchQuery.isBlank()) {
        ListSkeleton()
      } else if (filtered.isEmpty()) {
        EmptyStateCard(
          icon = Icons.Rounded.PersonAdd,
          message = strings.noCustomersFound,
          actionLabel = strings.addCustomer,
          onAction = onAddCustomer,
        )
      } else {
        LazyColumn(
          contentPadding = PaddingValues(bottom = 88.dp),
          verticalArrangement = Arrangement.spacedBy(Spacing.md),
        ) {
          itemsIndexed(filtered, key = { _, item -> item.customer.id }) { index, summary ->
            val c = summary.customer
            val context = LocalContext.current
            val haptics = rememberHaptics()
            val dismissState = rememberSwipeToDismissBoxState(
              confirmValueChange = { value ->
                when (value) {
                  SwipeToDismissBoxValue.StartToEnd -> {
                    // ডানে সোয়াইপ → কল
                    haptics.confirm()
                    if (c.mobileNumber.isNotBlank()) {
                      runCatching {
                        context.startActivity(
                          Intent(Intent.ACTION_DIAL, Uri.parse("tel:${c.mobileNumber}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                      }
                    }
                  }
                  SwipeToDismissBoxValue.EndToStart -> {
                    // বামে সোয়াইপ → বিস্তারিত
                    haptics.confirm()
                    onSelectCustomer(c.id)
                  }
                  SwipeToDismissBoxValue.Settled -> Unit
                }
                false
              },
            )
            SwipeToDismissBox(
              state = dismissState,
              modifier = Modifier.staggeredEntrance(index),
              backgroundContent = {
                SwipeActionBackground(
                  direction = dismissState.dismissDirection,
                  startIcon = Icons.Rounded.Call,
                  startColor = ledgerColors.paidColor,
                  endIcon = Icons.Rounded.Visibility,
                  endColor = MaterialTheme.colorScheme.primary,
                )
              },
            ) {
              Card(
                onClick = { onSelectCustomer(c.id) },
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("customer_card_${c.customerCode}"),
              ) {
                Row(
                  modifier = Modifier.padding(14.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(
                      "${c.fullName} (${c.customerCode})",
                      style = MaterialTheme.typography.titleMedium,
                      fontWeight = FontWeight.Bold,
                    )
                    Text(
                      listOf(c.mobileNumber, c.village.ifBlank { c.address.ifBlank { "-" } }).filter { it.isNotBlank() }.joinToString(" • "),
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                      Surface(
                        shape = MaterialTheme.shapes.small,
                        color = MaterialTheme.colorScheme.surfaceVariant,
                      ) {
                        Text(
                          "${summary.lands.size} জমি • ${summary.jobs.size} কাজ",
                          style = MaterialTheme.typography.labelSmall,
                          modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        )
                      }
                    }
                  }
                  Column(horizontalAlignment = Alignment.End) {
                    val (chipText, chipColor) = when {
                      summary.totalOutstandingBalance > 0.01 -> "বকেয়া" to ledgerColors.dueColor
                      summary.remainingAdvance > 0.01 -> "অগ্রিম" to ledgerColors.advanceColor
                      else -> "পরিশোধিত" to ledgerColors.paidColor
                    }
                    GlowStatusChip(text = chipText, color = chipColor)
                    Spacer(Modifier.height(Spacing.xs))
                    Text(
                      FormatUtils.formatTaka(summary.totalOutstandingBalance, currencySymbol),
                      style = MaterialTheme.typography.titleMedium,
                      fontWeight = FontWeight.Bold,
                      color = if (summary.totalOutstandingBalance > 0.01) ledgerColors.dueColor else ledgerColors.paidColor,
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
