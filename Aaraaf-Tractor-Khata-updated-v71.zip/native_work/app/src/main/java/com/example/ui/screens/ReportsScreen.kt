package com.example.ui.screens

import androidx.compose.ui.graphics.Color
import com.example.ui.components.NeonTrendChart
import com.example.ui.components.GlowOutlinedTextField
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.TableView
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.AgriculturalJobEntity
import com.example.data.local.entity.JobStatus
import com.example.data.local.entity.PaymentEntity
import com.example.domain.billing.BillingCalculator
import com.example.domain.billing.FormatUtils
import com.example.domain.model.BulkPrintFilter
import com.example.domain.model.CustomerFinancialSummary
import com.example.domain.model.ReportCategory
import com.example.domain.model.ReportPeriod
import com.example.localization.AppStrings
import com.example.ui.components.BulkPrintProminentCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.LocalLedgerColors

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReportsScreen(
  summaries: List<CustomerFinancialSummary>,
  jobs: List<AgriculturalJobEntity>,
  payments: List<PaymentEntity>,
  strings: AppStrings,
  currencySymbol: String,
  onOneClickBulkPrint: (BulkPrintFilter) -> Unit,
  onConfigureBulkPrint: () -> Unit,
  onExportExcel: (BulkPrintFilter) -> Unit,
  onSelectCustomer: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  var period by remember { mutableStateOf(ReportPeriod.ALL_TIME) }
  var category by remember { mutableStateOf(ReportCategory.OVERVIEW) }
  var customStart by remember { mutableStateOf("") }
  var customEnd by remember { mutableStateOf("") }
  val ledgerColors = LocalLedgerColors.current

  val (startMs, endMs) = remember(period, customStart, customEnd) {
    val now = System.currentTimeMillis()
    when (period) {
      ReportPeriod.DAILY -> FormatUtils.startOfDayMillis(now) to FormatUtils.endOfDayMillis(now)
      ReportPeriod.WEEKLY -> FormatUtils.startOfWeekMillis(now) to FormatUtils.endOfDayMillis(now)
      ReportPeriod.MONTHLY -> FormatUtils.startOfMonthMillis(now) to FormatUtils.endOfDayMillis(now)
      ReportPeriod.YEARLY -> FormatUtils.startOfYearMillis(now) to FormatUtils.endOfDayMillis(now)
      ReportPeriod.ALL_TIME -> null to null
      ReportPeriod.CUSTOM -> {
        val s = FormatUtils.parseDmyDate(customStart)?.let { FormatUtils.startOfDayMillis(it) }
        val e = FormatUtils.parseDmyDate(customEnd)?.let { FormatUtils.endOfDayMillis(it) }
        s to e
      }
    }
  }

  val activeFilter = remember(startMs, endMs, category) {
    BulkPrintFilter(
      startDateMillis = startMs,
      endDateMillis = endMs,
      onlyWithOutstandingDues = category == ReportCategory.OUTSTANDING_DUES,
    )
  }

  val filteredJobs = remember(jobs, startMs, endMs, category) {
    jobs.filter { j ->
      val inRange = (startMs == null || j.workDate >= startMs) && (endMs == null || j.workDate <= endMs)
      inRange && when (category) {
        ReportCategory.COMPLETED_JOBS -> j.status == JobStatus.COMPLETED.code
        ReportCategory.PENDING_JOBS -> j.status == JobStatus.PENDING.code || j.status == JobStatus.IN_PROGRESS.code
        else -> j.status != JobStatus.CANCELLED.code
      }
    }
  }

  val filteredPayments = remember(payments, startMs, endMs) {
    payments.filter { p ->
      (startMs == null || p.paymentDate >= startMs) && (endMs == null || p.paymentDate <= endMs)
    }
  }

  val periodBilled = BillingCalculator.roundCurrency(filteredJobs.sumOf { it.totalBill })
  val periodCollected = BillingCalculator.roundCurrency(filteredPayments.sumOf { it.amount })
  val totalOutstanding = BillingCalculator.roundCurrency(summaries.sumOf { it.totalOutstandingBalance })

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    // Mandatory One-Click Bulk Print Button in Reports Section
    item {
      BulkPrintProminentCard(
        title = strings.bulkPrintAllCustomersBtn,
        subtitle = strings.bulkPrintSubtitle,
        buttonTag = "reports_bulk_print_btn",
        onOneClickPrint = { onOneClickBulkPrint(activeFilter) },
        onConfigureFilter = onConfigureBulkPrint,
      )
    }

    // Excel Export
    item {
      OutlinedButton(
        onClick = { onExportExcel(activeFilter) },
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("export_excel_btn"),
      ) {
        Icon(Icons.Rounded.TableView, contentDescription = null)
        Spacer(Modifier.width(8.dp))
        Text(strings.exportExcel, fontWeight = FontWeight.SemiBold)
      }
    }

    // Period Chips
    item {
      SectionHeader(title = "সময়কাল ফিল্টার")
      Spacer(Modifier.height(6.dp))
      FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf(
          ReportPeriod.DAILY to "দৈনিক",
          ReportPeriod.WEEKLY to "সাপ্তাহিক",
          ReportPeriod.MONTHLY to "মাসিক",
          ReportPeriod.YEARLY to "বাৎসরিক",
          ReportPeriod.ALL_TIME to "সর্বমোট",
          ReportPeriod.CUSTOM to "কাস্টম তারিখ",
        ).forEach { (p, label) ->
          FilterChip(selected = period == p, onClick = { period = p }, label = { Text(label) })
        }
      }
      if (period == ReportPeriod.CUSTOM) {
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          GlowOutlinedTextField(
            value = customStart,
            onValueChange = { customStart = it },
            label = { Text(strings.startDate) },
            placeholder = { Text("01-01-2026") },
            modifier = Modifier.weight(1f),
          )
          GlowOutlinedTextField(
            value = customEnd,
            onValueChange = { customEnd = it },
            label = { Text(strings.endDate) },
            placeholder = { Text("31-12-2026") },
            modifier = Modifier.weight(1f),
          )
        }
      }
    }

    // Category Chips
    item {
      SectionHeader(title = "রিপোর্টের ধরন")
      Spacer(Modifier.height(6.dp))
      FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf(
          ReportCategory.OVERVIEW to "সারসংক্ষেপ",
          ReportCategory.CUSTOMER_WISE to "কাস্টমার ভিত্তিক",
          ReportCategory.LAND_WISE to "জমি ভিত্তিক",
          ReportCategory.WORK_RECORDS to "কাজের রিপোর্ট",
          ReportCategory.PAYMENT_COLLECTION to "আদায় রিপোর্ট",
          ReportCategory.OUTSTANDING_DUES to "বকেয়া রিপোর্ট",
          ReportCategory.COMPLETED_JOBS to "সম্পন্ন কাজ",
          ReportCategory.PENDING_JOBS to "অপেক্ষমাণ কাজ",
        ).forEach { (cat, label) ->
          FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(label) })
        }
      }
    }

    // Summary Metrics Card
    item {
      Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text("নির্বাচিত সময়ের সারসংক্ষেপ", fontWeight = FontWeight.Bold)
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("কাজের সংখ্যা: ${filteredJobs.size} টি")
            Text("${strings.totalBilled}: ${FormatUtils.formatTaka(periodBilled, currencySymbol)}", fontWeight = FontWeight.SemiBold)
          }
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("পেমেন্ট সংখ্যা: ${filteredPayments.size} টি")
            Text("${strings.totalCollected}: ${FormatUtils.formatTaka(periodCollected, currencySymbol)}", color = ledgerColors.paidColor, fontWeight = FontWeight.SemiBold)
          }
          Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("বর্তমান মোট বকেয়া:")
            Text(FormatUtils.formatTaka(totalOutstanding, currencySymbol), color = ledgerColors.dueColor, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // গত ৬ মাসের ট্রেন্ড: বিল বনাম আদায় (নিয়ন লাইন চার্ট)
    item {
      val bnMonths = listOf("জানু", "ফেব্রু", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টে", "অক্টো", "নভে", "ডিসে")
      val trend = remember(jobs, payments) {
        fun monthKey(ms: Long): Int {
          val c = java.util.Calendar.getInstance().apply { timeInMillis = ms }
          return c.get(java.util.Calendar.YEAR) * 12 + c.get(java.util.Calendar.MONTH)
        }
        val keys = (5 downTo 0).map { back ->
          monthKey(java.util.Calendar.getInstance().apply { add(java.util.Calendar.MONTH, -back) }.timeInMillis)
        }
        val billed = DoubleArray(6)
        val collected = DoubleArray(6)
        jobs.forEach { j ->
          if (j.status != JobStatus.CANCELLED.code) {
            val i = keys.indexOf(monthKey(j.workDate))
            if (i >= 0) billed[i] += j.totalBill
          }
        }
        payments.forEach { p ->
          val i = keys.indexOf(monthKey(p.paymentDate))
          if (i >= 0) collected[i] += p.amount
        }
        Triple(keys.map { bnMonths[it % 12] }, billed.toList(), collected.toList())
      }
      NeonTrendChart(
        title = "গত ৬ মাসের ট্রেন্ড",
        labels = trend.first,
        seriesA = trend.second,
        seriesB = trend.third,
        nameA = strings.totalBilled,
        nameB = strings.totalCollected,
        colorA = Color(0xFF8B5CF6),
        colorB = Color(0xFF22D3EE),
      )
    }

    // Category Details
    when (category) {
      ReportCategory.OVERVIEW, ReportCategory.CUSTOMER_WISE, ReportCategory.OUTSTANDING_DUES -> {
        val list = if (category == ReportCategory.OUTSTANDING_DUES) {
          summaries.filter { it.totalOutstandingBalance > 0.01 }.sortedByDescending { it.totalOutstandingBalance }
        } else summaries
        items(list, key = { it.customer.id }) { s ->
          Surface(
            onClick = { onSelectCustomer(s.customer.id) },
            shape = MaterialTheme.shapes.medium,
            tonalElevation = 1.dp,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
              Column(modifier = Modifier.weight(1f)) {
                Text("${s.customer.fullName} (${s.lands.size} জমি)", fontWeight = FontWeight.SemiBold)
                Text("বিল: ${FormatUtils.formatTaka(s.totalBilled, currencySymbol)} • জমা: ${FormatUtils.formatTaka(s.totalPaid, currencySymbol)}", style = MaterialTheme.typography.bodySmall)
              }
              Text(
                FormatUtils.formatTaka(s.totalOutstandingBalance, currencySymbol),
                fontWeight = FontWeight.Bold,
                color = if (s.totalOutstandingBalance > 0.01) ledgerColors.dueColor else ledgerColors.paidColor,
              )
            }
          }
        }
      }
      ReportCategory.LAND_WISE -> {
        val allLands = summaries.flatMap { s -> s.lands.map { s.customer to it } }
        items(allLands, key = { it.second.land.id }) { (cust, ls) ->
          Surface(shape = MaterialTheme.shapes.medium, tonalElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
              Column(modifier = Modifier.weight(1f)) {
                Text("${ls.land.landName} (${cust.fullName})", fontWeight = FontWeight.SemiBold)
                Text("${FormatUtils.formatNumber(ls.land.sizeValue)} ${strings.unitLabel(ls.land.unit)} • ${ls.jobs.size} কাজ", style = MaterialTheme.typography.bodySmall)
              }
              Text(
                FormatUtils.formatTaka(ls.currentBalance, currencySymbol),
                fontWeight = FontWeight.Bold,
                color = if (ls.currentBalance > 0.01) ledgerColors.dueColor else ledgerColors.paidColor,
              )
            }
          }
        }
      }
      ReportCategory.WORK_RECORDS, ReportCategory.COMPLETED_JOBS, ReportCategory.PENDING_JOBS -> {
        items(filteredJobs, key = { it.id }) { j ->
          Surface(shape = MaterialTheme.shapes.medium, tonalElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
              Column(modifier = Modifier.weight(1f)) {
                Text("${j.jobCode} • ${strings.workTypeLabel(j.workType, j.customWorkName)}", fontWeight = FontWeight.SemiBold)
                Text("${FormatUtils.formatDate(j.workDate)} • ${strings.jobStatusLabel(j.status)}", style = MaterialTheme.typography.bodySmall)
              }
              Text(FormatUtils.formatTaka(j.totalBill, currencySymbol), fontWeight = FontWeight.Bold)
            }
          }
        }
      }
      ReportCategory.PAYMENT_COLLECTION -> {
        items(filteredPayments, key = { it.id }) { p ->
          Surface(shape = MaterialTheme.shapes.medium, tonalElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
              Column(modifier = Modifier.weight(1f)) {
                Text("${p.receiptNumber} (${strings.paymentMethodLabel(p.paymentMethod)})", fontWeight = FontWeight.SemiBold)
                Text(FormatUtils.formatDate(p.paymentDate), style = MaterialTheme.typography.bodySmall)
              }
              Text(FormatUtils.formatTaka(p.amount, currencySymbol), fontWeight = FontWeight.Bold, color = ledgerColors.paidColor)
            }
          }
        }
      }
      ReportCategory.ADVANCE_PAYMENTS -> {
        val advCusts = summaries.filter { it.totalAdvanceReceived > 0 || it.remainingAdvance > 0 }
        items(advCusts, key = { it.customer.id }) { s ->
          Surface(shape = MaterialTheme.shapes.medium, tonalElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
              Column(modifier = Modifier.weight(1f)) {
                Text(s.customer.fullName, fontWeight = FontWeight.SemiBold)
                Text("গৃহীত: ${FormatUtils.formatTaka(s.totalAdvanceReceived, currencySymbol)} • ব্যবহৃত: ${FormatUtils.formatTaka(s.totalAdvanceUsed, currencySymbol)}", style = MaterialTheme.typography.bodySmall)
              }
              Text(
                FormatUtils.formatTaka(s.remainingAdvance, currencySymbol),
                fontWeight = FontWeight.Bold,
                color = ledgerColors.advanceColor,
              )
            }
          }
        }
      }
    }
  }
}
