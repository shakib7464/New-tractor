package com.example.ui.screens

import com.example.ui.components.GlassAlertDialog
import com.example.ui.components.GlowOutlinedTextField
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.CustomerEntity
import com.example.domain.billing.BillingCalculator
import com.example.domain.billing.FormatUtils
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import com.example.localization.AppStrings

/** কাস্টমার যোগের ফর্মেই প্রথম জমির তথ্য (ঐচ্ছিক) */
data class NewCustomerLand(
  val landName: String,
  val sizeKatha: Double,
  val passes: Int,
  val ratePerKatha: Double,
  val deposit: Double,
  val receiverName: String,
)

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun CustomerFormDialog(
  existing: CustomerEntity? = null,
  initialName: String = "",
  showLandSection: Boolean = false,
  defaultRatePerKatha: Double = 0.0,
  knownLandNames: List<String> = emptyList(),
  strings: AppStrings,
  onDismiss: () -> Unit,
  onSave: (
    fullName: String,
    mobileNumber: String,
    address: String,
    village: String,
    unionName: String,
    upazila: String,
    district: String,
    notes: String,
    regDate: Long,
    customRate: Double?,
    land: NewCustomerLand?,
  ) -> Unit,
) {
  var fullName by remember { mutableStateOf(existing?.fullName ?: initialName) }
  var mobile by remember { mutableStateOf(existing?.mobileNumber ?: "") }
  var address by remember { mutableStateOf(existing?.address ?: "") }
  var village by remember { mutableStateOf(existing?.village ?: "") }
  var unionName by remember { mutableStateOf(existing?.unionName ?: "") }
  var upazila by remember { mutableStateOf(existing?.upazila ?: "") }
  var district by remember { mutableStateOf(existing?.district ?: "") }
  var notes by remember { mutableStateOf(existing?.notes ?: "") }
  var regDateText by remember {
    mutableStateOf(FormatUtils.formatDate(existing?.registrationDate ?: System.currentTimeMillis()))
  }
  var customRateText by remember { mutableStateOf(existing?.customRatePerUnit?.toString() ?: "") }
  var errorMsg by remember { mutableStateOf<String?>(null) }

  // প্রথম জমির তথ্য (শুধু নতুন কাস্টমার যোগে)
  val withLand = existing == null && showLandSection
  var landName by remember { mutableStateOf("") }
  var landNameExpanded by remember { mutableStateOf(false) }
  var sizeText by remember { mutableStateOf("") }
  var passesText by remember { mutableStateOf("1") }
  var rateText by remember {
    mutableStateOf(
      if (defaultRatePerKatha > 0) {
        val r = BillingCalculator.roundCurrency(defaultRatePerKatha)
        if (r % 1.0 == 0.0) r.toLong().toString() else r.toString()
      } else ""
    )
  }
  var depositText by remember { mutableStateOf("") }
  var receiverName by remember { mutableStateOf("") }
  val sizeNow = sizeText.toDoubleOrNull() ?: 0.0
  val passesNow = (passesText.toIntOrNull() ?: 0).coerceAtLeast(0)
  val rateNow = rateText.toDoubleOrNull() ?: 0.0
  val depositNow = (depositText.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
  val landBill = BillingCalculator.roundCurrency(sizeNow * passesNow * rateNow)

  GlassAlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(if (existing == null) strings.addCustomer else "${strings.edit}: ${existing.fullName}") },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        GlowOutlinedTextField(
          value = fullName,
          onValueChange = { fullName = it; errorMsg = null },
          label = { Text(strings.fullName) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("customer_name_input"),
        )
        GlowOutlinedTextField(
          value = mobile,
          onValueChange = { mobile = it; errorMsg = null },
          label = { Text(strings.mobileNumber.replace("*", "").trim()) },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("customer_mobile_input"),
        )
        GlowOutlinedTextField(
          value = village,
          onValueChange = { village = it },
          label = { Text(strings.village) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("customer_village_input"),
        )
        GlowOutlinedTextField(
          value = regDateText,
          onValueChange = { regDateText = it },
          label = { Text(strings.registrationDate) },
          placeholder = { Text("DD-MM-YYYY") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        GlowOutlinedTextField(
          value = address,
          onValueChange = { address = it },
          label = { Text(strings.address) },
          modifier = Modifier.fillMaxWidth(),
        )
        GlowOutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text(strings.notes) },
          modifier = Modifier.fillMaxWidth(),
        )
        if (withLand) {
          HorizontalDivider()
          Text("জমি যোগ (ঐচ্ছিক)", style = MaterialTheme.typography.titleSmall)
          val suggestions = run {
            val q = landName.trim()
            if (q.isEmpty()) emptyList()
            else knownLandNames
              .filter { it.contains(q, ignoreCase = true) && !it.equals(q, ignoreCase = true) }
              .sortedBy { if (it.startsWith(q, ignoreCase = true)) 0 else 1 }
              .take(8)
          }
          ExposedDropdownMenuBox(
            expanded = landNameExpanded && suggestions.isNotEmpty(),
            onExpandedChange = { landNameExpanded = it },
          ) {
            GlowOutlinedTextField(
              value = landName,
              onValueChange = { landName = it; landNameExpanded = true },
              label = { Text("জমির নাম / পরিচয়") },
              singleLine = true,
              modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryEditable).fillMaxWidth().testTag("customer_land_name_input"),
            )
            ExposedDropdownMenu(
              expanded = landNameExpanded && suggestions.isNotEmpty(),
              onDismissRequest = { landNameExpanded = false },
            ) {
              suggestions.forEach { n ->
                DropdownMenuItem(text = { Text(n) }, onClick = { landName = n; landNameExpanded = false })
              }
            }
          }
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlowOutlinedTextField(
              value = sizeText,
              onValueChange = { sizeText = it; errorMsg = null },
              label = { Text("জমির পরিমাণ (কাঠা)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              singleLine = true,
              modifier = Modifier.weight(1f).testTag("customer_land_size_input"),
            )
            GlowOutlinedTextField(
              value = passesText,
              onValueChange = { passesText = it.filter { ch -> ch.isDigit() }.trimStart('0') },
              label = { Text("কয়বার চাষ") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              singleLine = true,
              modifier = Modifier.weight(1f),
            )
          }
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlowOutlinedTextField(
              value = rateText,
              onValueChange = { rateText = it },
              label = { Text("প্রতি কাঠার রেট") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              singleLine = true,
              modifier = Modifier.weight(1f),
            )
            GlowOutlinedTextField(
              value = depositText,
              onValueChange = { depositText = it },
              label = { Text("জমা (এখনই দেওয়া টাকা)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              singleLine = true,
              modifier = Modifier.weight(1f),
            )
          }
          if (sizeNow > 0.0) {
            Text("চাষের মোট বিল: ${FormatUtils.formatTaka(landBill)}", style = MaterialTheme.typography.bodyMedium)
            Text(
              "জমা বাদে মোট বাকি: ${FormatUtils.formatTaka(BillingCalculator.roundCurrency(landBill - depositNow))}",
              style = MaterialTheme.typography.titleSmall,
            )
          }
          GlowOutlinedTextField(
            value = receiverName,
            onValueChange = { receiverName = it },
            label = { Text("পেমেন্ট গ্রহণকারীর নাম") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
        }
        if (errorMsg != null) {
          Text(errorMsg!!, color = androidx.compose.material3.MaterialTheme.colorScheme.error)
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (fullName.isBlank()) {
            errorMsg = "নাম আবশ্যক"
            return@Button
          }
          val regMs = FormatUtils.parseDmyDate(regDateText) ?: System.currentTimeMillis()
          if (withLand && (landName.isNotBlank() || sizeText.isNotBlank()) && sizeNow <= 0.0) {
            errorMsg = "জমি যোগ করতে সঠিক জমির পরিমাণ দিন"
            return@Button
          }
          val landData = if (withLand && sizeNow > 0.0) {
            NewCustomerLand(landName.trim(), sizeNow, passesNow, rateNow, depositNow, receiverName.trim())
          } else null
          onSave(
            fullName, mobile, address, village, unionName, upazila, district,
            notes, regMs, customRateText.toDoubleOrNull(), landData,
          )
        },
        modifier = Modifier.height(48.dp).testTag("save_customer_btn"),
      ) {
        Text(strings.save)
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss, modifier = Modifier.height(48.dp)) {
        Text(strings.cancel)
      }
    },
  )
}
