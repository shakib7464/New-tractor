@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.ui.screens

import com.example.ui.components.GlassAlertDialog
import com.example.ui.components.GlowOutlinedTextField
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.StaffPaymentCategory
import com.example.data.local.entity.StaffPaymentEntity
import com.example.domain.billing.FormatUtils

private fun staffNumText(v: Double): String = if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()

/**
 * হেল্পার/ড্রাইভার অথবা গাড়ির মালিককে দেওয়া টাকার হিসাব: কাকে, কত টাকা, কোন তারিখে।
 * [category] দিয়ে ঠিক হয় কোন হিসাব দেখানো হবে (StaffPaymentCategory)।
 */
@Composable
fun StaffPaymentsScreen(
  category: String,
  payments: List<StaffPaymentEntity>,
  currencySymbol: String,
  onBack: () -> Unit,
  onSave: (String, Long, Double, String) -> Unit,
  onUpdate: (StaffPaymentEntity, String, Long, Double, String) -> Unit,
  onDelete: (StaffPaymentEntity) -> Unit,
) {
  val isHelper = category == StaffPaymentCategory.HELPER_DRIVER
  val screenTitle = if (isHelper) "বেতনের হিসাব" else "গাড়ির মালিকের হিসাব"
  val personLabel = if (isHelper) "কর্মীর নাম" else "গাড়ির মালিকের নাম"
  val emptyName = if (isHelper) "নাম নেই" else "গাড়ির মালিক"

  var showDialog by remember { mutableStateOf(false) }
  var editing by remember { mutableStateOf<StaffPaymentEntity?>(null) }
  var pendingDelete by remember { mutableStateOf<StaffPaymentEntity?>(null) }
  var filterName by remember { mutableStateOf<String?>(null) }

  fun displayName(p: StaffPaymentEntity) = p.personName.ifBlank { emptyName }

  val totalAll = payments.sumOf { it.amount }
  val perPerson = payments.groupBy { displayName(it) }
    .map { (name, list) -> name to list.sumOf { it.amount } }
    .sortedBy { it.first.lowercase() }
  val visible = if (filterName == null) payments else payments.filter { displayName(it) == filterName }

  Scaffold(
    floatingActionButton = {
      ExtendedFloatingActionButton(
        onClick = { showDialog = true },
        icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
        text = { Text(if (isHelper) "বেতন যোগ করুন" else "পরিশোধ যোগ করুন") },
      )
    },
  ) { innerPadding ->
    Column(
      modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        IconButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "ফিরে যান")
        }
        Text(screenTitle, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
      }

      LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Text(if (isHelper) "মোট বেতন পরিশোধ" else "মালিককে মোট পরিশোধ", style = MaterialTheme.typography.titleSmall)
              Text(
                FormatUtils.formatTaka(totalAll, currencySymbol),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
              )
              Text("${payments.size} টি লেনদেন • ব্যক্তি অনুযায়ী হিসাব দেখুন", style = MaterialTheme.typography.bodySmall)
            }
          }
        }

        if (perPerson.size > 1) {
          item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
              Text(if (isHelper) "কর্মী অনুযায়ী বেতন" else "মালিক অনুযায়ী পরিশোধ", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
              Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth().horizontalScrollCompat(),
              ) {
                FilterChip(
                  selected = filterName == null,
                  onClick = { filterName = null },
                  label = { Text("সবাই") },
                )
                perPerson.forEach { (name, sum) ->
                  FilterChip(
                    selected = filterName == name,
                    onClick = { filterName = if (filterName == name) null else name },
                    label = { Text("$name • ${FormatUtils.formatTaka(sum, currencySymbol)}") },
                  )
                }
              }
            }
          }
        }

        if (visible.isEmpty()) {
          item { Text("এখনো কোনো হিসাব যোগ হয়নি") }
        }
        items(visible, key = { it.id }) { p ->
          Card(
            modifier = Modifier.fillMaxWidth().clickable { editing = p },
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
          ) {
            Column(modifier = Modifier.fillMaxWidth().padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 6.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                  Text(displayName(p), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                  Text(if (isHelper) "বেতন গ্রহণকারী" else "গাড়ির মালিক", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(
                  FormatUtils.formatTaka(p.amount, currencySymbol),
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary,
                )
                IconButton(onClick = { pendingDelete = p }) {
                  Icon(Icons.Rounded.Delete, contentDescription = "মুছুন", tint = MaterialTheme.colorScheme.error)
                }
              }
              androidx.compose.material3.HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f))
              Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("তারিখ  ${FormatUtils.formatDate(p.paymentDate)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (p.note.isNotBlank()) {
                  Spacer(Modifier.weight(1f))
                  Text(p.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                }
              }
            }
          }
        }
        item { androidx.compose.foundation.layout.Spacer(Modifier.padding(bottom = 72.dp)) }
      }
    }
  }

  if (showDialog) {
    StaffPaymentDialog(
      title = "নতুন এন্ট্রি",
      personLabel = personLabel,
      nameRequired = isHelper,
      knownNames = perPerson.map { it.first }.filter { it != emptyName },
      initial = null,
      onDismiss = { showDialog = false },
      onSave = { name, date, amount, note ->
        onSave(name, date, amount, note)
        showDialog = false
      },
    )
  }

  editing?.let { e ->
    StaffPaymentDialog(
      title = "সংশোধন করুন",
      personLabel = personLabel,
      nameRequired = isHelper,
      knownNames = perPerson.map { it.first }.filter { it != emptyName },
      initial = e,
      onDismiss = { editing = null },
      onSave = { name, date, amount, note ->
        onUpdate(e, name, date, amount, note)
        editing = null
      },
    )
  }

  pendingDelete?.let { p ->
    GlassAlertDialog(
      onDismissRequest = { pendingDelete = null },
      title = { Text("এন্ট্রি মুছবেন?") },
      text = {
        Text("${displayName(p)} • ${FormatUtils.formatTaka(p.amount, currencySymbol)} • ${FormatUtils.formatDate(p.paymentDate)}")
      },
      confirmButton = {
        Button(onClick = {
          onDelete(p)
          pendingDelete = null
        }) { Text("মুছুন") }
      },
      dismissButton = { OutlinedButton(onClick = { pendingDelete = null }) { Text("বাতিল") } },
    )
  }
}

@Composable
private fun StaffPaymentDialog(
  title: String,
  personLabel: String,
  nameRequired: Boolean,
  knownNames: List<String>,
  initial: StaffPaymentEntity?,
  onDismiss: () -> Unit,
  onSave: (String, Long, Double, String) -> Unit,
) {
  var name by remember { mutableStateOf(initial?.personName ?: "") }
  var dateText by remember {
    mutableStateOf(FormatUtils.formatDate(initial?.paymentDate ?: System.currentTimeMillis()))
  }
  var amountText by remember { mutableStateOf(initial?.let { staffNumText(it.amount) } ?: "") }
  var note by remember { mutableStateOf(initial?.note ?: "") }

  val amount = amountText.toDoubleOrNull() ?: 0.0
  val parsedDate = FormatUtils.parseDmyDate(dateText)
  val canSave = amount > 0.0 && parsedDate != null && (!nameRequired || name.isNotBlank())

  GlassAlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(title) },
    text = {
      Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.verticalScroll(rememberScrollState()),
      ) {
        GlowOutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text(if (nameRequired) personLabel else "$personLabel (ঐচ্ছিক)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        val suggestions = knownNames.filter {
          name.isNotBlank() && it.contains(name.trim(), ignoreCase = true) && !it.equals(name.trim(), ignoreCase = true)
        }.take(4)
        if (suggestions.isNotEmpty()) {
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            suggestions.forEach { s -> TextButton(onClick = { name = s }) { Text(s) } }
          }
        }
        GlowOutlinedTextField(
          value = amountText,
          onValueChange = { amountText = it },
          label = { Text("কত টাকা") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        GlowOutlinedTextField(
          value = dateText,
          onValueChange = { dateText = it },
          label = { Text("তারিখ") },
          placeholder = { Text("DD-MM-YYYY") },
          isError = parsedDate == null,
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        GlowOutlinedTextField(
          value = note,
          onValueChange = { note = it },
          label = { Text("বেতনের বিবরণ (ঐচ্ছিক)") },
          modifier = Modifier.fillMaxWidth(),
        )
      }
    },
    confirmButton = {
      Button(
        enabled = canSave,
        onClick = { onSave(name, parsedDate ?: System.currentTimeMillis(), amount, note) },
      ) { Text("সংরক্ষণ করুন") }
    },
    dismissButton = { OutlinedButton(onClick = onDismiss) { Text("বাতিল") } },
  )
}

@Composable
private fun Modifier.horizontalScrollCompat(): Modifier =
  this.then(Modifier.horizontalScroll(rememberScrollState()))
