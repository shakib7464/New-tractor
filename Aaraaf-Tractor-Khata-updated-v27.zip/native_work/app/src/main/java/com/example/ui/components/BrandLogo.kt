package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.R

/**
 * অ্যাপের গোল লোগো। লোগোর নিচের লাল ফিতেটা (খালি জায়গা) আসল ছবিতে ফাঁকা,
 * তাই তার ওপর অ্যাপের বর্তমান ভার্সন লেখা হয়। অ্যাপ আপডেট হলে BuildConfig বদলায়,
 * ফলে লেখাও নিজে থেকে বদলে যায়।
 */
@Composable
fun BrandLogo(size: Dp, contentDescription: String?, modifier: Modifier = Modifier) {
  // লোগো ছবি 512x512; লাল ফিতে প্রায় x=177..343, y=397..435
  val ribbonX = size * (177f / 512f)
  val ribbonY = size * (397f / 512f)
  val ribbonW = size * (166f / 512f)
  val ribbonH = size * (38f / 512f)
  val fontSize = with(LocalDensity.current) { (size.toPx() * 0.058f).toSp() }

  Box(modifier = modifier.size(size).clip(CircleShape)) {
    Image(
      painter = painterResource(id = R.drawable.aaraaf_brand_logo),
      contentDescription = contentDescription,
      contentScale = ContentScale.Fit,
      modifier = Modifier.size(size),
    )
    Box(
      modifier = Modifier.offset(x = ribbonX, y = ribbonY).size(width = ribbonW, height = ribbonH),
      contentAlignment = Alignment.Center,
    ) {
      Text(
        text = "v${BuildConfig.VERSION_NAME}.${BuildConfig.VERSION_CODE}",
        maxLines = 1,
        softWrap = false,
        textAlign = TextAlign.Center,
        style = TextStyle(
          color = Color.White,
          fontSize = fontSize,
          fontWeight = FontWeight.ExtraBold,
          shadow = Shadow(color = Color(0xB3000000), blurRadius = 2f),
        ),
      )
    }
  }
}
