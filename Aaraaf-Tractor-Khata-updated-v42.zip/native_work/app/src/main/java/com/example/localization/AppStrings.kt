package com.example.localization

import com.example.data.local.entity.AdvanceEntryType
import com.example.data.local.entity.BillingMethod
import com.example.data.local.entity.JobStatus
import com.example.data.local.entity.LandUnit
import com.example.data.local.entity.PaymentMethod
import com.example.data.local.entity.TransactionType
import com.example.data.local.entity.WorkType
import com.example.data.preferences.AppLanguage

data class AppStrings(
  val appName: String,
  val navDashboard: String,
  val navCustomers: String,
  val navJobs: String,
  val navReports: String,
  val navSettings: String,

  // Dashboard
  val dashboardSubtitle: String,
  val totalCustomers: String,
  val totalLands: String,
  val totalJobs: String,
  val completedJobs: String,
  val pendingJobs: String,
  val totalBilled: String,
  val totalCollected: String,
  val totalOutstanding: String,
  val totalAdvanceReceived: String,
  val remainingAdvance: String,
  val todaysWork: String,
  val todaysCollection: String,
  val monthlyBilling: String,
  val monthlyCollection: String,
  val quickActions: String,
  val addCustomer: String,
  val addLand: String,
  val addJob: String,
  val receivePayment: String,
  val outstandingDues: String,
  val viewReports: String,
  val printStatements: String,
  val bulkPrintAllCustomersBtn: String,
  val bulkPrintSubtitle: String,
  val recentActivities: String,
  val noActivitiesYet: String,

  // Customers
  val searchCustomersHint: String,
  val allFilter: String,
  val withDuesFilter: String,
  val withAdvanceFilter: String,
  val noCustomersFound: String,
  val customerProfile: String,
  val fullName: String,
  val mobileNumber: String,
  val address: String,
  val village: String,
  val unionLabel: String,
  val upazila: String,
  val district: String,
  val notes: String,
  val registrationDate: String,
  val customRateOptional: String,
  val landsOwned: String,
  val jobsHistory: String,
  val paymentsHistory: String,
  val advanceLedger: String,
  val duplicateCustomerError: String,
  val printCustomerStatement: String,

  // Lands
  val landName: String,
  val landSize: String,
  val landUnit: String,
  val cropInfo: String,
  val cultivationSeason: String,
  val openingBalance: String,
  val locationDetails: String,
  val landLedger: String,
  val printLandStatement: String,
  val rateHistory: String,
  val manualAdjustment: String,
  val refundEntry: String,

  // Jobs
  val workDate: String,
  val workType: String,
  val customWorkName: String,
  val billingMethod: String,
  val landArea: String,
  val rate: String,
  val workingHours: String,
  val baseBill: String,
  val additionalCharges: String,
  val discount: String,
  val totalBill: String,
  val advanceAdjustment: String,
  val amountPaidNow: String,
  val remainingDue: String,
  val jobStatus: String,
  val tractorLabel: String,
  val rotavatorWidth: String,
  val workingDepth: String,
  val numberOfPasses: String,
  val startTime: String,
  val finishTime: String,
  val operatorName: String,
  val repeatWorkHint: String,

  // Payments & Advances
  val paymentDate: String,
  val paymentAmount: String,
  val paymentMethod: String,
  val paymentTarget: String,
  val receiptNumber: String,
  val previousBalance: String,
  val remainingBalance: String,
  val receiveAdvance: String,
  val adjustFromAdvance: String,
  val refundAdvance: String,
  val totalAdvanceUsed: String,
  val generateReceiptPdf: String,

  // Bulk Print & Reports
  val bulkPrintDialogTitle: String,
  val selectCustomers: String,
  val allCustomers: String,
  val selectLands: String,
  val allLands: String,
  val dateRange: String,
  val allDates: String,
  val startDate: String,
  val endDate: String,
  val onlyOutstandingCustomers: String,
  val includeZeroBalanceCustomers: String,
  val generateCombinedPdf: String,
  val generatingPdfProgress: String,
  val cancel: String,
  val previewPdf: String,
  val printSystem: String,
  val savePdf: String,
  val sharePdf: String,
  val exportExcel: String,

  // Tractors, Backup, Recycle Bin, Audit, Security
  val tractorsTitle: String,
  val addTractor: String,
  val tractorName: String,
  val tractorBrand: String,
  val tractorModel: String,
  val tractorReg: String,
  val activeStatus: String,
  val backupRestoreTitle: String,
  val googleDriveConnect: String,
  val googleDriveConnected: String,
  val backupNow: String,
  val autoBackup: String,
  val wifiOnlyBackup: String,
  val lastBackupLabel: String,
  val exportJson: String,
  val importJson: String,
  val restoreBackup: String,
  val recycleBinTitle: String,
  val recycleBinRetentionNote: String,
  val restoreItem: String,
  val permanentDelete: String,
  val auditLogTitle: String,
  val attachmentsTitle: String,
  val addPhotoAttachment: String,
  val settingsTitle: String,
  val languageLabel: String,
  val themeLabel: String,
  val pinLockLabel: String,
  val biometricLabel: String,
  val defaultRatesLabel: String,
  val save: String,
  val edit: String,
  val delete: String,
  val close: String,
  val confirm: String,
  val multiDeviceSyncNote: String,
) {
  fun unitLabel(code: String): String = when (code) {
    LandUnit.DECIMAL.code -> if (navDashboard == "ড্যাশবোর্ড") "শতাংশ" else "Decimal"
    LandUnit.KATHA.code -> if (navDashboard == "ড্যাশবোর্ড") "কাঠা" else "Katha"
    LandUnit.BIGHA.code -> if (navDashboard == "ড্যাশবোর্ড") "বিঘা" else "Bigha"
    LandUnit.ACRE.code -> if (navDashboard == "ড্যাশবোর্ড") "একর" else "Acre"
    else -> code
  }

  fun workTypeLabel(code: String, custom: String = ""): String {
    val bn = navDashboard == "ড্যাশবোর্ড"
    return when (code) {
      WorkType.ROTAVATOR.code -> if (bn) "রোটাভেটর" else "Rotavator"
      WorkType.LAND_PLOUGHING.code -> if (bn) "জমি চাষ" else "Land Ploughing"
      WorkType.HARROWING.code -> if (bn) "মই / হ্যারোইং" else "Harrowing"
      WorkType.LAND_PREPARATION.code -> if (bn) "জমি প্রস্তুতি" else "Land Preparation"
      WorkType.CUSTOM.code -> custom.ifBlank { if (bn) "অন্যান্য কৃষি কাজ" else "Custom Work" }
      else -> code
    }
  }

  fun billingMethodLabel(code: String): String {
    val bn = navDashboard == "ড্যাশবোর্ড"
    return when (code) {
      BillingMethod.PER_DECIMAL.code -> if (bn) "প্রতি শতাংশ" else "Per Decimal"
      BillingMethod.PER_KATHA.code -> if (bn) "প্রতি কাঠা" else "Per Katha"
      BillingMethod.PER_BIGHA.code -> if (bn) "প্রতি বিঘা" else "Per Bigha"
      BillingMethod.PER_ACRE.code -> if (bn) "প্রতি একর" else "Per Acre"
      BillingMethod.PER_HOUR.code -> if (bn) "প্রতি ঘণ্টা" else "Per Hour"
      BillingMethod.FIXED_AMOUNT.code -> if (bn) "নির্ধারিত টাকা" else "Fixed Amount"
      BillingMethod.CUSTOM_AMOUNT.code -> if (bn) "কাস্টম বিল" else "Custom Amount"
      else -> code
    }
  }

  fun jobStatusLabel(code: String): String {
    val bn = navDashboard == "ড্যাশবোর্ড"
    return when (code) {
      JobStatus.PENDING.code -> if (bn) "বাকি / অপেক্ষমাণ" else "Pending"
      JobStatus.IN_PROGRESS.code -> if (bn) "চলমান" else "In Progress"
      JobStatus.COMPLETED.code -> if (bn) "সম্পন্ন" else "Completed"
      JobStatus.CANCELLED.code -> if (bn) "বাতিল" else "Cancelled"
      else -> code
    }
  }

  fun paymentMethodLabel(code: String): String {
    val bn = navDashboard == "ড্যাশবোর্ড"
    return when (code) {
      PaymentMethod.CASH.code -> if (bn) "নগদ (Cash)" else "Cash"
      PaymentMethod.BANK.code -> if (bn) "ব্যাংক" else "Bank"
      PaymentMethod.BKASH.code -> if (bn) "বিকাশ (bKash)" else "bKash"
      PaymentMethod.NAGAD.code -> if (bn) "নগদ (Nagad)" else "Nagad"
      PaymentMethod.OTHER.code -> if (bn) "অন্যান্য" else "Other"
      else -> code
    }
  }

  fun transactionTypeLabel(code: String): String {
    val bn = navDashboard == "ড্যাশবোর্ড"
    return when (code) {
      TransactionType.OPENING_BALANCE.code -> if (bn) "পূর্বের বকেয়া (Opening)" else "Opening Balance"
      TransactionType.WORK_CHARGE.code -> if (bn) "চাষের বিল" else "Work Charge"
      TransactionType.ADDITIONAL_CHARGE.code -> if (bn) "অতিরিক্ত চার্জ" else "Additional Charge"
      TransactionType.DISCOUNT.code -> if (bn) "ডিসকাউন্ট / ছাড়" else "Discount"
      TransactionType.PAYMENT.code -> if (bn) "পেমেন্ট জমা" else "Payment"
      TransactionType.ADVANCE_RECEIVED.code -> if (bn) "অগ্রিম গ্রহণ" else "Advance Received"
      TransactionType.ADVANCE_ADJUSTMENT.code -> if (bn) "অগ্রিম সমন্বয়" else "Advance Adjustment"
      TransactionType.REFUND.code -> if (bn) "ফেরত (Refund)" else "Refund"
      TransactionType.MANUAL_ADJUSTMENT.code -> if (bn) "ম্যানুয়াল সমন্বয়" else "Manual Adjustment"
      else -> code
    }
  }

  fun advanceTypeLabel(code: String): String {
    val bn = navDashboard == "ড্যাশবোর্ড"
    return when (code) {
      AdvanceEntryType.RECEIVED.code -> if (bn) "অগ্রিম জমা" else "Received"
      AdvanceEntryType.ADJUSTED.code -> if (bn) "বিলে সমন্বয়" else "Adjusted"
      AdvanceEntryType.REFUNDED.code -> if (bn) "অগ্রিম ফেরত" else "Refunded"
      else -> code
    }
  }

  companion object {
    fun forLanguage(language: AppLanguage): AppStrings =
      if (language == AppLanguage.BENGALI) Bengali else English

    val Bengali = AppStrings(
      appName = "ট্র্যাক্টর খাতা",
      navDashboard = "ড্যাশবোর্ড",
      navCustomers = "কাস্টমার",
      navJobs = "কাজ ও বিল",
      navReports = "রিপোর্ট",
      navSettings = "আরও",
      dashboardSubtitle = "জমি ও ট্রাক্টর হিসাব ব্যবস্থাপনা",
      totalCustomers = "মোট কাস্টমার",
      totalLands = "মোট নিবন্ধিত জমি",
      totalJobs = "মোট কাজ",
      completedJobs = "সম্পন্ন কাজ",
      pendingJobs = "অপেক্ষমাণ কাজ",
      totalBilled = "মোট বিল",
      totalCollected = "মোট জমা",
      totalOutstanding = "মোট বকেয়া",
      totalAdvanceReceived = "মোট অগ্রিম গ্রহণ",
      remainingAdvance = "অবশিষ্ট অগ্রিম",
      todaysWork = "আজকের কাজ",
      todaysCollection = "আজকের আদায়",
      monthlyBilling = "মাসিক বিল",
      monthlyCollection = "মাসিক আদায়",
      quickActions = "দ্রুত কার্যক্রম",
      addCustomer = "কাস্টমার যোগ",
      addLand = "জমি চাষ",
      addJob = "নতুন কাজ",
      receivePayment = "পেমেন্ট গ্রহণ",
      outstandingDues = "বকেয়া তালিকা",
      viewReports = "রিপোর্ট দেখুন",
      printStatements = "স্টেটমেন্ট প্রিন্ট",
      bulkPrintAllCustomersBtn = "সব কাস্টমারের হিসাব একসাথে প্রিন্ট",
      bulkPrintSubtitle = "সকল কাস্টমার, জমি, কাজ, পেমেন্ট ও বকেয়ার সমন্বিত A4 PDF তৈরি করুন",
      recentActivities = "সাম্প্রতিক কার্যক্রম",
      noActivitiesYet = "এখনো কোনো কার্যক্রম নেই। নতুন কাস্টমার বা কাজ যোগ করে শুরু করুন।",
      searchCustomersHint = "নাম, মোবাইল বা গ্রাম দিয়ে খুঁজুন...",
      allFilter = "সকল",
      withDuesFilter = "বকেয়া আছে",
      withAdvanceFilter = "অগ্রিম আছে",
      noCustomersFound = "কোনো কাস্টমার পাওয়া যায়নি",
      customerProfile = "কাস্টমার প্রোফাইল",
      fullName = "পূর্ণ নাম *",
      mobileNumber = "মোবাইল নম্বর *",
      address = "ঠিকানা",
      village = "গ্রাম",
      unionLabel = "ইউনিয়ন",
      upazila = "উপজেলা",
      district = "জেলা",
      notes = "নোট / মন্তব্য",
      registrationDate = "নিবন্ধনের তারিখ",
      customRateOptional = "কাস্টমার-ভিত্তিক রেট (ঐচ্ছিক)",
      landsOwned = "জমিসমূহ",
      jobsHistory = "কাজের ইতিহাস",
      paymentsHistory = "পেমেন্ট ইতিহাস",
      advanceLedger = "অগ্রিম হিসাব",
      duplicateCustomerError = "এই মোবাইল নম্বর বা একই গ্রাম ও নামে কাস্টমার ইতিমধ্যে নিবন্ধিত আছে!",
      printCustomerStatement = "কাস্টমারের হিসাব প্রিন্ট / PDF",
      landName = "জমির নাম / পরিচয় *",
      landSize = "জমির পরিমাণ *",
      landUnit = "পরিমাপের একক",
      cropInfo = "ফসলের তথ্য",
      cultivationSeason = "চাষের মৌসুম",
      openingBalance = "পূর্বের বকেয়া (Opening Due)",
      locationDetails = "জমির অবস্থান / দাগ নং",
      landLedger = "জমির আলাদা খতিয়ান (Ledger)",
      printLandStatement = "জমির হিসাব PDF",
      rateHistory = "রেট ইতিহাস",
      manualAdjustment = "ম্যানুয়াল সমন্বয়",
      refundEntry = "ফেরত (Refund)",
      workDate = "কাজের তারিখ",
      workType = "কাজের ধরন",
      customWorkName = "কাস্টম কাজের নাম",
      billingMethod = "বিলের ধরন",
      landArea = "জমির পরিমাণ",
      rate = "দর / রেট (৳)",
      workingHours = "কাজের সময় (ঘণ্টা)",
      baseBill = "মূল বিল",
      additionalCharges = "অতিরিক্ত চার্জ",
      discount = "ডিসকাউন্ট / ছাড়",
      totalBill = "সর্বমোট বিল",
      advanceAdjustment = "অগ্রিম থেকে সমন্বয়",
      amountPaidNow = "নগদ/পরিশোধিত জমা",
      remainingDue = "অবশিষ্ট বকেয়া",
      jobStatus = "কাজের অবস্থা",
      tractorLabel = "ট্রাক্টর",
      rotavatorWidth = "রোটাভেটর প্রস্থ",
      workingDepth = "চাষের গভীরতা",
      numberOfPasses = "কত চাষ (Pass)",
      startTime = "শুরুর সময়",
      finishTime = "শেষের সময়",
      operatorName = "অপারেটরের নাম",
      repeatWorkHint = "একই জমিতে পুনরায় কাজ করলে নতুন আলাদা রেকর্ড তৈরি হবে",
      paymentDate = "পেমেন্ট তারিখ",
      paymentAmount = "টাকার পরিমাণ (৳) *",
      paymentMethod = "পেমেন্ট মাধ্যম",
      paymentTarget = "পেমেন্টের খাত",
      receiptNumber = "রসিদ নং",
      previousBalance = "পূর্বের বকেয়া",
      remainingBalance = "অবশিষ্ট বকেয়া",
      receiveAdvance = "অগ্রিম গ্রহণ",
      adjustFromAdvance = "অগ্রিম থেকে বিল সমন্বয়",
      refundAdvance = "অগ্রিম ফেরত",
      totalAdvanceUsed = "ব্যবহৃত অগ্রিম",
      generateReceiptPdf = "রসিদ PDF / প্রিন্ট",
      bulkPrintDialogTitle = "সব কাস্টমারের হিসাব একসাথে প্রিন্ট",
      selectCustomers = "কাস্টমার নির্বাচন",
      allCustomers = "সকল কাস্টমার",
      selectLands = "জমি নির্বাচন",
      allLands = "সকল জমি",
      dateRange = "তারিখ সীমা",
      allDates = "সকল তারিখ",
      startDate = "শুরুর তারিখ (DD-MM-YYYY)",
      endDate = "শেষের তারিখ (DD-MM-YYYY)",
      onlyOutstandingCustomers = "শুধুমাত্র বকেয়া থাকা কাস্টমার",
      includeZeroBalanceCustomers = "শূন্য বকেয়াসহ সকল কাস্টমার",
      generateCombinedPdf = "সমন্বিত PDF তৈরি করুন",
      generatingPdfProgress = "PDF তৈরি হচ্ছে...",
      cancel = "বাতিল",
      previewPdf = "প্রিভিউ",
      printSystem = "প্রিন্ট",
      savePdf = "সেভ PDF",
      sharePdf = "শেয়ার (WhatsApp)",
      exportExcel = "Excel (.xlsx) এক্সপোর্ট",
      tractorsTitle = "ট্রাক্টর ব্যবস্থাপনা",
      addTractor = "নতুন ট্রাক্টর যোগ",
      tractorName = "ট্রাক্টরের নাম *",
      tractorBrand = "ব্র্যান্ড",
      tractorModel = "মডেল",
      tractorReg = "রেজিস্ট্রেশন তথ্য",
      activeStatus = "সক্রিয়",
      backupRestoreTitle = "Google Drive ব্যাকআপ ও রিস্টোর",
      googleDriveConnect = "Google অ্যাকাউন্ট যুক্ত করুন",
      googleDriveConnected = "যুক্ত অ্যাকাউন্ট",
      backupNow = "এখনই ব্যাকআপ নিন",
      autoBackup = "ইন্টারনেট পেলে স্বয়ংক্রিয় ব্যাকআপ",
      wifiOnlyBackup = "শুধুমাত্র Wi-Fi তে ব্যাকআপ",
      lastBackupLabel = "সর্বশেষ সফল ব্যাকআপ",
      exportJson = "JSON ব্যাকআপ এক্সপোর্ট",
      importJson = "JSON ব্যাকআপ ইমপোর্ট",
      restoreBackup = "রিস্টোর করুন",
      recycleBinTitle = "রিসাইকেল বিন (৩০ দিন)",
      recycleBinRetentionNote = "মুছে ফেলা তথ্য ৩০ দিন পর্যন্ত পুনরুদ্ধার করা যাবে।",
      restoreItem = "পুনরুদ্ধার",
      permanentDelete = "স্থায়ীভাবে মুছুন",
      auditLogTitle = "অডিট লগ (কার্যক্রম ইতিহাস)",
      attachmentsTitle = "ছবি ও ডকুমেন্ট সংযুক্তি",
      addPhotoAttachment = "ছবি যোগ করুন",
      settingsTitle = "সেটিংস ও নিরাপত্তা",
      languageLabel = "ভাষা (Language)",
      themeLabel = "থিম (Theme)",
      pinLockLabel = "অ্যাপ লক (পিন / প্যাটার্ন / পাসওয়ার্ড)",
      biometricLabel = "ফিঙ্গারপ্রিন্ট আনলক",
      defaultRatesLabel = "ডিফল্ট চাষের রেট",
      save = "সংরক্ষণ করুন",
      edit = "সম্পাদনা",
      delete = "মুছুন",
      close = "বন্ধ করুন",
      confirm = "নিশ্চিত করুন",
      multiDeviceSyncNote = "দ্রষ্টব্য: Google Drive ব্যাকআপ ও রিস্টোর হলো পূর্ণ ডেটাবেস ও ছবির স্ন্যাপশট সংরক্ষণ পদ্ধতি। রিয়েল-টাইম একাধিক ডিভাইস সিঙ্ক করার জন্য ভবিষ্যতে ক্লাউড সার্ভার (যেমন Firestore/API) প্রয়োজন হবে; বর্তমানে সব রেকর্ডে UUID, ডিভাইস আইডি ও কনফ্লিক্ট শনাক্তকরণ প্রস্তুত রয়েছে।",
    )

    val English = AppStrings(
      appName = "Tractor Khata",
      navDashboard = "Dashboard",
      navCustomers = "Customers",
      navJobs = "Jobs & Bills",
      navReports = "Reports",
      navSettings = "More",
      dashboardSubtitle = "Agricultural Land & Tractor Ledger",
      totalCustomers = "Total Customers",
      totalLands = "Registered Lands",
      totalJobs = "Total Jobs",
      completedJobs = "Completed Jobs",
      pendingJobs = "Pending Jobs",
      totalBilled = "Total Billed",
      totalCollected = "Total Deposited",
      totalOutstanding = "Total Outstanding",
      totalAdvanceReceived = "Advance Received",
      remainingAdvance = "Remaining Advance",
      todaysWork = "Today's Work",
      todaysCollection = "Today's Collection",
      monthlyBilling = "Monthly Billing",
      monthlyCollection = "Monthly Collection",
      quickActions = "Quick Actions",
      addCustomer = "Add Customer",
      addLand = "Add Land",
      addJob = "Add Work",
      receivePayment = "Receive Payment",
      outstandingDues = "Outstanding Dues",
      viewReports = "View Reports",
      printStatements = "Print Statements",
      bulkPrintAllCustomersBtn = "সব কাস্টমারের হিসাব একসাথে প্রিন্ট",
      bulkPrintSubtitle = "One-click combined A4 PDF of all customers, lands, jobs, payments & dues",
      recentActivities = "Recent Activities",
      noActivitiesYet = "No activities yet. Add a customer or agricultural job to begin.",
      searchCustomersHint = "Search by name, mobile, or village...",
      allFilter = "All",
      withDuesFilter = "With Dues",
      withAdvanceFilter = "With Advance",
      noCustomersFound = "No customers found",
      customerProfile = "Customer Profile",
      fullName = "Full Name *",
      mobileNumber = "Mobile Number *",
      address = "Address",
      village = "Village",
      unionLabel = "Union",
      upazila = "Upazila",
      district = "District",
      notes = "Notes",
      registrationDate = "Registration Date",
      customRateOptional = "Customer-Specific Rate (Optional)",
      landsOwned = "Registered Lands",
      jobsHistory = "Agricultural Jobs",
      paymentsHistory = "Payments",
      advanceLedger = "Advance Ledger",
      duplicateCustomerError = "A customer with this mobile number or matching name & village already exists!",
      printCustomerStatement = "Print / PDF Statement",
      landName = "Land Name / ID *",
      landSize = "Land Size *",
      landUnit = "Measurement Unit",
      cropInfo = "Crop Info",
      cultivationSeason = "Cultivation Season",
      openingBalance = "Opening Outstanding Due",
      locationDetails = "Location / Plot Details",
      landLedger = "Independent Land Ledger",
      printLandStatement = "Land Statement PDF",
      rateHistory = "Rate History",
      manualAdjustment = "Manual Adjustment",
      refundEntry = "Refund",
      workDate = "Work Date",
      workType = "Work Type",
      customWorkName = "Custom Work Name",
      billingMethod = "Billing Method",
      landArea = "Land Area",
      rate = "Rate (৳)",
      workingHours = "Working Hours",
      baseBill = "Base Bill",
      additionalCharges = "Additional Charges",
      discount = "Discount",
      totalBill = "Total Bill",
      advanceAdjustment = "Advance Adjustment",
      amountPaidNow = "Amount Paid Now",
      remainingDue = "Remaining Due",
      jobStatus = "Job Status",
      tractorLabel = "Tractor",
      rotavatorWidth = "Rotavator Width",
      workingDepth = "Working Depth",
      numberOfPasses = "Number of Passes",
      startTime = "Start Time",
      finishTime = "Finish Time",
      operatorName = "Operator Name",
      repeatWorkHint = "Repeated work on the same land creates a separate job record",
      paymentDate = "Payment Date",
      paymentAmount = "Amount (৳) *",
      paymentMethod = "Payment Method",
      paymentTarget = "Payment Against",
      receiptNumber = "Receipt No.",
      previousBalance = "Previous Due",
      remainingBalance = "Remaining Due",
      receiveAdvance = "Receive Advance",
      adjustFromAdvance = "Adjust Advance to Land",
      refundAdvance = "Refund Advance",
      totalAdvanceUsed = "Advance Used",
      generateReceiptPdf = "Receipt PDF / Print",
      bulkPrintDialogTitle = "Bulk Print All Customers",
      selectCustomers = "Select Customers",
      allCustomers = "All Customers",
      selectLands = "Select Lands",
      allLands = "All Lands",
      dateRange = "Date Range",
      allDates = "All Dates",
      startDate = "Start Date (DD-MM-YYYY)",
      endDate = "End Date (DD-MM-YYYY)",
      onlyOutstandingCustomers = "Only customers with outstanding dues",
      includeZeroBalanceCustomers = "All customers (including zero balance)",
      generateCombinedPdf = "Generate Combined PDF",
      generatingPdfProgress = "Generating PDF...",
      cancel = "Cancel",
      previewPdf = "Preview",
      printSystem = "Print",
      savePdf = "Save PDF",
      sharePdf = "Share (WhatsApp)",
      exportExcel = "Export Excel (.xlsx)",
      tractorsTitle = "Tractor Management",
      addTractor = "Add Tractor",
      tractorName = "Tractor Name *",
      tractorBrand = "Brand",
      tractorModel = "Model",
      tractorReg = "Registration Info",
      activeStatus = "Active",
      backupRestoreTitle = "Google Drive Backup & Restore",
      googleDriveConnect = "Connect Google Account",
      googleDriveConnected = "Connected Account",
      backupNow = "Backup Now",
      autoBackup = "Auto backup when online",
      wifiOnlyBackup = "Wi-Fi only backup",
      lastBackupLabel = "Last successful backup",
      exportJson = "Export JSON Backup",
      importJson = "Import JSON Backup",
      restoreBackup = "Restore",
      recycleBinTitle = "Recycle Bin (30 Days)",
      recycleBinRetentionNote = "Deleted records remain recoverable for 30 days.",
      restoreItem = "Restore",
      permanentDelete = "Delete Permanently",
      auditLogTitle = "Audit Log",
      attachmentsTitle = "Photos & Documents",
      addPhotoAttachment = "Add Photo",
      settingsTitle = "Settings & Security",
      languageLabel = "Language",
      themeLabel = "Theme",
      pinLockLabel = "App Lock (PIN / Pattern / Password)",
      biometricLabel = "Fingerprint Unlock",
      defaultRatesLabel = "Default Billing Rates",
      save = "Save",
      edit = "Edit",
      delete = "Delete",
      close = "Close",
      confirm = "Confirm",
      multiDeviceSyncNote = "Note: Google Drive backup/restore saves complete point-in-time snapshots of the database and attachments. Real-time multi-device sync requires a central cloud backend; all local records already store UUIDs, device IDs, timestamps, versions, and conflict detection metadata.",
    )
  }
}
