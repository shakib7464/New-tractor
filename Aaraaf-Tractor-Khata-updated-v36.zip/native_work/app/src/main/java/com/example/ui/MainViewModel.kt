package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.AraafApplication
import com.example.data.backup.DriveBackupRemoteFile
import com.example.data.backup.RestoreSummary
import com.example.data.local.entity.AdvancePaymentEntity
import com.example.data.local.entity.AgriculturalJobEntity
import com.example.data.local.entity.AttachmentEntity
import com.example.data.local.entity.AuditLogEntity
import com.example.data.local.entity.BackupHistoryEntity
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.FuelDealerEntity
import com.example.data.local.entity.FuelEntryEntity
import com.example.data.local.entity.LandEntity
import com.example.data.local.entity.LedgerTransactionEntity
import com.example.data.local.entity.PaymentEntity
import com.example.data.local.entity.SyncQueueEntity
import com.example.data.local.entity.TractorEntity
import com.example.data.preferences.AppLanguage
import com.example.data.preferences.AppSettingsState
import com.example.data.preferences.AppThemeMode
import com.example.data.repository.DuplicateCustomerException
import com.example.domain.billing.BillingCalculator
import com.example.domain.model.BulkPrintFilter
import com.example.domain.model.CustomerFinancialSummary
import com.example.domain.model.DashboardSummary
import com.example.export.ExcelExporter
import com.example.localization.AppStrings
import com.example.worker.GoogleDriveBackupWorker
import com.example.worker.GoogleDriveSyncWorker
import java.io.File
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class PdfGenerationUiState {
  data object Idle : PdfGenerationUiState()
  data class Generating(val processed: Int, val total: Int) : PdfGenerationUiState()
  data class Ready(val file: File, val title: String) : PdfGenerationUiState()
  data class Error(val message: String) : PdfGenerationUiState()
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
  private val app = application as AraafApplication
  private val repo = app.khataRepository
  private val backupRepo = app.backupRepository
  private val syncRepo = app.syncRepository
  private val prefs = app.preferencesManager
  private val pdfGen = app.pdfGenerator

  val settings: StateFlow<AppSettingsState> = prefs.settingsFlow.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    AppSettingsState(),
  )

  val customers: StateFlow<List<CustomerEntity>> = repo.customersFlow.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    emptyList(),
  )

  val lands: StateFlow<List<LandEntity>> = repo.landsFlow.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    emptyList(),
  )

  val tractors: StateFlow<List<TractorEntity>> = repo.tractorsFlow.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    emptyList(),
  )

  val jobs: StateFlow<List<AgriculturalJobEntity>> = repo.jobsFlow.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    emptyList(),
  )

  val payments: StateFlow<List<PaymentEntity>> = repo.paymentsFlow.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    emptyList(),
  )

  val advances: StateFlow<List<AdvancePaymentEntity>> = repo.advancesFlow.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    emptyList(),
  )

  val transactions: StateFlow<List<LedgerTransactionEntity>> = repo.transactionsFlow.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    emptyList(),
  )

  val customerSummaries: StateFlow<List<CustomerFinancialSummary>> = repo.customerSummariesFlow.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    emptyList(),
  )

  val dashboardSummary: StateFlow<DashboardSummary> = repo.dashboardSummaryFlow.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    DashboardSummary(0, 0, 0, 0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 0.0, 0.0, emptyList()),
  )

  val auditLogs: StateFlow<List<AuditLogEntity>> = repo.auditLogsFlow.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    emptyList(),
  )

  val syncQueue: StateFlow<List<SyncQueueEntity>> = repo.syncQueueFlow.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    emptyList(),
  )

  val backupHistory: StateFlow<List<BackupHistoryEntity>> = backupRepo.backupHistoryFlow.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    emptyList(),
  )

  val deletedCustomers: StateFlow<List<CustomerEntity>> = repo.deletedCustomersFlow.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )
  val deletedLands: StateFlow<List<LandEntity>> = repo.deletedLandsFlow.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )
  val deletedJobs: StateFlow<List<AgriculturalJobEntity>> = repo.deletedJobsFlow.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )
  val deletedPayments: StateFlow<List<PaymentEntity>> = repo.deletedPaymentsFlow.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  private val _pdfState = MutableStateFlow<PdfGenerationUiState>(PdfGenerationUiState.Idle)
  val pdfState: StateFlow<PdfGenerationUiState> = _pdfState.asStateFlow()

  private val _driveBackups = MutableStateFlow<List<DriveBackupRemoteFile>>(emptyList())
  val driveBackups: StateFlow<List<DriveBackupRemoteFile>> = _driveBackups.asStateFlow()

  private val _isBusy = MutableStateFlow(false)
  val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

  private val _isSyncing = MutableStateFlow(false)
  val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

  private val _isUnlocked = MutableStateFlow(false)
  val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

  val fuelDealers: StateFlow<List<FuelDealerEntity>> = repo.fuelDealersFlow.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5_000),
    emptyList(),
  )
  val fuelEntries: StateFlow<List<FuelEntryEntity>> = repo.fuelEntriesFlow.stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5_000),
    emptyList(),
  )

  private val _snackbarEvents = MutableSharedFlow<String>(extraBufferCapacity = 8)
  val snackbarEvents = _snackbarEvents.asSharedFlow()

  private var activePdfJob: Job? = null

  fun currentStrings(): AppStrings = AppStrings.forLanguage(settings.value.language)

  fun markUnlocked() {
    _isUnlocked.value = true
  }

  /** অ্যাপ ব্যাকগ্রাউন্ডে কিছুক্ষণ থাকলে আবার পিন চাওয়ার জন্য */
  fun lockApp() {
    _isUnlocked.value = false
  }

  suspend fun pinLockRemainingMillis(): Long = prefs.pinLockRemainingMillis()

  suspend fun verifyPin(pin: String): Boolean {
    val ok = prefs.verifyPin(pin)
    if (ok) _isUnlocked.value = true
    return ok
  }

  fun saveCustomer(
    id: String? = null,
    fullName: String,
    mobileNumber: String,
    address: String,
    village: String,
    unionName: String,
    upazila: String,
    district: String,
    notes: String,
    registrationDate: Long,
    customRatePerUnit: Double? = null,
    customRateMethod: String? = null,
    onSuccess: (CustomerEntity) -> Unit = {},
  ) {
    viewModelScope.launch {
      repo.saveCustomer(
        id, fullName, mobileNumber, address, village, unionName, upazila, district,
        notes, registrationDate, customRatePerUnit, customRateMethod,
      ).onSuccess {
        _snackbarEvents.tryEmit("কাস্টমার সংরক্ষিত হয়েছে: ${it.fullName}")
        triggerAutoBackupIfEnabled()
        onSuccess(it)
      }.onFailure { err ->
        val msg = if (err is DuplicateCustomerException) {
          currentStrings().duplicateCustomerError
        } else {
          err.message ?: "Error saving customer"
        }
        _snackbarEvents.tryEmit(msg)
      }
    }
  }

  fun saveLand(
    id: String? = null,
    customerId: String,
    landName: String,
    village: String,
    locationDetails: String,
    sizeValue: Double,
    unit: String,
    cropInfo: String,
    cultivationSeason: String,
    openingBalance: Double,
    notes: String,
    firstCultivationRatePerKatha: Double = 0.0,
    firstCultivationCount: Int = 1,
    depositAmount: Double = 0.0,
    onSuccess: (LandEntity) -> Unit = {},
  ) {
    viewModelScope.launch {
      repo.saveLand(
        id, customerId, landName, village, locationDetails, sizeValue, unit,
        cropInfo, cultivationSeason, openingBalance, notes,
        firstCultivationRatePerKatha, firstCultivationCount, depositAmount,
      ).onSuccess {
        _snackbarEvents.tryEmit("জমি সংরক্ষিত হয়েছে: ${it.landName}")
        triggerAutoBackupIfEnabled()
        onSuccess(it)
      }.onFailure {
        _snackbarEvents.tryEmit(it.message ?: "Error saving land")
      }
    }
  }

  fun createJob(
    customerId: String,
    landId: String,
    tractorId: String?,
    workDate: Long,
    workType: String,
    customWorkName: String,
    billingMethod: String,
    landArea: Double,
    areaUnit: String,
    rate: Double,
    workingHours: Double?,
    additionalCharges: Double,
    discount: Double,
    advanceAdjustmentRequested: Double,
    amountPaidNow: Double,
    paymentMethod: String,
    status: String,
    rotavatorWidth: String,
    workingDepth: String,
    numberOfPasses: Int?,
    startTime: String,
    finishTime: String,
    operatorName: String,
    notes: String,
    onSuccess: (AgriculturalJobEntity) -> Unit = {},
  ) {
    viewModelScope.launch {
      repo.createAgriculturalJob(
        customerId, landId, tractorId, workDate, workType, customWorkName, billingMethod,
        landArea, areaUnit, rate, workingHours, additionalCharges, discount,
        advanceAdjustmentRequested, amountPaidNow, paymentMethod, status,
        rotavatorWidth, workingDepth, numberOfPasses, startTime, finishTime, operatorName, notes,
      ).onSuccess {
        _snackbarEvents.tryEmit("কাজ রেকর্ড করা হয়েছে (${it.jobCode})")
        triggerAutoBackupIfEnabled()
        onSuccess(it)
      }.onFailure {
        _snackbarEvents.tryEmit(it.message ?: "Error saving job")
      }
    }
  }

  fun updateJobStatus(jobId: String, newStatus: String) {
    viewModelScope.launch {
      repo.updateJobStatus(jobId, newStatus)
        .onSuccess { _snackbarEvents.tryEmit("কাজের অবস্থা আপডেট হয়েছে") }
        .onFailure { _snackbarEvents.tryEmit(it.message ?: "Error") }
    }
  }

  fun recordPayment(
    customerId: String,
    landId: String,
    jobId: String?,
    targetType: String,
    paymentDate: Long,
    amount: Double,
    paymentMethod: String,
    notes: String,
    onSuccess: (PaymentEntity) -> Unit = {},
  ) {
    viewModelScope.launch {
      repo.recordPayment(customerId, landId, jobId, targetType, paymentDate, amount, paymentMethod, notes)
        .onSuccess {
          _snackbarEvents.tryEmit("পেমেন্ট গৃহীত: ${it.receiptNumber}")
          triggerAutoBackupIfEnabled()
          onSuccess(it)
        }.onFailure {
          _snackbarEvents.tryEmit(it.message ?: "Payment failed")
        }
    }
  }

  fun saveFuelDealer(name: String, mobile: String, onSuccess: () -> Unit = {}) {
    viewModelScope.launch {
      repo.saveFuelDealer(name, mobile)
        .onSuccess {
          _snackbarEvents.tryEmit("দোকান যোগ হয়েছে")
          triggerAutoBackupIfEnabled()
          onSuccess()
        }.onFailure {
          _snackbarEvents.tryEmit(it.message ?: "সংরক্ষণ ব্যর্থ হয়েছে")
        }
    }
  }

  fun saveFuelEntry(
    dealerId: String,
    isPurchase: Boolean,
    entryDate: Long,
    liters: Double,
    ratePerLiter: Double,
    amount: Double,
    driverName: String,
    note: String,
    onSuccess: () -> Unit = {},
  ) {
    viewModelScope.launch {
      repo.saveFuelEntry(dealerId, isPurchase, entryDate, liters, ratePerLiter, amount, driverName, note)
        .onSuccess {
          _snackbarEvents.tryEmit("তেলের হিসাব সংরক্ষিত হয়েছে")
          triggerAutoBackupIfEnabled()
          onSuccess()
        }.onFailure {
          _snackbarEvents.tryEmit(it.message ?: "সংরক্ষণ ব্যর্থ হয়েছে")
        }
    }
  }

  fun updateFuelDealer(dealer: FuelDealerEntity, name: String, mobile: String) {
    viewModelScope.launch {
      repo.updateFuelDealer(dealer, name, mobile)
        .onSuccess {
          _snackbarEvents.tryEmit("দোকানের তথ্য সংশোধিত হয়েছে")
          triggerAutoBackupIfEnabled()
        }.onFailure {
          _snackbarEvents.tryEmit(it.message ?: "সংশোধন ব্যর্থ হয়েছে")
        }
    }
  }

  fun deleteFuelDealer(dealer: FuelDealerEntity) {
    viewModelScope.launch {
      repo.deleteFuelDealer(dealer)
        .onSuccess {
          _snackbarEvents.tryEmit("দোকান মুছে ফেলা হয়েছে")
          triggerAutoBackupIfEnabled()
        }.onFailure {
          _snackbarEvents.tryEmit(it.message ?: "মোছা যায়নি")
        }
    }
  }

  fun updateFuelEntry(
    entry: FuelEntryEntity,
    dealerId: String,
    isPurchase: Boolean,
    entryDate: Long,
    liters: Double,
    ratePerLiter: Double,
    amount: Double,
    driverName: String,
    note: String,
  ) {
    viewModelScope.launch {
      repo.updateFuelEntry(entry, dealerId, isPurchase, entryDate, liters, ratePerLiter, amount, driverName, note)
        .onSuccess {
          _snackbarEvents.tryEmit("এন্ট্রি সংশোধিত হয়েছে")
          triggerAutoBackupIfEnabled()
        }.onFailure {
          _snackbarEvents.tryEmit(it.message ?: "সংশোধন ব্যর্থ হয়েছে")
        }
    }
  }

  fun deleteFuelEntry(entry: FuelEntryEntity) {
    viewModelScope.launch {
      repo.deleteFuelEntry(entry)
        .onSuccess {
          _snackbarEvents.tryEmit("এন্ট্রি মুছে ফেলা হয়েছে")
          triggerAutoBackupIfEnabled()
        }.onFailure {
          _snackbarEvents.tryEmit(it.message ?: "মোছা যায়নি")
        }
    }
  }


  fun recordCustomerPayment(
    customerId: String,
    paymentDate: Long,
    amount: Double,
    paymentMethod: String,
    notes: String,
    onSuccess: () -> Unit = {},
  ) {
    viewModelScope.launch {
      repo.recordCustomerPayment(customerId, paymentDate, amount, paymentMethod, notes)
        .onSuccess {
          _snackbarEvents.tryEmit("পেমেন্ট গৃহীত হয়েছে")
          triggerAutoBackupIfEnabled()
          onSuccess()
        }.onFailure {
          _snackbarEvents.tryEmit(it.message ?: "Payment failed")
        }
    }
  }

  fun recordAdvanceReceived(
    customerId: String,
    landId: String?,
    amount: Double,
    paymentMethod: String,
    transactionDate: Long,
    notes: String,
    onSuccess: () -> Unit = {},
  ) {
    viewModelScope.launch {
      repo.recordAdvanceReceived(customerId, landId, amount, paymentMethod, transactionDate, notes)
        .onSuccess {
          _snackbarEvents.tryEmit("অগ্রিম গৃহীত হয়েছে (${it.receiptNumber})")
          triggerAutoBackupIfEnabled()
          onSuccess()
        }.onFailure {
          _snackbarEvents.tryEmit(it.message ?: "Failed")
        }
    }
  }

  fun adjustAdvanceToLand(
    customerId: String,
    landId: String,
    jobId: String?,
    amount: Double,
    transactionDate: Long,
    notes: String,
    onSuccess: () -> Unit = {},
  ) {
    viewModelScope.launch {
      repo.adjustAdvanceToLand(customerId, landId, jobId, amount, transactionDate, notes)
        .onSuccess {
          _snackbarEvents.tryEmit("অগ্রিম সমন্বয় সফল হয়েছে")
          triggerAutoBackupIfEnabled()
          onSuccess()
        }.onFailure {
          _snackbarEvents.tryEmit(it.message ?: "Failed")
        }
    }
  }

  fun recordManualLandAdjustment(
    customerId: String,
    landId: String,
    amount: Double,
    isChargeIncrease: Boolean,
    isRefund: Boolean,
    description: String,
    notes: String,
    dateMillis: Long,
    onSuccess: () -> Unit = {},
  ) {
    viewModelScope.launch {
      repo.recordManualLandAdjustment(
        customerId, landId, amount, isChargeIncrease, isRefund, description, notes, dateMillis
      ).onSuccess {
        _snackbarEvents.tryEmit("হিসাব সমন্বয় সংরক্ষিত হয়েছে")
        onSuccess()
      }.onFailure {
        _snackbarEvents.tryEmit(it.message ?: "Error")
      }
    }
  }

  fun saveTractor(
    id: String? = null,
    name: String,
    brand: String,
    model: String,
    registrationInfo: String,
    notes: String,
    isActive: Boolean,
    onSuccess: () -> Unit = {},
  ) {
    viewModelScope.launch {
      repo.saveTractor(id, name, brand, model, registrationInfo, notes, isActive)
        .onSuccess {
          _snackbarEvents.tryEmit("ট্রাক্টর সংরক্ষিত: ${it.name}")
          onSuccess()
        }.onFailure {
          _snackbarEvents.tryEmit(it.message ?: "Error")
        }
    }
  }

  fun softDeleteCustomer(id: String) = viewModelScope.launch {
    repo.softDeleteCustomer(id)
    _snackbarEvents.tryEmit("কাস্টমার রিসাইকেল বিনে পাঠানো হয়েছে")
  }

  fun softDeleteLand(id: String) = viewModelScope.launch {
    repo.softDeleteLand(id)
    _snackbarEvents.tryEmit("জমি রিসাইকেল বিনে পাঠানো হয়েছে")
  }

  fun softDeleteJob(id: String) = viewModelScope.launch {
    repo.softDeleteJob(id)
    _snackbarEvents.tryEmit("কাজ রিসাইকেল বিনে পাঠানো হয়েছে")
  }

  fun softDeletePayment(id: String) = viewModelScope.launch {
    repo.softDeletePayment(id)
    _snackbarEvents.tryEmit("পেমেন্ট রিসাইকেল বিনে পাঠানো হয়েছে")
  }

  fun restoreCustomer(id: String) = viewModelScope.launch {
    repo.restoreCustomer(id)
    _snackbarEvents.tryEmit("কাস্টমার পুনরুদ্ধার হয়েছে")
  }

  fun restoreLand(id: String) = viewModelScope.launch {
    repo.restoreLand(id)
    _snackbarEvents.tryEmit("জমি পুনরুদ্ধার হয়েছে")
  }

  fun restoreJob(id: String) = viewModelScope.launch {
    repo.restoreJob(id)
    _snackbarEvents.tryEmit("কাজ পুনরুদ্ধার হয়েছে")
  }

  fun restorePayment(id: String) = viewModelScope.launch {
    repo.restorePayment(id)
    _snackbarEvents.tryEmit("পেমেন্ট পুনরুদ্ধার হয়েছে")
  }

  fun permanentlyDeleteCustomer(id: String) = viewModelScope.launch {
    repo.permanentlyDeleteCustomer(id)
    _snackbarEvents.tryEmit("স্থায়ীভাবে মুছে ফেলা হয়েছে")
  }

  fun permanentlyDeleteJob(id: String) = viewModelScope.launch {
    repo.permanentlyDeleteJob(id)
    _snackbarEvents.tryEmit("স্থায়ীভাবে মুছে ফেলা হয়েছে")
  }

  fun observeAttachments(ownerType: String, ownerId: String): Flow<List<AttachmentEntity>> =
    repo.observeAttachments(ownerType, ownerId)

  fun addAttachment(ownerType: String, ownerId: String, uri: Uri) {
    viewModelScope.launch {
      repo.saveAttachmentFromUri(ownerType, ownerId, uri)
        .onSuccess { _snackbarEvents.tryEmit("সংযুক্তি যোগ হয়েছে") }
        .onFailure { _snackbarEvents.tryEmit("সংযুক্তি যোগ করা যায়নি") }
    }
  }

  fun deleteAttachment(id: String) = viewModelScope.launch { repo.deleteAttachment(id) }

  // PDF Generation (Recalculates fresh from DB before rendering!)
  fun generateBulkAllCustomersPdf(filter: BulkPrintFilter = BulkPrintFilter()) {
    activePdfJob?.cancel()
    activePdfJob = viewModelScope.launch {
      _pdfState.value = PdfGenerationUiState.Generating(0, 1)
      val summaries = repo.getBulkCustomerSummariesNow(filter)
      val consolidated = BillingCalculator.computeBulkConsolidatedSummary(summaries)
      pdfGen.generateBulkAllCustomersPdf(
        summaries = summaries,
        consolidated = consolidated,
        strings = currentStrings(),
        onProgress = { done, total ->
          _pdfState.value = PdfGenerationUiState.Generating(done, total.coerceAtLeast(1))
        },
      ).onSuccess { file ->
        _pdfState.value = PdfGenerationUiState.Ready(file, "সব কাস্টমারের হিসাব (Bulk Statement)")
      }.onFailure { err ->
        _pdfState.value = PdfGenerationUiState.Error(err.message ?: "PDF generation failed")
      }
    }
  }

  fun generateCustomerStatementPdf(customerId: String) {
    activePdfJob?.cancel()
    activePdfJob = viewModelScope.launch {
      _pdfState.value = PdfGenerationUiState.Generating(0, 1)
      val summary = repo.getRecalculatedCustomerSummaryNow(customerId)
      if (summary == null) {
        _pdfState.value = PdfGenerationUiState.Error("Customer not found")
        return@launch
      }
      pdfGen.generateCustomerStatementPdf(summary, currentStrings())
        .onSuccess { file ->
          _pdfState.value = PdfGenerationUiState.Ready(file, "${summary.customer.fullName} — হিসাব")
        }.onFailure { err ->
          _pdfState.value = PdfGenerationUiState.Error(err.message ?: "PDF failed")
        }
    }
  }

  fun generateLandStatementPdf(landId: String) {
    activePdfJob?.cancel()
    activePdfJob = viewModelScope.launch {
      _pdfState.value = PdfGenerationUiState.Generating(0, 1)
      val pair = repo.getRecalculatedLandSummaryNow(landId)
      if (pair == null) {
        _pdfState.value = PdfGenerationUiState.Error("Land not found")
        return@launch
      }
      pdfGen.generateLandStatementPdf(pair.first, pair.second, currentStrings())
        .onSuccess { file ->
          _pdfState.value = PdfGenerationUiState.Ready(file, "${pair.second.land.landName} — খতিয়ান")
        }.onFailure { err ->
          _pdfState.value = PdfGenerationUiState.Error(err.message ?: "PDF failed")
        }
    }
  }

  fun generatePaymentReceiptPdf(payment: PaymentEntity) {
    activePdfJob?.cancel()
    activePdfJob = viewModelScope.launch {
      _pdfState.value = PdfGenerationUiState.Generating(0, 1)
      val cust = customers.value.firstOrNull { it.id == payment.customerId }
      val land = lands.value.firstOrNull { it.id == payment.landId }
      pdfGen.generatePaymentReceiptPdf(
        payment = payment,
        customerName = cust?.fullName ?: "-",
        customerMobile = cust?.mobileNumber ?: "-",
        landName = land?.landName ?: "-",
        strings = currentStrings(),
      ).onSuccess { file ->
        _pdfState.value = PdfGenerationUiState.Ready(file, "রসিদ ${payment.receiptNumber}")
      }.onFailure { err ->
        _pdfState.value = PdfGenerationUiState.Error(err.message ?: "Receipt PDF failed")
      }
    }
  }

  fun cancelPdfGeneration() {
    activePdfJob?.cancel()
    _pdfState.value = PdfGenerationUiState.Idle
  }

  fun dismissPdfState() {
    _pdfState.value = PdfGenerationUiState.Idle
  }

  fun exportExcelReport(
    filter: BulkPrintFilter = BulkPrintFilter(),
    onFileReady: (File) -> Unit,
  ) {
    viewModelScope.launch {
      _isBusy.value = true
      val summaries = repo.getBulkCustomerSummariesNow(filter)
      val consolidated = BillingCalculator.computeBulkConsolidatedSummary(summaries)
      ExcelExporter.exportStatementsWorkbook(app, summaries, consolidated, currentStrings())
        .onSuccess {
          _isBusy.value = false
          onFileReady(it)
        }.onFailure {
          _isBusy.value = false
          _snackbarEvents.tryEmit(it.message ?: "Excel export failed")
        }
    }
  }

  // Backup, Drive & Settings
  fun setLanguage(lang: AppLanguage) = viewModelScope.launch { prefs.setLanguage(lang) }
  fun setThemeMode(mode: AppThemeMode) = viewModelScope.launch { prefs.setThemeMode(mode) }
  fun setDefaultUnit(unit: String) = viewModelScope.launch { prefs.setDefaultLandUnit(unit) }
  fun updateDefaultRates(d: Double, b: Double, a: Double, h: Double) = viewModelScope.launch {
    prefs.updateDefaultRates(d, b, a, h)
    _snackbarEvents.tryEmit("ডিফল্ট রেট আপডেট হয়েছে")
  }
  fun setPin(pin: String) = viewModelScope.launch {
    prefs.setPin(pin)
    _isUnlocked.value = true
    _snackbarEvents.tryEmit("পিন লক চালু হয়েছে")
  }
  fun setLock(type: com.example.data.preferences.AppLockType, secret: String) = viewModelScope.launch {
    prefs.setLock(type, secret)
    _isUnlocked.value = true
    _snackbarEvents.tryEmit(
      when (type) {
        com.example.data.preferences.AppLockType.PIN -> "পিন লক চালু হয়েছে"
        com.example.data.preferences.AppLockType.PATTERN -> "প্যাটার্ন লক চালু হয়েছে"
        com.example.data.preferences.AppLockType.PASSWORD -> "পাসওয়ার্ড লক চালু হয়েছে"
      }
    )
  }
  fun disablePin() = viewModelScope.launch {
    prefs.disablePin()
    _snackbarEvents.tryEmit("পিন লক বন্ধ করা হয়েছে")
  }
  fun setBiometric(enabled: Boolean) = viewModelScope.launch { prefs.setBiometricEnabled(enabled) }

  fun setDriveSession(email: String?, token: String?) {
    viewModelScope.launch {
      if (email == null) {
        prefs.setDriveSession(null, null)
        prefs.setLoginSkipped(false)
        GoogleDriveSyncWorker.schedulePeriodic(app, false)
        _driveBackups.value = emptyList()
        return@launch
      }
      val error = completeGoogleLogin(email, token)
      if (error != null) {
        _snackbarEvents.tryEmit(error)
      } else {
        _snackbarEvents.tryEmit("Google একাউন্ট যুক্ত হয়েছে")
        refreshDriveBackups()
      }
    }
  }

  /** Google লগইন শেষ করে। সফল হলে null, ব্যর্থ হলে দেখানোর মতো বার্তা ফেরত দেয়। */
  suspend fun completeGoogleLogin(emailHint: String?, token: String?): String? {
    return syncRepo.connectAccount(emailHint, token).fold(
      onSuccess = {
        GoogleDriveSyncWorker.schedulePeriodic(app, true)
        syncNow(silent = false)
        null
      },
      onFailure = { it.message ?: "লগইন ব্যর্থ হয়েছে" },
    )
  }

  /** লগইন কাজ না করলে (OAuth সেটআপ বাকি থাকলে) শুধু এই ফোনে অফলাইনে চালানোর পথ। */
  fun skipLogin() {
    viewModelScope.launch { prefs.setLoginSkipped(true) }
  }

  /** Google Drive-এর সাথে ডেটা মেলায়। silent = true হলে সফল/ব্যর্থ বার্তা দেখায় না। */
  fun syncNow(silent: Boolean = true) {
    if (_isSyncing.value) return
    viewModelScope.launch {
      if (prefs.getSettingsNow().driveAccountEmail.isNullOrBlank()) return@launch
      _isSyncing.value = true
      syncRepo.syncNow()
        .onSuccess {
          if (!silent) {
            _snackbarEvents.tryEmit(
              if (it.mergedFromCloud > 0) "সিঙ্ক সফল: ${it.mergedFromCloud} টি এন্ট্রি Drive থেকে এসেছে"
              else "সিঙ্ক সফল, সব ডেটা হালনাগাদ আছে"
            )
          }
        }
        .onFailure {
          if (!silent) _snackbarEvents.tryEmit("সিঙ্ক ব্যর্থ: ${it.message}")
        }
      _isSyncing.value = false
    }
  }

  fun setAutoBackup(enabled: Boolean, wifiOnly: Boolean) {
    viewModelScope.launch {
      prefs.setAutoBackupConfig(enabled, wifiOnly)
      GoogleDriveBackupWorker.scheduleAutoBackup(app, enabled, wifiOnly)
    }
  }

  private fun triggerAutoBackupIfEnabled() {
    val s = settings.value
    if (!s.driveAccountEmail.isNullOrBlank()) {
      GoogleDriveSyncWorker.enqueueSoon(app)
    }
    if (s.autoDriveBackupEnabled && !s.driveAccountEmail.isNullOrBlank()) {
      GoogleDriveBackupWorker.enqueueOneTimeWhenOnline(app, s.wifiOnlyBackup)
    }
  }

  fun backupToDriveNow(passphrase: String? = null) {
    viewModelScope.launch {
      _isBusy.value = true
      backupRepo.performGoogleDriveBackup(passphrase)
        .onSuccess {
          _snackbarEvents.tryEmit("Google Drive ব্যাকআপ সফল ও যাচাইকৃত হয়েছে")
          refreshDriveBackups()
        }.onFailure {
          _snackbarEvents.tryEmit("ব্যাকআপ ব্যর্থ: ${it.message}. ইন্টারনেট পেলে স্বয়ংক্রিয়ভাবে চেষ্টা করবে।")
          GoogleDriveBackupWorker.enqueueOneTimeWhenOnline(app, settings.value.wifiOnlyBackup)
        }
      _isBusy.value = false
    }
  }

  fun refreshDriveBackups() {
    viewModelScope.launch {
      backupRepo.listDriveBackups()
        .onSuccess { _driveBackups.value = it }
    }
  }

  fun restoreFromDrive(fileId: String, passphrase: String?, mergeOnly: Boolean, onDone: (RestoreSummary) -> Unit) {
    viewModelScope.launch {
      _isBusy.value = true
      backupRepo.restoreFromGoogleDrive(fileId, passphrase, mergeOnly)
        .onSuccess {
          _snackbarEvents.tryEmit("রিস্টোর সফল (${it.customersRestored} কাস্টমার)")
          onDone(it)
        }.onFailure {
          _snackbarEvents.tryEmit("রিস্টোর ব্যর্থ: ${it.message}")
        }
      _isBusy.value = false
    }
  }

  fun exportJsonBackup(passphrase: String? = null, onFileReady: (File) -> Unit) {
    viewModelScope.launch {
      _isBusy.value = true
      backupRepo.createLocalBackupJson(encryptionPassphrase = passphrase)
        .onSuccess { (file, _) ->
          _isBusy.value = false
          onFileReady(file)
        }.onFailure {
          _isBusy.value = false
          _snackbarEvents.tryEmit(it.message ?: "Backup export failed")
        }
    }
  }

  fun importJsonBackup(uri: Uri, passphrase: String?, mergePreventDuplicates: Boolean, onDone: (RestoreSummary) -> Unit) {
    viewModelScope.launch {
      _isBusy.value = true
      val text = runCatching {
        app.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
          ?: error("Cannot read file")
      }.getOrElse {
        _isBusy.value = false
        _snackbarEvents.tryEmit(it.message ?: "Cannot read file")
        return@launch
      }
      backupRepo.restoreFromJsonString(text, passphrase, mergePreventDuplicates)
        .onSuccess {
          _snackbarEvents.tryEmit("ইমপোর্ট সফল (${it.customersRestored} কাস্টমার)")
          onDone(it)
        }.onFailure {
          _snackbarEvents.tryEmit("ইমপোর্ট ব্যর্থ: ${it.message}")
        }
      _isBusy.value = false
    }
  }
}
