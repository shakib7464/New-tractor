package com.example.export

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object PdfPrintHelper {

  fun getShareableUri(context: Context, file: File): Uri {
    return FileProvider.getUriForFile(
      context,
      "${context.packageName}.fileprovider",
      file,
    )
  }

  fun shareFile(context: Context, file: File, mimeType: String = "application/pdf", title: String = "Share") {
    val uri = getShareableUri(context, file)
    val intent = Intent(Intent.ACTION_SEND).apply {
      type = mimeType
      putExtra(Intent.EXTRA_STREAM, uri)
      putExtra(Intent.EXTRA_SUBJECT, "Araaf Tractor Khata - ${file.name}")
      addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    val chooser = Intent.createChooser(intent, title).apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    context.startActivity(chooser)
  }

  fun copyFileToUri(context: Context, sourceFile: File, destUri: Uri): Result<Unit> = runCatching {
    context.contentResolver.openOutputStream(destUri)?.use { out ->
      FileInputStream(sourceFile).use { input ->
        input.copyTo(out)
      }
    } ?: error("Cannot open destination output stream")
  }

  fun printPdf(context: Context, pdfFile: File, jobName: String = "Araaf Tractor Khata Statement") {
    val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
    val adapter = object : PrintDocumentAdapter() {
      override fun onLayout(
        oldAttributes: PrintAttributes?,
        newAttributes: PrintAttributes?,
        cancellationSignal: CancellationSignal?,
        callback: LayoutResultCallback?,
        extras: Bundle?,
      ) {
        if (cancellationSignal?.isCanceled == true) {
          callback?.onLayoutCancelled()
          return
        }
        val info = PrintDocumentInfo.Builder(pdfFile.name)
          .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
          .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
          .build()
        callback?.onLayoutFinished(info, true)
      }

      override fun onWrite(
        pages: Array<out PageRange>?,
        destination: ParcelFileDescriptor?,
        cancellationSignal: CancellationSignal?,
        callback: WriteResultCallback?,
      ) {
        try {
          FileInputStream(pdfFile).use { input ->
            FileOutputStream(destination?.fileDescriptor).use { output ->
              val buffer = ByteArray(8192)
              var read: Int
              while (input.read(buffer).also { read = it } > 0) {
                if (cancellationSignal?.isCanceled == true) {
                  callback?.onWriteCancelled()
                  return
                }
                output.write(buffer, 0, read)
              }
            }
          }
          callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
        } catch (e: Exception) {
          callback?.onWriteFailed(e.message)
        }
      }
    }
    printManager.print(jobName, adapter, PrintAttributes.Builder().build())
  }
}
