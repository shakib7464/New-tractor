package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.LandEntity
import com.example.data.local.entity.LandUnit
import com.example.localization.AppStrings
import com.example.domain.billing.BillingCalculator
import com.example.domain.billing.FormatUtils

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun LandFormDialog(
  customers: List<CustomerEntity>,
  preselectedCustomerId: String?,
  existing: LandEntity? = null,
  existingCultivationPasses: Int? = null,
  existingCultivationRate: Double? = null,
  defaultUnit: String,
  strings: AppStrings,
  onDismiss: () -> Unit,
  onSave: (
    customerId: String,
    landName: String,
    village: String,
    locationDetails: String,
    sizeValue: Double,
    unit: String,
    cropInfo: String,
    season: String,
    openingBalance: Double,
    notes: String,
    cultivationRatePerKatha: Double,
    cultivationCount: Int,
  ) -> Unit,
) {
  var selectedCustomerId by remember {
    mutableStateOf(existing?.customerId ?: preselectedCustomerId ?: customers.firstOrNull()?.id ?: "")
  }
  var customerExpanded by remember { mutableStateOf(false) }
  var landName by remember { mutableStateOf(existing?.landName ?: "") }
  var village by remember { mutableStateOf(existing?.village ?: "") }
  var locationDetails by remember { mutableStateOf(existing?.locationDetails ?: "") }
  var sizeText by remember { mutableStateOf(existing?.let {
    val oldUnit = LandUnit.entries.firstOrNull { u -> u.code == it.unit } ?: LandUnit.KATHA
    BillingCalculator.convertArea(it.sizeValue, oldUnit, LandUnit.KATHA).toString()
  } ?: "") }
  var unit by remember { mutableStateOf(LandUnit.KATHA.code) }
  var cropInfo by remember { mutableStateOf(existing?.cropInfo ?: "") }
  var season by remember { mutableStateOf(existing?.cultivationSeason ?: "") }
  var openingText by remember { mutableStateOf(existing?.openingBalance?.takeIf { it > 0 }?.toString() ?: "0") }
  var notes by remember { mutableStateOf(existing?.notes ?: "") }
  var passesText by remember { mutableStateOf(existingCultivationPasses?.toString() ?: "1") }
  var rateText by remember {
    mutableStateOf(
      existingCultivationRate?.takeIf { it > 0 }?.let { r -> if (r % 1.0 == 0.0) r.toLong().toString() else r.toString() } ?: ""
    )
  }
  var errorMsg by remember { mutableStateOf<String?>(null) }

  // শুধু নতুন জমি যোগের সময় প্রথম চাষের বিল হিসাব হবে
  val isNewLand = existing == null
  // নতুন জমিতে সবসময়; পুরোনো জমিতে শুধু যদি আগে থেকে চাষের বিল থাকে (সংশোধনের জন্য)
  val showCultivation = isNewLand || existingCultivationRate != null
  val sizeNow = sizeText.toDoubleOrNull() ?: 0.0
  val passesNow = (passesText.toIntOrNull() ?: 1).coerceAtLeast(1)
  val rateNow = rateText.toDoubleOrNull() ?: 0.0
  val openingNow = (openingText.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
  val cultivationBill = BillingCalculator.roundCurrency(sizeNow * passesNow * rateNow)
  val grandTotal = BillingCalculator.roundCurrency(openingNow + cultivationBill)

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(if (existing == null) strings.addLand else "${strings.edit}: ${existing.landName}") },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        if (existing == null && preselectedCustomerId == null) {
          ExposedDropdownMenuBox(
            expanded = customerExpanded,
            onExpandedChange = { customerExpanded = !customerExpanded },
          ) {
            val custName = customers.firstOrNull { it.id == selectedCustomerId }?.fullName ?: "কাস্টমার নির্বাচন করুন"
            OutlinedTextField(
              value = custName,
              onValueChange = {},
              readOnly = true,
              label = { Text(strings.navCustomers) },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = customerExpanded) },
              modifier = Modifier
                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                .fillMaxWidth(),
            )
            ExposedDropdownMenu(
              expanded = customerExpanded,
              onDismissRequest = { customerExpanded = false },
            ) {
              customers.forEach { c ->
                DropdownMenuItem(
                  text = { Text("${c.fullName} (${c.mobileNumber})") },
                  onClick = {
                    selectedCustomerId = c.id
                    customerExpanded = false
                  },
                )
              }
            }
          }
        }

        OutlinedTextField(
          value = landName,
          onValueChange = { landName = it; errorMsg = null },
          label = { Text(strings.landName) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("land_name_input"),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = sizeText,
            onValueChange = { sizeText = it; errorMsg = null },
            label = { Text(strings.landSize) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.weight(1f).testTag("land_size_input"),
          )
          OutlinedTextField(
            value = openingText,
            onValueChange = { openingText = it },
            label = { Text(strings.openingBalance) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.weight(1f).testTag("land_opening_input"),
          )
        }
        Text(strings.landUnit, style = MaterialTheme.typography.labelMedium)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          listOf(LandUnit.KATHA).forEach { u ->
            FilterChip(
              selected = unit == u.code,
              onClick = { unit = u.code },
              label = { Text(strings.unitLabel(u.code)) },
            )
          }
        }
        if (showCultivation) {
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = passesText,
              onValueChange = { passesText = it.filter { ch -> ch.isDigit() }; errorMsg = null },
              label = { Text("কয়বার চাষ") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              singleLine = true,
              modifier = Modifier.weight(1f).testTag("land_passes_input"),
            )
            OutlinedTextField(
              value = rateText,
              onValueChange = { rateText = it; errorMsg = null },
              label = { Text("প্রতি কাঠায় চাষের রেট") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              singleLine = true,
              modifier = Modifier.weight(1f).testTag("land_rate_input"),
            )
          }
          Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            Text(
              (if (isNewLand) "চাষের মোট বিল: " else "নতুন চাষের বিল: ") + FormatUtils.formatTaka(cultivationBill),
              style = MaterialTheme.typography.bodyMedium,
            )
            if (!isNewLand) {
              Text(
                "জমি, চাষ বা রেট বদলালে বিল নতুন করে হিসাব হবে। আগের জমা ও পেমেন্টের ইতিহাস মুছবে না।",
                style = MaterialTheme.typography.bodySmall,
              )
            }
            Text(
              "আগের বকেয়া: ${FormatUtils.formatTaka(openingNow)}",
              style = MaterialTheme.typography.bodyMedium,
            )
            Text(
              "আগের বকেয়াসহ মোট পাওনা: ${FormatUtils.formatTaka(grandTotal)}",
              style = MaterialTheme.typography.titleSmall,
            )
          }
        }
        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text(strings.notes) },
          modifier = Modifier.fillMaxWidth(),
        )
        if (errorMsg != null) {
          Text(errorMsg!!, color = MaterialTheme.colorScheme.error)
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val size = sizeText.toDoubleOrNull()
          if (selectedCustomerId.isBlank() || landName.isBlank() || size == null || size <= 0) {
            errorMsg = "কাস্টমার, জমির নাম ও সঠিক পরিমাণ দিন"
            return@Button
          }
          onSave(
            selectedCustomerId,
            landName,
            village,
            locationDetails,
            size,
            unit,
            cropInfo,
            season,
            openingText.toDoubleOrNull() ?: 0.0,
            notes,
            if (showCultivation) rateNow else 0.0,
            if (showCultivation) passesNow else 1,
          )
        },
        modifier = Modifier.height(48.dp).testTag("save_land_btn"),
      ) {
        Text(strings.save)
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss, modifier = Modifier.height(48.dp)) {
        Text(strings.cancel)
      }
    },
  )
}
