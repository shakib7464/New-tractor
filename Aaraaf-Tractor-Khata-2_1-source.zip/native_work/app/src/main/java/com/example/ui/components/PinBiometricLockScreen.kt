package com.example.ui.components

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.launch

@Composable
fun PinBiometricLockScreen(
  biometricEnabled: Boolean,
  onVerifyPin: suspend (String) -> Boolean,
  onBiometricSuccess: () -> Unit,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  var pin by remember { mutableStateOf("") }
  var error by remember { mutableStateOf<String?>(null) }

  fun launchBiometric() {
    val activity = context as? FragmentActivity ?: return
    val manager = BiometricManager.from(context)
    val canAuth = manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK)
    if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) return

    val executor = ContextCompat.getMainExecutor(context)
    val prompt = BiometricPrompt(
      activity,
      executor,
      object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
          super.onAuthenticationSucceeded(result)
          onBiometricSuccess()
        }
      },
    )
    val info = BiometricPrompt.PromptInfo.Builder()
      .setTitle("Araaf Tractor Khata")
      .setSubtitle("আনলক করতে ফিঙ্গারপ্রিন্ট দিন")
      .setNegativeButtonText("পিন ব্যবহার করুন")
      .build()
    prompt.authenticate(info)
  }

  LaunchedEffect(biometricEnabled) {
    if (biometricEnabled) {
      launchBiometric()
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(28.dp),
    verticalArrangement = Arrangement.Center,
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Icon(
      imageVector = Icons.Rounded.Lock,
      contentDescription = "Locked",
      tint = MaterialTheme.colorScheme.primary,
      modifier = Modifier.size(64.dp),
    )
    Spacer(Modifier.height(16.dp))
    Text(
      text = "Araaf Tractor Khata",
      style = MaterialTheme.typography.headlineSmall,
      fontWeight = FontWeight.Bold,
    )
    Text(
      text = "হিসাব দেখতে পিন কোড দিন",
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Spacer(Modifier.height(24.dp))
    OutlinedTextField(
      value = pin,
      onValueChange = {
        if (it.length <= 6 && it.all { ch -> ch.isDigit() }) {
          pin = it
          error = null
        }
      },
      label = { Text("পিন কোড (PIN)") },
      visualTransformation = PasswordVisualTransformation(),
      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
      singleLine = true,
      isError = error != null,
      supportingText = error?.let { msg -> { Text(msg) } },
      modifier = Modifier
        .fillMaxWidth()
        .testTag("lock_pin_input"),
    )
    Spacer(Modifier.height(14.dp))
    Button(
      onClick = {
        scope.launch {
          if (!onVerifyPin(pin)) {
            error = "ভুল পিন কোড"
          }
        }
      },
      modifier = Modifier
        .fillMaxWidth()
        .height(48.dp)
        .testTag("lock_unlock_button"),
    ) {
      Text("আনলক করুন", fontWeight = FontWeight.Bold)
    }
    if (biometricEnabled) {
      Spacer(Modifier.height(12.dp))
      OutlinedButton(
        onClick = { launchBiometric() },
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp),
      ) {
        Icon(Icons.Rounded.Fingerprint, contentDescription = null)
        Text(" ফিঙ্গারপ্রিন্ট দিয়ে আনলক")
      }
    }
  }
}
