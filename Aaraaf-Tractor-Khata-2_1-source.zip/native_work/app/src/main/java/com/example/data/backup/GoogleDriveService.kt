package com.example.data.backup

import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

class GoogleDriveService {

  private val client = OkHttpClient.Builder()
    .connectTimeout(30, TimeUnit.SECONDS)
    .readTimeout(60, TimeUnit.SECONDS)
    .writeTimeout(60, TimeUnit.SECONDS)
    .build()

  suspend fun uploadBackupToAppData(
    accessToken: String,
    fileName: String,
    contentBytes: ByteArray,
  ): Result<DriveBackupRemoteFile> = withContext(Dispatchers.IO) {
    runCatching {
      val metadataJson = JSONObject().apply {
        put("name", fileName)
        put("parents", org.json.JSONArray().put("appDataFolder"))
        put("mimeType", "application/json")
      }.toString()

      val multipartBody = MultipartBody.Builder()
        .setType("multipart/related".toMediaType())
        .addPart(metadataJson.toRequestBody("application/json; charset=utf-8".toMediaType()))
        .addPart(contentBytes.toRequestBody("application/json".toMediaType()))
        .build()

      val request = Request.Builder()
        .url("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,size,createdTime")
        .addHeader("Authorization", "Bearer $accessToken")
        .post(multipartBody)
        .build()

      client.newCall(request).execute().use { response ->
        val bodyStr = response.body?.string().orEmpty()
        if (!response.isSuccessful) {
          throw IOException("Drive upload failed (${response.code}): $bodyStr")
        }
        val json = JSONObject(bodyStr)
        DriveBackupRemoteFile(
          id = json.getString("id"),
          name = json.optString("name", fileName),
          sizeBytes = json.optString("size", contentBytes.size.toString()).toLongOrNull() ?: contentBytes.size.toLong(),
          createdTime = json.optString("createdTime", ""),
        )
      }
    }
  }

  suspend fun listBackups(accessToken: String): Result<List<DriveBackupRemoteFile>> =
    withContext(Dispatchers.IO) {
      runCatching {
        val url = "https://www.googleapis.com/drive/v3/files" +
          "?spaces=appDataFolder" +
          "&q=name%20contains%20'AraafTractorKhata_Backup'" +
          "&orderBy=createdTime%20desc" +
          "&pageSize=30" +
          "&fields=files(id,name,size,createdTime)"

        val request = Request.Builder()
          .url(url)
          .addHeader("Authorization", "Bearer $accessToken")
          .get()
          .build()

        client.newCall(request).execute().use { response ->
          val bodyStr = response.body?.string().orEmpty()
          if (!response.isSuccessful) {
            throw IOException("Drive list failed (${response.code}): $bodyStr")
          }
          val filesArray = JSONObject(bodyStr).optJSONArray("files") ?: return@runCatching emptyList()
          buildList {
            for (i in 0 until filesArray.length()) {
              val item = filesArray.getJSONObject(i)
              add(
                DriveBackupRemoteFile(
                  id = item.getString("id"),
                  name = item.optString("name", "backup.json"),
                  sizeBytes = item.optString("size", "0").toLongOrNull() ?: 0L,
                  createdTime = item.optString("createdTime", ""),
                )
              )
            }
          }
        }
      }
    }

  suspend fun downloadBackup(accessToken: String, fileId: String): Result<ByteArray> =
    withContext(Dispatchers.IO) {
      runCatching {
        val request = Request.Builder()
          .url("https://www.googleapis.com/drive/v3/files/$fileId?alt=media")
          .addHeader("Authorization", "Bearer $accessToken")
          .get()
          .build()

        client.newCall(request).execute().use { response ->
          if (!response.isSuccessful) {
            throw IOException("Drive download failed (${response.code})")
          }
          response.body?.bytes() ?: throw IOException("Empty backup response")
        }
      }
    }

  suspend fun deleteFile(accessToken: String, fileId: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val request = Request.Builder()
          .url("https://www.googleapis.com/drive/v3/files/$fileId")
          .addHeader("Authorization", "Bearer $accessToken")
          .delete()
          .build()
        client.newCall(request).execute().use { response ->
          if (!response.isSuccessful && response.code != 404) {
            throw IOException("Drive delete failed (${response.code})")
          }
        }
      }
    }
}
