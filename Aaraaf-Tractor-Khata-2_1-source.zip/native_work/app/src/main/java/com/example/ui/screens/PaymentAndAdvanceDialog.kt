package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.AgriculturalJobEntity
import com.example.data.local.entity.PaymentMethod
import com.example.data.local.entity.PaymentTargetType
import com.example.domain.billing.FormatUtils
import com.example.domain.model.CustomerFinancialSummary
import com.example.localization.AppStrings

enum class PaymentDialogMode {
  PAYMENT,
  ADVANCE_RECEIVE,
  ADVANCE_ADJUST,
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PaymentAndAdvanceDialog(
  summaries: List<CustomerFinancialSummary>,
  jobs: List<AgriculturalJobEntity>,
  preselectedCustomerId: String? = null,
  preselectedLandId: String? = null,
  preselectedJobId: String? = null,
  initialMode: PaymentDialogMode = PaymentDialogMode.PAYMENT,
  strings: AppStrings,
  currencySymbol: String,
  onDismiss: () -> Unit,
  onSubmitPayment: (
    customerId: String,
    landId: String,
    jobId: String?,
    targetType: String,
    dateMillis: Long,
    amount: Double,
    method: String,
    notes: String,
  ) -> Unit,
  onSubmitAdvanceReceive: (
    customerId: String,
    landId: String?,
    amount: Double,
    method: String,
    dateMillis: Long,
    notes: String,
  ) -> Unit,
  onSubmitAdvanceAdjust: (
    customerId: String,
    landId: String,
    jobId: String?,
    amount: Double,
    dateMillis: Long,
    notes: String,
  ) -> Unit,
) {
  var mode by remember { mutableStateOf(initialMode) }
  var selectedCustomerId by remember {
    mutableStateOf(preselectedCustomerId ?: summaries.firstOrNull()?.customer?.id ?: "")
  }
  val activeSummary = summaries.firstOrNull { it.customer.id == selectedCustomerId }
  val customerLands = activeSummary?.lands.orEmpty()

  var selectedLandId by remember(selectedCustomerId) {
    mutableStateOf(
      preselectedLandId?.takeIf { id -> customerLands.any { it.land.id == id } }
        ?: customerLands.firstOrNull()?.land?.id
        ?: ""
    )
  }
  var selectedJobId by remember(selectedLandId) { mutableStateOf(preselectedJobId) }
  var amountText by remember { mutableStateOf("") }
  var method by remember { mutableStateOf(PaymentMethod.CASH.code) }
  var dateText by remember { mutableStateOf(FormatUtils.formatDate(System.currentTimeMillis())) }
  var timeText by remember { mutableStateOf(java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())) }
  var notes by remember { mutableStateOf("") }
  var errorMsg by remember { mutableStateOf<String?>(null) }

  var custExpanded by remember { mutableStateOf(false) }
  var landExpanded by remember { mutableStateOf(false) }
  var jobExpanded by remember { mutableStateOf(false) }

  val selectedLandSummary = customerLands.firstOrNull { it.land.id == selectedLandId }
  val landJobs = jobs.filter { it.landId == selectedLandId && it.remainingDue > 0.01 }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        when (mode) {
          PaymentDialogMode.PAYMENT -> strings.receivePayment
          PaymentDialogMode.ADVANCE_RECEIVE -> strings.receiveAdvance
          PaymentDialogMode.ADVANCE_ADJUST -> strings.adjustFromAdvance
        }
      )
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          FilterChip(
            selected = mode == PaymentDialogMode.PAYMENT,
            onClick = { mode = PaymentDialogMode.PAYMENT; errorMsg = null },
            label = { Text(strings.receivePayment) },
          )
          FilterChip(
            selected = mode == PaymentDialogMode.ADVANCE_RECEIVE,
            onClick = { mode = PaymentDialogMode.ADVANCE_RECEIVE; errorMsg = null },
            label = { Text(strings.receiveAdvance) },
          )
          FilterChip(
            selected = mode == PaymentDialogMode.ADVANCE_ADJUST,
            onClick = { mode = PaymentDialogMode.ADVANCE_ADJUST; errorMsg = null },
            label = { Text(strings.adjustFromAdvance) },
          )
        }

        ExposedDropdownMenuBox(
          expanded = custExpanded,
          onExpandedChange = { custExpanded = !custExpanded },
        ) {
          OutlinedTextField(
            value = activeSummary?.customer?.fullName ?: "কাস্টমার নির্বাচন করুন",
            onValueChange = {},
            readOnly = true,
            label = { Text(strings.navCustomers) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(custExpanded) },
            modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
          )
          ExposedDropdownMenu(expanded = custExpanded, onDismissRequest = { custExpanded = false }) {
            summaries.forEach { s ->
              DropdownMenuItem(
                text = {
                  Text("${s.customer.fullName} (বকেয়া: ${FormatUtils.formatTaka(s.totalOutstandingBalance, currencySymbol)})")
                },
                onClick = {
                  selectedCustomerId = s.customer.id
                  custExpanded = false
                },
              )
            }
          }
        }

        if (customerLands.isNotEmpty()) {
          ExposedDropdownMenuBox(
            expanded = landExpanded,
            onExpandedChange = { landExpanded = !landExpanded },
          ) {
            OutlinedTextField(
              value = selectedLandSummary?.let {
                "${it.land.landName} (বকেয়া: ${FormatUtils.formatTaka(it.currentBalance, currencySymbol)})"
              } ?: "জমি নির্বাচন করুন",
              onValueChange = {},
              readOnly = true,
              label = { Text(strings.landName) },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(landExpanded) },
              modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
            )
            ExposedDropdownMenu(expanded = landExpanded, onDismissRequest = { landExpanded = false }) {
              customerLands.forEach { ls ->
                DropdownMenuItem(
                  text = {
                    Text("${ls.land.landName} (${FormatUtils.formatTaka(ls.currentBalance, currencySymbol)})")
                  },
                  onClick = {
                    selectedLandId = ls.land.id
                    selectedJobId = null
                    landExpanded = false
                  },
                )
              }
            }
          }
        }

        if (mode != PaymentDialogMode.ADVANCE_RECEIVE && landJobs.isNotEmpty()) {
          ExposedDropdownMenuBox(
            expanded = jobExpanded,
            onExpandedChange = { jobExpanded = !jobExpanded },
          ) {
            val jobLabel = landJobs.firstOrNull { it.id == selectedJobId }?.let {
              "${it.jobCode} (${FormatUtils.formatTaka(it.remainingDue, currencySymbol)})"
            } ?: "সকল কাজের বিপরীতে (জমির খতিয়ান)"
            OutlinedTextField(
              value = jobLabel,
              onValueChange = {},
              readOnly = true,
              label = { Text("নির্দিষ্ট কাজ (ঐচ্ছিক)") },
              trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(jobExpanded) },
              modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
            )
            ExposedDropdownMenu(expanded = jobExpanded, onDismissRequest = { jobExpanded = false }) {
              DropdownMenuItem(
                text = { Text("জমির মোট বকেয়ার বিপরীতে") },
                onClick = { selectedJobId = null; jobExpanded = false },
              )
              landJobs.forEach { j ->
                DropdownMenuItem(
                  text = { Text("${j.jobCode} • বাকি ${FormatUtils.formatTaka(j.remainingDue, currencySymbol)}") },
                  onClick = { selectedJobId = j.id; jobExpanded = false },
                )
              }
            }
          }
        }

        // Balance summary banner
        if (activeSummary != null) {
          Surface(
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
            shape = MaterialTheme.shapes.small,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
              Text(
                "জমির বকেয়া: ${FormatUtils.formatTaka(selectedLandSummary?.currentBalance ?: 0.0, currencySymbol)} | মোট বকেয়া: ${FormatUtils.formatTaka(activeSummary.totalOutstandingBalance, currencySymbol)}",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold,
              )
              Text(
                "অবশিষ্ট অগ্রিম: ${FormatUtils.formatTaka(activeSummary.remainingAdvance, currencySymbol)}",
                style = MaterialTheme.typography.bodySmall,
              )
            }
          }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = amountText,
            onValueChange = { amountText = it; errorMsg = null },
            label = { Text(strings.paymentAmount) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.weight(1f).testTag("payment_amount_input"),
          )
          OutlinedTextField(
            value = dateText,
            onValueChange = { dateText = it },
            label = { Text(strings.paymentDate) },
            placeholder = { Text("DD-MM-YYYY") },
            singleLine = true,
            modifier = Modifier.weight(1f),
          )
        }

        OutlinedTextField(
          value = timeText,
          onValueChange = { timeText = it },
          label = { Text("সময় (HH:mm)") },
          placeholder = { Text("15:30") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )

        if (mode != PaymentDialogMode.ADVANCE_ADJUST) {
          Text(strings.paymentMethod, style = MaterialTheme.typography.labelMedium)
          FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PaymentMethod.entries.forEach { pm ->
              FilterChip(
                selected = method == pm.code,
                onClick = { method = pm.code },
                label = { Text(strings.paymentMethodLabel(pm.code)) },
              )
            }
          }
        }

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text(strings.notes) },
          modifier = Modifier.fillMaxWidth(),
        )

        if (errorMsg != null) {
          Text(errorMsg!!, color = MaterialTheme.colorScheme.error)
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val amt = amountText.toDoubleOrNull()
          if (selectedCustomerId.isBlank() || amt == null || amt <= 0.0) {
            errorMsg = "সঠিক কাস্টমার ও টাকার পরিমাণ দিন"
            return@Button
          }
          val parsedDate = FormatUtils.parseDmyDate(dateText) ?: System.currentTimeMillis()
          val timeParts = timeText.split(":")
          val dateCalendar = java.util.Calendar.getInstance().apply { timeInMillis = parsedDate }
          val hour = timeParts.getOrNull(0)?.toIntOrNull()
          val minute = timeParts.getOrNull(1)?.toIntOrNull()
          if (hour == null || minute == null || hour !in 0..23 || minute !in 0..59) {
            errorMsg = "সময় ২৪ ঘণ্টার HH:mm ফরম্যাটে লিখুন"
            return@Button
          }
          dateCalendar.set(java.util.Calendar.HOUR_OF_DAY, hour)
          dateCalendar.set(java.util.Calendar.MINUTE, minute)
          dateCalendar.set(java.util.Calendar.SECOND, 0)
          val dateMs = dateCalendar.timeInMillis
          when (mode) {
            PaymentDialogMode.PAYMENT -> {
              if (selectedLandId.isBlank()) {
                errorMsg = "জমির হিসাব আলাদা রাখতে একটি জমি নির্বাচন করুন"
                return@Button
              }
              val target = if (selectedJobId != null) PaymentTargetType.JOB.code else PaymentTargetType.LAND.code
              onSubmitPayment(selectedCustomerId, selectedLandId, selectedJobId, target, dateMs, amt, method, notes)
            }
            PaymentDialogMode.ADVANCE_RECEIVE -> {
              onSubmitAdvanceReceive(
                selectedCustomerId,
                selectedLandId.takeIf { it.isNotBlank() },
                amt,
                method,
                dateMs,
                notes,
              )
            }
            PaymentDialogMode.ADVANCE_ADJUST -> {
              if (selectedLandId.isBlank()) {
                errorMsg = "অগ্রিম সমন্বয়ের জন্য জমি নির্বাচন করুন"
                return@Button
              }
              onSubmitAdvanceAdjust(selectedCustomerId, selectedLandId, selectedJobId, amt, dateMs, notes)
            }
          }
        },
        modifier = Modifier.height(48.dp).testTag("submit_payment_btn"),
      ) {
        Text(strings.save)
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss, modifier = Modifier.height(48.dp)) {
        Text(strings.cancel)
      }
    },
  )
}
