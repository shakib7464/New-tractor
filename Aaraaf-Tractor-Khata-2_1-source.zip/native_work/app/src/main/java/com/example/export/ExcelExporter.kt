package com.example.export

import android.content.Context
import com.example.domain.billing.FormatUtils
import com.example.domain.model.BulkConsolidatedSummary
import com.example.domain.model.CustomerFinancialSummary
import com.example.localization.AppStrings
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Generates genuine Office Open XML (.xlsx) workbooks natively offline with zero external dependencies.
 */
object ExcelExporter {

  suspend fun exportStatementsWorkbook(
    context: Context,
    summaries: List<CustomerFinancialSummary>,
    consolidated: BulkConsolidatedSummary,
    strings: AppStrings,
  ): Result<File> = withContext(Dispatchers.IO) {
    runCatching {
      val dir = File(context.filesDir, "exports").apply { mkdirs() }
      val file = File(dir, "AraafTractorKhata_Report_${FormatUtils.formatTimestampForFile()}.xlsx")

      val summaryRows = listOf(
        listOf("Araaf Tractor Khata - Financial Report", FormatUtils.formatDateTime(System.currentTimeMillis())),
        listOf("Total Customers", consolidated.totalCustomers.toString()),
        listOf("Total Lands", consolidated.totalLands.toString()),
        listOf("Total Jobs", consolidated.totalJobs.toString()),
        listOf("Total Billed (BDT)", consolidated.totalBilledAmount.toString()),
        listOf("Total Discounts (BDT)", consolidated.totalDiscounts.toString()),
        listOf("Total Collected (BDT)", consolidated.totalPaymentsCollected.toString()),
        listOf("Total Advances Received (BDT)", consolidated.totalAdvancesReceived.toString()),
        listOf("Total Outstanding Due (BDT)", consolidated.totalOutstandingAmount.toString()),
      )

      val customerHeader = listOf(
        "Code", "Customer Name", "Mobile", "Village", "Lands", "Opening Due", "Billed", "Paid", "Remaining Advance", "Outstanding Due"
      )
      val customerRows = listOf(customerHeader) + summaries.map { s ->
        listOf(
          s.customer.customerCode,
          s.customer.fullName,
          s.customer.mobileNumber,
          s.customer.village,
          s.lands.size.toString(),
          s.openingBalance.toString(),
          s.totalBilled.toString(),
          s.totalPaid.toString(),
          s.remainingAdvance.toString(),
          s.totalOutstandingBalance.toString(),
        )
      }

      val landHeader = listOf(
        "Land Code", "Customer", "Land Name", "Size", "Unit", "Opening", "Work Charges", "Additional", "Discounts", "Payments", "Advance Adj", "Current Due"
      )
      val landRows = listOf(landHeader) + summaries.flatMap { s ->
        s.lands.map { l ->
          listOf(
            l.land.landCode,
            s.customer.fullName,
            l.land.landName,
            l.land.sizeValue.toString(),
            strings.unitLabel(l.land.unit),
            l.openingBalance.toString(),
            l.workCharges.toString(),
            l.additionalCharges.toString(),
            l.discounts.toString(),
            l.payments.toString(),
            l.advanceAdjustments.toString(),
            l.currentBalance.toString(),
          )
        }
      }

      val jobHeader = listOf(
        "Job Code", "Date", "Customer", "Land", "Work Type", "Area", "Rate", "Base Bill", "Additional", "Discount", "Total Bill", "Paid+Adv", "Due", "Status"
      )
      val jobRows = listOf(jobHeader) + summaries.flatMap { s ->
        val landNames = s.lands.associate { it.land.id to it.land.landName }
        s.jobs.map { j ->
          listOf(
            j.jobCode,
            FormatUtils.formatDate(j.workDate),
            s.customer.fullName,
            landNames[j.landId] ?: "-",
            strings.workTypeLabel(j.workType, j.customWorkName),
            j.landArea.toString(),
            j.rate.toString(),
            j.baseBill.toString(),
            j.additionalCharges.toString(),
            j.discount.toString(),
            j.totalBill.toString(),
            (j.amountPaid + j.advanceAdjustment).toString(),
            j.remainingDue.toString(),
            strings.jobStatusLabel(j.status),
          )
        }
      }

      val payHeader = listOf("Receipt No", "Date", "Customer", "Land", "Method", "Amount", "Notes")
      val payRows = listOf(payHeader) + summaries.flatMap { s ->
        val landNames = s.lands.associate { it.land.id to it.land.landName }
        s.payments.map { p ->
          listOf(
            p.receiptNumber,
            FormatUtils.formatDate(p.paymentDate),
            s.customer.fullName,
            landNames[p.landId] ?: "-",
            strings.paymentMethodLabel(p.paymentMethod),
            p.amount.toString(),
            p.notes,
          )
        }
      }

      val sheets = listOf(
        "Summary" to summaryRows,
        "Customers" to customerRows,
        "Lands" to landRows,
        "Jobs" to jobRows,
        "Payments" to payRows,
      )

      ZipOutputStream(FileOutputStream(file)).use { zip ->
        writeEntry(zip, "[Content_Types].xml", contentTypesXml(sheets.size))
        writeEntry(zip, "_rels/.rels", rootRelsXml())
        writeEntry(zip, "xl/workbook.xml", workbookXml(sheets.map { it.first }))
        writeEntry(zip, "xl/_rels/workbook.xml.rels", workbookRelsXml(sheets.size))
        sheets.forEachIndexed { idx, (_, rows) ->
          writeEntry(zip, "xl/worksheets/sheet${idx + 1}.xml", sheetXml(rows))
        }
      }

      file
    }
  }

  private fun writeEntry(zip: ZipOutputStream, name: String, content: String) {
    zip.putNextEntry(ZipEntry(name))
    zip.write(content.toByteArray(Charsets.UTF_8))
    zip.closeEntry()
  }

  private fun contentTypesXml(sheetCount: Int): String = buildString {
    append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
    append("""<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""")
    append("""<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""")
    append("""<Default Extension="xml" ContentType="application/xml"/>""")
    append("""<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>""")
    for (i in 1..sheetCount) {
      append("""<Override PartName="/xl/worksheets/sheet$i.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>""")
    }
    append("</Types>")
  }

  private fun rootRelsXml(): String =
    """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
      |<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      |<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
      |</Relationships>""".trimMargin()

  private fun workbookXml(names: List<String>): String = buildString {
    append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
    append("""<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>""")
    names.forEachIndexed { idx, name ->
      append("""<sheet name="${escapeXml(name)}" sheetId="${idx + 1}" r:id="rId${idx + 1}"/>""")
    }
    append("</sheets></workbook>")
  }

  private fun workbookRelsXml(sheetCount: Int): String = buildString {
    append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
    append("""<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
    for (i in 1..sheetCount) {
      append("""<Relationship Id="rId$i" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet$i.xml"/>""")
    }
    append("</Relationships>")
  }

  private fun sheetXml(rows: List<List<String>>): String = buildString {
    append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
    append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>""")
    rows.forEachIndexed { rIdx, row ->
      append("""<row r="${rIdx + 1}">""")
      row.forEachIndexed { cIdx, value ->
        val ref = "${colName(cIdx)}${rIdx + 1}"
        val num = value.toDoubleOrNull()
        if (num != null && !value.startsWith("0")) {
          append("""<c r="$ref" t="n"><v>$num</v></c>""")
        } else {
          append("""<c r="$ref" t="inlineStr"><is><t>${escapeXml(value)}</t></is></c>""")
        }
      }
      append("</row>")
    }
    append("</sheetData></worksheet>")
  }

  private fun colName(index: Int): String {
    var i = index
    val sb = StringBuilder()
    while (i >= 0) {
      sb.insert(0, ('A' + (i % 26)))
      i = i / 26 - 1
    }
    return sb.toString()
  }

  private fun escapeXml(input: String): String =
    input.replace("&", "&amp;")
      .replace("<", "&lt;")
      .replace(">", "&gt;")
      .replace("\"", "&quot;")
      .replace("'", "&apos;")
}
