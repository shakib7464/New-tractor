package com.example.ui.navigation

import android.widget.Toast
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Brush
import androidx.compose.material3.MaterialTheme
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavGraphBuilder
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.Agriculture
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.People
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.data.local.entity.AttachmentOwnerType
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.LandEntity
import com.example.domain.billing.BillingCalculator
import com.example.domain.billing.FormatUtils
import com.example.domain.model.BulkPrintFilter
import com.example.export.PdfPrintHelper
import com.example.localization.AppStrings
import com.example.ui.MainViewModel
import com.example.ui.components.AutoUpdatePrompt
import com.example.ui.components.BulkPrintFilterSheet
import com.example.ui.components.GoogleLoginScreen
import com.example.ui.components.PdfStateHostDialog
import com.example.ui.components.PinBiometricLockScreen
import com.example.ui.screens.AddJobDialog
import com.example.ui.screens.AuditLogScreen
import com.example.ui.screens.BackupRestoreScreen
import com.example.ui.screens.CheckUpdatesScreen
import com.example.ui.screens.CustomerDetailScreen
import com.example.ui.screens.CustomerFormDialog
import com.example.ui.screens.CustomersScreen
import com.example.data.profile.ProfileManager
import com.example.ui.screens.AccountsScreen
import com.example.ui.screens.DashboardListScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DashListKind
import com.example.ui.screens.JobsScreen
import com.example.ui.screens.LandDetailScreen
import com.example.ui.screens.LandFormDialog
import com.example.ui.screens.MoreHubScreen
import com.example.ui.screens.PaymentAndAdvanceDialog
import com.example.ui.screens.PaymentDialogMode
import com.example.ui.screens.RecycleBinScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TractorsScreen
import kotlinx.coroutines.delay
import kotlinx.serialization.Serializable

@Serializable data object RouteDashboard
@Serializable data class RouteCustomers(val duesOnly: Boolean = false)
@Serializable data object RoutePayments
@Serializable data object RouteJobs
@Serializable data object RouteReports
@Serializable data object RouteMore
@Serializable data object RouteFuel
@Serializable data class RouteDashList(val kind: String)
@Serializable data class RouteCustomerDetail(val customerId: String)
@Serializable data class RouteLandDetail(val landId: String)
@Serializable data object RouteTractors
@Serializable data object RouteAccounts
@Serializable data object RouteBackup
@Serializable data object RouteRecycleBin
@Serializable data object RouteAuditLog
@Serializable data object RouteSettings
@Serializable data object RouteUpdates

private val EmphasizedDecelerate = CubicBezierEasing(0.05f, 0.7f, 0.1f, 1f)
private val EmphasizedAccelerate = CubicBezierEasing(0.3f, 0f, 0.8f, 0.15f)

private fun NavBackStackEntry.isTopLevelEntry(): Boolean = destination.let { d ->
  d.hasRoute<RouteDashboard>() || d.hasRoute<RouteCustomers>() ||
    d.hasRoute<RouteJobs>() || d.hasRoute<RouteReports>() || d.hasRoute<RouteMore>()
}

/**
 * প্রতিটি স্ক্রিনের নিজস্ব অস্বচ্ছ ব্যাকগ্রাউন্ড (স্লাইডের সময় নিচের স্ক্রিন ভেসে না ওঠার জন্য) এবং
 * নিজস্ব স্ট্যাটাস-বার প্যাডিং (আগে NavHost-এ বদলাত বলে পেজ বদলের সময় লাফ দিত)।
 */
private inline fun <reified T : Any> NavGraphBuilder.screen(
  statusBar: Boolean = false,
  noinline content: @Composable (NavBackStackEntry) -> Unit,
) {
  composable<T> { entry ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
        .then(if (statusBar) Modifier.statusBarsPadding() else Modifier),
    ) { content(entry) }
  }
}

@Composable
fun AraafAppRoot(viewModel: MainViewModel) {
  val context = LocalContext.current
  val settings by viewModel.settings.collectAsStateWithLifecycle()
  val isUnlocked by viewModel.isUnlocked.collectAsStateWithLifecycle()
  val strings = remember(settings.language) { AppStrings.forLanguage(settings.language) }

  // সেটিংস লোড না হওয়া পর্যন্ত ফাঁকা (লগইন স্ক্রিন ঝলকে না ওঠার জন্য)
  if (!settings.isLoaded) {
    Box(modifier = Modifier.fillMaxSize())
    return
  }

  // Google লগইন (প্রথমবার)
  if (settings.driveAccountEmail.isNullOrBlank() && !settings.loginSkipped) {
    GoogleLoginScreen(
      appName = strings.appName,
      onLogin = { emailHint, token -> viewModel.completeGoogleLogin(emailHint, token) },
      onSkip = { viewModel.skipLogin() },
    )
    return
  }

  if (settings.pinLockEnabled && !isUnlocked) {
    PinBiometricLockScreen(
      biometricEnabled = settings.biometricEnabled,
      lockType = settings.lockType,
      onVerifyPin = { viewModel.verifyPin(it) },
      onBiometricSuccess = { viewModel.markUnlocked() },
      lockRemainingMillis = { viewModel.pinLockRemainingMillis() },
    )
    return
  }

  val navController = rememberNavController()
  val snackbarHostState = remember { SnackbarHostState() }

  val dashboardSummary by viewModel.dashboardSummary.collectAsStateWithLifecycle()
  val customerSummaries by viewModel.customerSummaries.collectAsStateWithLifecycle()
  val customers by viewModel.customers.collectAsStateWithLifecycle()
  val lands by viewModel.lands.collectAsStateWithLifecycle()
  val tractors by viewModel.tractors.collectAsStateWithLifecycle()
  val jobs by viewModel.jobs.collectAsStateWithLifecycle()
  val payments by viewModel.payments.collectAsStateWithLifecycle()
  val pdfState by viewModel.pdfState.collectAsStateWithLifecycle()

  LaunchedEffect(Unit) {
    viewModel.snackbarEvents.collect { msg ->
      snackbarHostState.showSnackbar(msg)
    }
  }

  // অ্যাপ খোলা থাকলে প্রায় রিয়েল-টাইম সিঙ্ক: খোলার সময় এবং তারপর প্রতি ৪৫ সেকেন্ডে
  val lifecycleOwner = LocalLifecycleOwner.current
  LaunchedEffect(settings.driveAccountEmail) {
    if (!settings.driveAccountEmail.isNullOrBlank()) {
      lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
        while (true) {
          viewModel.syncNow(silent = true)
          delay(45_000L)
        }
      }
    }
  }

  // Modal Dialog States
  var customerDialogEdit by remember { mutableStateOf<Pair<Boolean, CustomerEntity?>>(false to null) }
  var landDialogState by remember { mutableStateOf<Triple<Boolean, String?, LandEntity?>>(Triple(false, null, null)) }
  var landNewCustomer by remember { mutableStateOf<Pair<String, String>?>(null) }
  var addingCustomerForLand by remember { mutableStateOf(false) }
  var customerPrefillName by remember { mutableStateOf("") }
  var addingCustomerForJob by remember { mutableStateOf(false) }
  var addingLandForJob by remember { mutableStateOf(false) }
  var jobNewCustomerId by remember { mutableStateOf<String?>(null) }
  var jobNewLandId by remember { mutableStateOf<String?>(null) }
  var jobDialogPreselect by remember { mutableStateOf<Triple<Boolean, String?, String?>>(Triple(false, null, null)) }
  var paymentDialogPreselect by remember { mutableStateOf<Triple<Boolean, String?, String?>>(Triple(false, null, null)) }
  var showBulkFilterSheet by remember { mutableStateOf(false) }
  var activeProfileName by remember { mutableStateOf(ProfileManager.active(context).name) }

  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentDest = navBackStackEntry?.destination
  val isTopLevel = currentDest == null ||
    currentDest.hasRoute<RouteDashboard>() ||
    currentDest.hasRoute<RouteCustomers>() ||
    currentDest.hasRoute<RouteJobs>() ||
    currentDest.hasRoute<RouteReports>() ||
    currentDest.hasRoute<RouteMore>()

  val topTabs = listOf(
    Triple(RouteDashboard, strings.navDashboard, Icons.Rounded.Dashboard) to "nav_dashboard",
    Triple(RouteCustomers(false), strings.navCustomers, Icons.Rounded.People) to "nav_customers",
    Triple(RouteMore, "প্রোফাইল", Icons.Rounded.AccountCircle) to "nav_more",
  )

  fun navigateTop(route: Any) {
    navController.navigate(route) {
      popUpTo(RouteDashboard) { saveState = true }
      launchSingleTop = true
      restoreState = true
    }
  }

  BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
    val useRail = maxWidth >= 600.dp

    Row(modifier = Modifier.fillMaxSize()) {
      if (useRail && isTopLevel) {
        NavigationRail(containerColor = Color(0xFF1B4332), contentColor = Color.White) {
          topTabs.forEach { (triple, tag) ->
            val (route, label, icon) = triple
            val selected = when (route) {
              is RouteDashboard -> currentDest?.hasRoute<RouteDashboard>() == true
              is RouteCustomers -> currentDest?.hasRoute<RouteCustomers>() == true
              is RouteJobs -> currentDest?.hasRoute<RouteJobs>() == true
              is RouteReports -> currentDest?.hasRoute<RouteReports>() == true
              is RouteMore -> currentDest?.hasRoute<RouteMore>() == true
              else -> false
            }
            NavigationRailItem(
              selected = selected,
              onClick = { navigateTop(route) },
              icon = { Icon(icon, contentDescription = label) },
              label = { Text(label) },
              colors = NavigationRailItemDefaults.colors(
                selectedIconColor = Color(0xFF1B4332),
                selectedTextColor = Color(0xFFFDE68A),
                indicatorColor = Color(0xFFFDE68A),
                unselectedIconColor = Color.White.copy(alpha = 0.72f),
                unselectedTextColor = Color.White.copy(alpha = 0.72f),
              ),
              modifier = Modifier.testTag(tag),
            )
          }
        }
      }

      Scaffold(
        modifier = Modifier.weight(1f),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
          if (!useRail && isTopLevel) {
            NavigationBar(
              containerColor = Color.Transparent,
              contentColor = Color.White,
              modifier = Modifier.background(
                Brush.horizontalGradient(listOf(Color(0xFF1B4332), Color(0xFF2D6A4F), Color(0xFF40916C))),
              ),
            ) {
              topTabs.forEach { (triple, tag) ->
                val (route, label, icon) = triple
                val selected = when (route) {
                  is RouteDashboard -> currentDest?.hasRoute<RouteDashboard>() == true
                  is RouteCustomers -> currentDest?.hasRoute<RouteCustomers>() == true
                  is RouteJobs -> currentDest?.hasRoute<RouteJobs>() == true
                  is RouteReports -> currentDest?.hasRoute<RouteReports>() == true
                  is RouteMore -> currentDest?.hasRoute<RouteMore>() == true
                  else -> false
                }
                NavigationBarItem(
                  selected = selected,
                  onClick = { navigateTop(route) },
                  icon = { Icon(icon, contentDescription = label) },
                  label = { Text(label, maxLines = 1) },
                  colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color(0xFF1B4332),
                    selectedTextColor = Color(0xFFFDE68A),
                    indicatorColor = Color(0xFFFDE68A),
                    unselectedIconColor = Color.White.copy(alpha = 0.72f),
                    unselectedTextColor = Color.White.copy(alpha = 0.72f),
                  ),
                  modifier = Modifier.testTag(tag),
                )
              }
            }
          }
        },
      ) { innerPadding ->
        // যেসব স্ক্রিনে নিজস্ব TopAppBar নেই, সেখানে স্ট্যাটাস বারের নিচে কনটেন্ট নামানো হলো
        NavHost(
          navController = navController,
          startDestination = RouteDashboard,
          modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding),
          enterTransition = {
            if (initialState.isTopLevelEntry() && targetState.isTopLevelEntry()) {
              // ট্যাব বদল: পুরনোটা মিলিয়ে গিয়ে নতুনটা হালকা স্কেলসহ ফুটে ওঠে (fade-through)
              fadeIn(tween(210, delayMillis = 90, easing = EmphasizedDecelerate)) +
                scaleIn(tween(210, delayMillis = 90, easing = EmphasizedDecelerate), initialScale = 0.96f)
            } else {
              slideInHorizontally(tween(340, easing = EmphasizedDecelerate)) { it / 3 } +
                fadeIn(tween(220, easing = EmphasizedDecelerate))
            }
          },
          exitTransition = {
            if (initialState.isTopLevelEntry() && targetState.isTopLevelEntry()) {
              fadeOut(tween(90, easing = EmphasizedAccelerate))
            } else {
              slideOutHorizontally(tween(340, easing = EmphasizedDecelerate)) { -it / 6 } +
                fadeOut(tween(200, easing = EmphasizedAccelerate))
            }
          },
          popEnterTransition = {
            if (initialState.isTopLevelEntry() && targetState.isTopLevelEntry()) {
              fadeIn(tween(210, delayMillis = 90, easing = EmphasizedDecelerate)) +
                scaleIn(tween(210, delayMillis = 90, easing = EmphasizedDecelerate), initialScale = 0.96f)
            } else {
              slideInHorizontally(tween(340, easing = EmphasizedDecelerate)) { -it / 6 } +
                fadeIn(tween(220, easing = EmphasizedDecelerate))
            }
          },
          popExitTransition = {
            if (initialState.isTopLevelEntry() && targetState.isTopLevelEntry()) {
              fadeOut(tween(90, easing = EmphasizedAccelerate))
            } else {
              slideOutHorizontally(tween(340, easing = EmphasizedDecelerate)) { it / 3 } +
                fadeOut(tween(200, easing = EmphasizedAccelerate))
            }
          },
        ) {
          screen<RouteDashboard>(statusBar = true) {
            DashboardScreen(
              summary = dashboardSummary,
              strings = strings,
              currencySymbol = settings.currencySymbol,
              onAddCustomer = { customerDialogEdit = true to null },
              onAddLand = { landDialogState = Triple(true, null, null) },
              onAddJob = {
                if (lands.isEmpty()) {
                  Toast.makeText(context, "আগে কাস্টমার ও জমি যোগ করুন", Toast.LENGTH_SHORT).show()
                } else {
                  jobDialogPreselect = Triple(true, null, null)
                }
              },
              onReceivePayment = {
                if (customers.isEmpty()) {
                  Toast.makeText(context, "আগে কাস্টমার যোগ করুন", Toast.LENGTH_SHORT).show()
                } else {
                  paymentDialogPreselect = Triple(true, null, null)
                }
              },
              onOpenPayments = { navController.navigate(RoutePayments) },
              onViewOutstandingDues = { navigateTop(RouteCustomers(duesOnly = true)) },
              onViewReports = { navigateTop(RouteReports) },
              onOpenFuel = { navController.navigate(RouteFuel) },
              onOneClickBulkPrint = { viewModel.generateBulkAllCustomersPdf(BulkPrintFilter()) },
              onConfigureBulkPrint = { showBulkFilterSheet = true },
              profileName = activeProfileName,
              onOpenBills = { navController.navigate(RouteDashList(DashListKind.BILLS)) },
              onOpenCollected = { navController.navigate(RouteDashList(DashListKind.COLLECTED)) },
              onOpenDues = { navController.navigate(RouteDashList(DashListKind.DUES)) },
              onOpenTodaysWork = { navController.navigate(RouteDashList(DashListKind.TODAY_WORK)) },
              onOpenTodaysCollection = { navController.navigate(RouteDashList(DashListKind.TODAY_COLLECTION)) },
            )
          }

          screen<RouteDashList> { backStackEntry ->
            val args = backStackEntry.toRoute<RouteDashList>()
            DashboardListScreen(
              kind = args.kind,
              summaries = customerSummaries,
              jobs = jobs,
              payments = payments,
              customers = customers,
              lands = lands,
              strings = strings,
              currencySymbol = settings.currencySymbol,
              onBack = { navController.popBackStack() },
              onSelectCustomer = { id -> navController.navigate(RouteCustomerDetail(id)) },
            )
          }

          screen<RoutePayments> {
            com.example.ui.screens.PaymentsScreen(
              payments = payments,
              customers = customers,
              lands = lands,
              strings = strings,
              currencySymbol = settings.currencySymbol,
              onBack = { navController.popBackStack() },
              onAddPayment = {
                if (customers.isEmpty()) {
                  Toast.makeText(context, "আগে কাস্টমার যোগ করুন", Toast.LENGTH_SHORT).show()
                } else {
                  paymentDialogPreselect = Triple(true, null, null)
                }
              },
            )
          }

          screen<RouteCustomers>(statusBar = true) { backStackEntry ->
            val args = backStackEntry.toRoute<RouteCustomers>()
            CustomersScreen(
              summaries = customerSummaries,
              strings = strings,
              currencySymbol = settings.currencySymbol,
              initialFilterDuesOnly = args.duesOnly,
              onSelectCustomer = { id -> navController.navigate(RouteCustomerDetail(id)) },
              onAddCustomer = { customerDialogEdit = true to null },
              onOneClickBulkPrint = { viewModel.generateBulkAllCustomersPdf(BulkPrintFilter()) },
              onConfigureBulkPrint = { showBulkFilterSheet = true },
            )
          }

          screen<RouteJobs>(statusBar = true) {
            JobsScreen(
              jobs = jobs,
              customers = customers,
              lands = lands,
              strings = strings,
              currencySymbol = settings.currencySymbol,
              onAddJob = {
                if (lands.isEmpty()) {
                  Toast.makeText(context, "আগে কাস্টমার ও জমি যোগ করুন", Toast.LENGTH_SHORT).show()
                } else {
                  jobDialogPreselect = Triple(true, null, null)
                }
              },
              onUpdateStatus = { jobId, st -> viewModel.updateJobStatus(jobId, st) },
              onDeleteJob = { viewModel.softDeleteJob(it) },
            )
          }

          screen<RouteReports>(statusBar = true) {
            ReportsScreen(
              summaries = customerSummaries,
              jobs = jobs,
              payments = payments,
              strings = strings,
              currencySymbol = settings.currencySymbol,
              onOneClickBulkPrint = { filter -> viewModel.generateBulkAllCustomersPdf(filter) },
              onConfigureBulkPrint = { showBulkFilterSheet = true },
              onExportExcel = { filter ->
                viewModel.exportExcelReport(filter) { file ->
                  PdfPrintHelper.shareFile(
                    context,
                    file,
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "Tractor Khata Excel Report",
                  )
                }
              },
              onSelectCustomer = { id -> navController.navigate(RouteCustomerDetail(id)) },
            )
          }

          screen<RouteFuel>(statusBar = true) {
            val fuelDealers by viewModel.fuelDealers.collectAsStateWithLifecycle()
            val fuelEntries by viewModel.fuelEntries.collectAsStateWithLifecycle()
            com.example.ui.screens.FuelScreen(
              dealers = fuelDealers,
              entries = fuelEntries,
              currencySymbol = settings.currencySymbol,
              onBack = { navController.popBackStack() },
              onSaveDealer = { name, mobile -> viewModel.saveFuelDealer(name, mobile) },
              onUpdateDealer = { dealer, name, mobile -> viewModel.updateFuelDealer(dealer, name, mobile) },
              onDeleteDealer = { dealer -> viewModel.deleteFuelDealer(dealer) },
              onSaveEntry = { dealerId, isPurchase, date, liters, rate, amount, driver, note ->
                viewModel.saveFuelEntry(dealerId, isPurchase, date, liters, rate, amount, driver, note)
              },
              onUpdateEntry = { entry, dealerId, isPurchase, date, liters, rate, amount, driver, note ->
                viewModel.updateFuelEntry(entry, dealerId, isPurchase, date, liters, rate, amount, driver, note)
              },
              onDeleteEntry = { entry -> viewModel.deleteFuelEntry(entry) },
            )
          }
          screen<RouteMore>(statusBar = true) {
            val deletedCustomers by viewModel.deletedCustomers.collectAsStateWithLifecycle()
            val deletedLands by viewModel.deletedLands.collectAsStateWithLifecycle()
            val deletedJobs by viewModel.deletedJobs.collectAsStateWithLifecycle()
            val deletedPayments by viewModel.deletedPayments.collectAsStateWithLifecycle()
            val trashCount = deletedCustomers.size + deletedLands.size + deletedJobs.size + deletedPayments.size
            val lastBackupText = settings.lastSuccessfulBackupMillis?.let {
              "${strings.lastBackupLabel}: ${FormatUtils.formatDateTime(it)}"
            } ?: "অফলাইন JSON ও Google Drive ব্যাকআপ"

            MoreHubScreen(
              strings = strings,
              profileName = activeProfileName,
              profileCount = remember(activeProfileName) { ProfileManager.list(context).size },
              accountEmail = settings.driveAccountEmail,
              trashCount = trashCount,
              lastBackupText = lastBackupText,
              onOpenJobs = { navController.navigate(RouteJobs) },
              onOpenReports = { navController.navigate(RouteReports) },
              onOpenAccounts = { navController.navigate(RouteAccounts) },
              onOpenBackup = { navController.navigate(RouteBackup) },
              onOpenRecycleBin = { navController.navigate(RouteRecycleBin) },
              onOpenSettings = { navController.navigate(RouteSettings) },
              onOpenUpdates = { navController.navigate(RouteUpdates) },
            )
          }

          screen<RouteAccounts> {
            var profiles by remember { mutableStateOf(ProfileManager.list(context)) }
            AccountsScreen(
              profiles = profiles,
              activeId = ProfileManager.activeId(context),
              accountEmail = settings.driveAccountEmail,
              onLogout = { force, onResult -> viewModel.switchAccount(force, onResult) },
              onBack = { navController.popBackStack() },
              onAddProfile = { name ->
                ProfileManager.add(context, name).also { profiles = ProfileManager.list(context) }
              },
              onRename = { id, name ->
                ProfileManager.rename(context, id, name)
                profiles = ProfileManager.list(context)
                activeProfileName = ProfileManager.active(context).name
              },
              onDelete = { id ->
                ProfileManager.delete(context, id)
                profiles = ProfileManager.list(context)
              },
              onSwitch = { id ->
                ProfileManager.setActive(context, id)
                ProfileManager.restartApp(context)
              },
            )
          }

          screen<RouteCustomerDetail> { backStackEntry ->
            val args = backStackEntry.toRoute<RouteCustomerDetail>()
            val summary = customerSummaries.firstOrNull { it.customer.id == args.customerId }
            val attachments by viewModel
              .observeAttachments(AttachmentOwnerType.CUSTOMER.code, args.customerId)
              .collectAsStateWithLifecycle(emptyList())

            if (summary != null) {
              CustomerDetailScreen(
                summary = summary,
                attachments = attachments,
                strings = strings,
                currencySymbol = settings.currencySymbol,
                onBack = { navController.popBackStack() },
                onEditCustomer = { customerDialogEdit = true to summary.customer },
                onDeleteCustomer = {
                  viewModel.softDeleteCustomer(summary.customer.id)
                  navController.popBackStack()
                },
                onAddLand = { landDialogState = Triple(true, summary.customer.id, null) },
                onSelectLand = { landId -> navController.navigate(RouteLandDetail(landId)) },
                onAddJob = { jobDialogPreselect = Triple(true, summary.customer.id, null) },
                onReceivePayment = { paymentDialogPreselect = Triple(true, summary.customer.id, null) },
                onPrintCustomerStatement = { viewModel.generateCustomerStatementPdf(summary.customer.id) },
                onPrintPaymentReceipt = { pay -> viewModel.generatePaymentReceiptPdf(pay) },
                onAddAttachment = { uri ->
                  viewModel.addAttachment(AttachmentOwnerType.CUSTOMER.code, summary.customer.id, uri)
                },
                onDeleteAttachment = { viewModel.deleteAttachment(it) },
              )
            }
          }

          screen<RouteLandDetail> { backStackEntry ->
            val args = backStackEntry.toRoute<RouteLandDetail>()
            val land = lands.firstOrNull { it.id == args.landId }
            val customer = land?.let { l -> customers.firstOrNull { it.id == l.customerId } }
            val custSummary = customer?.let { c -> customerSummaries.firstOrNull { it.customer.id == c.id } }
            val landSummary = custSummary?.lands?.firstOrNull { it.land.id == args.landId }
            val attachments by viewModel
              .observeAttachments(AttachmentOwnerType.LAND.code, args.landId)
              .collectAsStateWithLifecycle(emptyList())

            if (customer != null && landSummary != null) {
              LandDetailScreen(
                customer = customer,
                landSummary = landSummary,
                cultivationCount = jobs.filter {
                  it.landId == landSummary.land.id && !it.isDeleted &&
                    it.status != com.example.data.local.entity.JobStatus.CANCELLED.code &&
                    it.billingMethod == com.example.data.local.entity.BillingMethod.PER_KATHA.code
                }.minByOrNull { it.createdAt }?.let { it.numberOfPasses ?: 1 } ?: 0,
                attachments = attachments,
                strings = strings,
                currencySymbol = settings.currencySymbol,
                onBack = { navController.popBackStack() },
                onEditLand = { landDialogState = Triple(true, customer.id, landSummary.land) },
                onDeleteLand = {
                  viewModel.softDeleteLand(landSummary.land.id)
                  navController.popBackStack()
                },
                onAddJobForLand = { jobDialogPreselect = Triple(true, customer.id, landSummary.land.id) },
                onReceivePaymentForLand = { paymentDialogPreselect = Triple(true, customer.id, landSummary.land.id) },
                onPrintLandStatement = { viewModel.generateLandStatementPdf(landSummary.land.id) },
                onRecordAdjustment = { amt, isInc, isRef, desc, notes ->
                  viewModel.recordManualLandAdjustment(
                    customer.id, landSummary.land.id, amt, isInc, isRef, desc, notes, System.currentTimeMillis()
                  )
                },
                onAddAttachment = { uri ->
                  viewModel.addAttachment(AttachmentOwnerType.LAND.code, landSummary.land.id, uri)
                },
                onDeleteAttachment = { viewModel.deleteAttachment(it) },
              )
            }
          }

          screen<RouteTractors> {
            TractorsScreen(
              tractors = tractors,
              strings = strings,
              onBack = { navController.popBackStack() },
              onSaveTractor = { id, name, brand, model, reg, notes, active ->
                viewModel.saveTractor(id, name, brand, model, reg, notes, active)
              },
            )
          }

          screen<RouteBackup> {
            val backupHistory by viewModel.backupHistory.collectAsStateWithLifecycle()
            val driveBackups by viewModel.driveBackups.collectAsStateWithLifecycle()
            val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()
            val isSyncing by viewModel.isSyncing.collectAsStateWithLifecycle()
            BackupRestoreScreen(
              settings = settings,
              history = backupHistory,
              driveBackups = driveBackups,
              isBusy = isBusy,
              strings = strings,
              onBack = { navController.popBackStack() },
              onDriveAuthorized = { email, token -> viewModel.setDriveSession(email, token) },
              onDisconnectDrive = { viewModel.setDriveSession(null, null) },
              onBackupDriveNow = { pass -> viewModel.backupToDriveNow(pass) },
              onRefreshDriveList = { viewModel.refreshDriveBackups() },
              onRestoreFromDrive = { fileId, pass, merge ->
                viewModel.restoreFromDrive(fileId, pass, merge) {}
              },
              onToggleAutoBackup = { auto, wifi -> viewModel.setAutoBackup(auto, wifi) },
              onExportJson = { pass, onReady -> viewModel.exportJsonBackup(pass, onReady) },
              onImportJsonUri = { uri, pass, merge -> viewModel.importJsonBackup(uri, pass, merge) {} },
              onShowMessage = { Toast.makeText(context, it, Toast.LENGTH_LONG).show() },
              isSyncing = isSyncing,
              onSyncNow = { viewModel.syncNow(silent = false) },
            )
          }

          screen<RouteRecycleBin> {
            val deletedCustomers by viewModel.deletedCustomers.collectAsStateWithLifecycle()
            val deletedLands by viewModel.deletedLands.collectAsStateWithLifecycle()
            val deletedJobs by viewModel.deletedJobs.collectAsStateWithLifecycle()
            val deletedPayments by viewModel.deletedPayments.collectAsStateWithLifecycle()
            RecycleBinScreen(
              deletedCustomers = deletedCustomers,
              deletedLands = deletedLands,
              deletedJobs = deletedJobs,
              deletedPayments = deletedPayments,
              strings = strings,
              onBack = { navController.popBackStack() },
              onRestoreCustomer = { viewModel.restoreCustomer(it) },
              onRestoreLand = { viewModel.restoreLand(it) },
              onRestoreJob = { viewModel.restoreJob(it) },
              onRestorePayment = { viewModel.restorePayment(it) },
              onPermanentDeleteCustomer = { viewModel.permanentlyDeleteCustomer(it) },
              onPermanentDeleteJob = { viewModel.permanentlyDeleteJob(it) },
            )
          }

          screen<RouteAuditLog> {
            val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()
            AuditLogScreen(
              logs = auditLogs,
              strings = strings,
              onBack = { navController.popBackStack() },
            )
          }

          screen<RouteUpdates> {
            CheckUpdatesScreen(onBack = { navController.popBackStack() })
          }

          screen<RouteSettings> {
            SettingsScreen(
              settings = settings,
              accountEmail = settings.driveAccountEmail,
              onAutoLockChange = { viewModel.setAutoLockSeconds(it) },
              strings = strings,
              onBack = { navController.popBackStack() },
              onLanguageChange = { viewModel.setLanguage(it) },
              onThemeChange = { viewModel.setThemeMode(it) },
              onDefaultUnitChange = { viewModel.setDefaultUnit(it) },
              onSaveDefaultRates = { d, b, a, h -> viewModel.updateDefaultRates(d, b, a, h) },
              onSetLock = { type, secret -> viewModel.setLock(type, secret) },
              onDisablePin = { viewModel.disablePin() },
              onToggleBiometric = { viewModel.setBiometric(it) },
              onOpenBackup = { navController.navigate(RouteBackup) },
            )
          }
        }
      }
    }
  }

  // Modal Dialogs

  if (landDialogState.first) {
    val editingLand = landDialogState.third
    val primaryCultivationJob = editingLand?.let { l ->
      com.example.domain.billing.CultivationJobSelector.pickPrimary(jobs.filter { it.landId == l.id })
    }
    LandFormDialog(
      customers = customers,
      preselectedCustomerId = landDialogState.second,
      existing = landDialogState.third,
      existingCultivationPasses = primaryCultivationJob?.let { it.numberOfPasses ?: 1 },
      existingCultivationRate = primaryCultivationJob?.rate,
      defaultRatePerKatha = settings.defaultRatePerDecimal * 1.65,
      customerSummaries = customerSummaries,
      onAddNewCustomer = { typed -> customerPrefillName = typed; addingCustomerForLand = true; customerDialogEdit = true to null },
      newCustomer = landNewCustomer,
      onNewCustomerConsumed = { landNewCustomer = null },
      defaultUnit = settings.defaultLandUnit,
      strings = strings,
      onDismiss = { landDialogState = Triple(false, null, null); addingLandForJob = false },
      onSave = { custId, name, village, loc, size, unit, crop, season, opening, notes, cultivationRate, cultivationCount, deposit ->
        viewModel.saveLand(
          id = landDialogState.third?.id,
          customerId = custId,
          landName = name,
          village = village,
          locationDetails = loc,
          sizeValue = size,
          unit = unit,
          cropInfo = crop,
          cultivationSeason = season,
          openingBalance = opening,
          notes = notes,
          firstCultivationRatePerKatha = cultivationRate,
          firstCultivationCount = cultivationCount,
          depositAmount = deposit,
        ) { savedLand ->
          landDialogState = Triple(false, null, null)
          if (addingLandForJob) {
            addingLandForJob = false
            jobNewLandId = savedLand.id
          }
        }
      },
    )
  }

  if (customerDialogEdit.first) {
    CustomerFormDialog(
      existing = customerDialogEdit.second,
      initialName = if (addingCustomerForLand) customerPrefillName else "",
      strings = strings,
      onDismiss = { customerDialogEdit = false to null; addingCustomerForLand = false; addingCustomerForJob = false },
      onSave = { name, mobile, addr, village, union, upazila, dist, notes, regDate, customRate ->
        viewModel.saveCustomer(
          id = customerDialogEdit.second?.id,
          fullName = name,
          mobileNumber = mobile,
          address = addr,
          village = village,
          unionName = union,
          upazila = upazila,
          district = dist,
          notes = notes,
          registrationDate = regDate,
          customRatePerUnit = customRate,
        ) { saved ->
          customerDialogEdit = false to null
          if (addingCustomerForLand) {
            addingCustomerForLand = false
            landNewCustomer = saved.id to saved.fullName
          }
          if (addingCustomerForJob) {
            addingCustomerForJob = false
            jobNewCustomerId = saved.id
          }
        }
      },
    )
  }

  if (jobDialogPreselect.first) {
    AddJobDialog(
      summaries = customerSummaries,
      tractors = tractors,
      settings = settings,
      strings = strings,
      preselectedCustomerId = jobDialogPreselect.second,
      preselectedLandId = jobDialogPreselect.third,
      onAddNewCustomer = { addingCustomerForJob = true; customerPrefillName = ""; customerDialogEdit = true to null },
      onAddNewLand = { custId -> addingLandForJob = true; landDialogState = Triple(true, custId, null) },
      pendingCustomerId = jobNewCustomerId,
      pendingLandId = jobNewLandId,
      onPendingCustomerConsumed = { jobNewCustomerId = null },
      onPendingLandConsumed = { jobNewLandId = null },
      onDismiss = { jobDialogPreselect = Triple(false, null, null); jobNewCustomerId = null; jobNewLandId = null },
      onSaveJob = { cId, lId, tId, wDate, wType, customName, bMethod, area, aUnit, rate, hours, addChg, disc, advAdj, paid, pMethod, status, width, depth, passes, startT, endT, opName, notes ->
        viewModel.createJob(
          cId, lId, tId, wDate, wType, customName, bMethod, area, aUnit, rate, hours,
          addChg, disc, advAdj, paid, pMethod, status, width, depth, passes, startT, endT, opName, notes,
        ) {
          jobDialogPreselect = Triple(false, null, null)
        }
      },
    )
  }

  if (paymentDialogPreselect.first) {
    PaymentAndAdvanceDialog(
      summaries = customerSummaries,
      jobs = jobs,
      preselectedCustomerId = paymentDialogPreselect.second,
      preselectedLandId = paymentDialogPreselect.third,
      initialMode = PaymentDialogMode.PAYMENT,
      strings = strings,
      currencySymbol = settings.currencySymbol,
      onDismiss = { paymentDialogPreselect = Triple(false, null, null) },
      onSubmitPayment = { cId, lId, jId, target, dateMs, amt, method, notes ->
        viewModel.recordPayment(cId, lId, jId, target, dateMs, amt, method, notes) {
          paymentDialogPreselect = Triple(false, null, null)
        }
      },
      onSubmitCustomerPayment = { cId, dateMs, amt, method, notes ->
        viewModel.recordCustomerPayment(cId, dateMs, amt, method, notes)
      },
      onSubmitAdvanceReceive = { cId, lId, amt, method, dateMs, notes ->
        viewModel.recordAdvanceReceived(cId, lId, amt, method, dateMs, notes) {
          paymentDialogPreselect = Triple(false, null, null)
        }
      },
      onSubmitAdvanceAdjust = { cId, lId, jId, amt, dateMs, notes ->
        viewModel.adjustAdvanceToLand(cId, lId, jId, amt, dateMs, notes) {
          paymentDialogPreselect = Triple(false, null, null)
        }
      },
    )
  }

  // নতুন ভার্সন থাকলে (GitHub Releases) আপডেট ডায়ালগ
  AutoUpdatePrompt()

  if (showBulkFilterSheet) {
    BulkPrintFilterSheet(
      customers = customers,
      lands = lands,
      initialFilter = BulkPrintFilter(),
      strings = strings,
      onDismiss = { showBulkFilterSheet = false },
      onGeneratePdf = { filter ->
        showBulkFilterSheet = false
        viewModel.generateBulkAllCustomersPdf(filter)
      },
    )
  }

  PdfStateHostDialog(
    pdfState = pdfState,
    strings = strings,
    onCancel = { viewModel.cancelPdfGeneration() },
    onDismiss = { viewModel.dismissPdfState() },
    onSavedLocallyMessage = { msg -> Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() },
  )
}
