package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.LandEntity
import com.example.data.local.entity.PaymentEntity
import com.example.domain.billing.FormatUtils
import com.example.localization.AppStrings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentsScreen(
  payments: List<PaymentEntity>,
  customers: List<CustomerEntity>,
  lands: List<LandEntity>,
  strings: AppStrings,
  currencySymbol: String,
  onBack: () -> Unit,
  onAddPayment: () -> Unit,
) {
  val activePayments = remember(payments) { payments.filter { !it.isDeleted }.sortedByDescending { it.paymentDate } }
  val totalPaid = remember(activePayments) { activePayments.sumOf { it.amount } }
  val receiverGroups = remember(activePayments) {
    activePayments.groupBy { payment ->
      Regex("(?:^|\\|\\s*)গ্রহণকারী:\\s*([^|]+)").find(payment.notes)?.groupValues?.getOrNull(1)?.trim()
        ?.takeIf { it.isNotBlank() } ?: "নাম উল্লেখ নেই"
    }.toList().sortedBy { it.first.lowercase() }
  }
  var expandedReceiver by remember { mutableStateOf<String?>(null) }
  var searchQuery by remember { mutableStateOf("") }
  val visibleReceiverGroups = remember(receiverGroups, searchQuery) {
    receiverGroups
      .filter { (name, entries) ->
        searchQuery.isBlank() || name.contains(searchQuery.trim(), ignoreCase = true) ||
          entries.any { payment ->
            payment.receiptNumber.contains(searchQuery.trim(), ignoreCase = true) ||
              payment.amount.toString().contains(searchQuery.trim())
          }
      }
      .sortedByDescending { it.second.sumOf { payment -> payment.amount } }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("পেমেন্ট গ্রহণকারীর হিসাব") },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, contentDescription = "ফিরে যান") } },
        actions = { Button(onClick = onAddPayment, modifier = Modifier.padding(end = 8.dp)) { Icon(Icons.Rounded.Add, contentDescription = null); Text("পেমেন্ট") } },
      )
    },
  ) { padding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(padding),
      contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth().animateContentSize(),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        ) {
          Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("সর্বমোট গ্রহণ", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
            Text(FormatUtils.formatTaka(totalPaid, currencySymbol), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
            Text("${receiverGroups.size} জন গ্রহণকারী • ${activePayments.size}টি লেনদেন", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
          }
        }
      }
      item {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true,
          label = { Text("গ্রহণকারীর নাম বা রসিদ খুঁজুন") },
          leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
          trailingIcon = {
            if (searchQuery.isNotEmpty()) IconButton(onClick = { searchQuery = "" }) {
              Icon(Icons.Rounded.Close, contentDescription = "মুছুন")
            }
          },
          shape = MaterialTheme.shapes.large,
        )
      }
      if (activePayments.isEmpty()) item { Text("এখনো কোনো পেমেন্টের তথ্য নেই।") }
      else if (visibleReceiverGroups.isEmpty()) item { Text("এই নামে কোনো গ্রহণকারী বা লেনদেন পাওয়া যায়নি।", color = MaterialTheme.colorScheme.onSurfaceVariant) }
      items(visibleReceiverGroups, key = { it.first }) { (receiver, entries) ->
        val expanded = expandedReceiver == receiver
        Card(
          modifier = Modifier.fillMaxWidth().animateContentSize().clickable {
            expandedReceiver = if (expanded) null else receiver
          },
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        ) {
          Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(receiver, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("${entries.size}টি লেনদেন", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              Column(horizontalAlignment = androidx.compose.ui.Alignment.End, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(FormatUtils.formatTaka(entries.sumOf { it.amount }, currencySymbol), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Icon(if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, contentDescription = if (expanded) "বন্ধ করুন" else "বিস্তারিত দেখুন", tint = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
            AnimatedVisibility(visible = expanded, enter = fadeIn(), exit = fadeOut()) {
              Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                entries.forEach { payment ->
                  Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f), shape = MaterialTheme.shapes.medium) {
                    Column(Modifier.fillMaxWidth().padding(11.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                      val customer = customers.firstOrNull { it.id == payment.customerId }
                      val land = lands.firstOrNull { it.id == payment.landId }
                      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(customer?.fullName ?: "অজানা কাস্টমার", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text(FormatUtils.formatTaka(payment.amount, currencySymbol), fontWeight = FontWeight.SemiBold)
                      }
                      Text("জমি: ${land?.landName ?: "—"}", style = MaterialTheme.typography.bodySmall)
                      Text("তারিখ: ${FormatUtils.formatDateTime(payment.paymentDate)}", style = MaterialTheme.typography.bodySmall)
                      Text("মাধ্যম: ${strings.paymentMethodLabel(payment.paymentMethod)}", style = MaterialTheme.typography.bodySmall)
                      Text("রসিদ: ${payment.receiptNumber}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
