package com.example

import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.backup.BackupRepository
import com.example.data.local.AraafDatabase
import com.example.data.local.entity.BillingMethod
import com.example.data.local.entity.JobStatus
import com.example.data.local.entity.LandUnit
import com.example.data.local.entity.LedgerTransactionEntity
import com.example.data.local.entity.PaymentMethod
import com.example.data.local.entity.PaymentTargetType
import com.example.data.local.entity.TransactionType
import com.example.data.local.entity.WorkType
import com.example.data.preferences.AppPreferencesManager
import com.example.data.repository.DuplicateCustomerException
import com.example.data.repository.KhataRepository
import com.example.domain.billing.BillingCalculator
import com.example.domain.billing.FormatUtils
import com.example.domain.model.BulkPrintFilter
import com.example.export.ExcelExporter
import com.example.export.PdfBackend
import com.example.export.PdfGenerator
import com.example.export.PdfPageHandle
import com.example.localization.AppStrings
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AraafKhataComprehensiveTest {

  private lateinit var context: Context
  private lateinit var db: AraafDatabase
  private lateinit var repo: KhataRepository
  private lateinit var prefs: AppPreferencesManager
  private lateinit var backupRepo: BackupRepository
  private lateinit var pdfGen: PdfGenerator

  private var lastPdfPageCount = 0

  @Before
  fun setup() {
    context = ApplicationProvider.getApplicationContext()
    db = Room.inMemoryDatabaseBuilder(context, AraafDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    repo = KhataRepository(context, db)
    prefs = AppPreferencesManager(context)
    backupRepo = BackupRepository(context, db, prefs)
    pdfGen = PdfGenerator(context) {
      object : PdfBackend {
        var pages = 0
        override fun startPage(width: Int, height: Int, pageNumber: Int): PdfPageHandle {
          pages++
          val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
          return object : PdfPageHandle {
            override val canvas: Canvas = Canvas(bmp)
          }
        }
        override fun finishPage(page: PdfPageHandle) {}
        override fun writeTo(out: FileOutputStream) {
          out.write("%PDF-1.4\n% Araaf Tractor Khata Pages=$pages\n%%EOF".toByteArray())
        }
        override fun close() {
          lastPdfPageCount = pages
        }
      }
    }
  }

  @After
  fun tearDown() {
    db.close()
  }

  @Test
  fun `billing calculator supports all six billing methods accurately`() {
    val perDec = BillingCalculator.calculateJobBill(
      BillingMethod.PER_DECIMAL.code, 45.0, 35.0, null, 100.0, 75.0, 200.0, 500.0
    )
    // 45 * 35 = 1575; +100 -75 = 1600; -200 -500 = 900
    assertEquals(1575.0, perDec.baseBill, 0.01)
    assertEquals(1600.0, perDec.totalBill, 0.01)
    assertEquals(900.0, perDec.remainingDue, 0.01)

    val perBigha = BillingCalculator.calculateJobBill(
      BillingMethod.PER_BIGHA.code, 2.5, 1200.0, null, 0.0, 0.0, 0.0, 0.0
    )
    assertEquals(3000.0, perBigha.totalBill, 0.01)

    val perAcre = BillingCalculator.calculateJobBill(
      BillingMethod.PER_ACRE.code, 1.5, 3400.0, null, 0.0, 100.0, 0.0, 0.0
    )
    assertEquals(5000.0, perAcre.totalBill, 0.01)

    val perHour = BillingCalculator.calculateJobBill(
      BillingMethod.PER_HOUR.code, 0.0, 1200.0, 2.5, 0.0, 0.0, 0.0, 1000.0
    )
    assertEquals(3000.0, perHour.baseBill, 0.01)
    assertEquals(2000.0, perHour.remainingDue, 0.01)

    val fixed = BillingCalculator.calculateJobBill(
      BillingMethod.FIXED_AMOUNT.code, 0.0, 2200.0, null, 0.0, 200.0, 0.0, 0.0
    )
    assertEquals(2000.0, fixed.totalBill, 0.01)

    val custom = BillingCalculator.calculateJobBill(
      BillingMethod.CUSTOM_AMOUNT.code, 0.0, 1850.0, null, 150.0, 0.0, 0.0, 0.0
    )
    assertEquals(2000.0, custom.totalBill, 0.01)
  }

  @Test
  fun `end to end customer lands independent ledgers advances payments pdf excel backup and recycle bin`() = runTest {
    AraafDatabase.seedInitialTractorAndDevice(db)
    val tractors = repo.getAllTractorsNow()
    assertEquals(1, tractors.size)

    // Add second tractor
    val tr2 = repo.saveTractor(null, "আরাফ ট্রাক্টর-০২", "John Deere", "5050D", "REG-2026", "", true).getOrThrow()
    assertEquals(2, repo.getAllTractorsNow().size)

    // 1. Add Customers & Duplicate Prevention
    val c1 = repo.saveCustomer(
      fullName = "মোঃ রহিম উদ্দিন",
      mobileNumber = "01711000001",
      address = "পূর্বপাড়া",
      village = "সোনাপুর",
      unionName = "সোনাপুর",
      upazila = "সদর",
      district = "বগুড়া",
      notes = "নিয়মিত কাস্টমার",
      registrationDate = System.currentTimeMillis(),
    ).getOrThrow()

    val dupResult = repo.saveCustomer(
      fullName = "মোঃ রহিম উদ্দিন",
      mobileNumber = "01711000001",
      address = "",
      village = "সোনাপুর",
      unionName = "",
      upazila = "",
      district = "",
      notes = "",
      registrationDate = System.currentTimeMillis(),
    )
    assertTrue(dupResult.exceptionOrNull() is DuplicateCustomerException)

    val c2 = repo.saveCustomer(
      fullName = "করিম মিয়া",
      mobileNumber = "01811000002",
      address = "উত্তরপাড়া",
      village = "মধুপুর",
      unionName = "",
      upazila = "",
      district = "বগুড়া",
      notes = "",
      registrationDate = System.currentTimeMillis(),
    ).getOrThrow()

    // 2. Multiple lands under customer 1 with opening balance
    val landA = repo.saveLand(
      customerId = c1.id,
      landName = "বিলপাড়ার জমি",
      village = "সোনাপুর",
      locationDetails = "দাগ ১০১",
      sizeValue = 50.0,
      unit = LandUnit.DECIMAL.code,
      cropInfo = "বোরো ধান",
      cultivationSeason = "রবি",
      openingBalance = 500.0,
      notes = "",
    ).getOrThrow()

    val landB = repo.saveLand(
      customerId = c1.id,
      landName = "পশ্চিমের মাঠ",
      village = "সোনাপুর",
      locationDetails = "দাগ ২০৫",
      sizeValue = 2.0,
      unit = LandUnit.BIGHA.code,
      cropInfo = "আমন",
      cultivationSeason = "খরিফ",
      openingBalance = 0.0,
      notes = "",
    ).getOrThrow()

    val landC = repo.saveLand(
      customerId = c2.id,
      landName = "নদীর ধারের জমি",
      village = "মধুপুর",
      locationDetails = "",
      sizeValue = 1.0,
      unit = LandUnit.ACRE.code,
      cropInfo = "ভুট্টা",
      cultivationSeason = "রবি",
      openingBalance = 0.0,
      notes = "",
    ).getOrThrow()

    // 3. Advance payment received (must NOT auto-deduct Land A's 500 opening due!)
    repo.recordAdvanceReceived(
      customerId = c1.id,
      landId = null,
      amount = 1000.0,
      paymentMethod = PaymentMethod.BKASH.code,
      transactionDate = System.currentTimeMillis(),
      notes = "অগ্রিম জমা",
    ).getOrThrow()

    assertEquals(500.0, repo.computeLandBalanceNow(landA.id), 0.01)

    // 4. Jobs on Land A and Land B (separate ledgers, repeated work on Land A)
    val job1 = repo.createAgriculturalJob(
      customerId = c1.id,
      landId = landA.id,
      tractorId = tractors.first().id,
      workDate = System.currentTimeMillis(),
      workType = WorkType.ROTAVATOR.code,
      customWorkName = "",
      billingMethod = BillingMethod.PER_DECIMAL.code,
      landArea = 50.0,
      areaUnit = LandUnit.DECIMAL.code,
      rate = 40.0, // 2000
      workingHours = null,
      additionalCharges = 100.0,
      discount = 50.0, // Total bill = 2050
      advanceAdjustmentRequested = 400.0, // explicit advance adjustment
      amountPaidNow = 650.0, // partial payment
      paymentMethod = PaymentMethod.CASH.code,
      status = JobStatus.COMPLETED.code,
      rotavatorWidth = "6 ft",
      workingDepth = "6 inch",
      numberOfPasses = 2,
      startTime = "08:00",
      finishTime = "10:00",
      operatorName = "জামাল",
      notes = "",
    ).getOrThrow()

    // Land A balance should be: 500 (opening) + 2050 (bill) - 400 (adv) - 650 (paid) = 1500
    assertEquals(1500.0, repo.computeLandBalanceNow(landA.id), 0.01)
    // Land B must remain completely untouched = 0
    assertEquals(0.0, repo.computeLandBalanceNow(landB.id), 0.01)

    // Repeat work on Land A + work on Land B
    repo.createAgriculturalJob(
      customerId = c1.id,
      landId = landA.id,
      tractorId = tr2.id,
      workDate = System.currentTimeMillis(),
      workType = WorkType.LAND_PLOUGHING.code,
      customWorkName = "",
      billingMethod = BillingMethod.PER_DECIMAL.code,
      landArea = 50.0,
      areaUnit = LandUnit.DECIMAL.code,
      rate = 20.0, // 1000
      workingHours = null,
      additionalCharges = 0.0,
      discount = 0.0,
      advanceAdjustmentRequested = 0.0,
      amountPaidNow = 0.0,
      paymentMethod = PaymentMethod.CASH.code,
      status = JobStatus.COMPLETED.code,
      rotavatorWidth = "",
      workingDepth = "",
      numberOfPasses = null,
      startTime = "",
      finishTime = "",
      operatorName = "",
      notes = "",
    ).getOrThrow()

    repo.createAgriculturalJob(
      customerId = c1.id,
      landId = landB.id,
      tractorId = tr2.id,
      workDate = System.currentTimeMillis(),
      workType = WorkType.HARROWING.code,
      customWorkName = "",
      billingMethod = BillingMethod.PER_BIGHA.code,
      landArea = 2.0,
      areaUnit = LandUnit.BIGHA.code,
      rate = 1200.0, // 2400
      workingHours = null,
      additionalCharges = 0.0,
      discount = 0.0,
      advanceAdjustmentRequested = 0.0,
      amountPaidNow = 0.0,
      paymentMethod = PaymentMethod.CASH.code,
      status = JobStatus.COMPLETED.code,
      rotavatorWidth = "",
      workingDepth = "",
      numberOfPasses = null,
      startTime = "",
      finishTime = "",
      operatorName = "",
      notes = "",
    ).getOrThrow()

    // Payment on Land B
    val payB = repo.recordPayment(
      customerId = c1.id,
      landId = landB.id,
      jobId = null,
      targetType = PaymentTargetType.LAND.code,
      paymentDate = System.currentTimeMillis(),
      amount = 1000.0,
      paymentMethod = PaymentMethod.NAGAD.code,
      notes = "আংশিক জমা",
    ).getOrThrow()

    assertEquals(2500.0, repo.computeLandBalanceNow(landA.id), 0.01)
    assertEquals(1400.0, repo.computeLandBalanceNow(landB.id), 0.01)

    val c1Summary = repo.getRecalculatedCustomerSummaryNow(c1.id)!!
    assertEquals(3900.0, c1Summary.totalOutstandingBalance, 0.01)
    assertEquals(600.0, c1Summary.remainingAdvance, 0.01) // 1000 - 400

    // Customer 2 has 0 balance (landC has no jobs)
    val c2Summary = repo.getRecalculatedCustomerSummaryNow(c2.id)!!
    assertEquals(0.0, c2Summary.totalOutstandingBalance, 0.01)

    // 5. Bulk Print Filters & Consolidated Total Verification
    val allSummaries = repo.getBulkCustomerSummariesNow(BulkPrintFilter())
    assertEquals(2, allSummaries.size)
    val consolidatedAll = BillingCalculator.computeBulkConsolidatedSummary(allSummaries)
    assertEquals(3900.0, consolidatedAll.totalOutstandingAmount, 0.01)

    val onlyDueSummaries = repo.getBulkCustomerSummariesNow(
      BulkPrintFilter(onlyWithOutstandingDues = true)
    )
    assertEquals(1, onlyDueSummaries.size)
    assertEquals(c1.id, onlyDueSummaries.first().customer.id)

    val selectedCustomerOnly = repo.getBulkCustomerSummariesNow(
      BulkPrintFilter(selectedCustomerIds = setOf(c2.id))
    )
    assertEquals(1, selectedCustomerOnly.size)

    // 6. Generate Real Multi-Page Bulk PDF, Individual Customer PDF, Individual Land PDF, Receipt PDF
    val strings = AppStrings.Bengali
    val bulkPdf = pdfGen.generateBulkAllCustomersPdf(allSummaries, consolidatedAll, strings).getOrThrow()
    assertTrue(bulkPdf.exists() && bulkPdf.length() > 20)
    assertTrue("Bulk PDF should have >= 3 pages (2 customers + consolidated summary)", lastPdfPageCount >= 3)

    val custPdf = pdfGen.generateCustomerStatementPdf(c1Summary, strings).getOrThrow()
    assertTrue(custPdf.exists() && custPdf.length() > 20)
    assertTrue(lastPdfPageCount >= 2)

    val landPair = repo.getRecalculatedLandSummaryNow(landA.id)!!
    val landPdf = pdfGen.generateLandStatementPdf(landPair.first, landPair.second, strings).getOrThrow()
    assertTrue(landPdf.exists() && landPdf.length() > 20)

    val receiptPdf = pdfGen.generatePaymentReceiptPdf(payB, c1.fullName, c1.mobileNumber, landB.landName, strings).getOrThrow()
    assertTrue(receiptPdf.exists() && receiptPdf.length() > 20)

    // 7. Generate Real Excel (.xlsx) Export
    val xlsxFile = ExcelExporter.exportStatementsWorkbook(context, allSummaries, consolidatedAll, strings).getOrThrow()
    assertTrue(xlsxFile.exists() && xlsxFile.length() > 500)
    ZipFile(xlsxFile).use { zip ->
      assertNotNull(zip.getEntry("xl/workbook.xml"))
      assertNotNull(zip.getEntry("xl/worksheets/sheet1.xml"))
    }

    // 8. Encrypted Backup & Validation & Restore (with safety backup)
    val (encFile, _) = backupRepo.createLocalBackupJson(encryptionPassphrase = "StrongPass123").getOrThrow()
    assertTrue(encFile.name.startsWith("AraafTractorKhata_Backup"))
    val rawEncText = encFile.readText()
    assertFalse("Encrypted backup should not expose plaintext customer name", rawEncText.contains("রহিম উদ্দিন"))

    val wrongPass = backupRepo.validateAndDecodeBackup(rawEncText, "WrongPass")
    assertTrue(wrongPass.isFailure)

    // Delete customer 1 -> Recycle Bin -> Restore from Recycle Bin
    repo.softDeleteCustomer(c1.id)
    assertEquals(1, repo.customersFlow.first().size)
    assertEquals(1, repo.deletedCustomersFlow.first().size)
    repo.restoreCustomer(c1.id)
    assertEquals(2, repo.customersFlow.first().size)
    assertEquals(3900.0, repo.getRecalculatedCustomerSummaryNow(c1.id)!!.totalOutstandingBalance, 0.01)

    // Restore from encrypted backup (creates safety backup automatically)
    val restoreSummary = backupRepo.restoreFromJsonString(rawEncText, "StrongPass123", mergePreventDuplicates = false).getOrThrow()
    assertEquals(2, restoreSummary.customersRestored)
    assertTrue(File(restoreSummary.safetyBackupPath).exists())
    assertEquals(3900.0, repo.getRecalculatedCustomerSummaryNow(c1.id)!!.totalOutstandingBalance, 0.01)

    // Verify DD-MM-YYYY date format
    val formatted = FormatUtils.formatDate(1767225600000L) // 01-01-2026 UTC+...
    assertTrue(formatted.matches(Regex("\\d{2}-\\d{2}-\\d{4}")))
  }

  @Test
  fun `room foreign keys enforce independent land-wise ledger ownership and restrict parent deletes`() = runTest {
    val now = System.currentTimeMillis()
    val c1 = repo.saveCustomer(null, "Customer One", "01711111111", "", "Village A", "", "", "", "", now).getOrThrow()
    val c2 = repo.saveCustomer(null, "Customer Two", "01722222222", "", "Village B", "", "", "", "", now).getOrThrow()
    val landOfC1 = repo.saveLand(null, c1.id, "C1 Land", "Village A", "", 30.0, LandUnit.DECIMAL.code, "", "", 250.0, "").getOrThrow()

    // Attempting to insert a ledger transaction mixing c2.id with c1's landId must fail FK constraint
    var mixedCustomerLandFailed = false
    try {
      db.ledgerTransactionDao().insert(
        LedgerTransactionEntity(
          id = "bad-txn-1",
          transactionCode = "TXN-99999",
          customerId = c2.id,
          landId = landOfC1.id,
          transactionDate = now,
          transactionType = TransactionType.WORK_CHARGE.code,
          debitAmount = 100.0,
          creditAmount = 0.0,
          description = "Cross-customer mix attempt",
          createdAt = now,
          updatedAt = now,
          deviceId = "test-device",
        )
      )
    } catch (_: SQLiteConstraintException) {
      mixedCustomerLandFailed = true
    }
    assertTrue("Composite FK (landId, customerId) must reject cross-customer transactions", mixedCustomerLandFailed)

    // Attempting to hard-delete land with existing opening-balance transaction must fail RESTRICT FK
    var restrictDeleteFailed = false
    try {
      db.landDao().hardDeleteById(landOfC1.id)
    } catch (_: SQLiteConstraintException) {
      restrictDeleteFailed = true
    }
    assertTrue("RESTRICT FK must protect land with existing ledger transactions", restrictDeleteFailed)
  }

  @Test
  fun `land edit revises first cultivation bill and keeps payments`() = runTest {
    val c = repo.saveCustomer(
      fullName = "টেস্ট কাস্টমার",
      mobileNumber = "01911000009",
      address = "",
      village = "সোনাপুর",
      unionName = "",
      upazila = "",
      district = "",
      notes = "",
      registrationDate = System.currentTimeMillis(),
    ).getOrThrow()

    // নতুন জমি: 10 কাঠা, 2 বার চাষ, রেট 100, আগের বকেয়া 300 => বিল 2000, মোট পাওনা 2300
    val land = repo.saveLand(
      customerId = c.id,
      landName = "টেস্ট জমি",
      village = "",
      locationDetails = "",
      sizeValue = 10.0,
      unit = LandUnit.KATHA.code,
      cropInfo = "",
      cultivationSeason = "",
      openingBalance = 300.0,
      notes = "",
      firstCultivationRatePerKatha = 100.0,
      firstCultivationCount = 2,
    ).getOrThrow()
    assertEquals(2300.0, repo.computeLandBalanceNow(land.id), 0.01)

    // 500 টাকা জমা
    repo.recordPayment(
      customerId = c.id, landId = land.id, jobId = null,
      targetType = PaymentTargetType.LAND.code,
      paymentDate = System.currentTimeMillis(), amount = 500.0,
      paymentMethod = PaymentMethod.CASH.code, notes = "",
    ).getOrThrow()
    assertEquals(1800.0, repo.computeLandBalanceNow(land.id), 0.01)

    // এডিট: চাষ 2 -> 1 বার => নতুন বিল 1000, বিল 1000 কমবে, জমার 500 অক্ষত
    repo.saveLand(
      id = land.id, customerId = c.id, landName = "টেস্ট জমি", village = "", locationDetails = "",
      sizeValue = 10.0, unit = LandUnit.KATHA.code, cropInfo = "", cultivationSeason = "",
      openingBalance = 300.0, notes = "",
      firstCultivationRatePerKatha = 100.0, firstCultivationCount = 1,
    ).getOrThrow()
    assertEquals(800.0, repo.computeLandBalanceNow(land.id), 0.01)

    val summary = repo.getRecalculatedLandSummaryNow(land.id)!!.second
    assertEquals(500.0, summary.payments, 0.01)
    assertEquals(1000.0, summary.workCharges, 0.01)
  }
}
