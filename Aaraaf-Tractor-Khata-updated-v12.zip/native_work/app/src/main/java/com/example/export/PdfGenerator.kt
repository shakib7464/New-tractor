package com.example.export

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextUtils
import android.text.TextPaint
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.PaymentEntity
import com.example.data.local.entity.TransactionType
import com.example.domain.billing.BillingCalculator
import com.example.domain.billing.FormatUtils
import com.example.domain.model.BulkConsolidatedSummary
import com.example.domain.model.CustomerFinancialSummary
import com.example.domain.model.LandFinancialSummary
import com.example.localization.AppStrings
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.coroutineContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

interface PdfPageHandle {
  val canvas: Canvas
}

interface PdfBackend {
  fun startPage(width: Int, height: Int, pageNumber: Int): PdfPageHandle
  fun finishPage(page: PdfPageHandle)
  fun writeTo(out: FileOutputStream)
  fun close()
}

class AndroidPdfDocumentBackend : PdfBackend {
  private val document = PdfDocument()

  private class PageWrapper(val page: PdfDocument.Page) : PdfPageHandle {
    override val canvas: Canvas get() = page.canvas
  }

  override fun startPage(width: Int, height: Int, pageNumber: Int): PdfPageHandle {
    val info = PdfDocument.PageInfo.Builder(width, height, pageNumber).create()
    return PageWrapper(document.startPage(info))
  }

  override fun finishPage(page: PdfPageHandle) {
    document.finishPage((page as PageWrapper).page)
  }

  override fun writeTo(out: FileOutputStream) {
    document.writeTo(out)
  }

  override fun close() {
    document.close()
  }
}

class PdfGenerator(
  private val context: Context,
  private val backendFactory: () -> PdfBackend = { AndroidPdfDocumentBackend() },
) {

  companion object {
    const val A4_WIDTH = 595
    const val A4_HEIGHT = 842
    const val MARGIN_X = 28f
    const val CONTENT_WIDTH = A4_WIDTH - MARGIN_X * 2
    const val TOP_Y = 30f
    const val BOTTOM_LIMIT = A4_HEIGHT - 36f
    // একজন কাস্টমারের কার্ড + টেবিল হেডার + অন্তত ২টি সারি একসাথে রাখার ন্যূনতম উচ্চতা
    const val CUSTOMER_MIN_BLOCK = 150f
  }

  private fun loadBengaliTypeface(): Typeface {
    return try {
      ResourcesCompat.getFont(context, R.font.noto_sans_bengali) ?: Typeface.DEFAULT
    } catch (_: Throwable) {
      Typeface.DEFAULT
    }
  }

  private inner class PdfWriter(
    private val document: PdfBackend,
    private val headerTitle: String,
    private val generatedAtText: String,
  ) {
    val regularTypeface: Typeface = loadBengaliTypeface()
    val boldTypeface: Typeface = Typeface.create(regularTypeface, Typeface.BOLD)

    val emeraldDark = Color.parseColor("#1B4332")
    val emeraldLight = Color.parseColor("#E8F5E9")
    val amberAccent = Color.parseColor("#D97706")
    val crimson = Color.parseColor("#B91C1C")
    val textDark = Color.parseColor("#111827")
    val textMuted = Color.parseColor("#4B5563")
    val borderLight = Color.parseColor("#D1D5DB")
    val rowAltBg = Color.parseColor("#F9FAFB")

    var pageNumber = 0
    var currentPage: PdfPageHandle? = null
    var canvas: Canvas? = null
    var y = TOP_Y
    /** বাল্ক স্টেটমেন্টের কাস্টমার পাতায় উপরের "Tractor Khata" ব্যানার দেখানো হবে কি না */
    var showBrandBar = true

    // পাতা ভাগ: প্রতি A4 তে সর্বোচ্চ ২ জন কাস্টমার (সমান দুই অর্ধেক)
    var pageContentTop = TOP_Y
    var slotsUsed = 0
    var pageExclusive = false

    fun startNewPage(subHeader: String? = null) {
      finishCurrentPage()
      pageNumber++
      val page = document.startPage(A4_WIDTH, A4_HEIGHT, pageNumber)
      currentPage = page
      canvas = page.canvas
      y = TOP_Y
      slotsUsed = 0
      pageExclusive = false
      drawTopBrandBar(subHeader)
      pageContentTop = y
    }

    fun finishCurrentPage() {
      val page = currentPage ?: return
      val c = page.canvas
      // Footer divider + page number + timestamp
      val linePaint = Paint().apply {
        color = borderLight
        strokeWidth = 0.8f
      }
      c.drawLine(MARGIN_X, A4_HEIGHT - 28f, A4_WIDTH - MARGIN_X, A4_HEIGHT - 28f, linePaint)

      val footerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = textMuted
        textSize = 8f
        typeface = regularTypeface
      }
      c.drawText("Tractor Khata  |  $generatedAtText", MARGIN_X, A4_HEIGHT - 15f, footerPaint)
      val pageStr = "পৃষ্ঠা / Page $pageNumber"
      val tw = footerPaint.measureText(pageStr)
      c.drawText(pageStr, A4_WIDTH - MARGIN_X - tw, A4_HEIGHT - 15f, footerPaint)
      document.finishPage(page)
      currentPage = null
      canvas = null
    }

    fun ensureSpace(neededHeight: Float, subHeader: String? = null) {
      if (currentPage == null || y + neededHeight > BOTTOM_LIMIT) {
        startNewPage(subHeader)
      }
    }

    private fun drawTopBrandBar(subHeader: String?) {
      if (!showBrandBar) return
      val c = canvas ?: return
      val barHeight = if (pageNumber == 1 || subHeader != null) 42f else 28f
      val bgPaint = Paint().apply { color = emeraldDark }
      c.drawRoundRect(RectF(MARGIN_X, y, A4_WIDTH - MARGIN_X, y + barHeight), 6f, 6f, bgPaint)

      val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 13f
        typeface = boldTypeface
      }
      c.drawText("Tractor Khata", MARGIN_X + 10f, y + 17f, titlePaint)

      val rightPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FDE68A")
        textSize = 9f
        typeface = regularTypeface
      }
      val hw = rightPaint.measureText(headerTitle)
      c.drawText(headerTitle, A4_WIDTH - MARGIN_X - 10f - hw, y + 17f, rightPaint)

      if (!subHeader.isNullOrBlank()) {
        val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
          color = Color.parseColor("#E5E7EB")
          textSize = 9f
          typeface = regularTypeface
        }
        c.drawText(subHeader, MARGIN_X + 10f, y + 33f, subPaint)
      } else if (pageNumber == 1) {
        val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
          color = Color.parseColor("#E5E7EB")
          textSize = 8.5f
          typeface = regularTypeface
        }
        c.drawText("তৈরির সময়: $generatedAtText", MARGIN_X + 10f, y + 33f, subPaint)
      }
      y += barHeight + 10f
    }

    fun drawSectionTitle(title: String, accentColor: Int = emeraldDark) {
      ensureSpace(24f)
      val c = canvas ?: return
      val barPaint = Paint().apply { color = accentColor }
      c.drawRect(MARGIN_X, y + 2f, MARGIN_X + 4f, y + 16f, barPaint)

      val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = accentColor
        textSize = 11f
        typeface = boldTypeface
      }
      c.drawText(title, MARGIN_X + 10f, y + 13f, tp)
      y += 20f
    }

    fun drawKeyValueBox(pairs: List<Pair<String, String>>, bgColor: Int = emeraldLight) {
      val lineCount = (pairs.size + 1) / 2
      val boxHeight = lineCount * 16f + 12f
      ensureSpace(boxHeight + 6f)
      val c = canvas ?: return
      val bgPaint = Paint().apply { color = bgColor }
      val borderPaint = Paint().apply {
        color = borderLight
        style = Paint.Style.STROKE
        strokeWidth = 0.8f
      }
      val rect = RectF(MARGIN_X, y, A4_WIDTH - MARGIN_X, y + boxHeight)
      c.drawRoundRect(rect, 5f, 5f, bgPaint)
      c.drawRoundRect(rect, 5f, 5f, borderPaint)

      val labelPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = textMuted
        textSize = 8.5f
        typeface = regularTypeface
      }
      val valPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = textDark
        textSize = 9f
        typeface = boldTypeface
      }

      val halfW = CONTENT_WIDTH / 2f
      var rowY = y + 15f
      pairs.chunked(2).forEach { row ->
        row.forEachIndexed { idx, (k, v) ->
          val x = MARGIN_X + 8f + idx * halfW
          val layout = buildStaticLayout("$k: ", labelPaint, (halfW - 14f).toInt())
          val valLayout = buildStaticLayout(v, valPaint, (halfW - 14f).toInt())
          val kWidth = labelPaint.measureText("$k: ").coerceAtMost(halfW * 0.5f)
          c.save()
          c.translate(x, rowY - 9f)
          layout.draw(c)
          c.restore()
          c.save()
          c.translate(x + kWidth + 2f, rowY - 9f)
          valLayout.draw(c)
          c.restore()
        }
        rowY += 16f
      }
      y += boxHeight + 8f
    }

    /** কার্ড + টেবিল + মোট বকেয়া বারের মোট উচ্চতা (আঁকার আগে মাপা) */
    fun measureCustomerBlock(
      cardPairCount: Int,
      headers: List<String>,
      colWeights: List<Float>,
      rows: List<List<String>>,
      rightAlignedCols: Set<Int>,
      boldCols: Set<Int>,
    ): Float {
      val cardH = 26f + ((cardPairCount + 1) / 2) * 15f + 10f + 8f
      val totalWeight = colWeights.sum()
      val colWidths = colWeights.map { (it / totalWeight) * CONTENT_WIDTH }
      val headerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 8.5f
        typeface = boldTypeface
      }
      val cellPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 8.5f
        typeface = regularTypeface
      }
      val boldPaint = TextPaint(cellPaint).apply { typeface = boldTypeface }
      fun h(text: String, paint: TextPaint, idx: Int): Int =
        buildStaticLayout(
          text,
          paint,
          (colWidths[idx] - 6f).toInt().coerceAtLeast(16),
          if (idx in rightAlignedCols) Layout.Alignment.ALIGN_OPPOSITE else Layout.Alignment.ALIGN_NORMAL,
        ).height
      val headerH = (headers.mapIndexed { i, t -> h(t, headerPaint, i) }.maxOrNull() ?: 12) + 8f
      var tableH = headerH
      rows.forEach { row ->
        tableH += (row.mapIndexed { i, t -> h(t, if (i in boldCols) boldPaint else cellPaint, i) }.maxOrNull() ?: 11) + 7f
      }
      tableH += 8f
      return cardH + tableH + 30f + 8f
    }

    /**
     * কাস্টমারের ব্লক কোথায় বসবে ঠিক করে:
     * - অর্ধেক পাতায় ধরলে → একই পাতার দ্বিতীয় অর্ধেকে (অথবা নতুন পাতার প্রথম অর্ধেকে)
     * - অর্ধেকের বেশি লাগলে → নিজের পুরো পাতা (প্রয়োজনে ২য় পাতাও), এরপর পরের জন নতুন পাতায়
     */
    fun beginCustomerBlock(blockHeight: Float) {
      val nominalTop = TOP_Y + 42f + 10f
      val halfCapacity = (BOTTOM_LIMIT - nominalTop) / 2f
      val fitsHalf = blockHeight <= halfCapacity
      if (fitsHalf && currentPage != null && slotsUsed == 1 && !pageExclusive) {
        val mid = pageContentTop + (BOTTOM_LIMIT - pageContentTop) / 2f
        val c = canvas
        if (c != null) {
          val sep = Paint().apply {
            color = borderLight
            strokeWidth = 0.8f
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(4f, 3f), 0f)
          }
          c.drawLine(MARGIN_X, mid - 4f, A4_WIDTH - MARGIN_X, mid - 4f, sep)
        }
        y = mid + 22f
        slotsUsed = 2
      } else {
        startNewPage(null)
        if (fitsHalf) {
          slotsUsed = 1
        } else {
          slotsUsed = 2
          pageExclusive = true
        }
      }
    }

    /** কাস্টমারের নাম টেবিলের ভিতরে (হেডার স্ট্রিপে), নিচে মূল তথ্য */
    fun drawCustomerCard(name: String, mobile: String, pairs: List<Pair<String, String>>) {
      val headerH = 26f
      val lineH = 15f
      val rowCount = (pairs.size + 1) / 2
      val bodyH = rowCount * lineH + 10f
      val c = canvas ?: return
      val left = MARGIN_X
      val right = A4_WIDTH - MARGIN_X
      val rect = RectF(left, y, right, y + headerH + bodyH)

      c.drawRoundRect(rect, 6f, 6f, Paint().apply { color = emeraldLight })
      c.save()
      c.clipRect(RectF(left, y, right, y + headerH))
      c.drawRoundRect(RectF(left, y, right, y + headerH + 10f), 6f, 6f, Paint().apply { color = emeraldDark })
      c.restore()
      c.drawRoundRect(
        rect, 6f, 6f,
        Paint().apply {
          color = emeraldDark
          style = Paint.Style.STROKE
          strokeWidth = 0.9f
        },
      )

      val mobilePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FDE68A")
        textSize = 9.5f
        typeface = regularTypeface
      }
      val mobileText = if (mobile.isBlank()) "" else mobile
      val mobileW = if (mobileText.isEmpty()) 0f else mobilePaint.measureText(mobileText)
      val namePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 13f
        typeface = boldTypeface
      }
      val nameAvail = (CONTENT_WIDTH - 20f - mobileW - 12f).coerceAtLeast(60f)
      val nameText = TextUtils.ellipsize(name, namePaint, nameAvail, TextUtils.TruncateAt.END).toString()
      c.drawText(nameText, left + 10f, y + 17.5f, namePaint)
      if (mobileText.isNotEmpty()) {
        c.drawText(mobileText, right - 10f - mobileW, y + 17f, mobilePaint)
      }

      val labelPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = textMuted
        textSize = 8.8f
        typeface = regularTypeface
      }
      val valPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = textDark
        textSize = 9.5f
        typeface = boldTypeface
      }
      val halfW = CONTENT_WIDTH / 2f
      var rowY = y + headerH + 14f
      pairs.chunked(2).forEach { row ->
        row.forEachIndexed { idx, (k, v) ->
          val x = left + 10f + idx * halfW
          val label = "$k: "
          val lw = labelPaint.measureText(label)
          c.drawText(label, x, rowY, labelPaint)
          val avail = (halfW - 20f - lw).coerceAtLeast(30f)
          val vText = TextUtils.ellipsize(v, valPaint, avail, TextUtils.TruncateAt.END).toString()
          c.drawText(vText, x + lw, rowY, valPaint)
        }
        rowY += lineH
      }
      y += headerH + bodyH + 8f
    }

    fun drawTable(
      headers: List<String>,
      colWeights: List<Float>,
      rows: List<List<String>>,
      rightAlignedCols: Set<Int> = emptySet(),
      subHeaderOnNewPage: String? = null,
      rowTextColor: (Int) -> Int? = { null },
      rowBgColor: (Int) -> Int? = { null },
      boldCols: Set<Int> = emptySet(),
    ) {
      val totalWeight = colWeights.sum()
      val colWidths = colWeights.map { (it / totalWeight) * CONTENT_WIDTH }

      val headerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 8.5f
        typeface = boldTypeface
      }
      val cellPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = textDark
        textSize = 8.5f
        typeface = regularTypeface
      }

      fun drawHeaderRow() {
        val layouts = headers.mapIndexed { idx, h ->
          buildStaticLayout(
            h,
            headerPaint,
            (colWidths[idx] - 6f).toInt().coerceAtLeast(16),
            if (idx in rightAlignedCols) Layout.Alignment.ALIGN_OPPOSITE else Layout.Alignment.ALIGN_NORMAL,
          )
        }
        val rowH = (layouts.maxOfOrNull { it.height } ?: 12) + 8f
        ensureSpace(rowH + 14f, subHeaderOnNewPage)
        val c = canvas ?: return
        c.drawRect(MARGIN_X, y, A4_WIDTH - MARGIN_X, y + rowH, Paint().apply { color = emeraldDark })
        var x = MARGIN_X
        layouts.forEachIndexed { idx, layout ->
          c.save()
          c.translate(x + 3f, y + 4f)
          layout.draw(c)
          c.restore()
          x += colWidths[idx]
        }
        y += rowH
      }

      drawHeaderRow()

      if (rows.isEmpty()) {
        ensureSpace(20f, subHeaderOnNewPage)
        val c = canvas ?: return
        c.drawRect(MARGIN_X, y, A4_WIDTH - MARGIN_X, y + 18f, Paint().apply { color = rowAltBg })
        c.drawText("— কোনো তথ্য নেই —", MARGIN_X + 8f, y + 12f, cellPaint)
        y += 22f
        return
      }

      val borderPaint = Paint().apply {
        color = borderLight
        strokeWidth = 0.5f
      }

      rows.forEachIndexed { rIdx, row ->
        val tint = rowTextColor(rIdx)
        val rowPaint = if (tint != null) TextPaint(cellPaint).apply { color = tint } else cellPaint
        val rowBoldPaint = TextPaint(rowPaint).apply { typeface = boldTypeface }
        val layouts = row.mapIndexed { idx, cell ->
          buildStaticLayout(
            cell,
            if (idx in boldCols) rowBoldPaint else rowPaint,
            (colWidths[idx] - 6f).toInt().coerceAtLeast(16),
            if (idx in rightAlignedCols) Layout.Alignment.ALIGN_OPPOSITE else Layout.Alignment.ALIGN_NORMAL,
          )
        }
        val rowH = (layouts.maxOfOrNull { it.height } ?: 11) + 7f
        if (y + rowH > BOTTOM_LIMIT) {
          startNewPage(subHeaderOnNewPage)
          drawHeaderRow()
        }
        val c = canvas ?: return@forEachIndexed
        val bg = rowBgColor(rIdx)
        if (bg != null) {
          c.drawRect(MARGIN_X, y, A4_WIDTH - MARGIN_X, y + rowH, Paint().apply { color = bg })
        } else if (rIdx % 2 == 1) {
          c.drawRect(MARGIN_X, y, A4_WIDTH - MARGIN_X, y + rowH, Paint().apply { color = rowAltBg })
        }
        var x = MARGIN_X
        layouts.forEachIndexed { idx, layout ->
          c.save()
          c.translate(x + 3f, y + 3.5f)
          layout.draw(c)
          c.restore()
          x += colWidths[idx]
        }
        c.drawLine(MARGIN_X, y + rowH, A4_WIDTH - MARGIN_X, y + rowH, borderPaint)
        y += rowH
      }
      y += 8f
    }

    fun drawHighlightTotalBar(label: String, value: String, colorInt: Int = crimson) {
      ensureSpace(28f)
      val c = canvas ?: return
      val rect = RectF(MARGIN_X, y, A4_WIDTH - MARGIN_X, y + 24f)
      c.drawRoundRect(rect, 5f, 5f, Paint().apply { color = colorInt })
      val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 10.5f
        typeface = boldTypeface
      }
      c.drawText(label, MARGIN_X + 10f, y + 16f, tp)
      val vw = tp.measureText(value)
      c.drawText(value, A4_WIDTH - MARGIN_X - 10f - vw, y + 16f, tp)
      y += 30f
    }

    private fun buildStaticLayout(
      text: String,
      paint: TextPaint,
      width: Int,
      alignment: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL,
    ): StaticLayout {
      return StaticLayout.Builder.obtain(text, 0, text.length, paint, width.coerceAtLeast(10))
        .setAlignment(alignment)
        .setLineSpacing(1.0f, 1.05f)
        .setIncludePad(false)
        .build()
    }
  }

  private fun pdfOutputFile(prefix: String): File {
    val dir = File(context.cacheDir, "pdfs").apply { mkdirs() }
    return File(dir, "${prefix}_${FormatUtils.formatTimestampForFile()}.pdf")
  }

  suspend fun generateBulkAllCustomersPdf(
    summaries: List<CustomerFinancialSummary>,
    consolidated: BulkConsolidatedSummary,
    strings: AppStrings,
    onProgress: (processed: Int, total: Int) -> Unit = { _, _ -> },
    headerTitle: String = "সকল কাস্টমারের সমন্বিত হিসাব",
    filePrefix: String = "AraafTractorKhata_AllCustomers_Statement",
  ): Result<File> = withContext(Dispatchers.IO) {
    runCatching {
      val doc = backendFactory()
      try {
        val nowStr = FormatUtils.formatDateTime(System.currentTimeMillis())
        val writer = PdfWriter(doc, headerTitle, nowStr)
        val total = summaries.size

      if (summaries.isEmpty()) {
        writer.startNewPage("খালি রিপোর্ট")
        writer.drawSectionTitle("নির্বাচিত ফিল্টারে কোনো কাস্টমার পাওয়া যায়নি")
      } else {
        writer.showBrandBar = false
        summaries.forEachIndexed { index, summary ->
          coroutineContext.ensureActive()
          onProgress(index, total)
          val c = summary.customer
          val subHeader = "${c.fullName}${if (c.mobileNumber.isBlank()) "" else " (${c.mobileNumber})"}"

          val cardPairs = listOf(
            "গ্রাম ও ঠিকানা" to listOf(c.village, c.unionName, c.upazila, c.address).filter { it.isNotBlank() }.joinToString(", ").ifBlank { "-" },
            "নিবন্ধিত জমি" to "${summary.lands.size} টি",
            "মোট কাজ ও চার্জ" to FormatUtils.formatTaka(summary.totalBilled),
          )

          // ২ নং টেবিল: কাজ + পেমেন্ট একসাথে, তারিখ অনুযায়ী, ডানে চলমান বাকি
          val landNameMap = summary.lands.associate { it.land.id to it.land.landName }
          val jobMap = summary.jobs.associateBy { it.id }
          val paymentMap = summary.payments.associateBy { it.id }

          fun qtyText(j: com.example.data.local.entity.AgriculturalJobEntity): String =
            if (j.areaUnit == com.example.data.local.entity.LandUnit.KATHA.code) {
              "${FormatUtils.formatNumber(j.landArea)} কাঠা × ${j.numberOfPasses ?: 1} = ${FormatUtils.formatNumber(j.landArea * (j.numberOfPasses ?: 1))} কাঠা @ ${FormatUtils.formatNumber(j.rate)}/কাঠা"
            } else {
              "${FormatUtils.formatNumber(j.landArea)} ${strings.unitLabel(j.areaUnit)} × ${j.numberOfPasses ?: 1} @ ${FormatUtils.formatNumber(j.rate)}"
            }

          data class LedgerLine(
            val date: Long,
            val order: Long,
            val land: String,
            val desc: String,
            val debit: Double,
            val credit: Double,
            val isPayment: Boolean,
          )

          val lines = mutableListOf<LedgerLine>()
          val jobTypes = setOf(
            TransactionType.WORK_CHARGE.code,
            TransactionType.ADDITIONAL_CHARGE.code,
            TransactionType.DISCOUNT.code,
          )
          val txns = summary.allTransactions
          // কাজ-সংক্রান্ত লেনদেন (বিল/অতিরিক্ত/ছাড়) এক কাজ = এক লাইন
          txns.filter { it.transactionType in jobTypes && it.jobId != null }
            .groupBy { it.jobId!! }
            .forEach { (jobId, group) ->
              val job = jobMap[jobId]
              val debit = group.sumOf { it.debitAmount }
              val credit = group.sumOf { it.creditAmount }
              val first = group.sortedWith(compareBy({ it.transactionDate }, { it.createdAt })).first()
              val desc = if (job != null) {
                buildString {
                  append(strings.workTypeLabel(job.workType, job.customWorkName))
                  append(" — ")
                  append(qtyText(job))
                  if (job.additionalCharges > 0.005) append(" (+${FormatUtils.formatNumber(job.additionalCharges)} অতিরিক্ত)")
                  if (job.discount > 0.005) append(" (-${FormatUtils.formatNumber(job.discount)} ছাড়)")
                }
              } else first.description
              lines += LedgerLine(
                first.transactionDate, first.createdAt,
                landNameMap[first.landId] ?: "-", desc,
                debit, credit, false,
              )
            }
          // বাকি সব লেনদেন আলাদা লাইন (পেমেন্ট, অগ্রিম সমন্বয়, পূর্বের বকেয়া ইত্যাদি)
          txns.filter { !(it.transactionType in jobTypes && it.jobId != null) }.forEach { t ->
            val isPay = t.transactionType == TransactionType.PAYMENT.code
            val pay = t.paymentId?.let { paymentMap[it] }
            val desc = if (isPay) {
              buildString {
                append("পেমেন্ট জমা")
                if (pay != null) append(" (${strings.paymentMethodLabel(pay.paymentMethod)})")
                val note = (pay?.notes ?: t.notes).ifBlank { "" }
                if (note.isNotBlank()) append(" — $note")
              }
            } else {
              val label = strings.transactionTypeLabel(t.transactionType)
              if (t.description.isBlank() || t.description == label) label else "$label — ${t.description}"
            }
            lines += LedgerLine(
              t.transactionDate, t.createdAt,
              landNameMap[t.landId] ?: "-", desc,
              t.debitAmount, t.creditAmount, isPay,
            )
          }
          lines.sortWith(compareBy({ it.date }, { it.order }))

          // কোনো তারিখ-সীমা ফিল্টার থাকলে আগের জের আলাদা লাইনে দেখানো হবে (যাতে মোট বকেয়া মিলে যায়)
          val netOfLines = lines.sumOf { it.debit - it.credit }
          val carry = BillingCalculator.roundCurrency(summary.totalOutstandingBalance - netOfLines)
          val tableRows = mutableListOf<List<String>>()
          val paymentRowIdx = mutableSetOf<Int>()
          var running = 0.0
          if (kotlin.math.abs(carry) > 0.005) {
            running = carry
            tableRows += listOf(
              "-", "-", "পূর্বের জের (আগের হিসাব)",
              if (carry > 0) FormatUtils.formatTaka(carry) else "-",
              if (carry < 0) FormatUtils.formatTaka(-carry) else "-",
              FormatUtils.formatTaka(running),
            )
          }
          lines.forEach { l ->
            running = BillingCalculator.roundCurrency(running + l.debit - l.credit)
            if (l.isPayment) paymentRowIdx += tableRows.size
            tableRows += listOf(
              FormatUtils.formatDate(l.date),
              l.land,
              l.desc,
              if (l.debit > 0.005) FormatUtils.formatTaka(l.debit) else "-",
              if (l.credit > 0.005) FormatUtils.formatTaka(l.credit) else "-",
              FormatUtils.formatTaka(running),
            )
          }

          val tableHeaders = listOf("তারিখ", "জমি", "বিবরণ (কাজ / পেমেন্ট)", "বিল", "জমা", "বাকি")
          val tableWeights = listOf(1.0f, 1.15f, 3.1f, 1.0f, 1.0f, 1.05f)
          val rightCols = setOf(3, 4, 5)
          val boldCols = setOf(5)

          // জায়গা ঠিক করা: অর্ধেক পাতা / পুরো পাতা
          writer.beginCustomerBlock(
            writer.measureCustomerBlock(
              cardPairCount = cardPairs.size,
              headers = tableHeaders,
              colWeights = tableWeights,
              rows = tableRows,
              rightAlignedCols = rightCols,
              boldCols = boldCols,
            ),
          )

          // ১ নং টেবিল: কাস্টমারের নাম ভিতরে + মূল তথ্য
          writer.drawCustomerCard(name = c.fullName, mobile = c.mobileNumber, pairs = cardPairs)

          writer.drawTable(
            headers = tableHeaders,
            colWeights = tableWeights,
            rows = tableRows,
            rightAlignedCols = rightCols,
            subHeaderOnNewPage = subHeader,
            rowTextColor = { i -> if (i in paymentRowIdx) android.graphics.Color.parseColor("#166534") else null },
            rowBgColor = { i -> if (i in paymentRowIdx) android.graphics.Color.parseColor("#ECFDF5") else null },
            boldCols = boldCols,
          )

          // মোট জমা: লাল "সর্বমোট বকেয়া" বারের ঠিক উপরের লাইনে, সবুজ রঙের বক্সে
          writer.drawHighlightTotalBar(
            label = "মোট জমা",
            value = FormatUtils.formatTaka(summary.totalPaid),
            colorInt = android.graphics.Color.parseColor("#15803D"),
          )
          writer.drawHighlightTotalBar(
            label = "${c.fullName} — সর্বমোট বকেয়া",
            value = FormatUtils.formatTaka(summary.totalOutstandingBalance),
            colorInt = if (summary.totalOutstandingBalance > 0.01) writer.crimson else writer.emeraldDark,
          )
        }
        onProgress(total, total)

        if (summaries.size > 1) {
          // Final Consolidated Summary Page
          writer.showBrandBar = true
          writer.startNewPage("চূড়ান্ত সমন্বিত সারসংক্ষেপ (Consolidated Summary)")
          writer.drawSectionTitle("সকল কাস্টমারের চূড়ান্ত হিসাব সারসংক্ষেপ", writer.amberAccent)
          writer.drawKeyValueBox(
            listOf(
              "মোট কাস্টমার সংখ্যা" to "${consolidated.totalCustomers} জন",
              "মোট নিবন্ধিত জমি" to "${consolidated.totalLands} টি",
              "মোট কৃষি কাজ" to "${consolidated.totalJobs} টি",
              "মোট বিল (কাজ + চার্জ - ছাড়)" to FormatUtils.formatTaka(consolidated.totalBilledAmount),
              "মোট অতিরিক্ত চার্জ" to FormatUtils.formatTaka(consolidated.totalAdditionalCharges),
              "মোট ডিসকাউন্ট / ছাড়" to FormatUtils.formatTaka(consolidated.totalDiscounts),
              "মোট জমা" to FormatUtils.formatTaka(consolidated.totalPaymentsCollected),
              "মোট অগ্রিম গ্রহণ" to FormatUtils.formatTaka(consolidated.totalAdvancesReceived),
              "মোট অগ্রিম সমন্বয়" to FormatUtils.formatTaka(consolidated.totalAdvanceAdjustments),
              "সর্বমোট বকেয়া (সকল কাস্টমার)" to FormatUtils.formatTaka(consolidated.totalOutstandingAmount),
            )
          )

          writer.drawSectionTitle("কাস্টমার-ভিত্তিক বকেয়া তালিকা")
          writer.drawTable(
            headers = listOf("ক্রমিক", "কাস্টমার", "মোবাইল", "মোট বিল", "মোট জমা", "বর্তমান বকেয়া", "মন্তব্য"),
            colWeights = listOf(0.55f, 1.7f, 1.3f, 1.15f, 1.15f, 1.25f, 1.095f),
            rows = summaries.mapIndexed { idx, s ->
              listOf(
                "${idx + 1}",
                s.customer.fullName,
                s.customer.mobileNumber,
                FormatUtils.formatTaka(s.totalBilled),
                FormatUtils.formatTaka(s.totalPaid),
                FormatUtils.formatTaka(s.totalOutstandingBalance),
                "",
              )
            },
            rightAlignedCols = setOf(3, 4, 5),
            subHeaderOnNewPage = "চূড়ান্ত সারসংক্ষেপ",
          )

          writer.drawHighlightTotalBar(
            label = "সর্বমোট বকেয়া (Verified Consolidated Total)",
            value = FormatUtils.formatTaka(consolidated.totalOutstandingAmount),
            colorInt = writer.emeraldDark,
          )
        }
      }

        writer.finishCurrentPage()
        val outFile = pdfOutputFile(filePrefix)
        FileOutputStream(outFile).use { doc.writeTo(it) }
        outFile
      } finally {
        doc.close()
      }
    }
  }

  suspend fun generateCustomerStatementPdf(
    summary: CustomerFinancialSummary,
    strings: AppStrings,
  ): Result<File> {
    val consolidated = BillingCalculator.computeBulkConsolidatedSummary(listOf(summary))
    return generateBulkAllCustomersPdf(
      summaries = listOf(summary),
      consolidated = consolidated,
      strings = strings,
      headerTitle = "কাস্টমার হিসাব বিবরণী",
      filePrefix = "AraafTractorKhata_Customer_Statement",
    )
  }

  suspend fun generateLandStatementPdf(
    customer: CustomerEntity,
    landSummary: LandFinancialSummary,
    strings: AppStrings,
  ): Result<File> = withContext(Dispatchers.IO) {
    runCatching {
      val doc = backendFactory()
      try {
        val nowStr = FormatUtils.formatDateTime(System.currentTimeMillis())
        val writer = PdfWriter(doc, "জমির আর্থিক বিবরণী", nowStr)
      val land = landSummary.land
      writer.startNewPage("${customer.fullName} • ${land.landName}")

      writer.drawSectionTitle("${land.landName} (${land.landCode})")
      writer.drawKeyValueBox(
        listOf(
          "মালিক / কাস্টমার" to "${customer.fullName}${if (customer.mobileNumber.isBlank()) "" else " (${customer.mobileNumber})"}",
          "জমির পরিমাণ" to "${FormatUtils.formatNumber(land.sizeValue)} ${strings.unitLabel(land.unit)}",
          "পূর্বের বকেয়া" to FormatUtils.formatTaka(landSummary.openingBalance),
          "মোট চাষের বিল" to FormatUtils.formatTaka(landSummary.workCharges),
          "অতিরিক্ত চার্জ" to FormatUtils.formatTaka(landSummary.additionalCharges),
          "ডিসকাউন্ট" to FormatUtils.formatTaka(landSummary.discounts),
          "মোট পেমেন্ট" to FormatUtils.formatTaka(landSummary.payments),
          "অগ্রিম সমন্বয়" to FormatUtils.formatTaka(landSummary.advanceAdjustments),
        )
      )

      writer.drawSectionTitle("জমির খতিয়ান (Chronological Ledger)")
      var running = 0.0
      writer.drawTable(
        headers = listOf("তারিখ", "ধরন", "বিবরণ", "ডেবিট (চার্জ)", "ক্রেডিট (জমা)", "জের (Balance)"),
        colWeights = listOf(1.1f, 1.3f, 2.0f, 1.1f, 1.1f, 1.2f),
        rows = landSummary.transactions.map { txn ->
          running = BillingCalculator.roundCurrency(running + txn.debitAmount - txn.creditAmount)
          listOf(
            FormatUtils.formatDateTime(txn.transactionDate),
            strings.transactionTypeLabel(txn.transactionType),
            txn.description,
            if (txn.debitAmount > 0) FormatUtils.formatTaka(txn.debitAmount) else "-",
            if (txn.creditAmount > 0) FormatUtils.formatTaka(txn.creditAmount) else "-",
            FormatUtils.formatTaka(running),
          )
        },
        rightAlignedCols = setOf(3, 4, 5),
      )

      writer.drawHighlightTotalBar(
        label = "${land.landName} — বর্তমান বকেয়া",
        value = FormatUtils.formatTaka(landSummary.currentBalance),
        colorInt = if (landSummary.currentBalance > 0.01) writer.crimson else writer.emeraldDark,
      )

      writer.finishCurrentPage()
      val outFile = pdfOutputFile("AraafTractorKhata_Land_${land.landCode}")
      FileOutputStream(outFile).use { doc.writeTo(it) }
      outFile
      } finally {
        doc.close()
      }
    }
  }

  suspend fun generatePaymentReceiptPdf(
    payment: PaymentEntity,
    customerName: String,
    customerMobile: String,
    landName: String,
    strings: AppStrings,
  ): Result<File> = withContext(Dispatchers.IO) {
    runCatching {
      val doc = backendFactory()
      try {
        val nowStr = FormatUtils.formatDateTime(System.currentTimeMillis())
        val writer = PdfWriter(doc, "পেমেন্ট রসিদ (Receipt)", nowStr)
        writer.startNewPage("রসিদ নং: ${payment.receiptNumber}")

        writer.drawSectionTitle("পেমেন্ট মানি রসিদ — Tractor Khata")
        writer.drawKeyValueBox(
          listOf(
            "রসিদ নম্বর" to payment.receiptNumber,
            "পেমেন্ট তারিখ ও সময়" to FormatUtils.formatDateTime(payment.paymentDate),
            "কাস্টমারের নাম" to customerName,
            "মোবাইল নম্বর" to customerMobile,
            "জমির নাম" to landName,
            "পেমেন্ট মাধ্যম" to strings.paymentMethodLabel(payment.paymentMethod),
            "পূর্বের বকেয়া" to FormatUtils.formatTaka(payment.previousBalanceSnapshot),
            "পরিশোধিত টাকা" to FormatUtils.formatTaka(payment.amount),
            "অবশিষ্ট বকেয়া" to FormatUtils.formatTaka(payment.remainingBalanceSnapshot),
            "মন্তব্য" to payment.notes.ifBlank { "-" },
          )
        )

        writer.drawHighlightTotalBar(
          label = "গৃহীত টাকার পরিমাণ",
          value = FormatUtils.formatTaka(payment.amount),
          colorInt = writer.emeraldDark,
        )

        writer.finishCurrentPage()
        val outFile = pdfOutputFile("AraafTractorKhata_Receipt_${payment.receiptNumber}")
        FileOutputStream(outFile).use { doc.writeTo(it) }
        outFile
      } finally {
        doc.close()
      }
    }
  }
}
